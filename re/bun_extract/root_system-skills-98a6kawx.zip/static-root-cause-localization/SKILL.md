---
name: static-root-cause-localization
description: Only the bug-fix sub-agent can use this skill to perform fast, evidence-driven static root-cause localization based on issue analysis, reproduction evidence, and project knowledge. Use this skill when root-cause candidates should be identified through adaptive retrieval, preferring semantic search for behavior, mechanism, or interaction-pattern clues and falling back to module-scoped structural search when semantic retrieval is ineffective or concrete code anchors are available.
---
# Static Root Cause Localization

**Goal:**
Use issue analysis, reproduction evidence, and project knowledge to perform fast, evidence-driven static root cause localization.

The agent MUST first build a retrieval-oriented understanding of the defect from the canonical issue-analysis artifact, then choose an appropriate retrieval strategy based on the available evidence and repository context.

Preferred strategy:
- use CodeSemanticSearch tool when the defect is better expressed as a behavior, mechanism, or interaction pattern suitable for semantic retrieval;

Fallback strategy:
- use module-scoped structural retrieval (for example, grep/read within documented module directories) when semantic retrieval is ineffective, unstable, too broad, or when the issue already provides sufficiently concrete structural clues.

The agent MUST adapt the retrieval method to the problem, rather than forcing a single search mechanism in all cases.
All localization hypotheses MUST remain grounded in available evidence and retrieved code context.

## Inputs

* Issue analysis:
  `{{project_root_dir}}/.bugfix/{{issue_number}}/analysis_results.json`

* Reproduction artifacts:
  `{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/`

* Project knowledge, when needed:
  * `{{project_root_dir}}/codebase-structure.md`
  * `{{project_root_dir}}/codebase-docs/<MODULE_NAME>-structure.md`


## Procedure

### Step 1: Decide initial retrieval strategy (Mandatory)

Before retrieval, read:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/analysis_results.json
{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/
```

Use issue analysis together with reproduction artifacts to understand the defect and choose exactly one initial retrieval strategy:

* `semantic_search`
* `scoped_structural_search`

Choose `semantic_search` when:
- the defect is better described as a behavior, mechanism, or interaction pattern, and
- the CodeSemanticSearch tool is available.

Choose `scoped_structural_search` when:
- the issue or reproduction artifacts already provide concrete structural clues, or
- semantic retrieval is unlikely to be precise enough, or
- the CodeSemanticSearch tool is not available.

Persist to:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/localization/retrieval_context.json
```

```json
{
  "initial_retrieval_strategy": "semantic_search|scoped_structural_search",
  "reason": ""
}
```

Rules:

* `analysis_results.json` and reproduction artifacts are the primary inputs for this step.
* `possible_root_cause` is only a hint, not a confirmed conclusion.
* The selected strategy is provisional and MAY be changed later if retrieval is ineffective.


### Step 2: Run initial retrieval based on the selected strategy (Mandatory)

Read:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/localization/retrieval_context.json
```

Based on `initial_retrieval_strategy`, perform exactly one of the following:

#### A. semantic_search

Construct 2 to 4 English queries for CodeSemanticSearch based on issue analysis and reproduction artifacts.

Queries MUST describe likely code behavior, defect mechanism, or interaction pattern.
Queries SHOULD be phrased as natural-language descriptions of where or how the relevant logic may be implemented.
Do NOT use raw keywords, stack traces, or grep-style query strings.

Example query styles include:

- Functional localization
  - "Where do we handle user login and session management?"
  - "How is the payment processing flow implemented?"
  - "Where are API rate limits enforced?"

- Architecture understanding
  - "How are services registered and initialized?"
  - "What is the pattern used for dependency injection?"
  - "How does the error handling middleware work?"

- Debugging and investigation
  - "Where does the database connection get established?"
  - "What code runs when a webhook is received?"
  - "How are background jobs scheduled and executed?"

For defect localization, prefer queries that describe:
- the expected behavior that should hold,
- the faulty behavior observed during reproduction,
- the likely mechanism that could explain the mismatch,
- or the interaction path between the affected components.

Run CodeSemanticSearch with the constructed queries and collect the ranked results.

#### B. scoped_structural_search

Read:

```text
{{project_root_dir}}/codebase-structure.md
{{project_root_dir}}/codebase-docs/<MODULE_NAME>-structure.md
```

Select the most relevant module and implementation directories based on issue analysis and reproduction artifacts.

Then perform scoped structural retrieval only within the selected scope using grep/read or equivalent structural search methods.

Persist to:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/localization/initial_retrieval.json
```

Rules:

* MUST follow the strategy selected in Step 1.
* Semantic queries MUST be written in English.
* Scoped structural retrieval MUST stay within the selected module and implementation directories.
* This step performs retrieval only; do NOT analyze root cause, refine queries, or switch strategy in this step.
* If this step is re-executed after query refinement or strategy switching, it MUST overwrite `initial_retrieval.json` with the latest retrieval results and record the revised strategy/query set used.

### Step 3: Analyze the current retrieval results and determine whether another retrieval round is needed (Mandatory)

Use the current retrieval results produced by the latest execution of Step 2 to perform static root-cause analysis.

When analyzing the retrieved code, focus on whether the code can explain the observed defect through concrete logic such as:

* validation
* branching
* state transformation
* exception handling
* return-value construction
* caller-callee interaction

The analysis MUST identify:

* the most likely defect-carrying files
* the most likely defect-carrying code ranges
* how the retrieved code could produce the observed actual behavior under the known trigger condition
* whether the defect is better explained by:
  * local implementation logic, or
  * context-dependent interaction logic

Then determine whether the current analysis result is satisfactory.

A result is satisfactory only if the current retrieval results are already sufficient to support bounded, evidence-based localization.

A result is not satisfactory if, for example:

* the retrieved code is too generic
* the retrieved code is weakly related to the observed defect
* the current candidates do not expose defect-carrying logic
* the current candidates are repetitive and do not improve localization
* the current analysis cannot bound a small set of plausible fault locations

If the result is not satisfactory, determine exactly one next action for the next retrieval execution:

* `refine_queries`
  - use when the current retrieval strategy is still appropriate, but the current queries are too broad, too weak, too generic, or insufficiently diagnostic;

* `switch_strategy`
  - use when the current retrieval strategy is likely inappropriate for the defect, and the alternative strategy is more suitable.

If `refine_queries` is selected, revise the query set using the current strategy.

If `switch_strategy` is selected, switch to the other strategy and construct a new query set using the Step 2 rules for that strategy.

Rules:

* This step only performs analysis on the current retrieval results and determines the next retrieval input.
* Do NOT run retrieval in this step.
* Do NOT describe how retrieval should be executed in this step.
* Root-cause analysis MUST be grounded in:
  * issue analysis,
  * reproduction artifacts,
  * and the current retrieval results.
* Do NOT rely on retrieval rank alone.
* Do NOT speculate beyond the retrieved code context and available evidence.
* If the next strategy is `semantic_search`, the revised queries MUST be written in English natural language.
* If the next strategy is `scoped_structural_search`, the revised queries MUST strictly follow the Step 2 anchor-selection constraints.
* `switch_strategy` MUST be explicitly justified by the weakness of the current results and the suitability of the alternative strategy.


---

### Step 4: Perform final static root-cause analysis using the final retrieval results (Mandatory)

Use the final retrieval results to perform the final round of static root-cause analysis.

The final retrieval results are:

* the latest retrieval results, if the retrieval-analysis step found them satisfactory; or
* the new retrieval results produced by re-executing the retrieval step with the revised strategy or query set determined by the retrieval-analysis step.

When analyzing the retrieved code, focus on whether the code can explain the observed defect through concrete logic such as:

* validation
* branching
* state transformation
* exception handling
* return-value construction
* caller-callee interaction

The final analysis MUST identify:

* the most likely defect-carrying files
* the most likely defect-carrying code ranges
* how the code could produce the observed actual behavior under the known trigger condition
* whether the defect is better explained by:
  * local implementation logic, or
  * context-dependent interaction logic

Select:

* Top 3 files
* Up to 5 ranges total

Persist the final retrieval and analysis result to:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/localization/final_retrieval.json
```

```json
{
  "strategy": "semantic_search|scoped_structural_search",
  "results": [],
  "final_top_localization": {
    "top_files": [],
    "top_ranges": []
  }
}
```

Rules:

* This step only performs final analysis using the final retrieval results.
* Do NOT run retrieval in this step.
* Do NOT describe how retrieval should be executed in this step.
* Final root-cause analysis MUST be grounded in:

  * issue analysis,
  * reproduction artifacts,
  * and the final retrieval results.
* Do NOT rely on retrieval rank alone.
* Do NOT treat semantically similar but behaviorally weak results as root-cause evidence.
* Do NOT speculate beyond the retrieved code context and available evidence.
* Root cause MUST describe shared faulty logic, not a single failing instance.



### Step 5: Produce Final Root Cause Localization Result
- Load localization schema:
  `<skill_root>/schema/root_cause_localization.schema.json`
- Write the final localization result to:
  `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/root_cause_localization.json`
- Determine localization status strictly as:
  - **confirmed**:
    - dynamic execution evidence exists,
    - and directly supports the identified faulty logic.
  - **plausible**:
    - localization is supported by consistent static evidence,
    - but dynamic validation is unavailable or failed.
  - **inconclusive**:
    - evidence is insufficient to bound a single faulty logic.

### Critical Constraints
- Root cause MUST describe shared faulty logic, not a single failing instance.
- Claims MUST be grounded in execution or static evidence.
- MUST NOT defer localization to seek additional context beyond available evidence.

### Output Validation (Mandatory)

Verify:

* `retrieval_context.json` exists and records the selected retrieval strategy.
* `initial_retrieval.json` exists and records the initial retrieval results.
* `final_retrieval.json` exists and contains `final_top_localization`.
* `root_cause_localization.json` exists and conforms to `<skill_root>/schema/root_cause_localization.schema.json`.
* `final_top_localization.top_files` is not empty unless localization status is `inconclusive`.
* `final_top_localization.top_ranges` is not empty unless localization status is `inconclusive`.


