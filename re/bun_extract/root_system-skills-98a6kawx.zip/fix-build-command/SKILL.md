---
name: fix-build-command
description: Only the bug-fix sub-agent can use this skill to validate and iteratively repair the build command documented in codebase-structure.md through lightweight, repository-native, configuration-aware checks. This skill supports Maven, Gradle, and Node.js projects.
---

# fix-build-command

Validate and repair the build command documented in `codebase-structure.md` without relying on full-project builds.

## Purpose

This skill is used to determine whether the build command recorded in `codebase-structure.md` is:

- correct,
- executable in the repository context,
- configuration-complete,
- and usable for future repository-specific execution.

If the documented command is incorrect or incomplete, this skill MUST iteratively repair it based on repository evidence and observed error output until a valid repository-specific command is obtained.

This skill MUST avoid validating correctness by compiling or building the entire project unless no cheaper validation path exists.

A command is considered valid only if there is direct evidence that the command itself succeeds in the intended repository context under a lightweight validation path.

Tool startup alone is NOT validation.

---

## Input Contract

Expected to know or determine:

- `project_root_dir`: absolute path to the repository root
- location of `codebase-structure.md`
- the currently documented build command in `codebase-structure.md`

If `codebase-structure.md` does not contain a build command, the skill MUST infer one from repository evidence and validate it using the workflow below.

---

## Output Contract

This skill MUST produce:

1. A corrected build command suitable for documentation and future reuse.
2. A validation verdict for the final candidate command:
    - `VALID`
    - `INVALID`
    - `INCONCLUSIVE`
3. A brief explanation of:
    - why the original command was wrong or incomplete,
    - which repository-local configuration or execution context was missing,
    - how the final command was validated,
    - why the final verdict is justified.
4. An updated `codebase-structure.md` if the command needed correction.

---

## Core Principles

- The documented build command MUST be treated as an initial candidate only, not as authoritative.
- MUST validate the documented command before accepting it.
- MUST prefer lightweight, configuration-aware, and scope-limited validation.
- MUST prefer repository-native wrappers, scripts, and local configuration files over global tool assumptions.
- MUST use concrete repository evidence and observed error messages to drive each refinement step.
- MUST NOT stop after the first validation failure.
- MUST NOT validate by building the entire repository unless no narrower validation path exists.
- MUST NOT treat tool startup, wrapper presence, or partial command execution as proof that the build command is usable.
- MUST NOT treat repository/plugin/dependency resolution failure as an acceptable or expected success condition.

---

## Critical Validation Rule

A build command is considered **validated** only if:

1. the command is executed in the correct repository context;
2. the command uses the correct wrapper / script / package manager / working directory / scope / config;
3. the chosen lightweight validation target completes successfully;
4. the success directly demonstrates that the command itself is usable in this repository.

The following do **NOT** count as successful validation:

- the tool binary exists;
- the wrapper file exists;
- the command starts running;
- the command is syntactically parseable;
- Maven/Gradle/npm/pnpm/yarn prints usage/help/version only;
- the command fails due to missing plugin, missing dependency, repository access failure, mirror failure, auth failure, or missing package;
- the command fails after partially starting and the agent concludes that the “basic command is executable”.

If the command fails for any repository-context reason, it MUST be treated as **not validated**.

The agent MUST NOT say or imply any of the following:

- “the basic command is executable, so the build command is usable”;
- “the failure is expected, therefore validation passed”;
- “plugin resolution failed, but the command itself is correct”;
- “Maven started successfully, so the command is valid”.

These are explicitly forbidden conclusions.

---

## Validation Verdict Rule

The final verdict for a candidate command MUST be one of:

### `VALID`
Use `VALID` only if the selected lightweight validation command succeeds and provides direct evidence that the build command is usable in the intended repository context.

### `INVALID`
Use `INVALID` if:
- the command fails due to wrong wrapper, wrong tool, wrong script, wrong working directory, wrong scope, missing config, missing profile, missing settings, missing workspace targeting, or any other command/context defect;
- the command fails due to plugin/dependency/repository/package resolution in a way that indicates the documented command is not currently usable in repository context.

### `INCONCLUSIVE`
Use `INCONCLUSIVE` only if:
- repository evidence is insufficient to determine the correct command, or
- environment limitations prevent meaningful validation even after repository-native correction attempts.

`INCONCLUSIVE` MUST NOT be used merely to avoid repairing a clearly broken command.

---

## Workflow

### Step 1: Load the Existing Build Command

- Read the build command currently documented in `codebase-structure.md`.
- Extract and record:
    - the build tool,
    - the working directory assumption,
    - any module / subproject / workspace scope,
    - any profile / config flags,
    - whether the command uses a repository-native wrapper or script.

If the documented command is missing, incomplete, or obviously generic, treat it as a weak candidate and continue with repository-driven reconstruction.

---

### Step 2: Detect the Repository Build Ecosystem

MUST determine which build system the repository actually uses.

#### Maven indicators
- `pom.xml`
- `mvnw` / `mvnw.cmd`
- `.mvn/`
- `settings.xml`

#### Gradle indicators
- `build.gradle`
- `build.gradle.kts`
- `settings.gradle`
- `settings.gradle.kts`
- `gradlew` / `gradlew.bat`
- `gradle.properties`

#### Node.js indicators
- `package.json`
- `package-lock.json`
- `npm-shrinkwrap.json`
- `yarn.lock`
- `pnpm-lock.yaml`
- `.npmrc`
- `.nvmrc`
- workspace definitions
- repository scripts defined in `package.json`

MUST prefer the repository’s actual native toolchain and entrypoint instead of reconstructing a generic command.

---

### Step 3: Select a Lightweight but Meaningful Validation Target

MUST choose the narrowest and cheapest validation path that still provides real evidence that the documented build command is usable in repository context.

Preferred validation approaches include:
- wrapper or script execution with repository-local config,
- config-file consumption checks,
- module-scoped / subproject-scoped / workspace-scoped validation,
- compile-only / check-only / validate-only / install-only validation,
- reduced-scope command execution that verifies invocation correctness in real project context,
- script execution that succeeds for the intended package/workspace/module.

MUST avoid:
- full-repo clean builds,
- full-repo package/build execution,
- full-repo test execution,
- any validation strategy whose primary cost comes from building the whole project.

The validation target MUST be meaningful.
It MUST NOT be a tool-presence check only.

In particular, the agent MUST NOT conclude that a Maven build command is valid merely because:
- `mvn` or `mvnw` exists,
- Maven is installed,
- the wrapper script is present,
- the command can be parsed syntactically,
- Maven starts and then fails due to plugin or repository problems.

---

### Step 4: Execute Lightweight Validation

Run the selected candidate command in repository context using the narrowest valid scope.

The result MUST be interpreted strictly:

- If the validation command succeeds, the candidate may be considered validated.
- If the validation command fails, the candidate is NOT validated.

Failure due to any of the following MUST be treated as command/context failure requiring further analysis, not as partial success:

- plugin resolution failure,
- dependency resolution failure,
- repository or mirror access failure,
- auth failure,
- missing wrapper/config/profile/script/package/workspace scope,
- wrong working directory,
- wrong module/subproject/package target,
- unresolved symbols caused by incorrect scope,
- missing resources required by the build tool.

The agent MUST NOT reinterpret such failures as evidence that the command is “basically usable”.

---

### Step 5: Refine Execution Context Only When Error Evidence Requires It

If validation fails, MUST first determine whether the failure is caused by missing repository-local execution context.

MUST first prefer repo-provided configuration before concluding dependency, environment, or tool installation problems.

Typical evidence includes:
- dependency resolution failures,
- repository or mirror resolution failures,
- missing wrapper usage,
- missing config-file usage,
- missing build profile,
- wrong package manager,
- wrong working directory,
- missing workspace / module / subproject scope,
- unresolved symbols caused by incorrect target scope,
- missing resources required by the build tool.

MUST modify the execution context ONLY when supported by observed error evidence.

---

### Step 6: Apply Configuration-Aware Repair Rules

If the command is wrong or incomplete, MUST search for repository-local configuration and repair the command minimally.

#### Maven repair rules

When the repository uses Maven, MUST check:

- whether `mvnw` / `mvnw.cmd` exists and should be preferred over `mvn`,
- whether a repository-local `settings.xml` exists and should be passed via `-s`,
- whether `.mvn/` provides wrapper or config context,
- whether a required profile is missing,
- whether the command should be validated on a narrower module scope,
- whether test-skipping or validate-only / compile-only validation is sufficient.

MUST prefer the smallest valid Maven command that preserves the repository’s intended workflow.

Examples of issues this step may fix:
- using `mvn` when `mvnw` exists,
- omitting `-s <settings.xml>`,
- omitting a required `-P ...`,
- validating from the wrong directory,
- using a full-repo goal where module-scoped validation is sufficient.

IMPORTANT:
A Maven command that fails because a required plugin cannot be resolved is NOT validated.
The agent MUST continue repairing or mark the command `INVALID` / `INCONCLUSIVE` according to evidence.
It MUST NOT conclude that “mvn validate is basically executable”.

---

#### Gradle repair rules

When the repository uses Gradle, MUST check:

- whether `gradlew` / `gradlew.bat` exists and should be preferred over `gradle`,
- whether `gradle.properties` or settings files imply required context,
- whether the documented command is missing the correct task,
- whether validation should be scoped to a subproject or narrower task,
- whether a lighter task can validate correctness without triggering a full build,
- whether the command assumes the wrong working directory.

MUST prefer the smallest valid Gradle command using the repository-native wrapper and the narrowest relevant task scope.

Examples of issues this step may fix:
- using `gradle` instead of `./gradlew`,
- invoking `build` when a lighter verification task is enough,
- missing subproject qualification,
- running from the wrong path,
- missing repository-local Gradle context.

---

#### Node.js repair rules

When the repository uses Node.js, MUST check:

- whether the correct package manager is `npm`, `yarn`, or `pnpm`,
- whether the package manager choice should follow the repository lockfile,
- whether `.npmrc`, workspace config, or repository scripts define required execution context,
- whether the documented command should invoke a script from `package.json` instead of a raw tool command,
- whether the command should run from the repo root or a specific workspace/package directory,
- whether the command should target a workspace/package rather than the whole monorepo,
- whether script naming differs from generic assumptions.

MUST prefer repository-defined scripts and the package manager implied by repository evidence.

Examples of issues this step may fix:
- using `npm` when `pnpm-lock.yaml` exists,
- invoking a generic build tool directly instead of `package.json` scripts,
- omitting workspace/package scoping,
- running from the wrong directory,
- ignoring `.npmrc` or workspace settings.

---

### Step 7: Iterative Repair

After each repair attempt, MUST re-run lightweight validation.

If validation still fails, MUST:
- inspect the latest error output,
- identify the next missing execution-context element,
- minimally revise the command,
- validate again.

MUST continue iterating until:
- a valid command is found, or
- the command is proven not currently usable, or
- the result is genuinely inconclusive.

MUST NOT stop after the first failure.

The agent MUST NOT stop with a “basically executable” conclusion.

---

### Step 8: Select the Final Command and Verdict

The final documented build command MUST:

- be executable in the repository context,
- use the repository-native toolchain and entrypoint,
- include necessary repository-local configuration,
- reflect the correct working directory and scope,
- avoid unnecessary full-project build cost,
- be minimal, stable, and reusable.

MUST prefer the most repository-aligned command, not merely the first command that partially works.

The agent MUST output one final verdict:

- `VALID`
- `INVALID`
- `INCONCLUSIVE`

A command that fails during lightweight validation MUST NOT receive `VALID`.

---

### Step 9: Update `codebase-structure.md`

If the original build command is incorrect or incomplete, the agent MUST update `codebase-structure.md` with the corrected command.

MUST also record a brief note including:
- why the original command failed,
- what repository-local config / wrapper / scope / script was missing,
- how the corrected command was validated,
- and why the final verdict is justified.

If no valid corrected command can be established, the note MUST say so explicitly.
The agent MUST NOT write or imply that the command is usable when validation failed.

---

## Additional Constraints

- MUST prefer repository-native wrappers over globally installed tools.
- MUST NOT assume global configuration if an equivalent repository-local configuration exists.
- MUST prefer minimal repair over unnecessary command reconstruction.
- MUST avoid full-project build/test/package execution unless no cheaper validation path is feasible.
- MUST use observed repository evidence and real error output to justify each refinement.
- MUST preserve the repository’s original build style whenever possible.
- MUST distinguish “tool can start” from “build command is validated”.
- MUST distinguish “environment failure” from “validation success”.

---

## Success Criteria

This skill succeeds only if the agent has:

1. verified that the documented build command is valid, or replaced it with a corrected one;
2. included any necessary repository-local configuration or wrapper/script usage;
3. validated the final command through a lightweight but successful repository-context check;
4. assigned a justified final verdict;
5. updated `codebase-structure.md` when correction was required.