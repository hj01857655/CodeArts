# Test Generation Guidelines

## 1. Global Generation Rules (Apply to ALL Types)

### 1. Generation Hierarchy & File Placement (CRITICAL)
* **Priority 1 (Reuse):** Directly reuse existing test methods/files if they perfectly match the requirement. This is mandatory for Type 1 and highly preferred for Type 2b. Do not generate new code.
  * *API_CALL Location:* Execute in-place.
  * *INPUT_ARTIFACT Location:* Copy to `workspace_dir`.
* **Priority 2 (Append):** Add new test methods to an appropriate existing test file.
  * *API_CALL Location (CRITICAL):* You MUST append DIRECTLY to the provided `reproduction_test_path` (which was generated in a previous phase). Do NOT copy it to `workspace_dir` first. You are strictly PROHIBITED from appending to the project's original, pre-existing test files.
  * *INPUT_ARTIFACT Location:* Copy a suitable existing test file into `workspace_dir` and append your new test method to the copy.
* **Priority 3 (Generate from Scratch):** Generate a brand new, standalone test file.
  * *API_CALL Location:* Generate directly inside the project's native test directory. You MUST ensure the new file/class name is unique and does not conflict with any existing tests. Do NOT generate in `workspace_dir` and move it.
  * *INPUT_ARTIFACT Location:* Generate strictly inside the `workspace_dir`.
* **Prohibition on Direct Project Mutation:** Across ALL paradigms, you are strictly prohibited from directly modifying the project's *original* native test files. The only test file you are allowed to mutate in-place is the `reproduction_test_path` provided to you.

### 2. Centralized Oracle Definition (CRITICAL)
* **No File Injection:** You are strictly PROHIBITED from injecting `// [Oracle]` or `// [Consistency]` header comments into the generated/appended test files.
* **The Generation Plan:** All expected behaviors, consistencies, and pass/fail oracles MUST be exclusively defined in the `test_generation_plan.json` file prior to code generation. This JSON acts as the single source of truth for the Agent during evaluation.

### 3. Logic Tabularization (Binding Rules)
| Test Case Type | Generation Preference | Verification Strategy | Logic |
| :--- |:----------------------| :--- | :--- |
| **Type 1 (Reproduction)** | **Always Reuse**      | **Absolute Oracle** | Fix Verification |
| **Type 2a (Variations)** | **Append > Generate** | **Absolute Oracle** | Fix Verification |
| **Type 2b (Compliance)** | **Reuse > Generate**  | **Differential Consistency** | Regression Prevention |
| **Type 3 (Edge Cases)** | **Append > Generate** | **Absolute Oracle** | Fix Verification |
| **Type 4 (Patch Adversarial)** | **Generate > Append** | **Absolute/Negative Oracle** | **Fix-Induced Vulnerability** |

### 4. Strict Target Language Consistency (CRITICAL)

* **Determine the Language ONCE:** Before generating any code, you must explicitly determine the **Target Test Language** (e.g., C, C++, Java, Python, Go).
    * **Source of Truth:**
        * Priority 1: The file extension of the provided `reproduction_test_path` (if available).
        * Priority 2: The code language used in the `reproduction_seed_snippet` within the Issue Analysis.
        * Priority 3: The file extensions mentioned in the issue description path (e.g., `src/foo.c` implies C).
* **Consistency Rule:** ALL generated test cases (Type 1, 2a, 2b, 3) MUST use this **exact same language**.
    * *Anti-Pattern:* Do NOT generate Java test cases just because the tool itself is written in Java (unless the tool tests Java code).
    * *Anti-Pattern:* Do NOT mix languages (e.g., 3 C files and 1 Python file) unless the issue explicitly involves multi-language interaction.
* **Extension Enforcement:** Ensure all generated files use the correct file extension corresponding to the determined language (e.g., `.c` or `.cpp` for C/C++, `.java` for Java).

### 5. Strict Internal Assertion Alignment (CRITICAL)

* **Post-Fix Assertion Mandate:** For all Fix Verification Tests (Type 1, Type 2a, and Type 3), any internal code assertions (e.g., `assert`, `assertEquals`, `EXPECT_TRUE`) MUST strictly evaluate and expect the **POST-FIX (corrected/intended)** behavior.
* **Prohibition:** You are strictly PROHIBITED from writing assertions that validate or expect the pre-fix (buggy) state. The test code logic must be designed to FAIL on the buggy version and PASS on the fixed version.

### 6. Zero-Compilation-Error Mandate & Common Mutation Pitfalls (CRITICAL)
* **Self-Contained Completeness:** Every generated test file MUST be fully self-contained, syntactically correct, and ready to compile and execute on the **FIRST attempt**. You are strictly penalized for relying on the execution loop to catch basic syntax or import errors.
* **MANDATORY Mutation Checklist (Avoid these common pitfalls):**
    1. **Missing Static & Standard Imports:** When you introduce new assertions, mock matchers, or utility classes during mutation, you MUST explicitly add the exact `import` or `import static` statements at the top of the file. Do not assume they are inherited from the seed snippet.
    2. **Mocking & Stubbing Mismatches:** If you mutate the input parameters of a test, you MUST strictly ensure that any corresponding mock setups or stubs within the test are updated to match the newly mutated inputs.
    3. **Scope & Context Loss:** When extracting or reusing snippets from an existing test, ensure all required base classes, test fixtures, and class-level variables are fully redefined, instantiated, or correctly inherited in your new standalone file. Do not reference undeclared variables.
    4. **Unhandled Exceptions:** If your mutation introduces code that throws new checked exceptions, you MUST update the test method signature to declare them or wrap them in a proper try-catch block.
    5. **Access Modifier Violations:** Do not attempt to directly access or invoke private/protected fields or methods unless your generated test file is placed in a context/package that explicitly allows it. strictly adhere to the expected method signatures and access modifiers.


## 2. Detailed Generation Strategy by Type

**Critical Handling Rule**: Always refer to the generation hierarchy (Reuse -> Append -> Generate) when deciding how to provision the test. Record the exact method-level location and expected oracle in `test_generation_plan.json`.

### Type 1: Existing Bug Reproduction Test Case (Core Case)
**Target:** The exact test case that reproduces the bug.

* **Action (Reuse):** You MUST reuse the provided `reproduction_test_path`. Identify the exact test method/file. Record its location in the `test_generation_plan.json`. Do NOT generate a new file, and do NOT modify its existing logic or assertions.

### Type 2a: Root Cause Variations (Logic Clones)
**Target:** Test cases relying on the exact same logic/mechanism as Type 1 but manifesting in different variations.

* **Action (Append preferred):** Locate the test file containing the Type 1 test. Copy it to `workspace_dir` (if not already copied). Append new variation test methods into this copied file. Record the new method locations and their absolute oracles in the plan.
* **Strategy Matrix for Variations:**
    * **Dimension 1 (Structure):** Loop variations, Conditional structures.
    * **Dimension 2 (Flow):** Early termination, Error/exception paths.
    * **Dimension 3 (Inputs):** Different data types, formats.

### Type 2b: Compliance Baselines (Control Group)
**Target:** Valid, correct usage patterns that the system MUST accept. Represents "Normal Usage" avoiding the bug trigger.

* **Action (Reuse preferred):** Scan existing test directories for valid usage patterns related to the context. If found, **Reuse** them directly by recording their exact method/file locations in the plan as Type 2b. If none are suitable, **Generate** or **Append** new baseline tests and record them.
* **Oracle:** Define the oracle in the plan as "Differential Consistency: Output should remain consistent between pre-fix and post-fix runs."

### Type 3: Edge Case Tests
**Target:** Complex boundary conditions applied to the EXACT SAME Primary Trigger Point as Type 1.

* **Action (Append preferred):** Same operational protocol as Type 2a. Prefer appending to the relevant existing test file, mutating only the necessary boundary conditions.
* **Mandatory Dimensional Pivot:** Must target an input dimension conceptually distinct from Type 1/2a (e.g., Data Magnitude, Structural Depth, Malformed payloads).

### Type 4: Patch Adversarial Tests (Fix-Induced Vulnerability)
**Target:** The newly added code blocks, branches, and state mutations introduced strictly by the `patch_path`.

* **Action (Generation preferred):** You MUST explicitly document your execution of these two steps in your output before generating code:
    * **Step 1 - Patch Analysis & Assumption Extraction:** First, explicitly describe the core *fix pattern*. Then, explicitly list at least two **hidden assumptions** the patch makes (e.g., "Assumes input length is always > 0," "Assumes specific data format"). Aggressively challenge these assumptions: What happens if we provide technically legal inputs that violate these specific assumptions?
    * **Step 2 - Multi-Dimensional Adversarial Generation (Mandatory Minimum):** Based on Step 1, you MUST generate a minimum of **THREE strictly distinct** adversarial tests. Taking a union approach, combine these to form a comprehensive suite. You must cover ALL of the following distinct attack vectors:
          * **Attack Vectors:**
              - **Bypass Attempt:** Craft inputs that superficially satisfy the new validation checks but bypass them to trigger the original vulnerable state downstream.
              - **Over-Restriction (False Positive Trigger):** Provide valid but extreme or "inverse pattern" inputs to verify if the patch is overly strict and breaks legitimate pre-existing functionality.
              - **Threshold & Boundary Exploitation (Anti-Laziness Mandate):** Identify any quantitative limits, data sizes, or loop bounds affected by the patch. You MUST engineer inputs that target the absolute mathematical boundaries (e.g., `Limit - 1`, `Limit`, `Limit + 1`). **Explicitly calculate and state the expected numerical outcome in your reasoning BEFORE generating this specific test.**

## 3. Generation Output Requirements & Constraints

1. **MANDATORY `test_generation_plan.json`:** Must be generated first, serving as the architectural blueprint and oracle dictionary. You must persist `test_generation_plan.json` at `workspace_dir/test_generation_plan.json`. And this JSON MUST confirm to `{{skill_root}}/schema/test_generation_plan.schema.json`.
2. **Target Granularity & Location Accuracy (CRITICAL):**
   - You must utilize the `target_granularity` field in your schema (choosing either "FILE" or "METHOD") to define the scope of the test execution.
   - If `target_granularity` is "METHOD", the `target_location` MUST use the precise format `FileName#methodName` (or equivalent framework syntax).
   - If `target_granularity` is "FILE" (highly preferred for Type 2b to run specific existing test files), the `target_location` MUST be exactly the specific file/class name. You are strictly PROHIBITED from using directory or package wildcards (e.g., `.**`, `*`) to include multiple files at once. You are also strictly PROHIBITED from hallucinating or inventing generic method names (like `testNormalFlow`) just to satisfy a method-level format when you intend to run a whole file.
3. **Produce a complete regression suite** covering Types 1, 2a, 2b, 3, and 4 via reuse, appending, or scratch generation.
4. **MANDATORY File Path Constraint:**
   - **INPUT_ARTIFACT:** ALL generated or modified test files MUST be placed strictly inside the `workspace_dir`.
   - **API_CALL:** Appended tests MUST reside in the existing `reproduction_test_path`. Newly generated tests MUST reside directly in the project's native test source tree (e.g., `src/test/`, `tests/`) with strictly unique names to avoid conflicts.

**Prohibited Actions:**
- Do NOT inject Oracle comments into the source code.
- Do NOT rewrite or generate a new Type 1 test. It must be reused.
- Do NOT directly modify original project files (always copy to `workspace_dir` before appending).