---
name: patch-generation
description: Only the bug-fix sub-agent can use this skill to generate, apply, validate, and iteratively refine a minimal generalizable patch based on root-cause localization results. Use this skill after root-cause localization to eliminate the localized defect, confirm the fix through rebuild and validation, and export an issue-scoped, no-commit, git-apply-compatible patch artifact.
---

# Patch Generation Skill

## Purpose
Generate and apply a **minimal, generalizable** fix patch that eliminates the localized root cause, then rebuild and validate to confirm effectiveness, and finally export an **issue-scoped, no-commit** patch artifact (`git apply` compatible).
This skill is designed for stage-constrained, evidence-driven defect resolution workflows.

## Input Contract
The caller MUST provide:

- `project_root_dir`: absolute path to the repository root
- `issue_number`: issue identifier used as the workspace key

## Critical Constraints

### Patch Scope and Strategy

* The patch MUST be minimal, generalizable, and directly attributable to the validated root cause.
* Each patch iteration MUST be evidence-driven and bounded. Unbounded trial-and-error is strictly prohibited.
* Avoid unrelated refactoring, formatting-only changes, broad restructuring, or speculative logic changes.
* MUST read and apply `<skill_root>/references/engineering-knowledge-reference.md` before designing or revising a patch strategy.

When the issue or reproducer leaves multiple valid behavioral interpretations open, the Agent MUST choose the repair direction using repository evidence and engineering principles, including:

* existing code behavior;
* nearby implementations;
* existing tests;
* API contracts;
* configuration semantics;
* caller expectations;
* repository conventions.

The Agent MUST NOT choose a repair direction solely because it satisfies the minimal reproducer if that direction conflicts with repository conventions, existing API usage, or engineering principles.

### Diagnostic Evidence and Instrumentation Hygiene

Before designing, implementing, or revising functional patch logic, the Agent MUST:

* read and apply `<skill_root>/references/diagnostic-evidence.md`;
* read saved reproduction-stage diagnostic evidence;
* ensure all `[BUGFIX_REPRO_TRACE]` instrumentation has been removed from `git diff`.

The Agent MUST NOT implement or revise functional patch logic while `[BUGFIX_REPRO_TRACE]` remains in `git diff`.

If patch-generation evidence is still insufficient, the Agent MUST collect patch-stage diagnostic evidence before revising functional logic.

Patch-stage diagnostic instrumentation MUST be removed before final patch export. After cleanup, final validation MUST be re-run.

### Validation

During validation, the Agent MUST execute reproduction-based validation first.

After reproduction-based validation passes, the Agent MUST execute as many directly related regression tests as practical using the repository-native test mechanism.

The Agent MUST NOT validate only the reproduction test when relevant existing regression tests are available.


## Workflow

### Step 1: **Load Canonical Root Cause Localization**

* Load the canonical localization result from the designated issue workspace path.
* Identify:

  * the faulty logic to be corrected,
  * the semantic condition that must hold after the fix,
  * the minimal code region where changes are required.

### Step 2: Design Minimal Patch Strategy

Before designing or revising the patch strategy, the Agent MUST read and apply:

`<skill_root>/references/engineering-knowledge-reference.md`

Design a minimal, generalizable fix that:

* directly addresses the validated root cause;
* preserves intended behavior under all valid preconditions;
* preserves existing API behavior, configuration semantics, compatibility expectations, and repository conventions unless the issue explicitly requires changing them;
* avoids new failure modes, including null-like returns, swallowed errors, weakened validation, data loss, resource leaks, or state inconsistency;
* does NOT special-case the reproduction test or enumerate finite concrete instances;
* does NOT introduce speculative logic changes unrelated to correcting the validated fault.

Prefer small, localized logic corrections over broad restructuring.

If multiple repair directions appear possible, choose the direction best supported by:

* the canonical issue analysis;
* the root-cause localization result;
* existing repository behavior;
* nearby implementation patterns;
* relevant tests;
* API contracts, configuration semantics, and compatibility expectations;
* repository conventions;
* the engineering principles from `engineering-knowledge-reference.md`.

The Agent MUST NOT choose a repair direction solely because it satisfies the reproducer if that direction conflicts with repository evidence, existing API usage, compatibility expectations, or engineering principles.



### Step 3: **Implement Primary Patch**

* Before implementing functional patch logic, MUST read and apply:

`{{skill_root}}/references/diagnostic-evidence.md`

* The Agent MUST read reproduction-stage diagnostic evidence from:

`{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/diagnostic_instrumentation.json`

* If trace output was observed, the Agent MUST also read:

`{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/diagnostic_observations.txt`

* After reading the saved evidence, the Agent MUST remove all `[BUGFIX_REPRO_TRACE]` instrumentation and verify through `git diff` that it no longer exists.

### Step 4: **Validate Primary Patch**

* Rebuild the project using the standard project build mechanism.

* Execute validation in the following order:

  1. original reproduction-based validation;
  2. at least one normal valid scenario for the affected functionality;
  3. directly related existing regression tests, as many as practical.

* During patch validation, MUST NOT overwrite any outputs or execution records produced during the earlier reproduction phase.

* Related regression tests include tests that directly or indirectly cover the modified class, method, API, component, semantic contract, edge case, caller, implementation, adapter, serializer/deserializer, validator, parser, or dependent behavior.

* Prefer repository-native targeted test commands over full-project execution when possible, for example:

  * Maven: `-Dtest=...` or module-scoped commands;
  * Gradle: `--tests ...` or module-scoped tasks;
  * Node.js: package-level or test-file-level commands;
  * Python: test-file-level or keyword-based pytest commands.

* The Agent MUST NOT stop after only the reproduction test if additional clearly relevant regression tests are available and practical to run.

* If some relevant regression tests are too expensive, unavailable, or blocked by environment limitations, run the most relevant subset and record which tests were skipped and why.

* If a test oracle is specified in test comments, the Agent MUST treat it as the expected oracle for validating execution results.

* The primary patch is valid only if:

  * the original defect symptom disappears;
  * the normal valid scenario still behaves correctly;
  * all executed related regression tests pass;
  * no new regression is observed.

* Determine whether the primary patch fixes the defect based only on observed validation results.

### Step 5: **Assess Semantic Impact Scope and Compatibility**

* Only after the primary patch has been validated as fixing the defect, determine whether the fix changes any externally observable semantic contract of the modified code, including but not limited to:

  * return-value meaning, nullability, default values, or value range,
  * method preconditions or postconditions,
  * exception behavior,
  * state transitions or side effects,
  * parent/child class behavioral consistency,
  * interface or override compatibility,
  * assumptions relied on by callers, implementers, or dependent code.

* If such semantic impact exists, the Agent MUST:

  * identify the affected scope of dependent code, including callers, overrides, implementations, inherited behavior, and related control-flow or state-dependent logic,
  * inspect whether code within that affected scope depends on the previous behavior, assumptions, or contract,
  * determine whether additional minimal compatibility-preserving changes are required to keep the system correct, safe, and semantically consistent after the fix.

* MUST NOT assume that the localized faulty code region is the only place requiring modification when the validated fix changes a broader semantic contract.

* If the fix would otherwise cause incompatible behavior, null-related failures, broken caller assumptions, inconsistent override behavior, invalid state propagation, or other semantic mismatches in the affected scope, the Agent MUST include the minimal additional changes necessary to preserve correctness and compatibility.

* Any such additional change MUST:

  * be directly justified by the validated impact of the primary fix,
  * remain minimal in scope,
  * and MUST NOT expand into unrelated refactoring, cleanup, or speculative hardening.


### Step 6: **Implement Minimal Compatibility Changes**

* If Step 5 identifies affected dependent code that must change to preserve correctness, compatibility, or semantic consistency, the Agent MUST modify that code accordingly and MUST NOT restrict the patch to the localized root-cause region alone.

* Modify only the code necessary within the affected dependent scope.

* Keep all such changes:

  * minimal,
  * readable,
  * clearly attributable to the validated semantic impact of the primary fix.

* The Agent MUST NOT modify code outside the validated faulty region and the affected dependent scope.

* If Step 5 identifies no affected dependent code requiring change, the Agent MUST NOT expand the patch scope.


### Step 7: **Validate Final Patch**
Validate the final patch using repository-native build and test mechanisms.

The Agent MUST:

* rebuild the project using the standard project build mechanism;
* execute reproduction-based validation first;
* validate the normal valid scenario;
* execute all available metamorphic variants, if present;
* execute the directly related regression tests identified in Step 4;
* execute additional regression tests for any affected dependent code modified after Step 4.

If affected dependent code was modified, validation MUST cover the impacted behavior or contract surface.

The Agent MUST make a best-effort attempt to maximize relevant regression coverage while keeping validation targeted and repository-native.

The Agent MUST NOT treat the final patch as validated if it only passes the reproduction test while clearly relevant existing regression tests were available but not executed.

If any relevant regression tests cannot be executed, the Agent MUST explicitly record:

* which tests were not executed;
* why they were not executed;
* whether final validation confidence is limited by the skipped tests.

Reuse the validation rules and correctness criteria defined in Step 4.

Determine final patch correctness only from observed validation results.

### Step 8: **Iterative Patch Refinement and Strategy Regeneration**
Before refinement, read `{{project_root_dir}}/.bugfix/bugfix-config.yaml` and set:

* `MAX_PATCH_ATTEMPTS_PER_STRATEGY` from `patch_generation_settings.patch_iteration_count`
* `MAX_PATCH_STRATEGIES` from `patch_generation_settings.strategy_switch_count`

If missing or invalid, use defaults:

* `MAX_PATCH_ATTEMPTS_PER_STRATEGY = 3`
* `MAX_PATCH_STRATEGIES = 3`

When patch validation fails, the Agent MUST first analyze the validation evidence before editing code.

If the failure cannot be fully explained by existing evidence, the Agent MUST collect additional runtime evidence through `<skill_root>/references/diagnostic-evidence.md` before revising functional logic.

The Agent MAY refine the current patch only when validation evidence still supports the same repair strategy. Repeated edits under the same root-cause interpretation and fix mechanism count as the same strategy.

If the current strategy reaches `MAX_PATCH_ATTEMPTS_PER_STRATEGY` without success, the Agent MUST:

1. stop refining the current strategy;
2. revert failed-strategy changes;
3. re-read upstream artifacts:

   * `{{project_root_dir}}/.bugfix/{{issue_number}}/analysis_results.json`
   * `{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/reproduction_result.json`
   * `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/root_cause_localization.json`
4. generate a materially different repair strategy.

A new strategy MUST differ in at least one substantial aspect, such as root-cause interpretation, semantic condition, code region, compatibility reasoning, implementation mechanism, or validation-failure explanation.

The Agent MUST attempt strategies sequentially and MUST NOT create parallel patch variants or branches.

### Step 9: **Termination Decision**

* If patch validation **succeeds within the allowed attempts and strategies**, and reproduction-based validation plus available directly related regression tests have passed:

  * preserve the final patched code and build outputs under the issue workspace;
  * proceed to downstream phases.

* If the current repair strategy fails after **MAX_PATCH_ATTEMPTS_PER_STRATEGY**, but fewer than **MAX_PATCH_STRATEGIES** strategies have been attempted:

  * do NOT terminate the workflow;
  * abandon the current failed strategy;
  * re-read all upstream canonical artifacts;
  * generate a new repair strategy according to Step 9;
  * restart patch generation from Step 2.

* If patch validation still fails after **MAX_PATCH_STRATEGIES** independent repair strategies:

  * conclude that the issue is **not repairable under the current evidence and constraints**;
  * explicitly record the failure reason for each attempted strategy;
  * stop the entire resolution workflow.

* The Agent MUST NOT export a failed, partially validated, diagnostic-only, or speculative patch as the final patch.


### Step 10: **Export Final Minimal Patch**

After successful final validation, export a no-commit patch containing only issue-related production-code changes.

#### 10.1 Pre-export cleanup gate

Before exporting, the Agent MUST inspect `git diff` and verify that the final diff excludes:

* test files or test-only changes;
* reproduction, validation, or regression-test artifacts;
* formatting-only or unrelated refactoring changes;
* environment, CI, build-script, dependency-mirror, or setup-only changes;
* temporary debugging code, print statements, logs, diagnostic instrumentation, probe-only comments, or validation-only branches.

The Agent MUST verify that all diagnostic instrumentation described in `<skill_root>/references/diagnostic-evidence.md` has been removed.

If any excluded change remains, the Agent MUST remove it, re-run final validation, and only then continue.

#### 10.2 Export patch

Generate the patch from the working tree diff without creating any Git commit.

The patch MUST include only relevant production file paths and MUST exclude test paths or test-like files such as `*Test.*`, `*Tests.*`, `test/**`, `tests/**`, `src/test/**`, or repository-specific equivalents.

Use:

```bash
git diff --binary --no-color --output="{{project_root_dir}}/.bugfix/{{issue_number}}/{{issue_number}}.patch" -- <relevant_production_file_paths>
```

Save the patch as:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/{{issue_number}}.patch
```

#### 10.3 Patch applicability check

Read `{{project_root_dir}}/.bugfix/bugfix-config.yaml` and load `patch_generation_settings.patch_apply_validation`.

If `patch_apply_validation` is `true`, run:

```bash
git apply --check "{{project_root_dir}}/.bugfix/{{issue_number}}/{{issue_number}}.patch"
```

If the check fails, repair the patch export and re-run the check until it passes, without adding test files, debug code, or unrelated changes.

#### 10.4 Commit message

Write a short Chinese explanation, no more than 50 words, describing what was fixed and why, to:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/commit_message.txt
```