# Engineering Knowledge Reference

This document defines common software engineering principles that MUST be considered when designing a repair strategy.

These principles do NOT override:

- issue requirements,
- repository behavior,
- existing tests,
- documented contracts.

They are intended to guide repair decisions when multiple repair directions appear possible.

---

## 1. Contract Preservation

Prefer preserving existing contracts.

A repair SHOULD preserve:

- API behavior,
- configuration semantics,
- documented behavior,
- compatibility expectations,
- caller expectations,
- existing invariants.

Do NOT change a contract unless the issue explicitly requires it.

---

## 2. Existing Behavior First

When the issue indicates that an existing behavior is no longer respected:

- restore the intended behavior;
- do not introduce a new interpretation merely because it satisfies the reproducer.

Favor behavior continuity over behavioral redesign.

---

## 3. Principle of Least Surprise

Prefer behavior that is most consistent with:

- nearby code,
- adjacent APIs,
- existing tests,
- repository conventions,
- normal developer expectations.

Avoid introducing surprising special cases.

---

## 4. Generalize the Fix

Fix the shared faulty logic.

Do NOT:

- hard-code reproducer values;
- special-case only the reported example;
- enumerate finite failing instances.

Prefer repairing the underlying mechanism.

---

## 5. Nullability and Empty Values

Preserve existing nullability semantics.

As a general rule, methods that return arrays, collections, maps, iterables, strings, optional-like containers, or structured result objects SHOULD NOT return null-like values to represent an empty result.

Prefer the repository's existing empty-value conventions, such as:

- zero-length arrays;
- empty collections;
- empty maps;
- empty strings;
- empty iterables;
- standard empty constants or helper methods already used in the repository.

Do NOT introduce a new `null`, `None`, `nil`, or `undefined` return path unless:

- the existing contract explicitly requires it;
- existing callers clearly expect it;
- or the issue explicitly reports that a null-like value is the correct behavior.

Before choosing a null-like return value, the Agent MUST check nearby code, existing tests, documented behavior, and caller usage.

A repair MUST NOT satisfy the reproducer by normalizing behavior to a null-like value if an empty value would preserve caller safety and repository conventions.

---

## 6. Error Handling

Fix root causes instead of suppressing symptoms.

Do NOT:

- swallow exceptions;
- silently ignore failures;
- replace meaningful failures with silent success;
- remove validation solely to satisfy a test.

Error behavior should remain consistent with surrounding code.

---

## 7. Validation and Safety

Do not weaken correctness checks merely to make execution succeed.

A repair SHOULD preserve:

- validation logic,
- security checks,
- consistency checks,
- state checks,
- resource checks.

Unless the issue demonstrates that the validation itself is incorrect.

---

## 8. State Consistency

Preserve valid state transitions.

Avoid repairs that:

- partially update state;
- leave related fields inconsistent;
- skip required initialization;
- skip required cleanup.

---

## 9. Data Integrity

Do not discard information unnecessarily.

Avoid:

- silent truncation;
- silent data loss;
- lossy conversions;
- replacing valid data with defaults.

Unless explicitly required by the issue.

---

## 10. Configuration Respect

If behavior is controlled by:

- configuration,
- feature flags,
- compatibility switches,
- runtime options,

the repair MUST preserve that control boundary.

Do not make configurable behavior unconditional.

---

## 11. Resource Management

Preserve resource lifecycle correctness.

Avoid introducing:

- leaks,
- double-closing,
- double-free,
- unreleased locks,
- unreleased handles,
- unreleased connections.

---

## 12. Concurrency Safety

Do not weaken existing concurrency guarantees.

Avoid introducing:

- races,
- deadlocks,
- visibility issues,
- inconsistent synchronization.

---

## 13. Repository Convention Priority

When the issue does not uniquely determine the correct behavior:

1. repository tests;
2. neighboring implementations;
3. documented behavior;
4. repository conventions;

take precedence over generic preferences.

---

## 14. Minimize Repair Scope

Prefer the smallest change that fully corrects the validated fault.

Do not modify unrelated modules, behaviors, or execution paths.

---

## 15. No New Failure Modes

A repair SHOULD NOT introduce new failure modes.

Before finalizing a patch, check whether the change can reasonably introduce:

- new exceptions,
- new null dereferences,
- new invalid states,
- new compatibility breaks,
- new resource problems,
- new concurrency hazards.

If so, reconsider the repair direction.