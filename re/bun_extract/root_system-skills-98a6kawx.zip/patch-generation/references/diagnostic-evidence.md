# Diagnostic Runtime Evidence Reference

## Purpose

Use diagnostic runtime evidence to avoid speculative patching.

This reference applies during patch generation whenever a patch decision depends on runtime values, branch decisions, selected code paths, state transitions, or exception-adjacent states.

## 1. Reuse reproduction-stage diagnostic evidence

Before implementing or revising functional patch logic, check whether these files exist:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/diagnostic_instrumentation.json
{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/diagnostic_observations.txt
```

If `diagnostic_instrumentation.json` exists, read it first.

If reproduction-stage traces were injected, use the recorded runtime values, branch decisions, selected implementations, state transitions, and exception-adjacent states as patch evidence.

If reproduction-stage traces were not injected, read `no_instrumentation_reason` and determine whether existing evidence is sufficient for patch design.

Do not treat diagnostic observations as confirmed root cause. They are runtime evidence that must be interpreted together with source code, localization results, tests, and repository conventions.

## 2. Decide whether additional patch-stage diagnostics are required

Before changing functional logic, determine whether any issue-relevant runtime fact remains unknown.

Additional diagnostics are required when any of the following remains unclear:

* actual value of an issue-relevant variable, argument, field, return value, flag, enum, annotation, collection content, parser state, cache state, adapter, handler, or selected implementation;
* actual branch decision or selected code path;
* state before and after the suspected faulty logic;
* exception-adjacent internal state;
* whether the current patch strategy explains the reproduced failure.

If any required runtime fact remains unknown, collect diagnostic runtime evidence before modifying functional logic.

Do not implement or revise functional patch logic based only on source-code reading when issue-relevant runtime evidence remains unobserved.

## 3. Add or adjust temporary diagnostic instrumentation

Patch-stage diagnostic instrumentation may be added, moved, or adjusted only to observe issue-relevant runtime evidence.

Use prefix:

```text
[BUGFIX_PATCH_TRACE]
```

Instrumentation must be:

* minimal and issue-scoped;
* limited to the suspected faulty region or directly related caller/callee path;
* placed in project-owned source, test code, execution carrier, or generated reproduction carrier only when needed;
* free of semantic changes to assertions, control flow, timing, or production behavior;
* treated as temporary evidence, not as a fix.

If test/carrier-level traces cannot expose the required internal runtime evidence, instrument the narrowest issue-relevant project-owned source location.

Do not limit instrumentation to the reproduction test/carrier when the unresolved evidence exists only inside project-owned source code.

## 4. Execute and record patch-stage diagnostic evidence

After adding or changing diagnostic instrumentation, run the reproduction-based validation command.

Save observed patch-stage trace output to:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/patch/diagnostic_observations.txt
```

Save diagnostic locations and purpose to:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/patch/diagnostic_instrumentation.json
```

The record must distinguish location type:

```text
test_carrier | project_source | execution_carrier | generated_reproducer
```

If no diagnostic output appears, record the likely reason, such as:

* instrumented path not reached;
* stale build artifact;
* wrong module;
* suppressed output;
* missing rebuild;
* reproduction input no longer reaches the intended path.

## 5. Use diagnostic evidence before patching

Before implementing or revising functional logic, summarize:

* observed runtime evidence;
* what assumption it confirms or rejects;
* how it affects the patch strategy.

A patch strategy is credible only when it is supported by:

* reproduction evidence;
* localization evidence;
* diagnostic runtime evidence when required;
* source-code inspection;
* repository conventions and related tests.

## 6. Cleanup before final validation and export

Before final validation and final patch export, remove all diagnostic instrumentation introduced during reproduction, localization, or patch generation.

Inspect `git diff` and ensure the final production diff contains no diagnostic-only code, including:

* `[BUGFIX_REPRO_TRACE]`;
* `[BUGFIX_PATCH_TRACE]`;
* `System.out.println`;
* `System.err.println`;
* `print(...)`;
* `console.log`;
* `console.error`;
* temporary logger statements;
* debug assertions;
* temporary state-dumping code;
* probe-only comments;
* validation-only branches.

If any diagnostic instrumentation remains in `git diff`, remove it before final validation.

The exported patch must contain only the validated production-code fix and required compatibility-preserving production changes.


