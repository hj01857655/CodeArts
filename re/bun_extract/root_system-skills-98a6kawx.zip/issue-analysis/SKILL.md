---
name: issue-analysis
description: Only the bug-fix sub-agent can use this skill to parse a raw issue description into a canonical issue-analysis JSON and determine whether the issue information is sufficient to start the Bug Fix workflow.
---

# Issue Analysis

## Inputs (Mandatory)

- If `issue_description` is already explicitly provided, the skill MUST use it directly and MUST NOT attempt to load any issue file.

- If `issue description` is not provided but issue number is known, the skill MUST ask the user to provide a textual issue description. The skill MUST NOT attempt to download or query issue content from external systems.

- If the issue description provides only one or more paths to external log files, do NOT read any full log directly.

- The skill MUST fail explicitly if:
  - neither issue description nor issue number is provided;
  - issue number is known but the user cannot provide a textual issue description.


---

## Outputs (Mandatory)

- A canonical issue analysis JSON written to:
  `{{project_root_dir}}/.bugfix/{{issue_number}}/analysis_results.json`

This file MUST always be generated or overwritten as a whole.

---

## Purpose

Parse a raw issue description into a **canonical, structured issue analysis JSON**
that precisely captures:

- defect preconditions,
- expected behavior,
- actual behavior,
- possible root cause,
- reproduction-relevant code seed fragments,
- minimal reproduction steps,
- and issue-relevant log or trace evidence selected from directly provided content or from one or more external log files.

This JSON is the **only authoritative semantic source** for all subsequent phases.  
No assumptions beyond the issue description are allowed.

**Any issue-related repository code search or analysis is STRICTLY FORBIDDEN in this skill**.

In addition, this skill MUST determine whether the extracted issue information is sufficient to start the Bug Fix workflow.

---

## Critical Definition

* **`preconditions`**

  * The prerequisite conditions required to trigger the reported problematic behavior, including relevant **input characteristics**, **parameters**, **configuration settings**, **invocation context**, **version information**, and **environmental assumptions**.
  * Preconditions must be concrete, actionable, and reproducible.
  * Only conditions explicitly stated or directly demonstrated by the issue description may be treated as required defect-triggering preconditions.
  * Optional examples, variants, comparison cases, boundary cases, or speculative extensions MUST NOT be recorded as required preconditions unless the issue explicitly states that they are necessary to reproduce the reported behavior.
  * If a boundary, limit, size, value range, mode, type, configuration, or environment is not explicitly stated or directly demonstrated as relevant to the failure, it MUST NOT be invented or overgeneralized.

* **`expected_behavior`**

  * The behavior that users reasonably expect **under the stated preconditions**, based on documented functionality, common usage expectations, or the intent implied by the issue description.

* **`actual_behavior`**

  * The behavior that is **actually observed** when the reported input is exercised under the stated preconditions, including **missing, extra, incorrect, inconsistent, or unstable outcomes**.
  * You must pay particular attention to any **quantitative limits, thresholds, or boundary conditions** mentioned in the issue description, and treat them as key evidence for identifying the defect-triggering conditions.

* **Clarification on Behavior Semantics**

  * The terms `expected_behavior` and `actual_behavior` describe whether the **observed behavior or existing-behavior expectation** aligns with the behavior reasonably expected under the same conditions.
  * All reasoning must be grounded in observable behavior, existing API behavior, configuration semantics, documented behavior, compatibility expectations, previously working behavior, or information explicitly stated or clearly implied in the issue description.
  * Non-empty but vague descriptions are insufficient. The extracted behaviors must be **clear, concrete, distinguishable, and actionable** for downstream Bug Fix execution.
  * Generic statements such as “it fails”, “it is broken”, “not working”, “has a bug”, or expected behavior stated only as “it should work correctly” MUST be treated as insufficient.
  * Implementation details, suspected code locations, stack frames, method names, configuration keys, or proposed code changes MAY be retained as diagnostic clues, but MUST NOT replace `expected_behavior` or `actual_behavior` unless they clearly identify the existing behavior that is wrong.

* **Observed Symptom / Existing-Behavior Violation vs Diagnostic Clue**

  * The skill MUST distinguish between:
    - **observed symptoms**: concrete reported behavior such as wrong output, exception, failed assertion, wrong return value, incorrect state, missing update, unexpected side effect, timeout, incorrect response, or inconsistent behavior;
    - **existing-behavior violations**: cases where an existing API, configuration, documented behavior, compatibility expectation, or previously working behavior is reported as not being respected, even if the issue is described using implementation details;
    - **diagnostic clues**: information that may help localization or repair, such as stack frames, file names, class names, method names, component names, configuration keys, suspected code paths, logs, or proposed fixes.

  * `expected_behavior` and `actual_behavior` MUST describe either an observed symptom or an existing-behavior violation.
  * Diagnostic clues MUST NOT replace `expected_behavior` or `actual_behavior` unless they clearly identify the behavior that is wrong.
  * Diagnostic clues MAY be recorded in `possible_root_cause` only when explicitly stated or clearly implied by the issue description.
  * If the issue contains diagnostic clues and a concrete observed symptom or existing-behavior violation can be identified, the workflow MAY continue.
  * If the issue contains only implementation preferences, refactoring suggestions, optimization ideas, or proposed code changes, but no concrete observed symptom and no identifiable existing-behavior violation, the workflow MUST be marked `BLOCKED`.

* **`reproduction_seed_snippet`**

  * A high-fidelity issue-provided code fragment, or a set of related code fragments, that is directly relevant to reproducing the reported problematic behavior.
  * This field may contain classes, methods, functions, fields, constructors, type declarations, annotations, decorators, configuration-in-code, setup code, initialization code, invocation code, test snippets, assertions, or other code-level artifacts tied to the issue.
  * This field does not need to be executable or semantically complete by itself.
  * The purpose of this field is to preserve reproduction-relevant code from the issue description for downstream reproduction, not to synthesize a complete test.
  * Non-code observations, such as exception messages, error outputs, logs, expected outputs, or actual outputs, MUST NOT be copied into this field; they should be recorded in `actual_behavior`, `expected_behavior`, `log_excerpt`, or `log_evidence`.

* **`minimal_reproduction_steps`**

  * A minimal, ordered description of the steps required to trigger the reported problematic behavior.
  * These steps must be extracted only from information explicitly stated or clearly implied in the issue description.
  * The steps must be concrete enough to support downstream reproduction planning, but MUST NOT include guessed details.

* **`log_excerpt`**

  * The most issue-relevant short portion of any provided **log, error message, exception output, failure output, or stack trace**.
  * If the issue description directly includes log or trace content, extract and retain only the short portion most directly related to the reported issue.
  * If the issue description provides one or more paths to external log files, do NOT read any full log directly.
  * If multiple candidate excerpts exist across directly provided content or external logs, retain only the short portion most directly related to the reported issue.
  * The stored excerpt MUST preserve the original wording of the most relevant failure evidence as much as possible.
  * This field is intended to store the core failure evidence only, rather than the full surrounding context.
  * If no relevant log or trace information is present, leave this field empty.

* **`log_evidence`**

  * A larger issue-relevant log evidence window that preserves the local context surrounding `log_excerpt`.
  * This field is intended to retain important diagnostic information that may appear before or after the core failure evidence, such as triggering events, warnings, request context, state transitions, follow-up errors, or related diagnostic messages.
  * If the issue description directly includes log or trace content, `log_evidence` should retain the most relevant local evidence window rather than only the shortest failure excerpt.
  * If the issue description provides one or more paths to external log files, `log_evidence` must be derived only from the issue-relevant matched log range(s), not from any full raw log.
  * `log_evidence` must contain:
    - the selected evidence source log path,
    - the selected evidence line range,
    - the original log content of that evidence window,
    - and a brief summary explaining why that window is relevant to the reported issue.
  * The stored content MUST preserve the original wording of the raw log as much as possible.
  * If no relevant log or trace information is present, leave all nested fields empty.

* **`possible_root_cause`**

  * A possible cause, diagnostic clue, or author-provided hypothesis related to the reported issue, only when it is explicitly stated or clearly implied in the issue description.
  * This field MAY include explicitly mentioned classes, methods, files, components, configuration keys, stack frames, suspected paths, or proposed repair directions when the issue uses them to explain the problem.

---

## Workflow Readiness Judgment

This skill MUST determine whether the issue description is semantically suitable for starting the Bug Fix workflow.

The Bug Fix workflow is intended for defect issues, including:

- incorrect logic behavior;
- explicit exception/error failure;
- violation of an existing behavior expectation, such as an existing API behavior, configuration effect, documented behavior, compatibility expectation, or previously working behavior.

Readiness MUST be judged based on semantic sufficiency, not on whether the issue uses user-facing language or internal implementation language.

If an issue is described mainly through implementation details, suspected code paths, configuration keys, or proposed fixes, the skill MUST determine whether those details clearly indicate an existing behavior violation. If they do, the issue may still be treated as a defect candidate.

Missing reproduction material MUST NOT by itself change the issue type. If an issue appears to be a defect candidate but lacks sufficient reproduction information, the workflow MUST be marked `BLOCKED` due to insufficient reproduction information.

At least one of the following MUST be non-empty for the workflow to continue:

- `reproduction_seed_snippet`
- `minimal_reproduction_steps`

The skill MUST NOT invent code for `reproduction_seed_snippet`.

When no reproduction-relevant code is provided, `reproduction_seed_snippet` MUST be empty. If clear reproduction steps are provided, they MUST be recorded in `minimal_reproduction_steps`.

If the issue description contains error-like evidence, such as an error, exception, crash, stack trace, failed execution, timeout, compile error, or runtime error, `log_excerpt` MUST preserve the core failure evidence when such evidence is provided or resolvable.

The skill MUST prefer semantic sufficiency over unnecessary strictness, but MUST NOT allow the workflow to continue when the extracted issue semantics are vague, generic, non-actionable, or lack both reproduction code and reproduction steps.

---

## Workflow

### Step 1: Identify Preconditions for Reproducing the Defect (`preconditions`)

Extract the minimal and sufficient conditions required to trigger the reported behavior.

Include only issue-supported conditions, such as:

* input-related constraints, including data, parameters, values, size, boundary, type, value range, mode, or special case;
* invocation context, including API call, command, request, operation mode, update flow, or execution path;
* environment-related constraints, including version, configuration, platform, runtime, dependency, or compatibility assumptions.

When filling fields such as `size_or_boundary`, record only boundaries, limits, sizes, value ranges, modes, or special cases that are explicitly stated or directly demonstrated as relevant to the failure.

Do NOT include optional variants, comparison cases, speculative extensions, inferred boundary conditions, or general background conditions as required preconditions.

If information is missing, leave the corresponding field empty rather than guessing.


### Step 2: Identify Expected Behavior (`expected_behavior`)

Describe the system-level behavior the software is reasonably expected to exhibit under valid usage.

Infer expected behavior only from the issue description, explicitly referenced specifications or semantics, or clearly implied existing behavior expectations, such as existing API behavior, configuration effect, documented behavior, compatibility expectation, or previously working behavior.

Do NOT introduce unstated requirements, idealized behavior, or unsupported assumptions.

The extracted `expected_behavior` MUST be specific enough to describe what should happen instead.

Non-empty but vague expectations MUST be treated as insufficient for workflow continuation.

### Step 3: Identify Actual Behavior (`actual_behavior`)

Describe the reported incorrect behavior under the stated preconditions.

The extracted `actual_behavior` MUST describe either:

* a concrete observed symptom, such as incorrect output, exception, failed assertion, wrong state, missing behavior, or unexpected side effect; or
* a violation of an existing behavior expectation, such as existing API behavior, configuration effect, documented behavior, compatibility expectation, or previously working behavior not being respected.

If the issue is described through implementation clues, suspected code paths, method names, configuration keys, or proposed fixes, extract the implied behavior consequence. Do NOT use the implementation clue itself as the main actual behavior unless the issue explicitly defines that implementation pattern as the violated behavior.

The actual behavior MUST be logically consistent with the stated preconditions, clear, concrete, and actionable.

Non-empty but vague actual behavior MUST be treated as insufficient for workflow continuation.

### Step 4: Identify Possible Root Cause (`possible_root_cause`)
- If the issue description does not explicitly indicate any possible root cause, this field MUST be left empty. DO NOT INFER in this skill.
- The field MUST use cautious wording unless the issue explicitly proves the cause.
  - Prefer: "The issue suggests...", "The report points to...", "The author suspects..."
  - Avoid: "The root cause is..." unless the issue explicitly establishes it.
- This field MUST NOT replace `expected_behavior` or `actual_behavior`.

### Step 5: Identify Defect-Relevant Code Seed (`reproduction_seed_snippet`)

Extract only issue-provided code fragment(s) that are directly useful for reproducing the reported behavior.

Preserve reproduction-relevant code faithfully, including:

* target classes, methods, functions, fields, constructors, test snippets, or scripts;
* referenced helper types, interfaces, subclasses, enum values, annotations, decorators, signatures, or declarations needed to understand the snippet;
* setup, initialization, object construction, invocation code, assertions, or code-level expected/actual checks;
* complete reproduction cases when provided by the issue description.

Rules:

* The snippet does not need to be executable or complete, and may be assembled from multiple issue-provided reproduction-relevant fragments.
* Preserve original identifiers, literals, declarations, annotations, signatures, and relative code structure as much as possible. Do NOT invent, complete, normalize, refactor, or rewrite missing code.
* Do NOT reduce the snippet to only the shortest visible code block when additional issue-provided fragments are necessary or highly useful for reproduction.
* Do NOT omit a complete reproduction case merely because a later step may also persist it as an artifact.
* Do NOT copy non-code observations such as exception messages, logs, expected outputs, or actual outputs into this field; record them in the corresponding behavior or log fields.
* If no concrete reproduction-relevant code fragment is present, leave this field empty.

### Step 6: Identify Minimal Reproduction Steps (`minimal_reproduction_steps`)

Extract the minimal ordered behavior-level steps required to trigger the reported behavior.

The steps MUST:

* be grounded in the issue description;
* be concise and actionable;
* exercise an affected API, command, request, configuration, input, state, or user operation;
* include a concrete observation or verification point when the issue provides or clearly implies one;
* avoid guessed commands, parameters, setup details, or internal implementation paths not supported by the issue.

Generic observations such as "observe failure", "observe incorrect behavior", or "it does not work" are insufficient unless paired with a concrete expected-vs-actual observation.

Implementation clues MUST NOT be used as standalone reproduction steps. For example, "use the code path that calls method X" is insufficient unless the issue also provides a behavior-level operation, configuration, input, or test setup that reaches that path.

If no behavior-level reproduction steps can be extracted, leave this field empty.

### Step 7: Identify Issue-Relevant Log or Trace Evidence (`log_excerpt`, `log_evidence`)

If the issue description contains log output, error output, exception messages, failure output, or stack traces, extract:

* `log_excerpt`: the shortest core failure evidence most directly related to the reported issue;
* `log_evidence`: a larger local evidence window preserving the most relevant surrounding context.

If the issue description directly contains log or trace content, extract both fields from that provided content.

If the issue description provides only log file paths, or indicates that relevant evidence must be read from external log files:

* if the referenced content is a short log or compact stack trace, extract `log_excerpt` and `log_evidence` directly from that referenced content;
* if the referenced content is a large runtime log or service log, do NOT read the full log directly into the model;
* instead, READ `{{skill_root}}/references/log-parsing.md` and follow its requirements to:

  * retrieve issue-relevant matched line ranges for each provided log path first;
  * inspect only those matched ranges;
  * compare candidate evidence across returned ranges;
  * derive `log_excerpt` from the most relevant short failure portion;
  * derive `log_evidence` from a larger local window around the most relevant failure evidence.

For `log_evidence`, prefer a window that preserves useful issue context before or after the core failure evidence.

The selected `log_evidence` MUST include:

* the selected evidence source log path;
* the selected evidence line range;
* the original content of that evidence window;
* a brief summary explaining why this window is relevant to the reported issue.

Do NOT infer root cause from service call chain evidence.

If the issue mentions error-like failure semantics, such as error, exception, crash, stack trace, failed execution, timeout, compile error, or runtime error, but no relevant log or trace evidence is present or resolvable, leave `log_excerpt` and `log_evidence `empty and treat the evidence as insufficient for workflow continuation.

If no log or trace information exists and the issue does not imply such evidence is required, leave these fields empty.

### Step 8: Optional: Extract and Persist Reproduction Artifact(s)

Run this step ONLY IF the issue description contains either:

* a complete reproduction test/case, such as a full test method/class, runnable snippet, or command script;
* an error stack trace, meaning a multi-line stack with exception type and stack frames.

This step is only for additional artifact preservation. It MUST NOT replace Step 5.

If the issue contains reproduction-relevant code fragments, Step 5 MUST still preserve the key fragments in `reproduction_seed_snippet`, even if this step also persists a complete reproduction artifact.

If neither condition exists, skip this step without producing files.

Otherwise, READ `{{skill_root}}/references/extract-raw-artifacts.md` and follow its requirements to extract and persist the reproduction artifact.

### Step 9: Determine Workflow Readiness (Mandatory)

Determine whether the extracted issue information is sufficient to start the Bug Fix workflow.

Set `workflow_readiness.decision` to `PASS` only when ALL conditions below are satisfied:

* the issue is within the supported defect scope, namely:

  * incorrect logic behavior;
  * explicit exception, error, crash, timeout, compile failure, or runtime failure;
  * violation of existing API behavior, configuration behavior, documented behavior, compatibility expectation, or previously working behavior;
* `actual_behavior.description` is clear, concrete, actionable, and logically consistent with the stated preconditions;
* `expected_behavior.description` is clear, concrete, and describes what should happen instead;
* `actual_behavior` and `expected_behavior` are behaviorally distinguishable;
* the extracted behavior describes a concrete observed mismatch or concrete existing-behavior violation, not merely a preferred implementation difference, optimization idea, refactoring suggestion, suspected code pattern, or proposed code change;
* at least one of `reproduction_seed_snippet` and `minimal_reproduction_steps` is non-empty;
* if the issue provides reproduction-relevant code fragments, `reproduction_seed_snippet` preserves the key provided fragments without omitting code necessary or highly useful for downstream reproduction;
* if the issue contains or references error-like failure evidence, `log_excerpt` preserves the core failure evidence.

Set `workflow_readiness.decision` to `BLOCKED` when any PASS condition is not satisfied, including when:

* the issue is outside the supported defect scope;
* the extracted semantics are vague, generic, or non-actionable;
* expected behavior or actual behavior is missing, vague, or not behaviorally distinguishable;
* the issue provides only implementation preferences, optimization ideas, refactoring suggestions, suspected code patterns, or proposed changes without a concrete observed symptom or identifiable existing-behavior violation;
* both `reproduction_seed_snippet` and `minimal_reproduction_steps` are empty;
* required error/log evidence is missing or cannot be resolved.

If the readiness decision is `BLOCKED`, `workflow_readiness.missing_or_insufficient_information` MUST identify exactly what information is missing or insufficient, or explicitly state that the issue is outside the supported defect scope.

### Step 10: Persist Canonical Issue Analysis (Mandatory)

Assemble a single complete issue analysis JSON object strictly following the required output schema.

Write the JSON object to:

`{{project_root_dir}}/.bugfix/{{issue_number}}/analysis_results.json`

The write operation MUST:

* overwrite any existing file at the target path;
* include all required fields even when some values are empty strings;
* preserve the exact field names, structure, and nesting defined in the schema.


## Output Contract (Strict)
- Output MUST be a **single JSON object**.
- Field names, structure, and nesting MUST exactly match the required format.
- Do NOT add, remove, or rename any fields.

## Required Output Format

```json
{
  "preconditions": {
    "inputs": {
      "dataset_or_case": "",
      "size_or_boundary": "",
      "other": ""
    },
    "environments": {
      "version": "",
      "other": ""
    }
  },
  "expected_behavior": {
    "description": ""
  },
  "actual_behavior": {
    "description": ""
  },
  "possible_root_cause": "",
  "reproduction_seed_snippet": "",
  "minimal_reproduction_steps": "",
  "log_excerpt": "",
  "log_evidence": {
    "log_path": "",
    "start_line": "",
    "end_line": "",
    "summary": "",
    "content": ""
  },
  "workflow_readiness": {
    "decision": "PASS or BLOCKED",
    "missing_or_insufficient_information": ""
  }
}
```