# Extract and Persist Reproduction Artifact(s)

## Inputs

* Authoritative issue description text already loaded in this skill (from the issue description JSON or description content).

## Output directory (MUST ensure exists)

* `{{project_root_dir}}/.bugfix/{{issue_number}}/analysis/`

## Outputs (write only when detected)
1. If the output directory do not exist, create it first.

2. If a complete reproduction case is found, write:

* `{{project_root_dir}}/.bugfix/{{issue_number}}/analysis/repro_case.txt`

3. If a complete stacktrace is found, write:

* `{{project_root_dir}}/.bugfix/{{issue_number}}/analysis/error_stacktrace.txt`

### Detection rules (practical heuristics)

Treat as **complete stacktrace** if the description contains:

* an exception header line, e.g. contains `Exception`, `Error`, `Caused by:`, AND
* at least **3** stack frames like `at com.xxx...(...)`.

Treat as **complete reproduction case** if the description contains either:

* a fenced code block (`…`) that includes obvious runnable/test indicators (e.g., `@Test`, `public static void main`, `mvn test`, `gradle test`, `java -cp`, `curl`, `python`), OR
* a clearly delimited “Steps to reproduce” section with concrete commands and inputs.

### Minimality constraints

* **Do not edit or normalize** content; persist the extracted text **verbatim**.
* If multiple candidates exist, pick the **largest contiguous** block that satisfies the detection rules.
* Do not guess missing lines; if partial, **do not persist** as “complete”.

