# Log Parsing

Use this reference only when the issue does not directly include a short log or compact stack trace, and the relevant log content must be located from one or more external log file paths.

The purpose of this reference is to reduce one or more potentially large runtime logs into a small number of issue-relevant candidate line ranges, so that the agent can inspect only those ranges and extract useful evidence for downstream Bug Fix steps.

## Inputs

The caller MUST provide:

- `log_paths`
  - one or more absolute paths to target log files

- `keywords`
  - exactly 5 issue-derived retrieval keywords
  - these keywords MUST already be selected by the agent from the issue-analysis result
  - prefer specific and defect-relevant terms such as:
    - exception names,
    - error message fragments,
    - class names,
    - method names,
    - API names,
    - endpoint fragments,
    - module names,
    - command names,
    - or other defect-relevant identifiers

- `issue_number`
  - used to determine the canonical output path

- `project_root_dir`
  - used to determine the canonical output path

## Preconditions

Before parsing:

- Ensure every path in `log_paths` is an OS-native absolute path.
- Ensure each provided log path exists and is readable.
- Ensure exactly 5 usable keywords are provided.
- Do NOT load any full log into the model.
- Do NOT attempt semantic interpretation of the issue beyond the provided keywords.
- Treat this reference as a retrieval-and-inspection procedure, not as a standalone root-cause analysis procedure.

If all provided log paths are missing, unreadable, or the provided keywords are missing or invalid, return no matched ranges.

## Required Execution

When this reference is triggered, the agent MUST invoke the `retrieveLogRanges` tool instead of manually scanning raw logs.

### Canonical Tool Invocation

The agent MUST use the `retrieveLogRanges` tool for each log path in your target list. The tool will automatically aggregate the hit ranges and export them to the specified output JSON file.

Example tool parameters payload:
```json
{
  "logPath": "/absolute/path/to/target.log",
  "keywords": [
    "<keyword1>",
    "<keyword2>",
    "<keyword3>",
    "<keyword4>",
    "<keyword5>"
  ],
  "output": "/absolute/path/to/output_ranges.json"
}
```

## Canonical Output File

The aggregated retrieval result MUST be written to:

`{{project_root_dir}}/.bugfix/{{issue_number}}/analysis/log_ranges.json`

If the file already exists, it MUST be overwritten.

After the tool execution, the agent MUST read the generated JSON result and use only the returned matched line ranges for downstream inspection.

The agent MUST NOT read any full raw log directly into the model.

## Tool Purpose

the `retrieveLogRanges` tool is used only to retrieve issue-relevant log line ranges from large external log files.

It does NOT determine the final `log_excerpt`.
It does NOT determine the final `log_evidence`.
It only returns candidate line ranges for the agent to inspect.

## Output

Return a structured aggregated result containing:

* `keywords`
* `log_results`

Each item in `log_results` should contain:

* `log_path`
* `used_encoding`

  * the actual file encoding successfully used by the `retrieveLogRanges` tool when reading the log
* `matched_line_ranges`

Each matched range should include:

* `start_line`
* `end_line`
* `matched_keywords`

## Output Format

```json
{
  "keywords": [
    "NullPointerException",
    "serialize",
    "UserResponse",
    "/api/chat",
    "failed to serialize"
  ],
  "log_results": [
    {
      "log_path": "/absolute/path/to/server.log",
      "used_encoding": "utf-8",
      "matched_line_ranges": [
        {
          "start_line": 10420,
          "end_line": 10458,
          "matched_keywords": [
            "serialize",
            "UserResponse",
            "failed to serialize"
          ]
        }
      ]
    },
    {
      "log_path": "/absolute/path/to/app.log",
      "used_encoding": "utf-8",
      "matched_line_ranges": [
        {
          "start_line": 20881,
          "end_line": 20910,
          "matched_keywords": [
            "NullPointerException"
          ]
        }
      ]
    }
  ]
}
```

## Failure Handling

If no relevant matches are found in any provided log, return:

```json
{
  "keywords": [
    "...",
    "...",
    "...",
    "...",
    "..."
  ],
  "log_results": [
    {
      "log_path": "/absolute/path/to/server.log",
      "used_encoding": "utf-8",
      "matched_line_ranges": []
    },
    {
      "log_path": "/absolute/path/to/app.log",
      "used_encoding": "utf-8",
      "matched_line_ranges": []
    }
  ]
}
```

Do NOT fabricate line ranges.

## Agent Handling Rules

After the `retrieveLogRanges` tool finishes, the agent MUST inspect the generated JSON result and determine whether the retrieval result is usable.

A retrieval result is considered usable only if:

* at least one item in `log_results` has non-empty `matched_line_ranges`, and
* the returned ranges appear relevant to the reported issue based on the provided keywords and issue context.

If all `matched_line_ranges` are empty, or all returned ranges are clearly irrelevant or unreasonable, the agent MUST adjust the keywords and invoke the `retrieveLogRanges` tool again for all log paths before proceeding.

The agent MUST NOT read any full raw log directly into the model during this process.

## Follow-up Inspection

After a usable retrieval result is obtained, the agent MUST inspect only the log content covered by the returned `matched_line_ranges`.

The goal of this step is to identify the log content that is actually useful for downstream Bug Fix work.

This includes:

* the shortest core failure evidence for `log_excerpt`;
* a larger local evidence window for `log_evidence`;

### Inspection Rules

#### 1. Read only the returned matched ranges

The agent MUST read only the log segments covered by `matched_line_ranges` in `log_results`.

Rules:

* Do NOT read any full raw log file into the model.
* Do NOT inspect unrelated parts of any log file.
* Do NOT manually re-scan full logs after `log_ranges.json` has already been produced.
* Restrict inspection to the returned candidate line ranges only.

#### 2. Find the most valuable content inside each range

For each matched range in each log file, inspect the corresponding log content and identify the content most useful for understanding the reported issue.

Prefer content that captures one or more of the following:

* the failure symptom,
* the exception type,
* the key failing location,
* the most defect-relevant diagnostic message,
* request context,
* triggering events,
* warnings that explain the later failure,
* state transitions related to the issue,
* follow-up errors,
* or the clearest evidence that the observed behavior matches the issue description.

Important issue evidence may appear before, within, or after the most obvious error line.
The agent MUST NOT assume that only the explicit `ERROR` line is useful.

#### 3. Construct `log_excerpt`

`log_excerpt` should be the shortest core failure evidence most directly related to the reported issue.

Prefer a short continuous excerpt that already captures the key failure signal.

Do NOT include unnecessary surrounding noise in `log_excerpt`.

If multiple log files contain relevant evidence, prefer the single shortest and strongest issue-relevant excerpt across all matched ranges.

#### 4. Construct `log_evidence`

`log_evidence` should preserve a larger local evidence window around the most relevant failure evidence.

This evidence window should retain important surrounding context when such context is useful for downstream reasoning, especially when it appears before or after the core failure evidence.

For `log_evidence`, preserve the smallest local window that still contains the most relevant supporting context.

If multiple log files contain useful evidence, `log_evidence` SHOULD prefer the file and local range that provide the strongest downstream support.

The resulting `log_evidence` should support downstream steps such as:

* issue understanding,
* reproduction planning,
* later evidence review,
* and final Bug Fix reasoning.

#### 5. Prefer compact but informative evidence

Both `log_excerpt` and `log_evidence` should remain useful without becoming unnecessarily long.

Rules:

* For `log_excerpt`, prefer short and highly focused failure evidence.
* For `log_evidence`, prefer the smallest local window that still preserves necessary context.
* Do NOT retain unrelated INFO noise unless it is needed to understand the failure.
* Keep only the minimum surrounding context necessary for downstream reasoning.

#### 6. Preserve original wording

The selected log content MUST preserve the original wording of the raw log as much as possible.

Do NOT paraphrase, summarize, or normalize the log content before storing it in `log_excerpt` or `log_evidence.content`.

#### 7. Prioritize the most useful evidence across ranges

If multiple matched ranges across one or more log files are relevant, the agent SHOULD prioritize the one(s) that most directly support downstream Bug Fix work.

Prefer the range or excerpt that most clearly provides:

* a concrete failure signal,
* a recognizable exception or error type,
* a specific failing location,
* issue-relevant context before or after the failure,
* a stable symptom consistent with the issue description,
* or the strongest diagnostic evidence for subsequent analysis.

## Final Selection Goal

Any downstream `log_excerpt` and `log_evidence` must be derived only from the content found within the matched line ranges returned by `log_ranges.json`.

`log_excerpt` should capture the core short failure evidence.

`log_evidence` should preserve a larger local evidence window with the most relevant surrounding context.

The agent MUST NOT fabricate failure evidence.

If the matched ranges across all provided logs still do not contain sufficiently relevant issue evidence, the agent MUST leave `log_excerpt` empty and leave all nested fields in `log_evidence` empty.

## Constraints

* Do NOT read any full log into the model.
* Do NOT summarize all logs as a substitute for evidence extraction.
* Do NOT perform root-cause analysis solely from unrelated log regions.
* Do NOT infer new keywords during the same retrieval attempt.
* Do NOT output vague statements such as “likely around the middle of the file”.
* Always rely on explicit matched line ranges or an empty result.

## Usage Notes

This reference is most appropriate for:

* large service logs,
* runtime logs with timestamps,
* operational logs with repetitive INFO output,
* or issue flows where logs are provided only by file path.

This reference is unnecessary when the issue already includes:

* a short relevant log excerpt, or
* a compact stack trace that can be used directly.
