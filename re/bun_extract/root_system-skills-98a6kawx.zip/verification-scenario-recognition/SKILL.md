---
name: verification-scenario-recognition
description: Analyze the context of a task to determine the appropriate verification scenario.
---

# Scenario Recognition Skill

## Objective
Analyze the current development task, issue description, or code context to determine its primary verification scenario category. 

## Execution Steps
1. Delete `{{project_root_dir}}/.resultverify/verification_scenario.json` if this file exists.
2. Analyze the available task inputs to understand the nature of the software change.
3. Classify the scenario into exactly one of the following categories: "bug-fix", "new-feature", or "other".
4. Generate the classification result as a JSON file and save it to the specified output path.

## Mandatory Output Requirements
You MUST create a JSON file at the exact following path:
`{{project_root_dir}}/.resultverify/verification_scenario.json`
And the generated file MUST conform to: `{{skill_root}}/schema/verification_scenario.schema.json`