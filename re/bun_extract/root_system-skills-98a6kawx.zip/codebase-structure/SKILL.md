---
name: codebase-structure
description: "Only the bug-fix sub-agent can use this skill to analyze a project and generate or improve the codebase-structure.md required by the bug-fix workflow. Use this skill when a structured project overview is needed, including tech stack, directory structure, build/test commands, and key modules. Supports Java, TypeScript, JavaScript, Python, C, and C++. Do NOT use for general code documentation or README generation."
---

# Codebase Structure Document Generation

## Overview

Generates a `codebase-structure.md` (and optional sub-documents) that captures a project's tech stack, directory hierarchy, and verified dev commands. Supports Java, TypeScript, JavaScript, Python, C, and C++. The output is always documentation — never source code.

## Quick Reference

| Situation | Action |
|-----------|--------|
| Single module, primary source tree ≤ 40 lines when expanded | One file: `codebase-structure.md` |
| Single module, primary source tree > 40 lines when expanded | Main doc + `codebase-docs/[project]-src-structure.md` |
| Multi-module (≥ 3 modules) OR any module > 40 lines | Main doc + one sub-doc per oversized module |
| Existing `codebase-structure.md` found at `$ARGUMENTS` path | Improve in place, preserve existing accurate content |

---

## Step 0 — Detect Project Language

- **YOU MUST complete this step before any other step. YOU MUST NOT assume a language without checking the filesystem for the decisive files listed below.**

Before anything else, identify the project's primary language by checking for the presence of these files, in priority order. A project may have secondary languages (e.g., a Java backend with JS frontend); document both but designate one as primary.

| Language | Decisive Files |
|----------|---------------|
| **Java** | `pom.xml`, `build.gradle`, `build.gradle.kts` |
| **TypeScript** | `tsconfig.json` + `package.json` |
| **JavaScript** | `package.json` (no `tsconfig.json`), `.js` entry points |
| **Python** | `pyproject.toml`, `setup.py`, `setup.cfg`, `poetry.lock`, `Pipfile` |
| **C++** | `CMakeLists.txt` with `CXX`/`cpp`, `*.cpp`/`*.cc` files in `src/` |
| **C** | `CMakeLists.txt` with C only, `Makefile`, `*.c` files in `src/`, no `*.cpp` |

If multiple indicators exist (e.g., `package.json` + `tsconfig.json`), treat it as TypeScript. If a `Makefile` exists alongside a `CMakeLists.txt`, prefer CMake as the authoritative build system.

---

## Step 1 — Gather Project Facts

- **YOU MUST collect every fact listed below directly from project files before writing any output. YOU MUST NOT infer or fabricate version numbers, dependencies, or commands — mark any fact not found in project files as "unknown".**

Collect these facts per language **before writing anything**. Never infer — if a fact cannot be found in project files, mark it as unknown.

### Java

```
pom.xml / build.gradle        → exact Java version, framework/dependency versions
README.md / README.adoc       → build/test/run commands (highest priority)
Makefile / Taskfile           → secondary command source
.github/workflows/            → fallback command source
src/main/java/**              → full package tree (folders only, no .java files)
src/main/resources/           → resource types (do NOT expand sub-dirs)
src/test/java/                → test coverage scope
```

### TypeScript / JavaScript

```
package.json (root + all sub-packages)
                              → exact Node version (engines field), all dependencies,
                                 scripts block (primary command source for each package)
tsconfig.json                 → TS version, target/module/strict settings (TS only)
.nvmrc / .node-version        → Node version override
vite.config.* / webpack.config.* / next.config.* / nuxt.config.*
                              → bundler / framework version
jest.config.* / vitest.config.* → test framework
src/ or app/ or lib/          → full directory tree (folders only, no .ts/.js files)
tests/ or __tests__ or spec/  → test coverage scope
```

> **README 多路径扫描（TypeScript / JavaScript 专项）**
>
> TypeScript/JavaScript 项目的 README 文件可能分散在多个目录下。**YOU MUST** 按以下顺序逐一检查，并从所有找到的 README 中汇总开发命令，不得仅读取根目录 README：
>
> 1. 项目根目录：`README.md` / `README.adoc` / `README.rst`
> 2. 各子包 / workspace 根目录（如 `packages/*/README.md`、`apps/*/README.md`、`libs/*/README.md`）
> 3. 文档目录：`docs/README.md`、`docs/development.md`、`docs/getting-started.md`（以及同层任何含 "build"、"dev"、"start"、"run"、"deploy" 关键字的 Markdown 文件）
> 4. `.github/` 下的 `CONTRIBUTING.md`
>
> 读取每份 README 时，重点提取含以下关键字的行或代码块：`install`、`build`、`dev`、`start`、`test`、`lint`、`run`、`deploy`、`compile`、`generate`。如果多个 README 提供了同类命令（如都有 build），以**最靠近对应源码目录的 README** 为准，并在注释中注明来源路径。

> **JSON 文件命令提取（TypeScript / JavaScript 专项）**
>
> TypeScript/JavaScript 项目的可执行命令和构建配置往往分布在多种 JSON 文件中。**YOU MUST** 检查以下所有 JSON 文件，提取其中的脚本与命令定义，**不得遗漏任何一个**：
>
> | 文件 | 提取目标 |
> |------|---------|
> | `package.json`（根） | `scripts` 字段下所有键值对；`engines.node` / `engines.npm` |
> | `packages/*/package.json`（各 workspace 子包） | 各子包独立的 `scripts` 字段；留意与根 `scripts` 的差异 |
> | `apps/*/package.json` / `libs/*/package.json` | 同上 |
> | `nx.json` | `targetDefaults`、`namedInputs`、`tasksRunnerOptions` 中定义的目标命令 |
> | `turbo.json` | `pipeline`（或 `tasks`）字段下各任务的 `dependsOn`、`outputs`、`command` |
> | `lerna.json` | `command.run.npmClient`、`command.bootstrap` 中的脚本引用 |
> | `angular.json` / `project.json`（Nx Angular） | `projects.[name].architect.[target].options.scripts` 及 `builder` 字段 |
> | `.vscode/tasks.json` | `tasks[].command` / `tasks[].script` |
>
> 提取规则：
> - **必须** 记录每条命令的完整调用方式（如 `npm run build:prod`、`npx nx build my-app`、`npx turbo run test`）
> - **必须** 在注释中注明来源文件及字段路径（如 `来源：turbo.json > pipeline.build`）
> - 若多个 JSON 文件定义了同名任务（如 `build`），按以下优先级取最终命令：`turbo.json` / `nx.json` 编排层 > 各子包 `package.json` > 根 `package.json`
> - `scripts` 中引用其他脚本（如 `"build": "npm run clean && npm run compile"`）时，**必须** 追踪并展开所有引用链，直至得到实际可执行命令

### Python

```
pyproject.toml                → Python version (requires-python), all dependencies,
                                 build backend (setuptools / poetry / hatchling / flit)
setup.py / setup.cfg          → legacy metadata, version, packages
poetry.lock / Pipfile.lock    → locked dependency versions
requirements*.txt             → runtime / dev / test dependencies
tox.ini / pytest.ini / .flake8 → test and lint configuration
src/[package]/ or [package]/  → full package tree (folders only, no .py files)
tests/ or test/               → test coverage scope
```

### C / C++

```
CMakeLists.txt (root)         → cmake_minimum_required, project() name, language,
                                 CMAKE_CXX_STANDARD / CMAKE_C_STANDARD,
                                 find_package() calls (external libs)
Makefile                      → targets and compiler flags (if no CMake)
meson.build                   → project name, language, dependency() calls
conanfile.txt / conanfile.py  → third-party library versions
vcpkg.json                    → manifest-mode dependency versions
README.md / INSTALL           → build/test/run commands (highest priority)
.github/workflows/ etc.       → fallback command source
src/ or source/ or lib/       → full directory tree (folders only, no source files)
include/                      → public header layout (folders only)
tests/ or test/               → test framework and coverage scope
```

---

## Step 2 — Apply Directory Tree Rules

- **YOU MUST NOT include any source filenames (`.java`, `.ts`, `.py`, `.cpp`, `.h`, `.c`, etc.) anywhere in the directory tree.**
- **YOU MUST write a business-context comment on every folder node; a generic label alone (e.g., "controllers") is not acceptable.**
- **YOU MUST NOT expand `resources/`, `assets/`, `static/`, or `public/` sub-directories — write a one-line summary only.**

### Primary Source Path per Language

| Language | Primary Source Path | Header Path | Test Path |
|----------|--------------------|-----------|----|
| Java | `src/main/java/` | — | `src/test/java/` |
| TypeScript / JS | `src/` (or `app/`, `lib/`) | — | `tests/` or `src/__tests__/` |
| Python | `src/[package]/` or `[package]/` | — | `tests/` or `test/` |
| C++ | `src/` or `source/` | `include/` | `tests/` |
| C | `src/` or `source/` | `include/` | `tests/` |

### TypeScript / JavaScript 专项 — 实际层级展开规则

**YOU MUST** 以项目**当前实际**的目录层级为展开依据，而非按预设模板套用。具体规则：

1. **以实际结构为准**：先用 `find . -maxdepth 3 -type d -not -path '*/node_modules/*' -not -path '*/.git/*'`（或等价方式）扫描真实目录布局，按**实际存在的层级**展开，**不得** 假设标准 monorepo 布局（如 `packages/` / `apps/` / `libs/`）一定存在，也**不得** 凭模板补全实际不存在的目录
2. **git 子模块 / 子仓库**：若项目通过 `git submodule`、`git subtree` 或 `.gitmodules` 引入了外部仓库内容，且这些内容驻留在主项目源码路径下并承担业务职责（非单纯的第三方依赖），**必须** 按其实际层级展开
3. **workspace 拉取的外部仓库**：若 monorepo 通过 `pnpm workspace` / `yarn workspaces` / `turbo` / `lerna` 链接或拉取了其他 git 仓库的内容到主项目目录下，且这些目录承载业务源码，**必须** 展开
4. **判定"是否需要展开"的标准**：依据是该目录**是否包含项目自身维护或集成的业务代码**——而非该目录的来源（自有 / git 拉取 / 第三方）。只要承担业务职责，就必须展开
5. **强制不展开**：以下目录**禁止** 展开，仅一行概述：
    - `node_modules/`、`.git/`、`.pnpm-store/`
    - 构建产物：`dist/` / `build/` / `out/` / `.next/` / `.nuxt/` / `.turbo/` / `.svelte-kit/`
    - 缓存与覆盖率：`coverage/` / `.cache/` / `.parcel-cache/` / `.vite/`
6. **多层 workspace 嵌套**：若 monorepo 子包内又包含 workspace（如 `packages/foo/packages/bar`），**必须** 逐层展开到实际叶节点，不得在中间层截断

### ✅ Correct — folders only, with business-context comments

```
├── controller/        # RESTful endpoints for user auth, order management, and product search
├── service/           # Business logic for the above domains
│   └── impl/         # Concrete implementations of service interfaces
```

```
├── components/        # Reusable UI widgets: Button, Modal, DataTable, FormField
├── pages/             # Route-level views: Dashboard, UserProfile, Settings
│   └── auth/         # Login, Register, and password-reset flows
```

```
├── src/
│   ├── handlers/      # Request validation: user, order, and inventory endpoints
│   ├── models/        # Include: User, Order, Product header declarations
│   └── utils/         # String processing, date formatting, error helpers
├── include/           # Public API headers exposed to downstream consumers
```

### ❌ Wrong — listing source files

```
├── controller/
│   ├── UserController.java     ← NEVER
│   ├── user_controller.py      ← NEVER
│   └── userController.ts       ← NEVER
```

**Rules:**
- Primary source path → expand every directory level, folders only, each with a detailed business-context comment
- `resources/`, `assets/`, `static/`, `public/` → single line, one-sentence summary, do NOT expand sub-dirs
- `include/` (C/C++) → expand folder levels, describe what the headers expose, no filenames
- Comments must describe **business content** ("user auth, role assignment, permission checks"), not generic labels ("controllers")

---

## Step 3 — Decide Split Strategy

- **YOU MUST count the expanded primary source tree lines before writing any output. YOU MUST split when the count exceeds 40 lines, and YOU MUST NOT split when it is 40 lines or fewer.**

Evaluate the expanded **primary source path** tree line count **before writing**:

```
≤ 40 lines  →  no split, include inline in main doc
> 40 lines  →  split: main doc shows summary + pointer, full tree goes to sub-doc
```

**Multi-module / multi-package project** (≥ 3 top-level modules or any module > 40 lines):
- Each oversized module → `codebase-docs/[module-name]-structure.md`
- Main doc shows one-liner + `# 📄 详见：codebase-docs/[module-name]-structure.md`

**Single-module with oversized source tree:**

```
├── src/           # Core business code spanning N domains (user/order/payment…)
│   # 📄 完整目录结构详见：codebase-docs/[project]-src-structure.md
```

> ⚠️ Do NOT split modules/packages whose expanded tree is ≤ 40 lines.

---

## Step 4 — Extract Dev Commands

- **YOU MUST follow the priority order below and stop at the first level that yields results. YOU MUST annotate every command with its source file and section. YOU MUST NOT write any command absent from project files — use the "未提供" placeholder instead.**
- **YOU MUST NEVER write the following commands unless they appear verbatim in the project's own documentation: `mvn clean install`, `java -jar target/app.jar`, `npm start`, `node index.js`, `python main.py`, `python -m [package]`, `./configure && make`, `make all`.**

Priority order — stop at the first level that yields results:

| Priority | Java | TypeScript / JS | Python | C / C++ |
|----------|------|----------------|--------|---------|
| 1 (highest) | `README.md` / `README.adoc` | 所有目录下的 README（见下方扫描规则） | `README.md` | `README.md` / `INSTALL` |
| 2 | `Makefile` / `Taskfile` | 所有 `package.json` 的 `scripts` 字段（根 + 各子包） | `Makefile` / `Taskfile` / `tox.ini` | `Makefile` / `CMakeLists.txt` comments |
| 3 | `pom.xml` / `build.gradle` plugin goals | `turbo.json` / `nx.json` / `lerna.json` / `angular.json` 等编排 JSON | `pyproject.toml` `[tool.taskipy]` / `[tool.poe]` | CI files |
| 4 | CI files | `vite/webpack/next` config files | CI files | — |
| 5 (lowest) | — | CI files | — | — |

### TypeScript / JavaScript — 命令提取细则

**YOU MUST** 在确定命令前完成以下所有动作，不得跳过：

#### A. README 多路径扫描

1. 列出项目内所有 `README.md` / `README.adoc` 文件路径（`find . -iname "readme*" -not -path "*/node_modules/*"`）
2. 按「距离源码目录由近到远」排序：子包 README > 根 README > docs/ README
3. 从每份 README 中提取含 `install`、`build`、`dev`、`start`、`test`、`lint`、`run`、`deploy`、`compile`、`generate` 关键字的代码块或行
4. 同类命令有多个来源时，以**最靠近对应源码**的 README 为准
5. 每条命令注释须标注完整来源路径，例如：`来源：packages/web/README.md > Development`

#### B. JSON 文件命令提取

按下列文件顺序逐一读取，提取所有可执行命令定义：

| 检查顺序 | 文件 | 提取字段 |
|---------|------|---------|
| 1 | 根 `package.json` | `scripts.*`、`engines.node` |
| 2 | `packages/*/package.json` | `scripts.*`（每个 workspace 子包） |
| 3 | `apps/*/package.json`、`libs/*/package.json` | `scripts.*` |
| 4 | `turbo.json` | `pipeline.*`（或 `tasks.*`）的 `command`、`dependsOn` |
| 5 | `nx.json` | `targetDefaults.*`、`tasksRunnerOptions` |
| 6 | `lerna.json` | `command.run`、`command.bootstrap` |
| 7 | `angular.json` / `project.json` | `projects.*.architect.*.options` |
| 8 | `.vscode/tasks.json` | `tasks[].command` / `tasks[].script` |

提取规则：
- 记录每条命令的**完整调用方式**（`npm run build`、`npx nx build my-app`、`npx turbo run test --filter=...`）
- 追踪 `scripts` 中的引用链（如 `"build": "npm run clean && npm run compile"`），展开到实际可执行命令
- 同名任务优先级：编排层（`turbo.json` / `nx.json`）> 子包 `package.json` > 根 `package.json`
- 注释示例：`来源：turbo.json > pipeline.build`、`来源：packages/api/package.json > scripts.test`

#### C. 命令交叉验证（构建与测试命令的正确性确认）

当 A、B 两步在 README、根 `package.json`、子包 `package.json`、`turbo.json` / `nx.json`、CI 配置等**多个来源**中发现**同类命令的不同写法**时，**YOU MUST** 执行以下交叉验证流程，不得直接采纳单一来源：

**1. 构建命令验证**

- 列出所有候选 build 命令及其来源（典型：根 `package.json scripts.build`、子包 `package.json scripts.build`、`turbo.json pipeline.build`、`nx.json targetDefaults.build`、各级 README 的 build 说明、CI 中的 build job）
- 检查是否存在编排层（`turbo.json` / `nx.json` / `lerna.json`）：若有 build pipeline，**编排层命令通常是真正的入口**
- 检查根 `scripts.build` 是否实际调用编排工具（如 `"build": "turbo run build"`、`"build": "nx run-many -t build"`）——若是，则**记录编排命令为权威命令**
- 调用 CI 配置（`.github/workflows/*.yml`、`.gitlab-ci.yml`、`circleci/config.yml` 等）作为**最终权威验证来源**：CI 中实际执行的命令即为可运行的真相
- 若 README / `package.json` 与 CI 不一致，**以 CI 为准**，并在注释中标明：`已与 .github/workflows/[文件].yml > [job] 对照验证`

**2. 测试命令验证**

- 列出所有候选 test 命令及其来源
- 检查测试编排：`turbo.json pipeline.test`、`nx.json` 中的 test target
- 读取测试配置文件确认实际使用的测试框架与运行方式：`jest.config.*`、`vitest.config.*`、`playwright.config.*`、`cypress.config.*`、`mocharc.*`
- 检查 CI 中实际执行的 test 步骤作为权威验证
- 若存在**多个测试层级**（如单元测试 / 集成测试 / E2E），**必须** 分别列出每一层级的命令及其来源，不得只列一条
- README 与 CI 不一致时，**以 CI 为准**

**3. 冲突解决与标注**

- 验证完成后，必须在最终命令注释中追加验证标记
- 示例：
  ```bash
  # 构建（来源：turbo.json > pipeline.build；已与 .github/workflows/ci.yml > build job 对照验证）
  npx turbo run build

  # 单元测试（来源：packages/api/package.json > scripts.test；已与 .github/workflows/ci.yml > test job 对照验证）
  npm run test --workspace=packages/api

  # E2E 测试（来源：playwright.config.ts + .github/workflows/e2e.yml）
  npx playwright test
  ```
- 若多个来源命令均独立可运行（如 monorepo 中可全量构建或单包构建），**必须** 同时列出，并注明各自适用场景

**4. 不可验证场景**

- 若项目**无 CI 配置**、且 README 与 JSON 命令存在冲突，**必须** 在注释中明确标注：
  ```bash
  # 来源冲突未验证：[来源 X] 给出 [命令 A]，[来源 Y] 给出 [命令 B]
  # 建议优先尝试 [推荐项]，备选 [备选项]
  ```
- **不得** 凭主观判断隐藏冲突或静默选择一项

**Mandatory annotation** — every command must cite its source:

```bash
# 安装依赖（来源：README.md > Quick Start）
npm install

# 构建（来源：packages/web/README.md > Build > Production；已与 .github/workflows/ci.yml 对照验证）
npm run build:prod

# 开发服务器（来源：根 package.json > scripts.dev）
npm run dev

# 测试（来源：turbo.json > pipeline.test；已与 CI 对照验证）
npx turbo run test --filter=...

# 构建（来源：README.md > Building）
cmake -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build

# 测试（来源：pyproject.toml > [tool.pytest.ini_options]）
pytest tests/ -v
```

**If a command type is not found anywhere:**

```bash
# 文档中未提供，请参考 [relevant config file] 自行确认
```

**Never write** undocumented default commands, including:
- `mvn clean install`, `java -jar target/app.jar`
- `npm start`, `node index.js`
- `python main.py`, `python -m [package]`
- `./configure && make`, `make all`

---

## Output Template

- **YOU MUST strictly generate the output according to this template. YOU MUST fill every `[placeholder]` with values sourced from project files, delete all tech-stack rows that do not apply to this project, and add no sections or content outside the template structure.**

> Copy this template verbatim. Fill every `[placeholder]`. Delete language rows in the tech-stack that do not apply. Delete "子文档索引" if no split occurred.

````markdown
# [ProjectName] Codebase 文档

> 📁 本文档为项目总览。目录结构较复杂的模块已拆分为独立子文档，详见各节说明。

## 1. 技术栈

<!-- Java project -->
- **Java [exact version]**（来自 pom.xml `java.version` / build.gradle `sourceCompatibility`）
- **构建工具**：Maven [version] / Gradle [version]
- **核心框架**：[Spring Boot / Quarkus / Micronaut / other] [exact version]
- **数据库**：[DB name] + [MyBatis / JPA / Hibernate] [version]
- **安全**：[Spring Security / Shiro / other] [version]（如有）
- **测试**：[JUnit 5 / TestNG] [version]

<!-- TypeScript / JavaScript project -->
- **Node.js [exact version]**（来自 package.json `engines` / `.nvmrc`）
- **语言**：TypeScript [exact version]（来自 package.json `devDependencies`）/ JavaScript
- **运行时 / 框架**：[Next.js / Nuxt / Express / NestJS / Vite / other] [exact version]
- **包管理器**：[npm / yarn / pnpm] [version]
- **Monorepo 工具**：[Turborepo / Nx / Lerna / none]（如有）
- **测试**：[Jest / Vitest / Mocha] [version]
- **Lint / 格式化**：[ESLint / Biome / Prettier] [version]（如有）

<!-- Python project -->
- **Python [exact version]**（来自 pyproject.toml `requires-python` / `.python-version`）
- **包管理器 / 构建后端**：[pip + setuptools / Poetry / uv + hatchling / Flit] [version]
- **核心框架**：[FastAPI / Django / Flask / other] [exact version]（如有）
- **数据库**：[DB name] + [SQLAlchemy / Django ORM / other] [version]（如有）
- **测试**：[pytest / unittest] [version]
- **Lint / 格式化**：[Ruff / Black / Flake8 / mypy] [version]（如有）

<!-- C / C++ project -->
- **语言标准**：[C11 / C17 / C++17 / C++20 / other]（来自 CMakeLists.txt `CMAKE_CXX_STANDARD` / `CMAKE_C_STANDARD`）
- **构建系统**：[CMake [version] / Make / Meson [version]]
- **编译器**：[GCC [version] / Clang [version] / MSVC [version]]（来自 CI 或 README）
- **核心依赖**：[Boost / Qt / OpenCV / other] [version]（来自 find_package / vcpkg.json / conanfile）
- **测试框架**：[Google Test / Catch2 / CTest] [version]（如有）

## 2. 项目目录结构

> 💡 已拆分为子文档的模块，在目录树中以 `📄 详见：[路径]` 标注，不在此处展开。
> 💡 TS/JS 项目：必须按**实际**目录层级展开（包括 git submodule / workspace 拉取的业务源码目录），不得按模板补全实际不存在的层级。

```
[根目录]/
├── [未拆分的子模块 — Java 示例]/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── com/xxx/
│   │   │   │       ├── controller/        # [业务描述]
│   │   │   │       ├── service/           # [业务描述]
│   │   │   │       │   └── impl/
│   │   │   │       ├── repository/        # [业务描述]
│   │   │   │       ├── entity/            # [业务描述]
│   │   │   │       ├── config/            # [业务描述]
│   │   │   │       └── util/              # [业务描述]
│   │   │   └── resources/                 # [一句话概述：配置文件、SQL 迁移脚本、静态资源等]
│   │   └── test/
│   │       └── java/
│   │           └── com/xxx/               # [测试覆盖范围：单元测试、集成测试等]
│   └── pom.xml
├── [未拆分的子模块 — TypeScript/JS 示例]/
│   ├── src/
│   │   ├── components/                    # [业务描述]
│   │   ├── pages/                         # [业务描述]
│   │   ├── services/                      # [业务描述]
│   │   ├── hooks/                         # [业务描述]（如有）
│   │   └── utils/                         # [业务描述]
│   ├── tests/                             # [测试覆盖范围]
│   ├── public/                            # [静态资源概述]
│   └── package.json
├── [未拆分的子模块 — Python 示例]/
│   ├── [package_name]/
│   │   ├── api/                           # [业务描述]
│   │   ├── models/                        # [业务描述]
│   │   ├── services/                      # [业务描述]
│   │   └── utils/                         # [业务描述]
│   ├── tests/                             # [测试覆盖范围]
│   └── pyproject.toml
├── [未拆分的子模块 — C/C++ 示例]/
│   ├── src/
│   │   ├── core/                          # [业务描述]
│   │   ├── network/                       # [业务描述]
│   │   └── utils/                         # [业务描述]
│   ├── include/
│   │   └── [project]/                     # [公开 API 头文件描述]
│   ├── tests/                             # [测试覆盖范围]
│   └── CMakeLists.txt
├── [src 过长时的写法 — 单模块]/
│   ├── src/                               # 核心业务代码，涵盖 [X] 个顶层包/模块（用户/订单/支付等）
│   │   # 📄 完整目录结构详见：codebase-docs/[项目名]-src-structure.md
│   └── [config file]
├── [已拆分的子模块1]/                      # [一句话职责摘要]
│   # 📄 详见：codebase-docs/[模块名]-structure.md
```

## 3. 开发命令（核心）

> ⚠️ 所有命令均来源于项目文档，每条命令后注明出处。
> ⚠️ TS/JS 项目：build / test 命令若来自多个来源，必须经过 Step 4-C 的交叉验证，并在注释中标明验证标记。

### 构建命令
```bash
# [command]（来源：[file > section][；已与 CI 对照验证]）
```

### 测试命令
```bash
# [command]（来源：[file > section][；已与 CI 对照验证]）
# 或：文档中未提供，请参考 [file] 自行确认
```

### 运行 / 启动命令
```bash
# [command]（来源：[file > section]）
# 或：文档中未提供，请参考 [file] 自行确认
```

## 4. 开发环境（简要）

### 前置要求

<!-- Java -->
- JDK [exact version]
- Maven [version] 或 Gradle [version]
- [Database, Redis, etc. if required]

<!-- TypeScript / JavaScript -->
- Node.js [exact version]（推荐使用 nvm 管理版本）
- [npm / yarn / pnpm] [version]

<!-- Python -->
- Python [exact version]
- [pip / Poetry / uv] [version]
- [virtualenv / venv（隐式）]

<!-- C / C++ -->
- [GCC [version] / Clang [version] / MSVC [version]]
- CMake [version] 或 Make [version]
- [vcpkg / Conan [version]]（如有依赖管理）

### 配置说明（选填）

[关键配置文件及其用途，如 application.yml、.env.example、config.toml；无特殊说明则省略本节]

## 5. 子文档索引

> 以下子文档由本次拆分自动生成。**若无拆分则删除本节。**

| 文档 | 对应模块/业务域 | 职责摘要 |
|------|----------------|----------|
| [module-structure.md](codebase-docs/[module]-structure.md) | [module] | [一句话摘要] |
| [project-src-structure.md](codebase-docs/[project]-src-structure.md) | `src/` 完整结构 | [一句话摘要] |
````

---

## Sub-document Template (when split is required)

- **YOU MUST use this template for every sub-document and include the "所属项目" and "关联主文档" back-links in every sub-document header.**

### TypeScript / JavaScript 专项 — 子文档简化规则

对于 **TS/JS 项目**（含 monorepo / workspace 结构），子文档**仅保留**以下两部分内容：

1. 模块职责 / 源码结构概述（2–4 句）
2. 完整目录结构（folders only，每个节点带业务上下文注释）

**YOU MUST NOT** 在 TS/JS 子文档中生成以下章节：

- ❌ "关键包 / 模块说明"
- ❌ "关键目录说明"
- ❌ 任何形式的"关键代码路径"段落或表格（即对特定路径做额外高亮 / 重点说明的章节）

理由：TS/JS 项目的业务上下文已通过目录树注释充分表达，额外的关键路径说明会造成冗余。Java / Python / C / C++ 子文档仍按下方完整模板生成。

### Module-level split (Java / Python / C / C++)

````markdown
# [ModuleName] 目录结构详解

> 所属项目：[MainProjectName]
> 文档位置：codebase-docs/[filename].md
> 关联主文档：codebase-structure.md

## 模块职责

[2–4 sentences: overall responsibility, exposed capabilities, dependencies on other modules]

## 目录结构

```
[full expanded tree — folders only, detailed business-context comments]
```

## 关键包 / 模块说明

[2–4 most important directories, 1–3 sentences each explaining their concrete business role]
````

### Module-level split (TypeScript / JavaScript)

````markdown
# [ModuleName] 目录结构详解

> 所属项目：[MainProjectName]
> 文档位置：codebase-docs/[filename].md
> 关联主文档：codebase-structure.md

## 模块职责

[2–4 sentences: overall responsibility, exposed capabilities, dependencies on other modules]

## 目录结构

```
[full expanded tree — folders only, detailed business-context comments;
 必须以实际项目层级为准，包括 git submodule / workspace 拉取的业务源码目录]
```
````

### Single-module src split (Java / Python / C / C++)

````markdown
# [ProjectName] src 目录结构详解

> 所属项目：[ProjectName]
> 文档位置：codebase-docs/[project]-src-structure.md
> 关联主文档：codebase-structure.md

## 源码结构概述

[2–4 sentences: business scope, top-level directory partitioning logic, overall architectural layering]

## 完整目录结构

```
[language-appropriate root]/
├── [full tree starting here — folders only, detailed comments]
```

## 关键目录说明

[3–6 most important directories, 1–3 sentences each]
````

### Single-module src split (TypeScript / JavaScript)

````markdown
# [ProjectName] src 目录结构详解

> 所属项目：[ProjectName]
> 文档位置：codebase-docs/[project]-src-structure.md
> 关联主文档：codebase-structure.md

## 源码结构概述

[2–4 sentences: business scope, top-level directory partitioning logic, overall architectural layering]

## 完整目录结构

```
[language-appropriate root]/
├── [full tree starting here — folders only, detailed comments;
   必须以实际项目层级为准，包括 git submodule / workspace 拉取的业务源码目录]
```
````

---

## Output Order

When multiple files are produced, always output them in this order:
1. `codebase-structure.md` (main document)
2. Module sub-documents, in the order they appear in the main doc
3. `[project]-src-structure.md` (src split doc, if any) — always last

---

## Critical Rules (summary)

- **YOU MUST NOT include any source filenames** (`.java`, `.ts`, `.py`, `.cpp`, `.h`, `.c`) anywhere in any directory tree
- **YOU MUST fully expand the primary source tree** at every directory level, unless the split rule applies
- **YOU MUST NOT expand** `resources/`, `assets/`, `static/`, `public/` — one-line summary only
- **YOU MUST expand `include/` (C/C++) at folder level only** — no header filenames
- **YOU MUST write a business-context comment for every folder node** — generic labels alone are not acceptable
- **YOU MUST annotate every dev command with its source** — no undocumented defaults
- **YOU MUST apply the 40-line split threshold exactly** — do not split below, do not skip above
- **YOU MUST run language detection (Step 0) before any other step** — do not assume Java
- **YOU MUST delete all inapplicable tech-stack rows** — never leave unfilled placeholder rows
- **YOU MUST scan all README files across all directories for TS/JS projects** — do not read only the root README
- **YOU MUST check all JSON files (package.json, turbo.json, nx.json, etc.) for TS/JS command definitions** — do not rely on root package.json alone
- **YOU MUST cross-verify TS/JS build and test commands across all sources** (README / `package.json` / 编排 JSON / CI) when multiple writings exist, and prefer CI as the final ground truth
- **YOU MUST expand TS/JS directories according to actual project hierarchy**, including git-pulled / workspace-linked business directories — do not assume template structures
- **YOU MUST NOT generate "关键包/模块说明" or "关键目录说明" sections in TS/JS sub-documents** — these sections are reserved for Java / Python / C / C++ sub-documents only