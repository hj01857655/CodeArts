# Result Evaluation Paradigms

## 1. Handling Failures
- **Patch Failures (CRITICAL)**: If a test executes properly but fails its Oracle/Consistency check, record as FAIL. Do NOT attempt to fix the patch or source code.
- **Unexecutable Tests**: If a test completely failed to compile/run after 2 retries, deduce the expected outcome or mark as untestable failure. Do NOT hallucinate execution results.
- **Strict Pass Criteria (ZERO TOLERANCE)**: The aggregated result of the regression suite is only successful if the pass rate is exactly 100%. A single failed, mismatched, or unexecutable test means the entire patch is unequivocally INCORRECT. You are strictly PROHIBITED from analyzing the semantics of a failed test to excuse it as "unrelated to the issue". Your judgment must be purely mechanical: if it fails the Oracle or violates Differential Consistency, it is a FAIL. If pre-fix baseline data is missing, un-comparable, or cannot be successfully executed, ANY post-fix test failure automatically and immediately results in a FAIL verdict.

## 2. Evaluation Paradigms

- **Paradigm 1: API_CALL Logic (Self-Verifying)**
  - *Applicability:* Tests with internal assertions where the process exit code or framework report indicates success/failure.
  - **Action**:
    1. Read the `{test}_.exitcode` file and the framework report in `{test}_.stdout.log`.
    2. **Direct Judgment**: If exit code is 0 (or framework says PASS) -> Outcome PASS. Otherwise -> FAIL.
    3. **Generate Verification Result**: Write the `_verification_result.json`.

- **Paradigm 2: INPUT_ARTIFACT Logic (Output Matching)**
  - **Applicability**: Tests acting as opaque boxes, where success is determined by the external output stream.
  - **Action**:
    1. **Generate Verification Script**: Create `verify_regression_test_output.sh`.
      - *Logic:* Read the `.stdout.log` or `.stderr.log`. Use tools like `grep`, `awk` to match the output against the specific `oracle` string defined in the `test_generation_plan.json` for that test case. Output "TRUE" or "FALSE".
    2. **Execute Script**: Run the verification script against the captured logs.
    3. **Generate Verification Result**: Read the script's output (TRUE/FALSE) and write the `_verification_result.json`.

## 3. Verification Logic by Test Type
- **Oracle Source (MANDATORY)**: You MUST retrieve the expected pass/fail condition or behavior for every test exclusively from the `oracle` field in the `test_generation_plan.json`. Do not scan test source code files for header comments.
- **For Fix & Robustness (Type 1, 2a, 3)**: Apply Paradigm to Post-Fix data. Must match the Absolute Oracle defined in the plan.
- **For Regression Prevention (Type 2b)**: Apply Paradigm to both Pre-Fix and Post-Fix data. Must be Identical (Differential Consistency as per the plan).
- **For Fix-Induced Vulnerability (Type 4)**: Apply Paradigm strictly to Post-Fix data. Must match the Absolute/Negative Oracle defined in the plan.

## Output (MANDATORY)
Persist the execution context as:
`{{regression_workspace}}/execution_context.json`s
The generated file MUST conform to:
`{{skill_root}}/schema/regression_result.schema.json`