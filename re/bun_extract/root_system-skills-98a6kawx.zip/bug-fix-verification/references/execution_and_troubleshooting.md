# Execution and Troubleshooting Protocol
You must only follow the following phases:
- Preparations & Execution Logic
- Orchestration Script Requirements
- 2-Round Execution
- Verification Gate & Troubleshooting (Blocking)

## Phase 1. Preparations & Execution Logic
- **Read Generation Plan (MANDATORY)**: You MUST explicitly read `workspace_dir/test_generation_plan.json` first. Extract the exact `target_location`, `target_granularity`, and `test_type` for every test to formulate your execution targets. **CRITICAL PARSING RULE:** If `target_granularity` is "METHOD", you MUST strictly extract and preserve the method identifier (the suffix after `#` or `::`) from the `target_location`. Do NOT strip it down to just the file or class name.
- **Distinguish Paradigms**: API_CALL (rely on test framework signals) vs INPUT_ARTIFACT (opaque box, rely on external log matching).
- **Project Build Command**: You MUST explicitly read the `repro_execution_script_path` first. Extract the project build command.
- **Execution Logic**: You MUST explicitly read the `repro_execution_script_path` first. Extract the core execution mechanics (e.g., testing framework invocations, environment variables, specific parameters) from this script and use them as your mandatory foundation. Expand upon this exact foundation to orchestrate the newly generated/appended/reused regression suite targets identified in the generation plan. Fallback: generate a new minimal execution script ONLY if the reproduction script is completely absent or fundamentally inapplicable.
- **Location Protocol (API_CALL)**: Priority 1 is in-place execution within `regression/`, but the actual test execution commands in the execution script MUST strictly be run from the project's root directory, targeting the specific method/class paths defined in the generation plan. Priority 2 (fallback) is copying to native test directory.

## Phase 2. Orchestration Script Requirements
You must synthesize a master script (`run_regression_suite.sh`) handling Git operations, compilation, and test execution sequentially.

### Script Design Best Practices (Static Review Criteria)

Before executing the script, you MUST statically verify that it enforces the following rules:
1. **Execution Efficiency & Command Precision**: 
   - Must strictly separate the compilation phase from the test execution phase. Do not trigger build lifecycles during individual test executions.
   - Must utilize targeted builds (e.g., compiling only the affected modules and test sources) instead of full-project packaging.
   - **NO PACKAGE/DIRECTORY WILDCARDS (ABSOLUTE RULE)**: You are strictly forbidden from using package-level or directory-level wildcards (e.g., `.**`, `/*`, `*`) in the test execution targets. You MUST strictly specify the exact File/Class names or Method names. Do not execute entire packages to avoid running unrelated tests.
   - **MANDATORY BATCHING & GRANULARITY ENFORCEMENT**: You MUST batch multiple test executions together into a single command. Critically, you MUST respect the `target_granularity` from the generation plan. If targeting specific methods ("METHOD" granularity), you MUST use the underlying testing framework's EXACT syntax for method-level execution.
2. **Path Resolution Rule**:
   * Any generated or invoked shell script MUST operate on absolute paths only.
     - Do NOT rely on `pwd` or the caller’s current working directory.
     - Do NOT use relative paths (`./`, `../`) for any inputs or outputs, including script paths.
     - All paths MUST be resolved to OS-native absolute paths BEFORE invoking `java`, `python`, or `jacococli`.
   * On Windows, all generated paths MUST be Windows drive absolute paths:
     - Allowed: `C:\...` or `C:/...`
     - Forbidden: POSIX drive paths like `/c/...`, `/d/...`
   * Any generated or invoked shell script MUST operate on absolute paths only and MUST NOT rely on cwd.
   * If the input `{{project_root_dir}}` is provided in POSIX drive form (e.g., `/c/...`),
     the agent MUST convert it to a Windows drive absolute path before emitting scripts/commands.

### Phase 3: 2-Round Execution
To execute, you must follow a 2-round phase:

- **Round 1: Pre-Fix Baseline Execution (Type 2b Only)**
  1. **Revert Patch**: If patched, execute `git apply -R {{patch_path}}` or `git checkout .` to revert to the **Pre-Fix State**.
  2. **Mandatory Compilation**: Explicitly build the pre-fix project. Check exit codes; abort if build fails.
  3. **Execute & Capture (Strictly Raw Logs)**: Run **Type 2b** test cases (target the exact locations specified in `test_generation_plan.json`; batch them into a single command if multiple exist).
    - **Action**: You MUST capture the exact standard output, standard error, and exit code of the batched execution into unified raw intermediate files.
    - **Naming Convention (Batched)**:
      - `workspace_dir/type2b_regression_tests_pre_fix.stdout.log`
      - `workspace_dir/type2b_regression_tests_pre_fix.stderr.log`
      - `workspace_dir/type2b_regression_tests_pre_fix.exitcode` (Save `$?` to this file)
    - **PROHIBITION**: Do NOT hardcode, mock, or fake test results in this script. Do NOT write `echo "PASS"` or generate JSONs here.

- **Round 2: Post-Fix Verification Execution (All Types)**
  1. **Apply Patch**: Execute `git apply {{patch_path}}` to establish the **Post-Fix State**.
  2. **Mandatory Compilation**: Explicitly build the post-fix project. Abort if build fails.
  3. **Execute & Capture (Strictly Raw Logs)**: Run **ALL** test cases (Type 1, 2a, 2b, 3, targeting the exact locations specified in `test_generation_plan.json`) **in a single batched command**.
    - **Action**: Capture the exact outputs of the batched execution into unified raw intermediate files.
    - **Naming Convention (Batched)**:
      - `workspace_dir/all_regression_tests_post_fix.stdout.log`
      - `workspace_dir/all_regression_tests_post_fix.stderr.log`
      - `workspace_dir/all_regression_tests_post_fix.exitcode`

## Phase 4. Verification Gate & Troubleshooting (Blocking)
- **Verification Gate & Remediation (Blocking)**:
  - You MUST verify that the expected RAW LOG files (`.stdout.log`, `.stderr.log`, `.exitcode`) exist and represent a complete run (not abruptly failed due to compilation errors).
  - **Troubleshooting Protocol (Max 2 Retries)**: If execution fails due to test environment issues, test code syntax errors, or script errors (NOT test assertion failures), you must attempt to fix them so the test can properly run.
    1. **Analyze**: Read the `.stdout.log` and `.stderr.log` to identify the exact compilation or script execution error.
    2. **Fix**: Edit the *existing* test file or execution script to resolve the issue. You MUST NOT generate new test cases or new scripts from scratch. **CRITICAL: You are absolutely prohibited from editing the project's source code or the `.patch` file during this troubleshooting cycle. Only fix the test infrastructure. If the execution failure is related to exact artifact sizes/lengths, debug your generation scripts rather than manually editing the artifact text.**
    3. **Mandatory Re-execution**: After editing the files, you MUST use the `Bash` tool to physically re-execute the orchestration script (e.g., `./run_regression_suite.sh`) to generate new logs. You MUST NOT assume the fix works or proceed to Step 5 without actual execution evidence confirming the compilation/execution success.
    4. **Retry Limit**: You are strictly limited to a maximum of 2 `fix -> re-execute` cycles per test case.
    5. **Failure to Resolve**: If a test case still fails to compile or execute properly after 2 repair attempts, STOP. Do not waste further effort. Skip the execution for this specific test case, leave the latest logs as they are, and proceed to the next one.
  - **Action**: Ensure all valid tests are run and broken tests are either repaired (with verified new logs) or skipped (if retry limit reached) before proceeding to Step 5.