---
name: bug-fix-verification
description: Orchestrates the generation, execution, and objective evaluation of regression tests (Type 1, 2a, 2b, 3) to validate a bug fix using a Differential Testing Strategy.
---

# Bug-Fix Verification Skill

## Input Contract
1. `workspace_dir`: Target directory for all artifacts.
2. `issue_analysis_path`: Canonical issue analysis JSON.
3. `project_understanding_documentation_path`: Project Understanding Documentation markdown.
4. `reproduction_test_path`: Verified reproduction test from Phase C.
5. `repro_execution_script_path`: Reproduction execution script.
6. `patch_path`: The proposed fix.
7. `existing_test_directory`: Used for Type 2b reuse.

## Core Rules
- **Strict Objectivity & Impartiality**: You are an impartial auditor. You MUST NOT assume the patch is correct. 
- **NO Patch Modification**: You are strictly forbidden from modifying the actual bug-fix patch or the project's source code during this skill's execution.
- **Explicit Patch Skepticism:** You MUST explicitly output a written, critical analysis of the patch's logic *before* generating any adversarial tests. You must actively challenge the fix: identify its core pattern and hypothesize how it might over-correct or introduce new blind spots. Generating tests without first writing down this analysis is a strict violation.
- **Blind Mechanical Verification:** You are a mechanical executor. You MUST evaluate test outcomes based ONLY on the predefined Oracle or Pre/Post-fix Differential Consistency. You must NEVER analyze a test failure to determine if it is "related" or "unrelated" to the issue.

## Execution Steps

### Step 1: Generate Regression Tests

**Goal:** Independently generate a comprehensive regression test suite covering Bug Reproduction (Type 1), Root Cause Variations (Type 2a), Compliance Baselines (Type 2b), Edge Cases (Type 3), and Patch Adversarial (Type 4). 

**Action:** You MUST carefully read and strictly adhere to the external guidelines for all generation rules, strategies, and output constraints.
- **Execute Action:** Read the file `references/test_generation_guidelines.md` using the read tool before writing any test code.

### Step 2: Synthesize Execution Script & Step 3: Execute Regression Suite

**Goal:** Synthesize the orchestration script (`run_regression_suite.sh`) and execute the regression suite to establish baselines and verify fixes.

**Action:** You MUST dynamically read the execution and troubleshooting protocol. This external reference contains absolute rules for script requirements, execution phases (Pre-Fix and Post-Fix), and the blocking troubleshooting loop.
- **Execute Action:** Read the file `references/execution_and_troubleshooting.md` using the read tool before synthesizing any execution scripts.

### Step 4: Result Analysis and Result JSON Generation & Step 5: Final Report Generation

**Goal:** Read raw log files, independently evaluate outcomes, generate schema-compliant JSON results, and produce the final analysis report.

**Action:** You MUST read and strictly apply the evaluation paradigms to judge the test outcomes correctly (API_CALL vs INPUT_ARTIFACT logic) and handle any test failures.
- **Execute Action:** Read the file `references/evaluation_paradigms.md` using the read tool before analyzing any raw execution logs or writing JSON results.