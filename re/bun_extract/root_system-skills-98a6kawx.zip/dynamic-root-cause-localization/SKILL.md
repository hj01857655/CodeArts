---
name: dynamic-root-cause-localization
description: Only the bug-fix sub-agent can use this skill to first collect dynamic execution traces and then perform evidence-driven root-cause localization based on the collected traces.
---

# Dynamic Root Cause Localization

Collect dynamic execution coverage via minimal JaCoCo injection, enrich it into traceable source-level execution ranges, and focus the trace using reproduction evidence to produce actionable line-range indices and evidence-backed localization hypotheses.

## Path resolution rule

- Any generated or invoked shell script MUST operate on absolute paths only.
    - Do NOT rely on `pwd` or the caller’s current working directory.
    - Do NOT use relative paths (`./`, `../`) for any inputs or outputs, including
      `jacoco.exec`, `jacoco_report.xml`, and all script paths.
    - All paths MUST be resolved to OS-native absolute paths BEFORE invoking `java`, `python`, or `jacococli`.

* On Windows, all generated paths MUST be Windows drive absolute paths:
    - Allowed: `C:\...` or `C:/...`
    - Forbidden: POSIX drive paths like `/c/...`, `/d/...`
* Any generated or invoked shell script MUST operate on absolute paths only and MUST NOT rely on cwd.
* If the input `{{project_root_dir}}` is provided in POSIX drive form (e.g., `/c/...`),
  the agent MUST convert it to a Windows drive absolute path before emitting scripts/commands.

## Inputs

Required paths/values (resolve from your pipeline context):

- `codebase_root`: `{{project_root_dir}}`
- `issue_number`: `{{issue_number}}`
- `test_run_script_path`: path to the existing test execution script that currently runs the reproduction / tests
    - Examples: `run_repro.sh`, `run_test.sh`, `scripts/run.sh`, etc.

## Required JaCoCo assets

JaCoCo assets MUST be resolved according to the detected runner before use.

Runner-specific resolution rules:

- Maven:
    - Resolve `org.jacoco:org.jacoco.agent:<version>:runtime` through Maven.
    - Resolve `org.jacoco:org.jacoco.cli:<version>:nodeps` through Maven when CLI-based XML report generation is required.

- Direct `java`:
    - Resolve `org.jacoco:org.jacoco.agent:<version>:runtime` through Maven.
    - Resolve `org.jacoco:org.jacoco.cli:<version>:nodeps` through Maven when CLI-based XML report generation is required.
    - Use the resolved JaCoCo agent runtime jar for direct `-javaagent` injection.

- Gradle:
    - Use Gradle-native JaCoCo integration.
    - Configure the Gradle `Test` task to produce the canonical `jacoco.exec`.
    - Use a Gradle `JacocoReport` task to produce XML report data.

Resolved artifact paths:

- `{{resolved_jacoco_agent_runtime_jar}}`
- `{{resolved_jacoco_cli_nodeps_jar}}`

Rules:
- `{{resolved_jacoco_agent_runtime_jar}}` MUST be the absolute path to the resolved JaCoCo agent runtime jar when direct `-javaagent` injection is used.
- `{{resolved_jacoco_cli_nodeps_jar}}` MUST be the absolute path to the resolved JaCoCo CLI jar when CLI-based XML report generation is required.
- For Maven and direct `java` execution, resolved JaCoCo paths MUST point to artifacts in the local Maven repository.
- For Gradle execution, JaCoCo report generation SHOULD be performed through Gradle-native `JacocoReport`.
- The required JaCoCo asset for the selected execution path MUST exist before JaCoCo injection or report generation begins.


## Procedure

### Step 0: Ensure workspace and prepare JaCoCo

**Goal:** ensure the localization workspace exists and prepare the JaCoCo assets or runner-native JaCoCo capability required by later steps.

#### 0.1 Ensure workspace

Ensure directory exists:

`{{project_root_dir}}/.bugfix/{{issue_number}}/localization`

Ensure directory exists for temporary JaCoCo preparation artifacts and build-file backups:

`{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco-resolution`

#### 0.2 Detect runner and check JaCoCo readiness

Inspect `test_run_script_path` and determine the primary runner:

- direct `java`
- Maven
- Gradle

Before applying any JaCoCo preparation, the Agent MUST check whether the required JaCoCo capability is already available:

- For direct `java` and Maven:
    - check whether usable JaCoCo agent runtime and CLI jars already exist in the local Maven repository;
    - if both required jars exist and are non-empty, set:
        - `{{resolved_jacoco_agent_runtime_jar}}`
        - `{{resolved_jacoco_cli_nodeps_jar}}`

- For Gradle:
    - check whether the target Gradle project already applies or can execute Gradle-native JaCoCo tasks;
    - check whether an existing `JacocoReport` task can generate XML output.

If the required JaCoCo capability is already available, proceed to Step 1.

#### 0.3 Resolve missing JaCoCo capability

If any required JaCoCo capability is missing, incomplete, or not safely usable, the Agent MUST read and follow:

`<skill_root>/references/jacoco-resolution.md`

The reference MUST be followed only for the detected runner.

After the reference procedure completes, the Agent MUST verify:

- for direct `java` and Maven:
    - `{{resolved_jacoco_agent_runtime_jar}}` exists and is non-empty;
    - `{{resolved_jacoco_cli_nodeps_jar}}` exists and is non-empty;

- for Gradle:
    - the Gradle `Test` task can produce the canonical execution data file:
      `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco.exec`;
    - XML report generation is available through Gradle-native `JacocoReport`.

If JaCoCo still cannot be prepared, stop and report the detected runner, missing capability, and preparation failure reason.

#### 0.4 Restoration requirement

If any build configuration file is temporarily modified during JaCoCo preparation, it MUST be backed up before modification and restored after JaCoCo execution or failure.

Before leaving the localization workflow, the Agent MUST verify that each restored file exactly matches its backup.

---

### Step 1: Prepare canonical JaCoCo execution entrypoint

**Goal:** create a canonical execution script and define the JaCoCo output paths used by later steps.

#### 1. Copy original execution script

1. Read the original script at `test_run_script_path`.
2. Write a copied script to:

   `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/run_with_jacoco.sh`

Rules:
- The copied script is the canonical execution entrypoint for instrumented execution.
- The copied script MUST preserve the original execution semantics.
- Do NOT rewrite unrelated commands, environment variables, classpaths, arguments, working directories, heredocs, or script structure.

#### 2. Reuse the runner selected in Step 0

Reuse the primary runner determined in Step 0:

- direct `java`
- Maven
- Gradle

If the copied script is inconsistent with the runner selected in Step 0, stop and report the mismatch.

#### 3. Define canonical JaCoCo paths

The canonical JaCoCo execution data path MUST be:

`{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco.exec`

The canonical JaCoCo XML report path MUST be:

`{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_report.xml`

For direct `java` and Maven injection, the canonical JaCoCo agent option MUST be:

`-javaagent:{{resolved_jacoco_agent_runtime_jar}}=destfile={{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco.exec,append=false`

Rules:
- `{{resolved_jacoco_agent_runtime_jar}}` MUST already be prepared by Step 0 before this option is used.
- The JaCoCo agent option MUST use the canonical `jacoco.exec` path.
- All paths MUST be normalized according to the Path resolution rule before being written into scripts, commands, or build configuration files.

---
### Step 2: Apply runner-specific JaCoCo instrumentation

**Goal:** enable JaCoCo coverage collection through the minimal effective mechanism for the selected runner.

#### 1. Direct `java` runner

Modify only the target `java ...` invocation in:

`{{project_root_dir}}/.bugfix/{{issue_number}}/localization/run_with_jacoco.sh`

Required action:
- Insert the canonical JaCoCo agent option immediately after the `java` token.

Example:

```bash
java <original-options-and-args>
````

becomes:

```bash
java -javaagent:{{resolved_jacoco_agent_runtime_jar}}=destfile={{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco.exec,append=false <original-options-and-args>
```

Constraints:

* Do NOT change classpath, arguments, environment variables, working directory, heredocs, or script structure.
* Do NOT modify unrelated `java` invocations unless they are part of the target scenario.

#### 2. Maven runner

Before injection, verify that Step 0 prepared:

* `{{resolved_jacoco_agent_runtime_jar}}`
* `{{resolved_jacoco_cli_nodeps_jar}}`

Classify the Maven execution path into exactly one case:

1. **Surefire/Failsafe test execution**

* Applies when the target scenario is executed through `maven-surefire-plugin` or `maven-failsafe-plugin`.
* Examples: `test`, `verify`, `surefire:test`, `failsafe:integration-test`.

2. **Other Maven-managed JVM execution**

* Applies when Maven launches the target scenario through another JVM execution path.

Rules:

* For Surefire/Failsafe, injection MUST reach the forked test JVM.
* Prefer POM-based `argLine` injection in the module that actually runs the target test.
* Command-level `-DargLine=...` MAY be used only when it is proven to reach the forked test JVM and does not overwrite required JVM options.
* For other Maven-managed JVM execution, use the minimal command-level or execution-specific injection point that reaches the actual executed JVM.
* Do NOT inject only into the Maven launcher JVM.
* Do NOT modify unrelated modules or Maven goals/phases.

If detailed Maven handling is needed, read and follow:

`<skill_root>/references/jacoco-resolution.md`

If `pom.xml` is temporarily modified for JaCoCo dependency resolution or `argLine` injection, the Agent MUST back it up before modification and restore it after JaCoCo execution or failure.

#### 3. Gradle runner

Use Gradle-native JaCoCo instrumentation.

Required behavior:

* The target Gradle `Test` task MUST write execution data to:

  `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco.exec`

* XML report generation MUST be available through a Gradle `JacocoReport` task and write to:

  `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_report.xml`

Rules:

* Do NOT rely on `JAVA_TOOL_OPTIONS` or `GRADLE_OPTS` as the sole coverage mechanism.
* Do NOT claim coverage correctness unless JaCoCo reaches the forked Gradle `Test` JVM.
* Do NOT rewrite unrelated Gradle tasks, plugins, dependencies, or repository configuration.

If detailed Gradle handling is needed, read and follow:

`<skill_root>/references/jacoco-resolution.md`

If `build.gradle`, `build.gradle.kts`, or a convention plugin file is temporarily modified for JaCoCo configuration, the Agent MUST back it up before modification and restore it after JaCoCo execution or failure.

#### 4. Multi-invocation handling

If the copied script invokes the selected runner multiple times:

* Prefer instrumenting only the invocation that runs the target scenario.
* If ambiguous, instrument only matched target-scenario invocations and record the ambiguity.
* Do NOT instrument unrelated build, setup, cleanup, or helper invocations.

#### 5. Safety checks before execution

Run:

```bash
chmod +x {{project_root_dir}}/.bugfix/{{issue_number}}/localization/run_with_jacoco.sh
```

Then verify:

* For direct `java`:

    * `run_with_jacoco.sh` contains a target `java -javaagent:` invocation.
    * The injected `destfile` equals the canonical `jacoco.exec` path.

* For Maven:

    * The selected injection method reaches the JVM that actually executes the target scenario.
    * For Surefire/Failsafe, the injection reaches the forked test JVM.

* For Gradle:

    * The target `Test` task can produce the canonical `jacoco.exec`.
    * A `JacocoReport` task can produce the canonical `jacoco_report.xml`.

If no valid runner-appropriate coverage collection path is detected, stop and report the detected runner, selected strategy, modified file, and missing condition.

---

### Step 3: Execute instrumented setup and verify JaCoCo execution data

**Goal:** execute the canonical JaCoCo-enabled entrypoint and verify that the canonical `jacoco.exec` file is generated.

#### 1. Execute the canonical entrypoint

Run:

```bash
{{project_root_dir}}/.bugfix/{{issue_number}}/localization/run_with_jacoco.sh
```

Rules:

* Persist full stdout/stderr verbatim.
* The command MUST use the OS-normalized absolute path to `run_with_jacoco.sh`.
* The execution MUST preserve the original test/reproduction semantics.

#### 2. Check Windows path issues first on failure

If execution fails, before any other diagnosis, check whether the failure is caused by MSYS/Git-Bash path formats.

Look for patterns such as:

* `/c/...`, `/d/...`, `/mnt/c/...`
* `Invalid or corrupt jarfile`
* `No such file or directory`
* `The system cannot find the path specified`
* malformed classpath errors
* `javac: invalid flag: /c/...`

If detected:

* apply only minimal path normalization:

    * `/c/xxx` → `C:/xxx`
    * `/d/xxx` → `D:/xxx`
* do NOT change command semantics;
* re-run the canonical entrypoint once;
* record the normalization applied.

#### 3. Verify canonical JaCoCo exec output

Verify:

`{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco.exec`

Required conditions:

* file exists;
* file is non-empty.

If both conditions hold, proceed to the next step.

If either condition fails, perform one minimal runner-appropriate correction round.

#### 4. Runner-specific diagnosis

Diagnose according to the runner selected in Step 0.

##### Direct `java`

Verify:

* the target invocation contains `java -javaagent:`;
* the injected `-javaagent` uses `{{resolved_jacoco_agent_runtime_jar}}`;
* the injected `destfile` exactly matches the canonical `jacoco.exec` path;
* the modified invocation is the one that actually runs the target scenario;
* Windows path normalization was applied if needed.

##### Maven

Verify:

* `{{resolved_jacoco_agent_runtime_jar}}` exists and is non-empty;
* the effective `destfile` exactly matches the canonical `jacoco.exec` path;
* the selected injection method reaches the JVM that actually executes the target scenario.

If the target scenario is executed through Surefire/Failsafe, additionally verify:

* the injection reaches the forked test JVM;
* the correct test-running module contains the effective `argLine` if POM-based injection is used;
* command-level `-DargLine=...` is not treated as valid unless it is proven to reach the forked test JVM.

If the target scenario is executed through another Maven-managed JVM path:

* verify the chosen command-level or execution-specific injection reaches the actual executed JVM;
* do NOT treat Surefire/Failsafe configuration as relevant.

If an exec file exists elsewhere but not at the canonical path, treat the configuration as inconsistent and correct the `destfile`.

##### Gradle

Verify:

* the target Gradle `Test` task is the task that actually runs the target scenario;
* Gradle-native JaCoCo configuration reaches the forked `Test` JVM;
* the configured execution data output path exactly matches the canonical `jacoco.exec` path;
* launcher-only JVM options such as `JAVA_TOOL_OPTIONS` or `GRADLE_OPTS` are not treated as sufficient.

#### 5. Apply one bounded correction round

If the canonical `jacoco.exec` file is missing or empty:

1. Apply one minimal correction based on the diagnosis above.

2. If detailed runner-specific handling is needed, read and follow:

   `<skill_root>/references/jacoco-resolution.md`

3. Re-run the canonical entrypoint once.

4. Re-check the canonical `jacoco.exec` file.

If the canonical `jacoco.exec` file is still missing or empty, stop and report:

* detected runner;
* selected instrumentation strategy;
* command or script path;
* modified build configuration file, if any;
* captured stdout/stderr;
* correction attempted;
* most likely reason the current runner is not correctly instrumented.

#### 6. Restore temporary build configuration changes

After JaCoCo execution and the bounded correction round, the Agent MUST restore any temporarily modified build configuration file before proceeding to trace generation.

Files that may need restoration include:

- `pom.xml`
- `build.gradle`
- `build.gradle.kts`
- convention plugin files

Required checks:

- the backup file exists;
- the modified file is restored from the backup;
- the restored file content exactly matches the backup.

If restoration fails, stop and report the restoration failure explicitly.

---

## Step 4: Generate Enriched Dynamic Execution Trace

**Goal:** run the JaCoCo Trace Tool to generate `jacoco_report.xml`, `jacoco_trace.json`, and `jacoco_trace_enriched.json` within a single module-bounded scope.

#### 1. Determine `target_module_root`

Before invoking the pipeline, determine exactly one `target_module_root`.

Procedure:

1. Read:

   `{{project_root_dir}}/codebase-structure.md`

2. Identify the most relevant module based on:

    - issue/analysis evidence;
    - API entry point;
    - package prefix hints;
    - stacktrace frames;
    - reproduction evidence;
    - primary executed area confirmed in previous steps.

3. Read, if it exists:

   `{{project_root_dir}}/codebase-docs/<module_name>-structure.md`

4. Set `target_module_root` to the selected module root directory.

Rules:

- `target_module_root` MUST correspond to exactly one module.
- `target_module_root` MUST contain the primary execution area, suspected defect location, or relevant API entry point.
- If multiple candidate modules exist, choose the single best-supported module and record a brief evidence-based justification.
- Do NOT use repository root as `target_module_root` unless the repository is a single-module project or the repository root is the correct execution/source scope.

#### 2. Invoke the JaCoCo Trace Tool

The canonical JaCoCo XML report path is:
`{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_report.xml`

For Maven or direct `java`, invoke the `extractJacocoTrace` tool with the following arguments:

* `issueName`: "{{issue_number}}"
* `codebaseRoot`: "{{project_root_dir}}"
* `moduleRoot`: "{{target_module_root}}"
* `jacococliJar`: "{{resolved_jacoco_cli_nodeps_jar}}"
* `jacocoXml`: "{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_report.xml"
* `printBody`: true

For Gradle, if the canonical XML report was already generated by Gradle `JacocoReport`, invoke the `extractJacocoTrace` tool with:

* `issueName`: "{{issue_number}}"
* `codebaseRoot`: "{{project_root_dir}}"
* `moduleRoot`: "{{target_module_root}}"
* `jacocoXml`: "{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_report.xml"
* `printBody`: true

If Gradle did not generate the canonical XML report, the Agent MAY invoke the tool including `jacococliJar` only when `{{resolved_jacoco_cli_nodeps_jar}}` exists and module-local class/source roots can be verified.

Rules:
* `moduleRoot` MUST identify exactly one target module root.
* `jacocoXml` MUST point to the canonical XML report path.
* Maven and direct `java` MUST provide `jacococliJar`.
* Gradle MAY omit `jacococliJar` only when the canonical XML report already exists and is non-empty.
* All paths MUST be OS-native absolute paths before invocation.

#### 3. Enforce module-bounded processing

The pipeline MUST:
* generate or reuse the canonical `jacoco_report.xml`;
* restrict CLI-based XML generation to `{{target_module_root}}`;
* restrict source enrichment to `{{target_module_root}}`;
* avoid scanning unrelated repository `src/**`, `target/**`, or `build/**` directories;
* preserve available executed classes/methods even when source enrichment is partial.

#### 4. Validate outputs

The tool invocation MUST produce:
```text
{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_report.xml
{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_trace.json
{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_trace_enriched.json
```

After execution, verify:

1. `jacoco_report.xml` exists and is non-empty;
2. `jacoco_trace.json` exists and is non-empty;
3. `jacoco_trace_enriched.json` exists and is non-empty;
4. `jacoco_trace_enriched.json` contains a non-empty `"execution_flow"` array.

If any condition fails, stop with an explicit trace-generation error including:

* detected runner;
* `target_module_root`;
* canonical `jacoco.exec` path;
* canonical `jacoco_report.xml` path;
* captured tool error messages.


----

### Step 5: Analyze Enriched Trace and Confirm Root Cause

**Goal:**
Use runtime evidence and the enriched execution trace to first perform preliminary trace-based analysis, then mandatorily classify the defect into the correct root-cause strategy, and only then perform detailed root-cause localization.


#### 1. Classify root-cause strategy (Mandatory)

Before any detailed root-cause localization, you MUST first classify the defect into **exactly one** of the following categories:

#### Category A: Local Implementation Logic Defect

The defect is primarily caused by faulty logic inside the already identified executed method or code range itself.

#### Category B: Context-Dependent Integration Defect

The defect cannot be confidently explained from the local executed code alone, and root-cause confirmation requires checking external context such as other files, APIs, callees, callers, or module interactions.

To perform this classification, you MUST complete all of the following sub-steps:

1. Read:

```text
{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_trace_enriched.json
```

2. Extract anchor tokens from runtime evidence (exception, logs, diffs, issue description).

* Must appear verbatim
* ≤ 10
* No rewriting

3. In `execution_flow`, locate executed methods whose:

* class name
* method name
* source path
* or method body

contains any anchor.

4. Based on:

* defect preconditions
* expected vs actual behavior
* matched executed methods

identify the most suspicious executed file(s) and line range(s) as **preliminary suspects for classification only**.

At this stage, you MUST NOT perform detailed root-cause analysis, cross-file confirmation, or final hypothesis construction.

Classification rules:

* MUST choose exactly one category.
* MUST base the classification on the preliminary suspects, runtime evidence, and executed trace context.
* Classify based on whether the root cause is primarily:

    * inside the local implementation itself, or
    * in the interaction between the local code and external context.

#### 2. Perform detailed root-cause localization based on the selected strategy (Mandatory)

After completing the required classification:

* If Category A is selected, MUST read `<skill_root>/references/local-localization.md` and follow the reference for **Local Implementation Logic Defect** localization.
* If Category B is selected, MUST read `<skill_root>/references/context-dependent-localization.md` and follow the reference for **Context-Dependent Integration Defect** localization.

- Use the selected strategy to perform detailed analysis and confirm the root cause, then produce the final suspicious file(s) and line range(s) with concise, evidence-based explanations.


### Step 5: Produce Final Root Cause Localization Result
- Load localization schema:
  `<skill_root>/schema/root_cause_localization.schema.json`
- Write the final localization result to:
  `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/root_cause_localization.json`
- Determine localization status strictly as:
    - **confirmed**:
        - dynamic execution evidence exists,
        - and directly supports the identified faulty logic.
    - **plausible**:
        - localization is supported by consistent static evidence,
        - but dynamic validation is unavailable or failed.
    - **inconclusive**:
        - evidence is insufficient to bound a single faulty logic.

### Result Critical Constraints
- Root cause MUST describe shared faulty logic, not a single failing instance.
- Claims MUST be grounded in execution or static evidence.
- MUST NOT defer localization to seek additional context beyond available evidence.

## Constraints

* All JaCoCo preparation MUST be minimal and runner-specific:
    * direct `java`: inject only the canonical `-javaagent:...` option immediately after the target `java` token;
    * Maven: resolve required JaCoCo artifacts through Maven, and ensure injection reaches the actual target JVM;
    * Maven Surefire/Failsafe: injection MUST reach the forked test JVM through effective `argLine`;
    * Gradle: use Gradle-native JaCoCo configuration, and claim coverage only if it reaches the forked `Test` JVM.

* XML report generation MUST use the runner-appropriate path:
    * Maven/direct `java`: use the resolved JaCoCo CLI jar when CLI-based XML generation is required;
    * Gradle: prefer Gradle `JacocoReport`, or use a bounded CLI fallback only when module-local inputs are verified.

* Output paths MUST match the canonical localization paths exactly.

* `target_module_root` MUST identify exactly one module; XML generation and source enrichment MUST NOT scan unrelated modules.

* Any temporary build-file modification MUST be backed up, restored after execution or failure, and verified against the backup.

* If enrichment is partial, keep raw dynamic trace intact and do not invent mappings, line ranges, call relations, or root-cause evidence.


