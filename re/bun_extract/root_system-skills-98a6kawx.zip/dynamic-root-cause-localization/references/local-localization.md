## Local Implementation Logic Defect Localization

Use this strategy only when the defect is primarily caused by faulty logic inside the already identified function or code range itself.

### Objective

Refine localization within the current file and nearby code region to identify the precise local logic error.

### Required actions

* Start from the top-ranked local candidate ranges.
* Inspect the current function, directly adjacent branches, and closely related statements.
* Focus on logic that can independently explain the symptom, such as:

  * incorrect conditions
  * missing branches
  * wrong state updates
  * incorrect return values
  * invalid null or empty handling
  * incorrect exception handling
  * boundary or ordering errors

### Constraints

* Do NOT expand to cross-file inspection unless strictly required by direct evidence.
* Do NOT rely on external API semantics if the symptom can already be explained locally.
* Keep the analysis centered on the local implementation logic.

### Output requirements

For each selected hypothesis:

* identify the exact file and line range
* cite the matched anchors or snippets
* explain how the local code logic could directly produce the observed symptom
* keep the explanation short and evidence-based