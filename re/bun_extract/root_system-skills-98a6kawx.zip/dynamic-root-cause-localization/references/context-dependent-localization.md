## Context-Dependent Integration Defect Localization

Use this strategy only when the defect cannot be confidently explained from the local code alone, and root-cause confirmation requires external context.

### Objective

Refine localization by checking the local code together with the minimal necessary external context to identify the true integration-related root cause.

### Required actions

* Start from the top-ranked local candidate ranges.
* For every context-dependent case, you MUST first determine whether the relevant API, callee, caller, type, or dependency context belongs to the same repository.
* You MUST complete this in-repository check before considering any external-library inspection, decompilation, or dependency-level reasoning.

#### Case A: Context is inside the same repository
* Read:

  * `{{project_root_dir}}/codebase-structure.md`
  * `{{project_root_dir}}/codebase-docs/<MODULE_NAME>.md`
* Use them to determine the most relevant module and implementation directories for targeted inspection.
* Search only within the relevant in-repo folders to find related code files, API definitions, callees, callers, or dependency flow needed to confirm the root cause.
* If the relevant context can be resolved inside the repository, you MUST continue the localization within the repository and MUST NOT jump to external-library reasoning.

#### Case B: Context is not inside the same repository

* Only after the in-repository check is exhausted may you conclude that the relevant context points to an external library or dependency.
* Do NOT treat the external library implementation itself as the primary localization target.
* Instead, identify and explain how the current repository misuses, misunderstands, or incorrectly depends on that external API, contract, or behavior.
* If the defect is determined to be external-library-related, you MUST state this clearly in the root-cause explanation.


### Nested API inspection rule

* If a single line or expression contains nested API calls, inspect from the innermost API outward.
* Resolve inner-call semantics first, then analyze how the outer call depends on or misuses the inner result.

### Focus areas

* API misuse
* wrong argument propagation
* incorrect call order
* contract mismatch
* wrong dependency selection
* cross-module state or data-flow mismatch

### Constraints

* Expand across files only when needed to confirm the root cause.
* Keep the exploration narrow and traceable to the current candidate range.
* Do NOT perform broad speculative repository traversal.
* Do NOT speculate about hidden dependency behavior unless supported by visible usage evidence.

### Output requirements

For each selected hypothesis:

* identify the exact file and line range
* cite the matched anchors or snippets
* explain which external context was checked
* explain how the interaction between the local code and that context could produce the observed symptom
* if external-library-related, state that explicitly
* keep the explanation short and evidence-based

