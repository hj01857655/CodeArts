# JaCoCo Resolution Reference

## Purpose

Prepare JaCoCo for dynamic root-cause localization only when the required JaCoCo capability is missing or not safely usable.

This reference is runner-specific. The Agent MUST follow only the section matching the detected runner.

## Common Rules

- All generated or modified paths MUST be OS-native absolute paths.
- Existing build behavior MUST be preserved.
- Do NOT modify unrelated modules, tasks, plugins, dependencies, or repository configuration.
- Prefer command-based JaCoCo artifact resolution over build-file modification.
- Temporary build-file modification is allowed only when command-based resolution is unavailable or ineffective.

Backup directory for any temporary build-file modification:

`{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco-resolution/backups`

If any build file is temporarily modified, it MUST be backed up before modification and restored after JaCoCo execution or failure.

---

## A. Maven-based JaCoCo Resolution

Applies to:

- Maven runner
- direct `java` runner that can use Maven to resolve JaCoCo jars

Required artifacts:

- `org.jacoco:org.jacoco.agent:<version>:runtime`
- `org.jacoco:org.jacoco.cli:<version>:nodeps`

Expected local Maven repository jars:

```text
~/.m2/repository/org/jacoco/org.jacoco.agent/<version>/org.jacoco.agent-<version>-runtime.jar
~/.m2/repository/org/jacoco/org.jacoco.cli/<version>/org.jacoco.cli-<version>-nodeps.jar
````

### A.1 Select JaCoCo version

* Reuse an existing project-defined JaCoCo version property if it can be resolved safely.
* Otherwise, use `0.8.8` unless another project-local JaCoCo version is clearly required.

### A.2 Resolve JaCoCo jars using Maven commands

The Agent SHOULD resolve the required JaCoCo jars without modifying `pom.xml`.

Preferred commands:

```bash
mvn -U org.apache.maven.plugins:maven-dependency-plugin:3.6.1:get "-Dartifact=org.jacoco:org.jacoco.agent:<version>:jar:runtime"
```

```bash
mvn -U org.apache.maven.plugins:maven-dependency-plugin:3.6.1:get "-Dartifact=org.jacoco:org.jacoco.cli:<version>:jar:nodeps"
```

If the project uses Maven Wrapper, prefer:

```bash
./mvnw -U org.apache.maven.plugins:maven-dependency-plugin:3.6.1:get "-Dartifact=org.jacoco:org.jacoco.agent:<version>:jar:runtime"
```

```bash
./mvnw -U org.apache.maven.plugins:maven-dependency-plugin:3.6.1:get "-Dartifact=org.jacoco:org.jacoco.cli:<version>:jar:nodeps"
```
If a custom Maven settings file is required, include it before the plugin goal:
```bash
mvn -s <settings.xml> -U org.apache.maven.plugins:maven-dependency-plugin:3.6.1:get "-Dartifact=org.jacoco:org.jacoco.agent:<version>:jar:runtime"
```

```bash
mvn -s <settings.xml> -U org.apache.maven.plugins:maven-dependency-plugin:3.6.1:get "-Dartifact=org.jacoco:org.jacoco.cli:<version>:jar:nodeps"
```

Rules:

* Preserve required Maven invocation context when known, including:

    * Maven wrapper usage;
    * `-s <settings.xml>`;
    * repository or mirror configuration;
    * required profiles or project-specific Maven options.
* Do NOT use Maven offline mode.
* Do NOT modify `pom.xml` merely to download JaCoCo jars.
* If `dependency:get` succeeds, no build-file modification is allowed for artifact resolution.

### A.3 Locate resolved jars

After `dependency:get`, locate and normalize both resolved jars to OS-native absolute paths.

Set:

* `{{resolved_jacoco_agent_runtime_jar}}`
* `{{resolved_jacoco_cli_nodeps_jar}}`

Required checks:

* `{{resolved_jacoco_agent_runtime_jar}}` exists and is non-empty.
* `{{resolved_jacoco_cli_nodeps_jar}}` exists and is non-empty.
* The agent jar file name MUST match:

```text
org.jacoco.agent-<version>-runtime.jar
```

* The CLI jar file name MUST match:

```text
org.jacoco.cli-<version>-nodeps.jar
```

If either jar cannot be found, the Agent MUST perform one bounded retry with the project’s Maven wrapper or required `settings.xml` if available.

### A.4 Fallback: temporary POM modification

Use this fallback only if command-based Maven resolution fails or is unavailable.

Rules:

* Select the nearest relevant Maven project or the module that actually runs the target test.
* Back up the selected `pom.xml` before modification.
* Add only missing JaCoCo dependencies.
* Restore the original `pom.xml` after JaCoCo execution or failure.

Temporary dependency example:

```xml
<dependency>
    <groupId>org.jacoco</groupId>
    <artifactId>org.jacoco.agent</artifactId>
    <version>${jacoco.version}</version>
    <classifier>runtime</classifier>
    <scope>test</scope>
</dependency>
<dependency>
<groupId>org.jacoco</groupId>
<artifactId>org.jacoco.cli</artifactId>
<version>${jacoco.version}</version>
<classifier>nodeps</classifier>
<scope>test</scope>
</dependency>
```

Rules:

* `${jacoco.version}` is illustrative.
* The actual version MUST be either an existing project property or a concrete version such as `0.8.8`.
* Dependencies MUST be added only if absent.
* If `<dependencies>` is absent, create the minimal `<dependencies>` section under `<project>`.
* Do NOT modify unrelated modules or Maven configuration.

After modification, run Maven dependency resolution using the project’s original Maven invocation style, then locate the resolved jars as defined in A.3.

If resolution still fails, stop and report a JaCoCo artifact resolution failure.

---

## B. Gradle-native JaCoCo Preparation

Applies to:

* Gradle runner

### B.1 Select Gradle project

Identify the Gradle project or subproject that actually runs the target test.

If temporary configuration is needed, back up the relevant file before modification:

* `build.gradle`
* `build.gradle.kts`
* relevant convention plugin file

### B.2 Minimal required Gradle capability

The selected Gradle project MUST have:

1. the `jacoco` plugin applied;

2. the relevant `Test` task configured to write execution data to:

   `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco.exec`

3. optionally, a `JacocoReport` task capable of generating XML output at:

   `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_report.xml`

For Gradle runner, XML MAY be generated by Gradle `JacocoReport`. If Gradle does not generate XML, the later Python pipeline MAY generate XML only when a valid JaCoCo CLI jar is available and module-local class/source roots are verified.

### B.3 Groovy DSL example

Use only for `build.gradle`.

```groovy
plugins {
    id 'jacoco'
}

jacoco {
    toolVersion = '0.8.8'
}

tasks.withType(Test).configureEach {
    jacoco {
        destinationFile = file('<canonical-jacoco-exec-path>')
    }
}

tasks.register('bugfixJacocoReport', JacocoReport) {
    executionData file('<canonical-jacoco-exec-path>')

    sourceDirectories.from files(sourceSets.main.allSource.srcDirs)
    classDirectories.from files(sourceSets.main.output)

    reports {
        xml.required = true
        html.required = false
        csv.required = false
        xml.outputLocation = file('<canonical-jacoco-xml-path>')
    }
}
```

### B.4 Kotlin DSL example

Use only for `build.gradle.kts`.

```kotlin
plugins {
    jacoco
}

jacoco {
    toolVersion = "0.8.8"
}

tasks.withType<Test>().configureEach {
    extensions.configure<JacocoTaskExtension> {
        destinationFile = file("<canonical-jacoco-exec-path>")
    }
}

tasks.register<JacocoReport>("bugfixJacocoReport") {
    executionData(file("<canonical-jacoco-exec-path>"))

    sourceDirectories.setFrom(files(sourceSets.main.get().allSource.srcDirs))
    classDirectories.setFrom(files(sourceSets.main.get().output))

    reports {
        xml.required.set(true)
        html.required.set(false)
        csv.required.set(false)
        xml.outputLocation.set(file("<canonical-jacoco-xml-path>"))
    }
}
```

Rules:

* `<canonical-jacoco-exec-path>` MUST be replaced with:

  `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco.exec`

* `<canonical-jacoco-xml-path>` MUST be replaced with:

  `{{project_root_dir}}/.bugfix/{{issue_number}}/localization/jacoco_report.xml`

* Preserve existing test framework configuration, such as `useJUnitPlatform()`.

* Do NOT rewrite unrelated Gradle tasks, plugins, dependencies, or repository configuration.

If Gradle-native JaCoCo configuration cannot be applied safely, stop and report that the current Gradle runner is not safely instrumentable.

