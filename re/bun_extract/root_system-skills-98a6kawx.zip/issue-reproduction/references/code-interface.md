## Code Interface Reproduction

### Goal
Generate and execute exactly one minimal, runnable, repository-aligned UT-form reproducer that triggers the defect and yields raw execution evidence.

The agent MUST reproduce the issue in unit-test form.
The agent MUST first search the repository for reusable test templates, especially under `src/test/**`, and use them whenever possible.

Code entry point confirmation, invocation-shape analysis, template retrieval, and execution-context derivation are preparatory steps only.
None of them can be treated as completion of this goal.

This goal is complete only when:
- a concrete UT-form reproducer has been generated,
- the reproducer has been executed,
- and raw execution evidence has been collected.

### Mandatory Reproduction-First Rule

Finding a likely root cause, suspicious file, high-confidence defect location, or seemingly sufficient static evidence does NOT satisfy the goal of this skill and MUST NOT be used to skip reproducer generation, execution, or evidence collection.

The agent MUST NOT use trigger-path difficulty, execution complexity, environment limitations, static-analysis confidence, or any other convenience-based reason to skip reproducer generation.

Before claiming that reproduction is difficult or impractical, the agent MUST first search the repository for reusable test templates, especially related test cases under `src/test/**`.

If repository evidence shows that a test template can preserve the required invocation semantics, the agent MUST generate a reproducer from that form and MUST NOT proceed to downstream phases without doing so.

### Global Search Scope Constraint

Before performing any repository search, you MUST determine a bounded search scope.

Procedure:

1. Read:

```

{{project_root_dir}}/codebase-structure.md

```
2. Identify the most relevant module name based on:

* issue/analysis evidence,
* package prefix hints,
* stacktrace information (if available).
3. Read:

```

{{project_root_dir}}/codebase-docs/<module_name>-structure.md

```
4. Determine the module root directory and set it as `search_root`.

5. ***All Grep/Glob operations MUST be executed with an explicit scope:***
```

Grep/Glob "<pattern>" in {{search_root}}

```

Unscoped Grep/GLob is FORBIDDEN.

If scoped Grep/GLob returns too many matches, you MUST narrow scope further
(e.g., module_root → specific package directory) and retry, rather than removing scope.

## Workflow

### Step 1: Confirm code entry point and Invocation Signature

MUST identify:
- the fully-qualified code entry identifier (e.g., `com.pkg.Class#method`, `module.func`)
- the module (if applicable)

Entry point MUST be evidence-backed using:
- `analysis_results.json`
- stacktrace frames
- error signatures

MUST NOT infer or invent a new code entry point without explicit evidence.

If multiple candidates exist, you MUST narrow down to exactly one primary entry point and record justification.

MUST also confirm:

#### 1.1 Invocation Shape
Describe the minimal call pattern required to trigger the defect.

Constraints:
- MUST NOT include concrete argument values.
- MUST preserve required call ordering.
- MUST reflect semantic constraints implied by the issue.

#### 1.2 Required Setup and Semantic Preconditions
Identify:
- minimal executable setup,
- any semantic preconditions implied by the issue.

These MUST be derived from issue evidence and MUST NOT be fabricated.

### Step 2: Retrieve and Select Test Template

Using the confirmed `entry_point` and related tokens, you MUST search the repository for related functional test cases that can serve as templates for a UT-form reproducer.

Search locations (in order):

1. `src/test/**`
2. `examples/`, `samples/`
3. main module usage sites
4. repo documentation snippets

Mandatory rules:
- `src/test/**` MUST be searched first and completed before any non-test location is considered.
- If related test cases exist in `src/test/**`, the agent MUST evaluate them first as reproducer templates.
- The agent MUST NOT bypass a suitable test template merely because writing a new test appears easier.
- The agent MUST NOT skip this template search.

For each candidate, record:
- file path
- matched tokens
- whether invocation matches the confirmed entry point
- whether setup/initialization matches the required semantics
- whether test-scope dependencies or lifecycle support are involved

Store matched paths in `template_paths`.

If one template clearly reflects the required invocation semantics, you MUST select it and record `selected_template_path`.

### Step 3: Determine Minimal Execution Context

Derive the minimal execution context from `codebase-structure.md`, the confirmed code entry point, and the generated UT-form reproducer plan.

MUST use the global build/test commands recorded in `codebase-structure.md` as the authoritative command source. 

#### 3.1 Determine minimal execution scope

Identify the smallest module scope that contains:

* the generated UT-form reproducer;
* the module containing the confirmed code entry point;
* required upstream dependencies.

Prefer module-scoped execution over full-repository execution.

For Maven multi-module commands, any use of `-pl` MUST include `-am`.

Full-repository execution is allowed only when module isolation is impossible.

#### 3.2 Determine build/run split

Determine `build_cmd` and `run_cmd` exactly once in this step.

Derive `run_cmd` by adapting the global test command to the selected module scope and generated reproducer.

If `run_cmd` is a repository-native test command that compiles required sources before execution, set `build_cmd` to an empty string.

If `run_cmd` only executes an already-built artifact, set `build_cmd` to the minimal command required to compile or prepare that artifact.

The Agent MUST avoid duplicate compilation. It MUST NOT set both:

* a separate compile-only `build_cmd`, and
* a `run_cmd` that already performs compilation.

Record the selected scope, `build_cmd`, `run_cmd`, and build/run split justification in `execution_context.json`.

#### 3.3 Command hardening

Only minimally rewrite commands to preserve repo-defined execution behavior, such as:

* applying the selected module scope;
* adding Maven `-am` when `-pl` is used;
* preserving wrapper scripts or config flags already present in `codebase-structure.md`;
* converting paths to absolute paths when needed.

Do NOT change build systems, build targets, dependency configuration, or execution semantics.

### Output (MANDATORY)

Persist the execution context as:

`{{reproduction_workspace}}/execution_context.json`

The generated file MUST conform to:

`{{skill_root}}/schema/execution_context.schema.json`

Additionally, persist the reproduction invocation context as:

`{{reproduction_workspace}}/repro_context.json`

The generated file MUST conform to:

`{{skill_root}}/schema/repro_context.schema.json`


---

### Step 4: Generate Exactly One Minimal UT-Form Reproducer

Step 4 is mandatory for every CODE_INTERFACE reproduction attempt.

- Generate exactly one UT-form reproducer.
- The reproducer MUST:
  - invoke the confirmed code entry point,
  - represent exactly one defect scenario,
  - contain no unrelated logic.

- If `selected_template_path` exists, the reproducer MUST mimic its invocation structure while removing unrelated logic.
- If a suitable test template exists, the agent MUST generate the reproducer from that template.

Constraints:
- every line MUST directly contribute to triggering or observing the defect;
- no randomness, no unrelated logic, no unnecessary mocking;
- all generated artifact paths MUST be absolute and MUST match `execution_context.json`.

Persist all generated artifacts under the reproduction workspace.

#### Optional Step: Create Input Artifacts

If the reproduction requires external inputs (files, configuration, payloads, datasets, etc.), you MUST follow:

`<skill_root>/references/input-artifact-generation.md`

to derive the minimal artifact specification and generate the required input artifact(s).

Any generated artifact MUST:
- reside under `{{reproduction_workspace}}`
- be referenced by the reproducer
- match the artifact paths recorded in `execution_context.json`

If no external inputs are required, this step MUST be skipped.

---

### Step 5: Create Dedicated Execution Script

* Load `execution_context.json`.
* Generate exactly one execution script:

`{{reproduction_workspace}}/run_repro.sh`

The script MUST:

* execute `build_cmd` only when `build_cmd` is non-empty;
* execute `run_cmd` exactly once;
* preserve the command sequence recorded in `execution_context.json`;
* operate on absolute paths only.

The build/run split MUST already be determined in `execution_context.json`.

`run_repro.sh` is the only authoritative reproduction execution entrypoint.

The script’s responsibility is execution only, not interpretation.

---

### Step 6: Apply Source-Level Diagnostic Traces

Before executing `run_repro.sh`, the agent MUST inject diagnostic traces.

Diagnostic traces MUST be injected into the narrowest issue-relevant project-owned production/library source location executed by the reproducer.

The agent MUST NOT satisfy this step by instrumenting only:

* the generated reproduction test;
* test helper files;
* configuration files;
* scripts;
* build files;
* wrapper files;
* execution carriers.

Test/carrier-level traces are allowed only as supplementary traces. At least one diagnostic trace MUST be inserted into `project_source`.

The agent MUST apply the following instrumentation principles:

1. **Logical decomposition**
   Instrument the smallest relevant logical unit, such as a method body, branch, loop, parser step, adapter dispatch, validator decision, state update, or exception construction site.

2. **State traceability**
   Record issue-relevant inputs, transformed values, intermediate values, selected objects/types, outputs, and state before/after the suspected logic.

3. **Control-flow traceability**
   Record which issue-relevant branch, handler, adapter, implementation, parser path, validator path, or exception path is actually selected.

4. **Causal usefulness**
   Each trace MUST answer a concrete debugging question. Do not add broad, noisy, or unrelated traces.

All diagnostic traces MUST use prefix `[BUGFIX_REPRO_TRACE]`.

The agent MUST keep diagnostic traces in place for reproduction execution.

The agent MUST write a schema-conformant record to:

`{{reproduction_workspace}}/diagnostic_instrumentation.json`

The record MUST conform to:

`{{skill_root}}/schema/diagnostic_instrumentation.schema.json`

The record MUST include at least one `instrumented_locations` item with:

* `location_type="project_source"`;
* a concrete `debug_question`;
* a concrete `trace_kind`;
* the observed values or branches intended to be printed.

The agent MUST NOT proceed to Step 7 until `diagnostic_instrumentation.json` exists and passes schema validation.

---

### Step 7: Execute and Collect Raw Evidence

- MUST execute the reproduction exclusively via `run_repro.sh`.
- MUST persist the following artifacts under the reproduction workspace:
  - `stdout.txt`
  - `stderr.txt`
  - `exit_code.txt`
  - any output results of SUT

- If diagnostic traces were injected, MUST extract all output lines containing `[BUGFIX_REPRO_TRACE]` from `stdout.txt`, `stderr.txt`, generated logs, or SUT output files, and save them to:

  `{{reproduction_workspace}}/diagnostic_observations.txt`

- After execution, the agent MUST update `diagnostic_instrumentation.json` with whether `[BUGFIX_REPRO_TRACE]` output was observed.

- If no trace output is observed, the agent MUST set `trace_output_observed=false` and fill `missing_trace_output_reason`.

- If trace output is observed, the agent MUST save all `[BUGFIX_REPRO_TRACE]` lines to `diagnostic_observations.txt` and set `diagnostic_output_path` accordingly.

- The updated `diagnostic_instrumentation.json` MUST still conform to:

  `{{skill_root}}/schema/diagnostic_instrumentation.schema.json`

---

### Step 8: Controlled Fallback to MINIMAL_MAIN

Fallback to `MINIMAL_MAIN` is allowed only when the UT-form reproducer has been generated, executed through the repository-aligned test path, and still cannot run due to environment or test-framework configuration problems after bounded execution-context refinement.

Fallback is forbidden when the UT-form reproducer is executable but semantically invalid, including wrong entry point, wrong setup/input, wrong assertion, or mismatch with the issue behavior. In such cases, refine the UT-form reproducer instead.

Constraints:

* `MAX_UT_EXECUTION_ATTEMPTS = 3`
* fallback MUST NOT be used because UT-form execution is complex, slow, inconvenient, or because `MINIMAL_MAIN` appears easier;
* fallback MUST replace the current reproducer with exactly one `MINIMAL_MAIN` reproducer;
* the `MINIMAL_MAIN` reproducer MUST preserve the same confirmed entry point, call ordering, setup, and semantic preconditions.

Record the fallback decision in `repro_context.json`, including:

* failed UT execution evidence;
* why the failure is an environment or test-framework configuration problem;
* what bounded refinement was attempted;
* why UT-form execution is still not viable;
* how `MINIMAL_MAIN` preserves the original invocation semantics.

---

### Step 9: Assess Reproducer Correctness

Compare the collected execution evidence against `analysis_results.json`, focusing on:
- defect preconditions,
- the code entry point and invocation shape,
- the required setup and execution path,
- the observable bug signature,
- if the issue contains an exception stack trace, error trace, or diagnostic trace, whether the reproduced failure matches the issue-indicated trace path on exception/error type, core error message, key project/library stack frame(s), and defect-triggering code entry path.

Confirm whether the reproducer:
1. encodes the required preconditions,
2. invokes the correct code entry point,
3. produces an issue-consistent observable signature,
4. when trace evidence is available in the issue, preserves the issue-indicated failure path as much as practical.

Determination rules:
- If the reproducer did not reach the intended code entry point, mark as `REPRODUCER_INVALID`.
- If the reproducer reaches the entry point but fails due to context wiring errors, mark as `REPRODUCER_INVALID`.
- If the issue contains trace evidence and the reproduced failure has a materially different exception/error type, core error message, key project/library stack frame(s), or defect-triggering API/command path, refine the reproducer or mark the attempt as `REPRODUCER_INVALID`; do NOT treat it as high-confidence reproduced.
- If the reproducer reaches the entry point and context is correct, but the expected bug signature is absent, bounded refinement is allowed before considering `NOT_REPRODUCED`.

If reproducer correctness is not confirmed:
- mark the attempt as `REPRODUCER_INVALID`,
- do NOT conclude `NOT_REPRODUCED`,
- proceed to Step 9.

---

### Step 10: Iterative Refinement

Before refinement, read `{{project_root_dir}}/.bugfix/bugfix-config.yaml` and set `MAX_ATTEMPTS` from `reproduction_settings.iteration_count`.

Trigger:

* reproducer marked as `REPRODUCER_INVALID`, or
* execution blocked by concrete errors.

Refinement order:

1. refine the UT-form reproducer;
2. refine execution context only when evidence requires it;
3. refine concrete arguments/inputs only when issue preconditions require it;
4. consider issue-fixed hypothesis only as a last resort.

Constraints:

* each iteration MUST record the change, reason, and supporting evidence.
* If `reproduction_settings.iteration_count` is missing or invalid, default `MAX_ATTEMPTS = 5`.
