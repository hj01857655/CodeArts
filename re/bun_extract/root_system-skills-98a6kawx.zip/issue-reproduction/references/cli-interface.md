### CLI Interface Reproduction

This document defines how to derive and execute a **CLI-based reproducer**
for a defect-triggering interface classified as **CLI_INTERFACE**.

The goal is to construct a deterministic execution entry that runs the
reproduction exactly as defined by the repository evidence and the
confirmed execution context.

---

### Authority & Evidence

- If `{{project_root_dir}}/codebase-structure.md` exists, you MUST load and treat it as the **primary hint source** for candidate commands or entrypoints.

- Candidate commands MAY also be derived from:

    - repository documentation,
    - CI configuration files,
    - build scripts,
    - example commands found in the repository.

- You MUST NOT invent commands without repository evidence.

- However, you MAY perform **evidence-driven minimal command hardening**
  to make candidate commands runnable in the current repository.

---

### Execution Context Confirmation

Before generating the execution script, the following must be confirmed:

- `build_cmd`: optional command required to build the project.
- `run_cmd`: the CLI command responsible for triggering the defect.

Both commands MUST be derived from repository evidence.

The execution context MUST be persisted as:

```

{{reproduction_workspace}}/execution_context.json

```

The file MUST conform to:

```

{{skill_root}}/schema/execution_context.schema.json

```

---

### Optional Step: Create Input Artifacts

If the reproduction requires external inputs (files, configuration, payloads, datasets, etc.), you MUST follow:

```

<skill_root>/references/input-artifact-generation.md

```

to derive the minimal artifact specification and generate the required input artifact(s).

Any generated artifact MUST:

- reside under `{{reproduction_workspace}}`,
- be referenced by absolute path in `run_cmd`,
- match the artifact paths recorded in `execution_context.json`.

If no external inputs are required by the CLI interface, this step MUST be skipped.

---

### Step: Create Dedicated Execution Script

#### Goal

Create a single deterministic execution entry that runs the reproduction exactly as specified.

---

#### Rules

You MUST generate exactly one execution script:

```

{{reproduction_workspace}}/run_repro.sh

```

The script MUST:
- MATCH the content recorded in `execution_context.json`.
- execute `build_cmd` (if non-empty),
- execute `run_cmd`,
- operate using **absolute paths only**.

The script MUST NOT:

- re-derive commands,
- infer outcomes,
- embed verdict or correctness logic.

The script is responsible for **execution only**.

---

### Step: Execute and Collect Raw Evidence

#### Goal

Execute the reproduction deterministically and collect **raw, uninterpreted evidence**.

---

#### Rules

You MUST execute the reproduction **exclusively via `run_repro.sh`**.

You MUST persist the following artifacts and any outputs of this execution under the reproduction workspace:

- `stdout.txt`
- `stderr.txt`
- `exit_code.txt`
- any output artifacts produced by the SUT

You MUST NOT:

- assess reproduction correctness,
- infer success or failure,
- modify any artifact after execution.

All collected artifacts represent **raw execution evidence only**.

---

### Step: Assess Reproducer Correctness

* Compare the execution evidence (`stdout.txt`, `stderr.txt`, `exit_code.txt`, and any produced artifacts) against `analysis_results.json`, focusing on:

  * defect preconditions (environment/config assumptions relevant to artifact consumption),
  * **input artifact structural requirements** (type/format/schema/version/required fields),
  * **artifact consumption mode** and binding (CLI arg/stdin/config/fixture discovery),
  * observable bug signature (error message pattern, crash type, incorrect output signature, etc.).

* Confirm whether the reproducer:

  1. **encodes required preconditions** for artifact consumption (as described in the issue),
  2. **ensures the SUT actually consumes** any generated input artifact via the declared `run_cmd`,
  3. provides an **issue-consistent observable signature** that can be checked deterministically from collected evidence.

* Determination rules (Mandatory, evidence-driven):

  * If the evidence does NOT show that the artifact was consumed (e.g., tool reports missing/ignored input, wrong mode, wrong path),
    mark as `REPRODUCER_INVALID` (do NOT conclude `NOT_REPRODUCED`).
  * If the artifact consumption is correct but the artifact **does not satisfy format/structure constraints** implied by the issue/repo evidence,
    mark as `REPRODUCER_INVALID`.
  * If artifact consumption and structure are correct but the expected bug signature is absent,
    you MAY proceed with bounded refinement before considering `NOT_REPRODUCED`.

* If reproducer correctness is NOT confirmed:

  * mark the attempt as `REPRODUCER_INVALID`,
  * you MUST NOT conclude `NOT_REPRODUCED`,
  * proceed to iterative refinement.

---

### Step: Iterative Refinement

Trigger:

* Reproducer marked as `REPRODUCER_INVALID`, or
* execution blocked by concrete errors.

Refinement order (MUST follow):
Build Configuration Check (Highest Priority)

If the build reports missing JARs, unresolved dependencies, missing plugins, or repository access failures, first verify whether the compilation is using the project-provided build configuration files from the project root (e.g., settings.xml).

Do not attribute the failure to missing dependencies or environment issues before this check is completed.

1. **Execution Context Refinement (Only if Evidence Requires)**

* First prefer repo-provided build configuration from the project root (e.g., settings.xml) before concluding dependency or environment issues.
* Modify build/run context ONLY when indicated by errors:
  * dependency resolution failures,
  * missing tool wrapper/config,
  * symbol resolution/build failures,
  * missing resources required for artifact consumption.

* You MUST apply minimal repo-local hardening only (wrapper/config/env from repo evidence).

2. **Artifact Specification / Consumption Refinement (Highest Priority)**

* Adjust the reproduction to ensure the SUT consumes the artifact as intended:
  * fix `run_cmd` binding to the artifact path(s),
  * switch consumption mode ONLY if supported by repo evidence (CLI arg ↔ stdin ↔ config_ref ↔ fixture discovery),
  * align with repo-local documented conventions (subcommand/flag name/expected directory layout).

* Evidence gate:

  * every adjustment MUST be directly motivated by observed logs/errors or repo evidence.

3. **Input Artifact Content Refinement (Second Priority)**

* Re-invoke:

```

<skill_root>/references/input-artifacts-generation.md

```

to regenerate the artifact instance with minimal changes based on observed errors.

* Constraints:

  * keep exactly one scenario,
  * minimal change per iteration,
  * no unrelated content.


4. **Issue-Fixed Hypothesis (Last Resort)**

* Allowed ONLY if:

  * artifact consumption correctness has been confirmed,
  * input artifact satisfies the confirmed structure constraints,
  * execution context is correct,
  * repeated executions yield stable non-reproduction with consistent evidence.

Constraints:

```
MAX_ATTEMPTS = 10

```
