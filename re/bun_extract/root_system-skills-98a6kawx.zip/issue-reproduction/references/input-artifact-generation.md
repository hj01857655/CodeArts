### Input Artifact Generation

This document defines how to derive and generate **input artifacts**
that may be required to trigger the defect.

Input artifacts are **optional reproduction assets** and may be required
by either **CLI_INTERFACE** or **API_INTERFACE**.

This document defines **artifact specification and generation only**.

Execution commands, API invocation logic, and execution context
MUST be handled by the corresponding interface reproduction logic.

---

### Phase A: Confirm Input Artifact Specification

#### Goal

Confirm the **type and minimal structural requirements** of the input artifact
needed to trigger the defect.

---

### Authority & Evidence

Artifact specifications MUST be derived from repository evidence, including:

- sample inputs or fixtures
- documented input formats
- input parsing code
- configuration loaders
- example commands or API usage referencing input files

You MUST NOT invent input formats without repository evidence.

---

### Confirm Artifact Type

Based on `analysis_results.json` and repository evidence,
identify the artifact **type**, for example:

- JSON / YAML / XML
- binary file
- directory structure
- configuration file
- dataset fragment

The artifact type MUST correspond to what the SUT consumes.

---

### Confirm Minimal Structural Requirements

Determine the **minimal required structure** of the artifact, including:

- required fields
- structural hierarchy
- format constraints
- required file extensions
- schema or version indicators (if applicable)

This information MUST be derived from repository evidence such as:

- example inputs
- parsing logic
- configuration loaders
- schema definitions

Concrete field values MUST NOT be decided in this step.

---

### Phase B: Generate Exactly One Minimal Input Artifact

#### Goal

Generate **exactly one minimal artifact instance**
that conforms to the confirmed specification.

---

### Rules

The generated artifact MUST:
- Ensure there are no indentation errors.
- match the "reproduction_seed_snippet" in the issue analysis result
- match the confirmed artifact type
- satisfy the minimal structural requirements
- represent **exactly one defect-triggering scenario**

Every element in the artifact MUST directly contribute to triggering or observing the defect.

Constraints:

- No randomness
- No external inputs
- No network access unless explicitly required by repository evidence

Artifact paths MUST:

- be absolute
- reside under `{{reproduction_workspace}}`

The artifact MUST be referenced by the interface reproduction logic
(e.g., CLI argument, API parameter, configuration reference).

---

### Phase C: Artifact-Aware Validation

After execution of the reproduction attempt,
the interface reproduction logic may invoke artifact validation.

Artifact validation focuses on whether:

- the artifact was successfully consumed by the SUT
- the artifact structure matches the expected format
- the artifact binding (CLI argument / API parameter / configuration reference)
  is correct

If logs or evidence indicate that the artifact was **not consumed**
or **structurally invalid**, the reproduction attempt MUST be marked:

```

REPRODUCER_INVALID

```

The interface reproduction logic MAY then trigger artifact regeneration.

---

### Phase D: Artifact Content Refinement (Optional)

Artifact refinement MAY be triggered when:

- artifact parsing fails
- artifact schema validation fails
- required fields are missing
- artifact structure prevents the SUT from consuming the artifact

Refinement MUST:

- adjust only the **artifact structure or content**
- keep exactly **one scenario**
- apply **minimal changes per iteration**


Those adjustments MUST be handled by the corresponding  interface reproduction logic.

Artifact refinement is **bounded** and should only occur when execution evidence indicates that the artifact itself is invalid.
```

