---
name: issue-reproduction
description: Generate, compile, execute, and iteratively refine a minimal reproduction test from canonical issue analysis; determine minimal execution context autonomously; collect execution evidence; emit a schema-conformant reproduction result record.
---

# Issue Reproduction

## Purpose
Generate a minimal, executable reproduction test that captures the core defect-triggering logic inferred from the canonical issue analysis, then determine an executable context and minimal scope, compile and execute it deterministically, collect evidence, and emit a schema-conformant reproduction result record.

This skill is a mandatory execution phase, not an analysis-only phase and not a root-cause-localization phase.

MUST NOT skip reproduction test generation and directly generate `reproduction_result.json`.
MUST execute a concrete reproduction test.
MUST follow the DTI-specific workflow by reading the corresponding reference file and executing its required steps.
**MUST NOT treat environment limitations as justification for skipping reproduction test generation.**

This skill is complete only when all of the following have been finished:

1. a concrete reproduction test/carrier has been generated;
2. the required execution context has been determined and persisted;
3. the reproduction has been actually executed;
4. raw execution evidence has been collected;
5. diagnostic trace evidence has been collected or the reason for unavailable trace evidence has been recorded;
6. the required schema-conformant output record has been produced.

**If the current attempt cannot yet generate or execute a valid reproducer, the agent MUST continue refinement within this skill rather than proceeding to the next phase**.

## Reproduction Phase Boundary

This skill MUST NOT confirm, finalize, or lock the root cause.

The agent's responsibility in this phase is limited to:
- generating and executing a concrete reproducer;
- recording expected behavior, observed behavior, reproducibility status, and raw execution evidence;
- preserving observed stack trace paths, executed APIs, and diagnostic traces as evidence for later localization.

Stack traces, suspicious methods/classes, issue-reported guesses, diagnostic traces, and reproducer execution paths are NOT confirmed root cause.

The agent MUST NOT:
- state that a specific method, class, branch, condition, or code block is the root cause;
- write reproduction test comments, test names, assertion messages, logs, or summaries that describe an implementation defect as fact;
- propose or imply a patch location or fix direction;
- skip root-cause localization because the reproducer appears to expose the faulty code.

The agent MAY record suspicious or issue-indicated locations only as observed evidence, issue-reported hypotheses, or downstream localization hints.

## Input Contract
This skill consumes canonical artifacts from earlier phases when available.

MUST include:
- Canonical issue analysis result (`analysis_results.json`) content (provided inline or readable via path).

MAY include (when available):
- Project understanding (`codebase-structure.md`) including confirmed build/test commands and environment assumptions.
This skill MUST NOT require any static localization outputs as inputs.

## Reproduction Workspace
All artifacts produced by this skill MUST be stored under:
`{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/`

## Diagnostic Trace Policy

The selected DTI reference workflow MUST handle the diagnostic trace lifecycle as part of reproduction execution.

It MUST:

* decide whether diagnostic traces are needed before the final reproduction execution;
* inject `[BUGFIX_REPRO_TRACE]` traces when runtime path, branch decisions, selected implementations, state transitions, or exception-adjacent state cannot be confirmed otherwise;
* instrument the narrowest issue-relevant project-owned source location when test/carrier-level traces cannot expose the required internal runtime evidence;
* write `{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/diagnostic_instrumentation.json`;
* validate it against `{{skill_root}}/schema/diagnostic_instrumentation.schema.json`;
* write `diagnostic_observations.txt` when trace output is observed.

This skill MUST NOT remove diagnostic traces before reproduction completion. They are preserved for downstream localization and patch generation, and MUST be removed later before final patch export.


## Global Search Scope Constraint

Before performing any repository search, you MUST determine a bounded search scope.

Procedure:

1. Read:

```

{{project_root_dir}}/codebase-structure.md

```
2. Identify the most relevant module name based on:

* issue/analysis evidence,
* package prefix hints,
* stacktrace information (if available).
3. Read:

```

{{project_root_dir}}/codebase-docs/<module_name>-structure.md

```
4. Determine the module root directory and set it as `search_root`.

5. ***All Grep/Glob operations MUST be executed with an explicit scope:***
```

Grep/Glob "<pattern>" in {{search_root}}

```

Unscoped Grep/GLob is FORBIDDEN.

If scoped Grep/GLob returns too many matches, you MUST narrow scope further
(e.g., module_root → specific package directory) and retry, rather than removing scope.

## Workflow

### Step 1: Load Canonical Inputs
- Load `analysis_results.json` (canonical issue representation).
- If `codebase-structure.md` exists at `{{project_root_dir}}`, load it as the authoritative execution context reference (commands + environment assumptions).
- If a complete reproduction test or a complete stacktrace exists at `{{project_root_dir}}/.bugfix/{{issue_number}}/analysis/`, load it as **authoritative reproduction evidence** and preserve its content verbatim.

### Step 2: Interpret Defect Semantics
- Infer defect-triggering logic strictly from `analysis_results.json`:
    - preconditions, inputs, environment notes,
    - expected vs actual behavior,
    - any reproduction hints (treat as semantic guidance, do NOT copy verbatim unless explicitly required).
- Identify the minimal set of API calls / statements / configuration required to:
    1) trigger the defect, and
    2) observe a deterministic verdict.

- If the canonical issue analysis contains an exception stack trace, error trace, or diagnostic trace, the reproducer MUST be designed to preserve the issue-indicated failure path as much as practical.
- The reproducer SHOULD match the issue trace on:
    - exception/error type;
    - core error message;
    - key project/library stack frame(s);
    - defect-triggering API or command path.
- The reproducer is NOT required to match unrelated framework, test-runner, reflection, launcher, or harness frames.
- If the generated reproducer triggers the same external failure but through a materially different stack path, the agent MUST record the mismatch and either refine the reproducer or mark the reproduction confidence as limited/inconclusive according to the schema.
- The agent MUST NOT use trace matching to confirm root cause. Trace matching only validates that the reproduction reaches the issue-reported failure path.

### Step 3: Select DTI and Execute the Corresponding Workflow

From `analysis_results.json`, determine the primary defect-triggering interface (DTI). Choose exactly one:

* `CODE_INTERFACE`: triggered through an in-process programmatic code entry, such as a function, method, constructor, class API, library API, framework API, or unit-test callable entry, without requiring a separate running service process.
* `CLI_INTERFACE`: triggered by executing a command, executable, build command, CLI argument, script invocation, or command-line workflow.

If multiple interfaces exist, choose the one required by the issue preconditions and matching the observed failure mode.

Immediately after selecting the DTI, MUST read and execute exactly one corresponding reference workflow:

* If `DTI == CODE_INTERFACE`, read and execute:

  `{{skill_root}}/references/code-interface.md`

* If `DTI == CLI_INTERFACE`, read and execute:

  `{{skill_root}}/references/cli-interface.md`

The selected DTI reference MUST perform reproduction generation, diagnostic trace decision, diagnostic trace execution when required, and reproduction execution as one integrated workflow.

The selected reference MUST produce or overwrite:

* `{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/exec_context.json`
* `{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/run_repro.sh`
* `{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/diagnostic_instrumentation.json`

If diagnostic trace output is observed, the selected reference MUST also produce:

* `{{project_root_dir}}/.bugfix/{{issue_number}}/reproduction/diagnostic_observations.txt`

The selected reference MUST validate `diagnostic_instrumentation.json` against:

`{{skill_root}}/schema/diagnostic_instrumentation.schema.json`

Step 3 is complete only after the selected reference has finished and all required artifacts above exist.

The agent MUST NOT continue to Step 4 before `diagnostic_instrumentation.json` exists and passes schema validation.

### Step 4: Generate Final Reproduction Result Record

Only after the final reproduction judgement has been fully determined, the agent MUST:

- Load schema:
  `{{skill_root}}/schema/reproduction_result.schema.json`

- Populate required fields strictly per schema using:
  - evidence from the final reproduction attempt, and
  - MT result, if MT was required.

- Persist the final `reproduction_result.json` to the reproduction workspace.

The final `reproduction_result.json` MUST record:
- the final `reproduction_result`,
- the `reproduction_strategy`,
- whether MT was required,
- whether MT was executed,
- the final evidence-grounded `reproduction_analysis`,
- whether diagnostic traces were injected,
- where diagnostic traces were injected,
- whether diagnostic trace output was observed,
- and how the trace evidence affects reproduction refinement or downstream root-cause localization.

`reproduction_result.json` MUST be generated only in this step.
It MUST NOT be generated, loaded, or persisted earlier as the final authoritative result.