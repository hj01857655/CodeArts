---
name: generate-ut-for-ts
description: Generate high-coverage unit tests for TS/JS functions. Use when "generate unit test", "write unit test", or file path + function name is given. Not for integration/E2E tests.
language: javascript,typescript
---

# TS/JS Complex Function Unit Test Generation

Generate unit tests for complex TypeScript or JavaScript functions, ensuring line coverage >90% and branch coverage >=80%. Automatically detects Bun/Jest/Vitest/Mocha/node:test testing frameworks, and applies corresponding syntax rules based on language and framework detection results. The general workflow applies to any TS/JS project without over-relying on project-specific content.

## Workflow

### 1. Parse Request and Lightweight Analysis

- Extract file path and function name from the prompt; ask user if extraction fails
- **Language Detection**: `.ts`/`.tsx` → TS; `.js`/`.jsx`/`.mjs` → JS
- **Framework Detection** (when multiple configurations coexist, refer to `references/framework-detection-guide.md` as needed):
  1. Read import statements from existing test files in the target test directory (most reliable signal):
     - `from "bun:test"` → Bun; `from "@jest/globals"` or global `describe`/`it` → Jest; `from "vitest"` → Vitest; `from "chai"`/`sinon` → Mocha+Sinon; `from "node:test"` → node:test
  2. When no existing tests, check configuration files: `bunfig.toml`/`bun.lockb` → Bun; `jest.config.*` → Jest; `vitest.config.*` → Vitest; `.mocharc.*` → Mocha
  3. **Multiple Configurations Coexist**: When the target directory uses a different framework than other project directories, check 2-3 other test directories to determine project-level conventions, prioritizing project-level conventions (e.g., if project has 99 files using `bun:test` and 1 directory using `node:test`, choose `bun:test`)
  4. When no configuration files, infer from `package.json` scripts/devDependencies
- **Dependency Check**: Install dependencies when `node_modules` does not exist (use `bun install` for Bun projects, `npm install --ignore-scripts` for others). Verify that key imports from source files are resolvable (e.g., `ls node_modules/<pkg>`)
- **Path Aliases**: When source code uses `@/` aliases, prioritize using relative import paths in tests
- **When Source File Does Not Exist**: Search and confirm non-existence → If the task description fully defines target behavior, create the source file based on the description with `[created-from-task-description]` note; otherwise report as blocked

**TS/JS Key Differences (Inline Quick Reference):**

| Dimension      | TypeScript                     | JavaScript     |
| --------- | ------------------------------ | -------------- |
| Type Annotations  | `import type`, interfaces, generics      | None             |
| Mock Conversion | `as unknown as Type`           | Create objects directly   |
| Compile Check  | `tsc --noEmit` or framework compile passes  | `node --check` |
| Bare `any`  | Prohibited, use `Partial<T>`/factory functions | N/A         |

**Framework Mock API Quick Reference:**

| Operation      | Bun test                | Jest                    | Vitest                  | Mocha+Sinon          | node:test              |
| --------- | ----------------------- | ----------------------- | ----------------------- | -------------------- | ---------------------- |
| Create mock | `mock(fn)`              | `jest.fn()`             | `vi.fn()`               | `sandbox.stub()`     | `mock.method()`        |
| Async Success  | `m.mockResolvedValue()` | `fn.mockResolvedValue()`| `fn.mockResolvedValue()`| `stub.resolves()`    | `m.mockResolvedValue()`|
| Cleanup      | `mock.restore()`        | `jest.clearAllMocks()`  | `vi.clearAllMocks()`    | `sandbox.restore()`  | `m.mockRestore()`      |
| Module Mock | `mock.module()` (async) | `jest.mock()`           | `vi.mock()`             | `proxyquire`         | `mock.module()`        |

### 2. Analyze Target Function and Existing Tests

Read the target function in one go, extracting: function signature, execution paths (branches/loops/exceptions), external dependencies, async operations, edge conditions, function type (middleware/DI/event handler/regular).

**Existing Test Detection**:
- Find existing test files → Determine framework/assertion/Mock style → Test file placement (mirror source directory structure)
- **When existing tests exist, must actually run the existing test suite to get coverage data** (must not infer from code analysis alone). Identify uncovered branches based on coverage report
- Incremental mode (target function partially covered): Only supplement uncovered scenarios, **prohibited from rewriting or deleting existing tests**
- Full mode (no tests or target function uncovered): Write minimal initial test first → Run coverage → Then supplement edge cases

Refer to `references/mock-and-testing-patterns.md` as needed for framework-specific Mock templates, complex dependency strategies, and domain testing patterns.

### 3. Pre-Generation Confirmation

Before coding, output confirmation (2-4 lines):

- **Framework**: `____`
- **Mock Method**: `____` (e.g., `jest.fn()`/`vi.fn()`/`mock()`/`sandbox.stub()`)
- **Additional for TS Projects**: 1 typed Mock example
- **Additional for Incremental Mode**: Are existing test's Mock strategies compatible? If not, how to preserve existing tests? (e.g., create new file or use proxy pattern)

Execute according to the confirmed plan after confirmation. If Mock or import technical obstacles are encountered, adjusting specific Mock strategies is allowed (e.g., switching from `jest.mock` to manual injection), but the overall testing goal must not be abandoned. When encountering technical obstacles, specific issues must be reported and alternative solutions attempted, **no verification steps may be silently skipped**.

### 4. Design and Generate Tests

**Test cases must include:**

| Category     | Content                                                                 |
| -------- | -------------------------------------------------------------------- |
| Normal Path | happy path + Mock call argument verification (`toHaveBeenCalledWith` or equivalent)       |
| Edge Conditions | null, undefined, empty, 0, **threshold proximity values** (e.g., `age > 5min` tests `5min-1`, `5min`, `5min+1`) |
| Error Paths | Each throw, catch, reject                                            |
| Async Operations | Promise success/failure                                                    |

**Mock Principles:**
- Only Mock external dependencies (config, env, network, database); use real implementations for mature libraries
- TS: `as unknown as Type`, bare `any` prohibited; JS: create objects directly
- Set up Mocks before importing the module under test; rebuild in `beforeEach`, clean up in `afterEach`
- Modules with code executed on import: hoisted Mock variables + `jest.requireActual()` (Bun uses `await mock.module()`)
- ESM default export Mock: Add `__esModule: true` and `default` property in factory
- **Core Module Mock**: Node.js core modules (`fs`/`path`) properties are not configurable. Jest uses `jest.mock()` factory; Mocha+Sinon uses real temp files or `proxyquire`; Bun uses `mock.module()`
- **Complex Dependencies (5+ Mocks)**: Use factory functions to batch-create Mock objects; Mock dependencies step by step by priority (Mock modules blocking imports first, then business dependencies); if Mock complexity is too high, split into multiple test files. Refer to the "Complex Dependency Mock Strategy" chapter in `references/mock-and-testing-patterns.md`

**Test File Creation:**
- In incremental mode, create new test files or append to existing files, **prohibited from overwriting existing test files**
- New file naming follows project conventions (e.g., `-full.test.ts` suffix)

**Code Self-Check (Before Writing)**: Bracket matching, camelCase, no duplicate properties, variables declared before use, TS uses top-level `import type`, import paths match actual file paths.

**Assertion Validity**: Prohibited from using `expect(x).toBeDefined()` as the sole verification for complex objects.

### 5. Compilation Verification (Mandatory Gate)

- **TS (Jest/Vitest/Mocha)**: `npx tsc --noEmit <test-file>`; when tsconfig excludes test directory, framework compilation passing is sufficient
- **TS (Bun)**: `bun test <test-file>` compilation passing is sufficient (Bun has built-in TS support). Complex type modules may append `tsc --noEmit --skipLibCheck <test-file>` as supplementary
- **JS**: `node --check <test-file>`

### 6. Execute Tests and Coverage Verification (Mandatory Gate)

```bash
# Bun test
bun test <test-file> --coverage
# Jest
npx jest <test-file> --coverage --coverageReporters=text --coverageReporters=lcov
# Vitest
npx vitest run <test-file> --coverage
# Mocha + c8
npx c8 --reporter=text --reporter=lcov --src <source-file> npx mocha <test-file>
```

**Line Coverage >90% (Mandatory)**: Not met → Supplement tests → Re-execute. Maximum 5 rounds (first 3 automatic, 4-5 line-by-line analysis).

**Branch Coverage >=80% (Mandatory)**: Exempted when no BR/BRDA lines, but line coverage must not be skipped. **When multiple configurations coexist**: If project has both Bun and Jest configurations, consider using Jest for coverage to get branch coverage data (Bun does not generate BR/BRDA lines).

**Trust the Test Runner**: Once the test runner reports coverage targets are met, verification is complete. One coverage report check is allowed to identify uncovered lines for supplementing tests, but repeated manual checks after meeting targets are prohibited.

**Dead Code Escape**: Code paths that still cannot be triggered after 1 round of attempts are marked as dead code with a comment explaining why, then continue. Prohibited from modifying source code or using prototype mock to force coverage.

**Loop Detection**: Stop immediately when the same issue is analyzed repeatedly more than 3 times without progress.

**Run `node scripts/validate-coverage.mjs <source-file> --threshold 90 --branch-threshold 80` to verify coverage.** The script is located in the skill directory, use full path to execute. Refer to `references/coverage-verification.md` as needed.

### 7. Final Verification

**Mandatory Final Verification (After All Edits Complete):**

1. Compilation/syntax check passes
2. All tests pass (target test file only)
3. Line coverage >90%, branch coverage >=80% (or exempted)
4. At least one test file created or modified
5. Mock call arguments verified (`toHaveBeenCalledWith` or equivalent assertion)
6. No bare `any` (TS projects)
7. Middleware/route tests cover actual invocation behavior (if applicable)
8. Existing tests not deleted in incremental mode

## Constraints

1. Line coverage >90%, branch coverage >=80% (or exempted for no BR lines)
2. Compilation verification must actually be executed, speculative claims prohibited
3. All file operations within the specified task directory
4. Error scenarios mandatory coverage (null/undefined, exception throws, invalid input)
5. New tests consistent with existing test style, using project-configured framework
6. Only create/update test files for target functions
7. TS bare `any` prohibited; minimize Mocks, only Mock external dependencies
8. New code must be generated even if existing tests already cover the target
9. Mock call argument validation required when mocking external functions
10. Pre-generation confirmation (Step 3) must be completed before coding
11. Report and attempt alternative solutions when encountering technical obstacles, never silently skip verification steps

## Prohibited Behaviors

1. Do not modify source code under test
2. Do not skip failing tests (`xit`/`skip`)
3. Do not skip coverage verification
4. Do not modify unrelated files (supplementing `moduleNameMapper` excepted)
5. Do not run full test suite for coverage (target test file only)
6. Do not create helper scripts or temp files (use inline `node -e` instead)
7. Do not flatten test directory structure
8. Do not over-Mock internal implementations of mature libraries
9. Do not use inline `import('...').Type`, use top-level `import type`
10. Do not create `.env` files, Mock config module instead
11. Do not iterate on dead code for more than 1 round
12. Do not repeatedly attempt `tsc` when tsconfig excludes test directory
13. Do not run redundant manual coverage checks after tests pass and coverage targets are met
14. Do not abandon tasks or skip verification steps due to target function complexity or Mock difficulty
15. Do not rewrite or delete existing tests in incremental mode
16. Do not overwrite existing test files (create new files or append cases)

## Gotchas

- **Mock not taking effect**: `jest.mock()`/`vi.mock()`/`mock.module()` must be at the top of the file or in `beforeAll`, before importing the module under test. ESM projects require `--experimental-vm-modules` (Jest). Bun's `mock.module()` is async and must be `await`ed in `beforeAll`. (trace)
- **Async tests not executing assertions**: Forgot `return` Promise or `await`. Ensure all async tests correctly return or use async/await. (trace)
- **ESM default export Mock**: Add `__esModule: true` and `default` property in `jest.mock()` factory. (analyzer)
- **TS syntax used in JS projects**: After detecting language, corresponding syntax must be used. JS does not use `as unknown as`, `import type`. (manual)
- **Core Module Mock Fails**: Node.js core modules (`fs`/`path`) properties are not configurable, `jest.spyOn`/`sinon.stub` both fail. Jest uses `jest.mock()` factory; Mocha+Sinon uses real temp files or `proxyquire`; Bun uses `mock.module()`. (analyzer)
- **Bun mock.module Process-Level Scope**: `mock.module()` is process-level scoped and cannot be isolated to a single file. When testing both real fs and Mock fs in the same file is needed, use proxy pattern (conditional flag controls whether Mock intercepts) or create separate test files. (analyzer)
- **Windows bash Compatibility**: Avoid cmd syntax (`if exist`, `findstr`, `2>nul`) in bash shell on Windows. Use Unix-style commands (`ls`, `grep`, `2>/dev/null`). `2>nul` redirection will create a file named `nul` on Windows. (analyzer)

## Verification Checklist

- [ ] Test file exists and syntax is correct
- [ ] TS compilation passes or JS syntax check passes (Bun projects `bun test` compilation passes)
- [ ] All test cases pass (target test file only)
- [ ] Line coverage >90%
- [ ] Branch coverage >=80% (or exempted)
- [ ] At least one test file created or modified
- [ ] No bare `any` (TS projects)
- [ ] Mock call arguments verified (`toHaveBeenCalledWith` or equivalent assertion)
- [ ] Middleware/route tests cover actual invocation behavior (if applicable)
- [ ] Existing tests not deleted in incremental mode
- [ ] Run `node scripts/validate-coverage.mjs` to verify coverage

## Bundled Resources

- `references/framework-detection-guide.md`: Multi-framework detection decision tree (Bun/Jest/Vitest/Mocha/node:test), multiple configuration coexistence handling, project-level convention identification. **Refer as needed**: Only when framework detection is ambiguous or multiple configurations coexist.
- `references/ts-js-adaptation-guide.md`: Complete TS/JS difference comparison, tsconfig compilation options, cross-type Mock, import path decision tree, Bun TS compilation. **Refer as needed**: When encountering TS/JS adaptation issues in Steps 1 and 5.
- `references/mock-and-testing-patterns.md`: Complete Mock templates for each framework (TS+JS, including Bun/node:test), complex dependency Mock strategies, Bun mock.module proxy pattern, domain testing patterns, incremental testing guide. **Refer as needed**: When encountering Mock issues in Steps 2 and 4.
- `references/coverage-verification.md`: lcov.info parsing, dead code escape, iteration strategy, Bun coverage output handling, multi-configuration coverage tool selection. **Refer as needed**: When encountering coverage issues in Step 6.
- `scripts/validate-coverage.mjs`: Cross-platform coverage verification script. Run in Step 6: `node scripts/validate-coverage.mjs <source-file> --threshold 90 --branch-threshold 80`
