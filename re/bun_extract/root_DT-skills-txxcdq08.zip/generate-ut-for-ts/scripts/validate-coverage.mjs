#!/usr/bin/env node

/**
 * validate-coverage.mjs — 跨平台覆盖率验证脚本
 *
 * 检查 lcov.info 存在性、DA 行非零命中、行覆盖率阈值、分支覆盖率阈值。
 * 支持 DA/BR 和 DA/BRDA 两种 lcov.info 格式。
 *
 * v7 修复：在 end_of_record 时保存目标文件数据，避免多文件 lcov.info 中
 * 后续 SF: 行清空目标文件的 DA/BR 数组。
 *
 * 用法：
 *   node scripts/validate-coverage.mjs <source-file> --threshold 90 --branch-threshold 80 [--lcov-path coverage/lcov.info]
 *
 * 退出码：
 *   0 — 验证通过
 *   1 — lcov.info 不存在或为空
 *   2 — 未找到目标文件的 DA 行
 *   3 — DA 行全为零
 *   4 — 行覆盖率低于阈值
 *   5 — 分支覆盖率低于阈值
 *   6 — 内部错误
 */

import { readFileSync, existsSync, statSync } from "fs";
import { resolve, basename } from "path";

function parseArgs(args) {
  const positional = [];
  const named = {};
  let i = 0;
  while (i < args.length) {
    if (args[i].startsWith("--")) {
      const key = args[i].slice(2);
      const value = args[i + 1];
      if (value && !value.startsWith("--")) {
        named[key] = value;
        i += 2;
      } else {
        named[key] = true;
        i += 1;
      }
    } else {
      positional.push(args[i]);
      i += 1;
    }
  }
  return { positional, named };
}

/**
 * Match source file path in lcov.info SF line.
 * Priority: endswith exact match > includes fallback (with warning).
 */
function isTargetFile(filePath, sourceBaseName) {
  if (
    filePath.endsWith("/" + sourceBaseName) ||
    filePath.endsWith("\\" + sourceBaseName)
  ) {
    return { match: true, ambiguous: false };
  }
  if (filePath === sourceBaseName) {
    return { match: true, ambiguous: false };
  }
  if (filePath.includes(sourceBaseName)) {
    return { match: true, ambiguous: true };
  }
  return { match: false, ambiguous: false };
}

function main() {
  try {
    const { positional, named } = parseArgs(process.argv.slice(2));

    const sourceFile = positional[0];
    if (!sourceFile) {
      console.error(
        "Usage: node scripts/validate-coverage.mjs <source-file> --threshold 90 --branch-threshold 80 [--lcov-path coverage/lcov.info]",
      );
      process.exit(6);
    }

    const threshold = parseInt(named.threshold || "90", 10);
    const branchThreshold = parseInt(named["branch-threshold"] || "80", 10);

    // Step 1: Find lcov.info
    const lcovCandidates = named["lcov-path"]
      ? [named["lcov-path"]]
      : ["coverage/lcov.info", "lcov.info", ".nyc_output/lcov.info"];

    let resolvedLcovPath = "";
    for (const candidate of lcovCandidates) {
      const absPath = resolve(candidate);
      if (existsSync(absPath) && statSync(absPath).size > 0) {
        resolvedLcovPath = absPath;
        break;
      }
    }

    if (!resolvedLcovPath) {
      console.error(
        "FAIL: lcov.info not found in " + lcovCandidates.join(", "),
      );
      console.error("Hint: Re-run coverage with --reporter=lcov");
      process.exit(1);
    }

    console.log("Found lcov.info at: " + resolvedLcovPath);

    // Step 2: Read lcov.info
    let lcovContent;
    try {
      lcovContent = readFileSync(resolvedLcovPath, "utf-8");
    } catch (e) {
      console.error("FAIL: Cannot read lcov.info: " + e.message);
      process.exit(1);
    }

    if (!lcovContent.trim()) {
      console.error("FAIL: lcov.info is empty");
      console.error("Hint: Re-run coverage with --reporter=lcov");
      process.exit(1);
    }

    // Step 3: Parse lcov.info for target file
    // v7 fix: Save target file data at end_of_record instead of relying on
    // arrays surviving until end of loop (they get cleared by next SF: line)
    const sourceBaseName = basename(sourceFile);
    const lines = lcovContent.split("\n");
    let inTargetFile = false;
    let matchedAmbiguous = false;

    // Saved target file data (preserved across SF: boundaries)
    let targetDaLines = [];
    let targetBrLines = [];
    let targetFound = false;

    // Current file's temporary buffers
    let currentDaLines = [];
    let currentBrLines = [];

    for (const line of lines) {
      const trimmed = line.trim();

      if (trimmed.startsWith("SF:")) {
        // Start new file record — reset temp buffers
        inTargetFile = false;
        currentDaLines = [];
        currentBrLines = [];

        const filePath = trimmed.slice(3);
        const result = isTargetFile(filePath, sourceBaseName);
        if (result.match) {
          inTargetFile = true;
          matchedAmbiguous = result.ambiguous;
        }
      } else if (trimmed === "end_of_record") {
        // Save target file data when its record ends
        if (inTargetFile) {
          targetDaLines = [...currentDaLines];
          targetBrLines = [...currentBrLines];
          targetFound = true;
        }
        inTargetFile = false;
      } else if (inTargetFile) {
        if (trimmed.startsWith("DA:")) {
          currentDaLines.push(trimmed);
        } else if (trimmed.startsWith("BR:") || trimmed.startsWith("BRDA:")) {
          currentBrLines.push(trimmed);
        }
      }
    }

    // Handle case where lcov.info doesn't have end_of_record (malformed)
    if (!targetFound && inTargetFile) {
      targetDaLines = [...currentDaLines];
      targetBrLines = [...currentBrLines];
      targetFound = true;
    }

    if (matchedAmbiguous) {
      console.log(
        "WARNING: File matched by includes() fallback, not exact endswith. " +
          "Source basename '" +
          sourceBaseName +
          "' may match multiple files. " +
          "Verify the correct file was matched.",
      );
    }

    if (targetDaLines.length === 0 && targetBrLines.length === 0) {
      console.error(
        "FAIL: No DA/BR lines found for " + sourceBaseName + " in lcov.info",
      );
      console.error(
        "Hint: Use --src <source-file> when running c8 to scope coverage",
      );
      process.exit(2);
    }

    // Step 4: Analyze DA lines (line coverage)
    let totalLines = 0;
    let coveredLines = 0;
    const zeroHitLines = [];

    for (const daLine of targetDaLines) {
      const parts = daLine.substring(3).split(",");
      const lineNum = parseInt(parts[0], 10);
      const hitCount = parseInt(parts[1], 10);

      totalLines++;
      if (hitCount > 0) {
        coveredLines++;
      } else {
        zeroHitLines.push(lineNum);
      }
    }

    if (totalLines === 0) {
      console.error("FAIL: No DA lines found for " + sourceBaseName);
      process.exit(2);
    }

    const lineCoverage = (coveredLines / totalLines) * 100;
    const lineCoverageStr = lineCoverage.toFixed(1);

    console.log("Target file: " + sourceBaseName);
    console.log("Total lines: " + totalLines);
    console.log("Covered lines: " + coveredLines);
    console.log("Line coverage: " + lineCoverageStr + "%");
    console.log("Line threshold: " + threshold + "%");

    if (zeroHitLines.length > 0 && zeroHitLines.length <= 20) {
      console.log("WARNING: Zero-hit lines: " + zeroHitLines.join(", "));
    } else if (zeroHitLines.length > 20) {
      console.log(
        "WARNING: " +
          zeroHitLines.length +
          " zero-hit lines (too many to list)",
      );
    }

    if (coveredLines === 0) {
      console.error(
        "FAIL: All DA lines have zero hits - lcov.info may be stale",
      );
      console.error(
        "Hint: Re-run coverage with --reporter=lcov and --src <source-file>",
      );
      process.exit(3);
    }

    // Step 5: Analyze BR/BRDA lines (branch coverage)
    let branchFailed = false;
    let branchExempted = false;

    if (targetBrLines.length > 0) {
      let totalBranches = 0;
      let coveredBranches = 0;
      const uncoveredBranches = [];

      for (const brLine of targetBrLines) {
        const prefix = brLine.startsWith("BRDA:") ? "BRDA:" : "BR:";
        const parts = brLine.substring(prefix.length).split(",");
        const lineNum = parseInt(parts[0], 10);
        const takenCount = parts[3];

        totalBranches++;
        if (takenCount !== "-" && parseInt(takenCount, 10) > 0) {
          coveredBranches++;
        } else if (takenCount === "0") {
          uncoveredBranches.push("line " + lineNum);
        }
      }

      if (totalBranches > 0) {
        const branchCoverage = (coveredBranches / totalBranches) * 100;
        const branchCoverageStr = branchCoverage.toFixed(1);
        console.log(
          "Branch coverage: " +
            branchCoverageStr +
            "% (" +
            coveredBranches +
            "/" +
            totalBranches +
            ")",
        );
        console.log("Branch threshold: " + branchThreshold + "%");

        if (uncoveredBranches.length > 0 && uncoveredBranches.length <= 10) {
          console.log("Uncovered branches: " + uncoveredBranches.join(", "));
        } else if (uncoveredBranches.length > 10) {
          console.log(
            "WARNING: " +
              uncoveredBranches.length +
              " uncovered branches (too many to list)",
          );
        }

        if (Math.floor(branchCoverage) < branchThreshold) {
          console.error(
            "FAIL: Branch coverage " +
              branchCoverageStr +
              "% is below threshold " +
              branchThreshold +
              "%",
          );
          branchFailed = true;
        } else {
          console.log(
            "PASS: Branch coverage " +
              branchCoverageStr +
              "% meets threshold " +
              branchThreshold +
              "%",
          );
        }
      }
    } else {
      console.log(
        "WARNING: No BR/BRDA lines found for " +
          sourceBaseName +
          " in lcov.info.",
      );
      console.log(
        "This may occur in pure JS projects or when the coverage tool " +
          "(e.g., c8) is not configured to generate branch information.",
      );
      console.log(
        "Branch coverage threshold is EXEMPTED for this file. " +
          "Line coverage validation still applies.",
      );
      branchExempted = true;
    }

    // Step 6: Check line coverage threshold
    if (Math.floor(lineCoverage) < threshold) {
      console.error(
        "FAIL: Line coverage " +
          lineCoverageStr +
          "% is below threshold " +
          threshold +
          "%",
      );
      process.exit(4);
    }

    console.log(
      "PASS: Line coverage " +
        lineCoverageStr +
        "% meets threshold " +
        threshold +
        "%",
    );

    // Step 7: Check branch threshold
    if (branchFailed) {
      process.exit(5);
    }

    if (branchExempted) {
      console.log(
        "OVERALL: PASS (line coverage met, branch coverage exempted due to no BR data)",
      );
    }

    process.exit(0);
  } catch (e) {
    console.error("INTERNAL ERROR: " + e.message);
    process.exit(6);
  }
}

main();
