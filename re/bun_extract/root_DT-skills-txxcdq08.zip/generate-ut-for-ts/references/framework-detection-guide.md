# Framework Detection Guide

This file supports Step 1 of SKILL.md, providing a complete decision tree for multi-framework detection and multiple configuration coexistence handling. **Refer as needed**: Only when the inline detection steps in SKILL.md are insufficient to determine the framework.

## Detection Priority

Framework detection is performed in the following priority order, with the first match being the actual framework:

### Signal 1: Import Statements in Existing Test Files (Most Reliable)

Read existing test files (up to 2) in the target test directory and check import statements:

| Import Pattern                          | Framework           | Description                          |
| ------------------------------------ | -------------- | ----------------------------- |
| `import { ... } from "bun:test"`     | Bun test       | Bun built-in testing framework              |
| `import { ... } from "@jest/globals"`| Jest           | Jest explicit import mode             |
| Global `describe`/`it`/`expect` (no import) | Jest (default) | Jest global mode, requires `@types/jest` |
| `import { ... } from "vitest"`       | Vitest         | Vite ecosystem testing framework             |
| `import { expect } from "chai"`      | Mocha + Chai   | Mocha with Chai assertions          |
| `import sinon from "sinon"`          | Mocha + Sinon  | Mocha with Sinon Mock         |
| `import { test } from "node:test"`   | node:test      | Node.js built-in testing framework          |

### Signal 2: Configuration Files

When no existing test files, check configuration files in the project root:

| Configuration File                          | Framework           | Additional Signals                          |
| --------------------------------- | -------------- | --------------------------------- |
| `bunfig.toml` with `[test]` section      | Bun test       | Check if `bun.lockb` exists         |
| `bun.lockb` exists + no other test config | Bun test       | Bun projects default to `bun:test`       |
| `jest.config.*` (js/ts/json/mjs)  | Jest           | Check `preset` field (e.g., ts-jest)  |
| `vitest.config.*` (js/ts/mjs)     | Vitest         | May be configured in `vite.config.*`     |
| `.mocharc.*` (js/json/yml)        | Mocha          | Check `.c8rc.json`/`.nycrc` coverage config |

### Signal 3: package.json

When no configuration files, infer from `package.json`:

```json
{
  "scripts": {
    "test": "bun test"    // → Bun test
    "test": "jest"        // → Jest
    "test": "vitest"      // → Vitest
    "test": "mocha"       // → Mocha
  },
  "devDependencies": {
    "bun": "...",          // → Bun test (Bun is both runtime and test framework)
    "jest": "...",         // → Jest
    "vitest": "...",       // → Vitest
    "mocha": "..."         // → Mocha
  }
}
```

## Multiple Configuration Coexistence Handling

A project may have configuration files for multiple testing frameworks simultaneously (e.g., both `jest.config.ts` and `bunfig.toml`). Handling steps:

1. **Prioritize Signal 1**: Read import statements from existing test files in the target test directory
2. **Check Project-Level Conventions**: If the target directory uses a different framework than other project directories, check 2-3 other test directories to determine project-level conventions
   - Example: Target directory uses `node:test`, but project's 99 test files use `bun:test` → Choose `bun:test`
   - Example: Target directory uses `chai`, but other project directories use `@jest/globals` → Choose Jest
3. **If still undetermined**: Check `package.json`'s `scripts.test` field, use the framework that actually runs
4. **Final fallback**: Prefer Jest (most common TS testing framework) unless there are clear Bun signals

### Key Decision Rules

- **node:test in Bun Projects**: Bun can run `node:test` tests, but project conventions typically use `bun:test`. If `bun.lockb` or `bunfig.toml` exists, prioritize `bun:test`
- **Bun + Jest Coexistence**: Both can run TS tests. Selection criteria: which framework's imports existing test files use, which one `package.json` scripts.test points to
- **Coverage Tool Differences**: Bun does not generate BR/BRDA (branch coverage) data, Jest does. If branch coverage verification is needed, consider using Jest to run coverage

## Bun Project Identification

Bun projects have the following characteristics (meeting any one may indicate a Bun project):

| Signal                     | Reliability | Description                                         |
| ------------------------ | ------ | -------------------------------------------- |
| `bun.lockb` exists         | High     | Bun's binary lock file                            |
| `bunfig.toml` exists       | High     | Bun configuration file                                 |
| Test files `from "bun:test"` | Highest   | Direct evidence                                     |
| `package.json` scripts contains `bun test` | High | Script configuration                                     |
| `package.json` contains `"bun"` field | Medium | Bun-specific configuration                                 |

### Bun vs Jest Key Differences

| Dimension        | Bun test                         | Jest                           |
| ----------- | -------------------------------- | ------------------------------ |
| Test Run    | `bun test`                       | `npx jest`                     |
| Import      | `from "bun:test"`                | `from "@jest/globals"` or global  |
| Mock Create   | `mock(fn)`                       | `jest.fn()`                    |
| Module Mock   | `mock.module()` (async)          | `jest.mock()` (sync, hoisted)  |
| TS Support     | Built-in, no configuration needed                   | Requires ts-jest or `@swc/jest`    |
| Coverage      | `bun test --coverage` (built-in)     | `--coverage` (requires configuration)          |
| Branch Coverage  | Does not generate BR/BRDA lines                | Generates BR/BRDA lines                |
| ESM Support    | Native                             | Requires `--experimental-vm-modules` |
| Config File    | `bunfig.toml` (optional)             | `jest.config.*`                |

## Framework-Specific Notes

### Bun test

- **Built-in TypeScript**: No need for ts-jest, ts-node, or swc; Bun natively supports TS
- **mock.module() is Async**: Unlike Jest's `jest.mock()`, Bun's `mock.module()` returns a Promise and must be `await`ed in `beforeAll`
- **Built-in Coverage**: `bun test --coverage` directly outputs coverage, generating `coverage/` directory
- **No Global Mock**: Bun's `mock()` must be imported from `"bun:test"`, unlike Jest's global `jest`
- **mock.clearAllMocks()**: Bun supports both `mock.clearAllMocks()` and `mock.restore()` for cleanup
- **No Branch Coverage Data**: Bun's coverage tool does not generate BR/BRDA lines; branch coverage verification will be exempted

### Jest

- **ts-jest preset**: Check the `preset` field in `jest.config.*`; if using `ts-jest`, ensure `tsconfig.json` compatibility
- **Global vs Explicit Import**: Jest can use global `describe`/`it`/`expect` or import from `@jest/globals`
- **jest.mock Hoisting**: `jest.mock()` will be hoisted to the top of the file, but variables not hoisted cannot be referenced inside the factory
- **ESM Requires Additional Configuration**: `--experimental-vm-modules` + `transform: {}`

### Vitest

- **Vite Ecosystem**: Typically used with Vite; configuration may be in `vite.config.*` or `vitest.config.*`
- **Jest-Compatible API**: `vi.fn()`, `vi.mock()` are similar to Jest API
- **Coverage Requires Plugin**: Requires installing `@vitest/coverage-v8` or `@vitest/coverage-istanbul`

### Mocha + Sinon

- **No Built-in Mock**: Requires Sinon (`sandbox.stub()`) or proxyquire
- **Coverage Requires c8/nyc**: Mocha does not have built-in coverage; requires `npx c8` or `npx nyc`
- **Assertion Library Optional**: Chai (`expect`/`should`/`assert`) or Node.js built-in `assert`
- **Configuration File**: `.mocharc.json`/`.mocharc.yml`, check `spec` and `extension` fields

### node:test

- **Node.js Built-in**: No additional dependencies required; built into Node.js >= 18
- **Bun Compatible**: Bun can run `node:test` tests, but project conventions typically use `bun:test`
- **Mock API**: `import { mock } from "node:test"`, use `mock.method()`, `mock.fn()`
- **Coverage**: Requires c8 or nyc, same as Mocha
- **Assertions**: Typically paired with `node:assert` or `node:assert/strict`
