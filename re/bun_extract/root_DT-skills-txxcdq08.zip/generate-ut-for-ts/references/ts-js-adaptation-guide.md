# TS/JS Language Adaptation Guide

This file supports Steps 1 and 5 of SKILL.md, providing a complete TS/JS difference comparison for unit test generation. **Refer as needed**: When encountering TS/JS adaptation issues.

## Language Detection

| Signal                 | TypeScript    | JavaScript             |
| -------------------- | ------------- | ---------------------- |
| File Extension           | `.ts`, `.tsx` | `.js`, `.jsx`, `.mjs`  |
| `tsconfig.json` Exists | Yes            | No (or only `allowJs`) |
| `import type` Syntax   | Available          | Unavailable                 |

## tsconfig Compilation Options Check

Before writing TS test code, quickly check the following flags in `tsconfig.json`:

| Flag                    | Effect                       | Test Code Notes                      |
| ----------------------- | -------------------------- | --------------------------------- |
| `strict: true`          | Enables all strict type checks       | Mock objects must match types, `any` prohibited |
| `noUnusedLocals: true`  | Prohibits unused local variables       | Do not declare unused utility functions or variables    |
| `noImplicitAny: true`   | Prohibits implicit `any`             | Function parameters must have explicit types            |
| `esModuleInterop: true` | Allows default import interoperability | Affects ESM Mock syntax                |

## Syntax Difference Comparison

### Type Declarations

```typescript
// TypeScript
import type { Request, Response } from "express";
interface MockRequest {
  token: { _id: string };
  currentUser?: Record<string, unknown>;
}
const mockFn: jest.Mock<string, [string]> = jest.fn();
```

```javascript
// JavaScript — No type annotations
const mockFn = jest.fn();
const mockReq = { token: { _id: "test-id" } };
```

### Mock Type Conversion

```typescript
// TypeScript — Use as unknown as Type, bare as any prohibited
const mockClient = { create: jest.fn() } as unknown as {
  create: (data: unknown) => Promise<unknown>;
};
const mockReq = { token: { _id: "test" } } as unknown as Request;
```

```javascript
// JavaScript — Create objects directly, no type conversion needed
const mockClient = { create: jest.fn() };
const mockReq = { token: { _id: "test" } };
```

### Factory Function Pattern

```typescript
// TypeScript — Factory function returns typed Mock
function createMockRequest(overrides: Partial<MockRequest> = {}): MockRequest {
  return { token: { _id: "default-id" }, ...overrides };
}
```

```javascript
// JavaScript — Factory function without types
function createMockRequest(overrides = {}) {
  return { token: { _id: "default-id" }, ...overrides };
}
```

## Intersection Type Mock Pattern (TS Only)

When mocking enhanced global types (e.g., Express Request with added `currentUser` property), **prohibited from using `interface extends Partial<Request>`**, which causes TS2430 type conflicts.

```typescript
// ✅ Correct: Use intersection type
type MockRequest = Partial<Request> & {
  token: { _id: string };
  currentUser?: Record<string, unknown>;
};

// ❌ Wrong: interface extends causes type conflicts
// interface MockRequest extends Partial<Request> {
//   currentUser?: Record<string, unknown>;
// }
```

## Compilation Check Strategy

| Project Type                           | Check Command                                      | Description                    |
| ---------------------------------- | --------------------------------------------- | ----------------------- |
| TypeScript (Jest/Vitest/Mocha)     | `npx tsc --noEmit <test-file>`                | Standard compilation check            |
| TypeScript (fallback)              | `npx tsc --noEmit --skipLibCheck <test-file>` | When node_modules type conflicts exist |
| TypeScript (tsconfig excludes test directory) | Framework compilation passing is sufficient (ts-jest / swc)              | Do not repeatedly attempt `tsc`      |
| TypeScript (Bun)                   | `bun test <test-file>` compilation passing is sufficient            | Bun has built-in TS, no tsc needed   |
| JavaScript                         | `node --check <test-file>`                    | Syntax check only              |

### Bun TS Compilation Notes

Bun has native TypeScript support, no need for ts-jest, ts-node, or swc:

- `bun test <test-file>` will automatically transpile TS and execute tests
- If `bun test` passes, TS compilation verification is complete
- No need to run `tsc --noEmit` separately (unless the project has special type checking needs)
- Bun's TS transpilation does not support `enum` and some `const enum` features; if compilation errors occur, check if these features are used
- Complex type modules (generics, conditional types) may append `tsc --noEmit --skipLibCheck <test-file>` as supplementary checks

## Import Path Decision Tree

```
Does source code use path aliases like @/?
├── No → Use relative import paths directly
└── Yes → Does test runner have corresponding moduleNameMapper/resolve.alias?
    ├── Yes → Use alias imports (consistent with source code style)
    └── No → Prioritize relative import paths (e.g., ../../src/services/mailer)
        └── Relative paths impractical or existing tests already use aliases?
            ├── Yes → Supplement moduleNameMapper in jest.config.js/vitest.config.ts (acceptable test infrastructure change)
            └── No → Use relative import paths
```

### Bun Project Path Aliases

Bun natively supports `tsconfig.json` `paths` configuration, no additional `moduleNameMapper` needed:

- If `tsconfig.json` is configured with `"paths": { "@/*": ["./src/*"] }`, Bun will automatically resolve
- No need to additionally configure path aliases in `bunfig.toml` for Bun projects

### Key Rules

1. **Relative Imports First**: Avoid modifying project configuration files, reduce side effects
2. **moduleNameMapper is an Acceptable Change**: Supplementing `moduleNameMapper` belongs to necessary test infrastructure changes
3. **Prohibited from Verifying Path Aliases with Non-Test-Runner Tools**: `@/` aliases only take effect in the test runner's module resolver
4. **TS Uses Top-Level `import type`**: Inline `import('...').Type` syntax prohibited

## TS Bare `any` Prohibition Alternatives

| Scenario      | Prohibited               | Recommended                                             |
| --------- | ------------------ | ------------------------------------------------ |
| Mock Objects | `let x: any`       | `Partial<T>` or `Record<string, jest.Mock>`      |
| Type Conversion  | `obj as any`       | `obj as unknown as Type`                         |
| Function Parameters  | `(req: any)`       | `(req: Partial<Request> & { customProp: Type })` |
| Callback Types  | `(...args: any[])` | `(...args: unknown[])`                           |
| Spy Types  | `const spy: any`   | `const spy: jest.SpyInstance = jest.spyOn(...)`  |

### Typed Mock in Bun Projects

```typescript
// Bun test + TypeScript
import { mock, type Mock } from "bun:test";

// Typed Mock function
const mockFn: Mock<[string], string> = mock((s: string) => "default");

// Typed Mock object
const mockClient = { create: mock() } as unknown as {
  create: (data: unknown) => Promise<unknown>;
};
```

## ESM Interoperability

```typescript
// TypeScript/JavaScript — ESM default export Mock (Jest)
jest.mock("@/config", () => ({
  __esModule: true,
  default: { jwtSecret: "test-secret", port: 3000 },
}));
```

```typescript
// Bun test — ESM default export Mock
await mock.module("@/config", () => ({
  __esModule: true,
  default: { jwtSecret: "test-secret", port: 3000 },
}));
```

- The `__esModule: true` marker is key for ESM interoperability; missing it will cause `Cannot read properties of undefined`
- For modules with top-level side effects (e.g., `dotenv.config()`), use hoisted Mock variables:

```typescript
// Jest — Hoisted variable pattern
const mockDotenvConfig = jest.fn();
jest.mock("dotenv", () => ({ config: mockDotenvConfig }));
```

```typescript
// Bun — await in beforeAll
beforeAll(async () => {
  await mock.module("dotenv", () => ({ config: mock(() => {}) }));
});
```
