# Mock Patterns and Testing Patterns Guide

This file supports Steps 2 and 4 of SKILL.md, providing complete Mock templates for each framework, complex dependency Mock strategies, Bun mock.module proxy pattern, and incremental testing guide. **Refer as needed**: When encountering Mock issues.

## Framework Mock API Quick Reference

| Operation       | Bun test                | Jest                    | Vitest                  | Mocha+Sinon          | node:test              |
| ---------- | ----------------------- | ----------------------- | ----------------------- | -------------------- | ---------------------- |
| Create mock  | `mock(fn)`              | `jest.fn()`             | `vi.fn()`               | `sandbox.stub()`     | `mock.method()`/`mock.fn()` |
| Return Value     | `m.mockReturnValue(v)`  | `fn.mockReturnValue(v)` | `fn.mockReturnValue(v)` | `stub.returns(v)`    | `m.mockReturnValue(v)` |
| Async Success   | `m.mockResolvedValue(v)`| `fn.mockResolvedValue(v)`| `fn.mockResolvedValue(v)`| `stub.resolves(v)` | `m.mockResolvedValue(v)` |
| Async Failure   | `m.mockRejectedValue(e)`| `fn.mockRejectedValue(e)`| `fn.mockRejectedValue(e)`| `stub.rejects(e)`  | `m.mockRejectedValue(e)` |
| Call Count   | `m.mock.calls.length`   | `fn.mock.calls.length`  | `fn.mock.calls.length`  | `stub.callCount`     | `m.mock.calls.length`  |
| Call Arguments   | `m.mock.calls[n]`       | `fn.mock.calls[n]`      | `fn.mock.calls[n]`      | `stub.getCall(n).args` | `m.mock.calls[n]`    |
| Verify Call   | `expect(m).toHaveBeenCalled()` | `expect(fn).toHaveBeenCalled()` | `expect(fn).toHaveBeenCalled()` | `sinon.assert.called(stub)` | `assert(m.mock.calls.length > 0)` |
| Verify Arguments   | `expect(m).toHaveBeenCalledWith(...args)` | `expect(fn).toHaveBeenCalledWith(...args)` | `expect(fn).toHaveBeenCalledWith(...args)` | `sinon.assert.calledWith(stub, ...args)` | `assert.deepEqual(m.mock.calls[n], [...args])` |
| Cleanup       | `mock.restore()` / `mock.clearAllMocks()` | `jest.clearAllMocks()` | `vi.clearAllMocks()` | `sandbox.restore()` | `m.mockRestore()` / `mock.reset()` |
| Module Mock  | `await mock.module(path, factory)` | `jest.mock(path, factory)` | `vi.mock(path, factory)` | `proxyquire` | `mock.module()` |

## Bun test Mock Templates

### TypeScript

```typescript
import { describe, test, expect, mock, beforeEach, afterEach } from "bun:test";
import type { Mock } from "bun:test";

// Typed Mock function
const mockFn: Mock<[string], string> = mock((s: string) => "default");

// Typed Mock object (intersection type)
type MockRequest = Partial<Request> & {
  token?: { _id: string };
  currentUser?: Record<string, unknown>;
};

function createMockRequest(overrides: Partial<MockRequest> = {}): MockRequest {
  return { token: { _id: "test-id" }, ...overrides };
}

// Module-level Mock (async, must await in beforeAll)
beforeAll(async () => {
  await mock.module("../../src/db", () => ({
    query: mock(() => []),
  }));
});

// ESM default export Mock
beforeAll(async () => {
  await mock.module("@/config", () => ({
    __esModule: true,
    default: { jwtSecret: "test-secret", port: 3000 },
  }));
});
```

### JavaScript

```javascript
import { describe, test, expect, mock, beforeEach, afterEach } from "bun:test";

const mockFn = mock(() => "default");
const mockReq = { token: { _id: "test-id" } };

beforeAll(async () => {
  await mock.module("../../src/db", () => ({
    query: mock(() => []),
  }));
});
```

### Bun mock.module Notes

- **Async API**: `mock.module()` returns a Promise and must be `await`ed in `beforeAll`
- **No Hoisting**: Unlike Jest's `jest.mock()`, Bun's `mock.module()` will not be hoisted to the top of the file
- **Import Order**: `mock.module()` must execute before importing the module under test, typically placed in `beforeAll`
- **mock.clearAllMocks()**: Bun supports `mock.clearAllMocks()` to clear all mock call records
- **mock.restore()**: Restores all mocks to original implementations
- **Process-Level Scope**: `mock.module()` is process-level scoped and cannot be isolated to a single file

### Bun mock.module Proxy Pattern (Preserve Existing Tests in Incremental Testing)

When testing both real fs and Mock fs in the same file is needed, use the proxy pattern:

```typescript
import { describe, test, expect, mock, beforeAll, afterAll } from "bun:test";
import * as fs from "fs/promises";
import * as path from "path";
import { tmpdir } from "os";

// Proxy flag: controls whether Mock intercepts
let mockFsEnabled = false;
const realFs = { ...fs };

beforeAll(async () => {
  await mock.module("fs/promises", () => ({
    readFile: mock((...args: unknown[]) => {
      if (mockFsEnabled) throw new Error("Mocked read error");
      return realFs.readFile(...args as [string]);
    }),
    writeFile: mock((...args: unknown[]) => {
      if (mockFsEnabled) throw new Error("Mocked write error");
      return realFs.writeFile(...args as [string, string]);
    }),
  }));
});

// Real fs tests (uses real implementation when mockFsEnabled = false)
describe("real fs operations", () => {
  beforeEach(() => { mockFsEnabled = false; });
  test("writes and reads file", async () => {
    const tmpFile = path.join(tmpdir(), `test-${Date.now()}.txt`);
    await fs.writeFile(tmpFile, "hello");
    const content = await fs.readFile(tmpFile, "utf-8");
    expect(content).toBe("hello");
  });
});

// Mock fs error path tests (uses Mock when mockFsEnabled = true)
describe("mocked fs error paths", () => {
  beforeEach(() => { mockFsEnabled = true; });
  afterEach(() => { mockFsEnabled = false; });
  test("handles read error", async () => {
    await expect(fs.readFile("/nonexistent", "utf-8")).rejects.toThrow("Mocked read error");
  });
});
```

**Alternative**: If the proxy pattern is too complex, create separate test files (e.g., `module-name-mocked.test.ts`), use `mock.module()` for full Mocking there, and keep the original test file unchanged.

## Jest Mock Templates

### TypeScript

```typescript
import { jest } from "@jest/globals";
import type { Request, Response, NextFunction } from "express";

// Typed Mock function
const mockFn: jest.Mock<string, [string]> = jest.fn();

// Typed Mock object (intersection type, avoids extends conflicts)
type MockRequest = Partial<Request> & {
  token?: { _id: string };
  currentUser?: Record<string, unknown>;
};

function createMockRequest(overrides: Partial<MockRequest> = {}): MockRequest {
  return { token: { _id: "test-id" }, ...overrides };
}

// Module-level Mock (hoisted variable pattern)
const mockDbQuery = jest.fn();
jest.mock("../../src/db", () => ({
  __esModule: true,
  query: mockDbQuery,
  default: { query: mockDbQuery },
}));

// DI Container Mock (preserves decorators)
jest.mock("typedi", () => {
  const actual = jest.requireActual("typedi");
  return {
    ...actual,
    Container: { ...actual.Container, get: jest.fn() },
  };
});

// Spy
const spy: jest.SpyInstance = jest.spyOn(console, "log");
```

### JavaScript

```javascript
const mockFn = jest.fn();
const mockReq = { token: { _id: "test-id" } };

const mockDbQuery = jest.fn();
jest.mock("../../src/db", () => ({
  __esModule: true,
  query: mockDbQuery,
  default: { query: mockDbQuery },
}));
```

## Vitest Mock Templates

```typescript
// TypeScript
import { vi } from "vitest";
const mockFn: ReturnType<typeof vi.fn> = vi.fn();
vi.mock("../../src/db", () => ({ query: vi.fn() }));
```

```javascript
// JavaScript
const mockFn = vi.fn();
vi.mock("../../src/db", () => ({ query: vi.fn() }));
```

## Mocha + Sinon Mock Templates

```javascript
import sinon from "sinon";
const sandbox = sinon.createSandbox();

beforeEach(() => {
  sandbox.stub(db, "query").resolves([]);
});
afterEach(() => {
  sandbox.restore();
});
```

## node:test Mock Templates

```javascript
import { test, mock } from "node:test";
import assert from "node:assert/strict";

const mockFn = mock.fn(() => "default");
const mockMethod = mock.method(obj, "methodName", () => "mocked");

test("calls function with correct args", () => {
  mockFn("arg1", "arg2");
  assert.equal(mockFn.mock.calls.length, 1);
  assert.deepEqual(mockFn.mock.calls[0].arguments, ["arg1", "arg2"]);
  mockFn.mockRestore();
});
```

## Complex Dependency Mock Strategy (5+ Dependencies)

When the target function depends on 5 or more external modules, use the following strategies:

### 1. Priority Sorting

Sort Mock priority by blocking level:
1. **Modules Blocking Imports**: Modules that execute code on import (e.g., `dotenv.config()`, database connections) must be Mocked first
2. **Directly Called External Services**: External APIs and database queries directly called in the function body
3. **Indirect Dependencies**: Dependencies passed via parameters or DI injection
4. **Utility Functions**: Logging, formatting, and other utility functions

### 2. Factory Function Batch Creation

```typescript
// TS — Factory function to batch-create Mock objects
function createMockDeps() {
  return {
    logger: { info: jest.fn(), error: jest.fn(), warn: jest.fn() },
    config: { get: jest.fn((key: string) => mockConfigValues[key]) },
    db: { query: jest.fn().mockResolvedValue([]) },
    httpClient: { get: jest.fn().mockResolvedValue({ data: {} }) },
    cache: { get: jest.fn(), set: jest.fn() },
  };
}

// Use in tests
const deps = createMockDeps();
jest.mock("../../src/logger", () => ({ __esModule: true, default: deps.logger }));
jest.mock("../../src/config", () => ({ __esModule: true, default: deps.config }));
```

### 3. Split Test Files

If Mock complexity is too high (more than 10 dependencies), consider splitting into multiple test files:
- `module-name-happy.test.ts` — Normal path tests
- `module-name-errors.test.ts` — Error path tests (requiring different Mock configurations)
- `module-name-integration.test.ts` — Integration tests using real dependencies

### 4. Step-by-Step Mock Strategy

Do not set up all Mocks at once. Proceed step by step:
1. First Mock modules blocking imports to ensure the module under test can be imported
2. Write minimal happy path test to verify basic functionality
3. Gradually add other Mocks, supplementing error paths and edge tests
4. Run tests to verify after adding each Mock, ensuring Mocks do not break existing tests

## Hoisted Variable Pattern (Modules with Code Executed on Import)

When a module executes code on import (e.g., `dotenv.config()`, database connections), hoisted Mock variables must be used:

```typescript
// Jest — ✅ Correct: Hoisted variable declared before jest.mock
const mockDbConnect = jest.fn();
jest.mock("../../src/db", () => ({
  __esModule: true,
  connect: mockDbConnect,
  default: { connect: mockDbConnect },
}));
```

```typescript
// Bun — ✅ Correct: await mock.module in beforeAll
const mockDbConnect = mock(() => undefined);
beforeAll(async () => {
  await mock.module("../../src/db", () => ({
    connect: mockDbConnect,
  }));
});
```

After `jest.resetModules()`, the module under test must be re-imported with `require()`.

## ESM Configuration

ESM projects (`"type": "module"` in `package.json`) require additional configuration:

```json
// Jest ESM Configuration
{ "transform": {}, "extensionsToTreatAsEsm": [".ts"] }
```

```bash
node --experimental-vm-modules node_modules/.bin/jest <test-file>
```

Bun and Vitest have native ESM support, no additional configuration needed.

## Domain-Specific Testing Patterns

### Express/Koa Middleware

```typescript
type MockRequest = Partial<Request> & {
  token?: { _id: string };
  user?: unknown;
};
type MockResponse = Partial<Response> & { statusCode: number; json: jest.Mock };

it("should call next() on success", () => {
  const req = createMockReq();
  const res = createMockRes();
  const next = jest.fn();
  middleware(req, res, next);
  expect(next).toHaveBeenCalled();
});

it("should return 401 on missing token", () => {
  const req = createMockReq({ token: undefined });
  const res = createMockRes();
  const next = jest.fn();
  middleware(req, res, next);
  expect(res.statusCode).toBe(401);
  expect(res.json).toHaveBeenCalledWith({ error: "Unauthorized" });
});
```

### DI Container Injection

```typescript
jest.mock("typedi", () => {
  const actual = jest.requireActual("typedi");
  return { ...actual, Container: { ...actual.Container, get: jest.fn() } };
});
(Container.get as jest.Mock).mockReturnValue(mockService);
```

### Configuration/Logging Modules

Only Mock external dependencies; use real implementations for mature libraries like winston. Verify actual behavior rather than just `toBeDefined()`.

## Incremental Testing Patterns

| Existing Coverage                   | Mode     | Strategy                                           |
| ---------------------------- | -------- | ---------------------------------------------- |
| 0% (no tests or target function uncovered) | Full Mode | Write minimal initial test first → Run coverage → Then supplement edge cases |
| 0-100% (partially covered)           | Incremental Mode | Only supplement uncovered scenarios, **prohibited from rewriting or deleting existing tests**   |
| 100% (fully covered)             | Supplement Mode | Still generate new tests (e.g., verify call arguments)               |

### Incremental Mode Operation Steps

1. **Run existing tests to get coverage report** (must actually execute, must not infer from code analysis alone)
2. Identify uncovered lines and branches for the target function
3. Only design test cases for uncovered scenarios
4. Append cases to existing test files, or create new files (e.g., `module-name-full.test.ts`), **prohibited from overwriting existing files**
5. Re-run to verify coverage improvement

### Incremental Mode Prohibitions

- Prohibited from rewriting existing tests (even if Mock strategies are incompatible)
- Prohibited from deleting existing test cases
- If new tests' Mock strategies are incompatible with existing tests (e.g., Bun `mock.module()` process-level scope), use proxy pattern or create separate test files

### Full Mode Should Also Simulate Incremental Workflow

Even without existing tests:

1. First create minimal initial tests (happy path)
2. Run coverage
3. Supplement edge cases based on coverage report

## Async Testing Best Practices

```typescript
// ✅ Correct: Use async/await
it("should handle async success", async () => {
  const result = await asyncFunction();
  expect(result).toBe(expected);
});

// ❌ Wrong: Forgot return or await
it("should handle async", () => {
  asyncFunction(); // Assertions will not execute
  expect(mockFn).toHaveBeenCalled();
});
```

## Test File Placement Rules

- Test directories **must mirror source directory structure**
- Flattened paths prohibited
- Prioritize same directory as existing test files
- File naming follows project conventions (`*.spec.ts` or `*.test.ts`)
- In incremental mode, use distinguishing suffixes like `-full.test.ts` when creating new files

## Style Alignment Checklist

- [ ] Test framework consistent with project configuration
- [ ] Assertion style consistent with existing tests
- [ ] Mock API consistent with project
- [ ] describe/it organization consistent
- [ ] setup/teardown patterns consistent
- [ ] Import style consistent
