# Coverage Verification Guide

This file supports Step 6 of SKILL.md, providing detailed steps for coverage verification, lcov.info parsing methods, dead code escape, and fallback strategies. **Refer as needed**: When encountering coverage issues.

## Coverage Tool Flag Differences

| Tool   | Line Coverage     | Branch Coverage           | lcov Output                  | Scope                                |
| ------ | ------------ | -------------------- | -------------------------- | --------------------------------------- |
| Bun    | `--coverage` | Does not generate BR/BRDA       | `coverage/` directory           | `--coverage` (built-in, no additional configuration needed)       |
| Jest   | `--coverage` | `--coverage` (automatic) | `--coverageReporters=lcov` | `--collectCoverageFrom`                 |
| Vitest | `--coverage` | `--coverage` (automatic) | `--coverage.reporter=lcov` | `--coverage.include`                    |
| c8     | Default         | Default                 | `--reporter=lcov`          | `--src <file>` or `--include <pattern>` |
| nyc    | Default         | Default                 | `--reporter=lcov`          | `--include <pattern>`                   |

### Multiple Configuration Coverage Tool Selection

When a project has both Bun and Jest configurations, coverage tool selection strategy:

| Scenario | Recommended Tool | Reason |
| --- | --- | --- |
| Bun only | `bun test --coverage` | Only option, branch coverage exempted |
| Jest only | `npx jest --coverage` | Standard option, generates complete BR/BRDA |
| Bun + Jest coexistence | Prefer `npx jest --coverage` | Generates branch coverage data, more complete verification |
| Bun + Jest coexistence (Jest config incompatible) | `bun test --coverage` | Fallback to Bun, branch coverage exempted |

**Key Difference**: Bun's coverage tool does not generate BR/BRDA (branch coverage) lines; branch coverage verification will be exempted. Jest's Istanbul coverage tool generates complete BR/BRDA lines, allowing mechanical verification of branch coverage >=80%.

### Bun Coverage

Bun has built-in coverage support, no additional tools required:

```bash
# Basic coverage
bun test <test-file> --coverage

# Bun generates coverage/ directory, containing lcov.info
# Coverage output format is compatible with standard lcov.info
```

Bun coverage features:
- Built-in V8 coverage, no need for c8/nyc
- Generates `coverage/lcov.info` (standard lcov format)
- Supports line coverage
- **Does not generate branch coverage data (BR/BRDA lines)**
- No additional `bunfig.toml` configuration needed

### c8 vs nyc

- c8 uses V8 built-in coverage, no instrumentation needed, better ESM support
- nyc/Istanbul requires instrumentation, but provides more complete branch coverage reporting
- When c8 output has issues, fallback to nyc: `npx nyc --reporter=lcov --reporter=text mocha <test-file>`

## validate-coverage.mjs Script Usage

### Path Resolution

The script is located at `scripts/validate-coverage.mjs` in the skill directory. Full path must be specified when using:

```bash
# Run from project root (recommended)
node <skill-dir>/scripts/validate-coverage.mjs <source-file> --threshold 90 --branch-threshold 80

# If lcov.info is not in the default location, specify path
node <skill-dir>/scripts/validate-coverage.mjs <source-file> --threshold 90 --branch-threshold 80 --lcov-path <path-to-lcov.info>
```

### Default lcov.info Search Paths

The script searches for lcov.info in the following order:
1. `coverage/lcov.info`
2. `lcov.info`
3. `.nyc_output/lcov.info`

### Output Interpretation

```
Found lcov.info at: /path/to/coverage/lcov.info
Target file: example.ts
Total lines: 100
Covered lines: 95
Line coverage: 95.0%
Line threshold: 90%
PASS: Line coverage 95.0% meets threshold 90%
Branch coverage: 85.0% (17/20)
Branch threshold: 80%
PASS: Branch coverage 85.0% meets threshold 80%
```

If you see `WARNING: No BR/BRDA lines found`, it means the coverage tool did not generate branch data (e.g., Bun), and branch coverage verification is exempted.

## lcov.info Parsing

### DA Lines (Line Coverage)

```
DA:<line_number>,<hit_count>
```

- `DA:15,3` → Line 15 executed 3 times
- `DA:20,0` → Line 20 not executed (zero hits)

### BR/BRDA Lines (Branch Coverage)

```
BR:<line_number>,<block_number>,<branch_number>,<taken_count>
BRDA:<line_number>,<block_number>,<branch_number>,<taken_count>
```

- `BR:30,0,0,1` → Branch 0 on line 30 executed 1 time
- `BRDA:30,0,1,0` → Branch 1 on line 30 not executed

### Verification Steps

1. Confirm `lcov.info` has been generated and is not empty
2. Find the target file's `SF:` line (source file path)
3. Check DA lines for non-zero hits
4. Calculate `lineCoverage = coveredLines / totalLines * 100`
5. If BR/BRDA lines exist, calculate `branchCoverage = coveredBranches / totalBranches * 100`
6. If no BR/BRDA lines exist, exempt branch coverage verification

## Handling No BR Lines

Some JS projects or Bun/c8 configurations may not generate branch information.

Handling approach:

1. Record this situation
2. Exempt branch coverage verification
3. **Must not skip line coverage verification**

## Trust Test Runner Output

The test runner's coverage report is the authoritative verification mechanism. When the test runner reports that coverage targets are met:

- Coverage verification is complete
- **One lcov.info check is allowed**: To identify specific uncovered lines for supplementing tests
- Repeated manual checks after meeting targets are prohibited (grep lcov.info, tsc checking test files)

Only run additional verification in the following cases:

- Coverage output is suspicious (e.g., suddenly 100% but tests are clearly incomplete)
- Test runner did not generate lcov.info
- Branch coverage details need confirmation

## Dead Code Escape

### Determination Criteria

Code paths that still cannot be triggered after **1 round** of attempts, meeting one of the following conditions:

- Empty try block (no logic inside try or only unreachable calls)
- Structurally unreachable catch (preceding calls必然 crash, catch will never execute)
- Branches where conditions are永远 false

### Handling Approach

1. Add a comment in the test file explaining:
   ```typescript
   // Dead code: line 53 is unreachable because generateToken() throws
   // before the null check on line 52 can be reached.
   ```
2. Continue with subsequent steps, do not modify source code
3. **Prohibited from using prototype mock, spyOn, or other workarounds to force coverage of unreachable paths**

### Iteration Limits

- Maximum **1 round** of attempts to cover suspected dead code
- After 1 failed round, immediately mark as dead code and continue
- When the same issue is analyzed repeatedly more than **3 times** without progress, stop immediately and record

## Coverage Iteration Strategy

### Rounds 1-3: Automatic Supplement

1. Parse lcov.info to identify zero-hit DA lines and uncovered BR lines
2. Design targeted tests for each uncovered line/branch
3. Re-run tests to verify coverage improvement

### Rounds 4-5: Manual Analysis

1. Output structured coverage tracking report
2. Analyze uncovered reasons line by line
3. Distinguish "coverable but uncovered" from "dead code"

### Iteration Termination Conditions

- Line coverage >90% and branch coverage >=80% (or exempted) → Stop
- Remaining uncovered lines confirmed as dead code → Stop
- 5 rounds of iteration completed → Stop and record limitations

## Fallback Strategy

### Test Execution Failure

1. Attempt to execute tools directly from `node_modules/.bin/`
2. Check for missing `moduleNameMapper` (when source code uses `@/` aliases)

### Coverage Tool Unavailable

1. Bun: `--coverage` is built-in, ensure Bun version >= 1.0
2. Jest: Ensure `--coverage` flag is passed
3. Vitest: May need `@vitest/coverage-v8` or `@vitest/coverage-istanbul`
4. Mocha: Install `c8` or `nyc`

### lcov.info All Zeros or Outdated

1. Explicitly regenerate with `--reporter=lcov`
2. Scope coverage with `--src <source-file>`
3. Confirm DA lines have non-zero hits before continuing

### Bun Coverage Output Location

Bun's coverage output defaults to the `coverage/` directory:
- `coverage/lcov.info` — Standard lcov format
- HTML reports in `coverage/` directory
- If `coverage/lcov.info` does not exist, check `coverage/` directory structure
- Bun's lcov.info format is compatible with Jest/c8 and can be verified directly with `validate-coverage.mjs`
