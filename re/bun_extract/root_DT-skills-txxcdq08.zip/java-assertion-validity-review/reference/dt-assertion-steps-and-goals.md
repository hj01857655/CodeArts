# DT Assertion Steps and Assertion Goals — Review Reference

This document follows the structure of the DT assertion-validity review reference and the Huawei Cloud assertion-validity review reference, and distills requirements from **Assertion Steps** on assertion goals, what must be asserted, what must be avoided, and Flux/Mono reactive assertions into a review reference usable by this Skill or other tools.  
**Purpose**: Use as reference only; not the Skill body.

---

## Must Read Before Review: Context and Content to Observe (General)

**Principle**: First read **the implementation of the method under test and its immediate context**, then judge whether test assertions are sufficient based on “value change” dimensions present in the implementation; do not infer from test code or names only.

| Priority | Context to observe (files/code to read) | Content to observe (what to look for in that context) |
|----------|----------------------------------------|--------------------------------------------------------|
| **Required** | **Source file of the method under test** (e.g. `XxxServiceImpl.java`) | Method body of the method under test; method bodies of methods it calls in the same file; **instance and static field** declarations and read/write in this method. |
| **As needed** | **Source of other classes/interfaces** called inside the method under test (if readable in the project, e.g. same module or dependency source) | **Definitions** of called methods (parameters, return value, whether they modify arguments, whether they write static/instance state, observable side effects). If only jar without source, infer from method signature and docs/Javadoc. |
| **Existing** | Test class file (e.g. `XxxTest.java`) | Whether each case calls the method under test; what assertions target (return value, argument change, external state); presence of assertTrue(true), only assertNotNull, etc. |
| **Existing** | This reference document | Each review point’s “context and content to observe” and verdict criteria. |

Sections below list **context and content to observe for that review item** in tables or at section end; use together with the general principle above.

---

## I. Assertion Goal

**Goal**: Ensure assertions are **meaningful and effective**; tests must cover **value-change** dimensions of the method under test as far as possible.

| # | Review point | Description |
|---|--------------|-------------|
| 1 | Whether “value change” dimensions are verified | Assertions should cover: **non-local variables** (state outside the method), **changes to fields inside argument objects**, **return value and its fields**; if a dimension exists and is missing, assess whether it was omitted |
| 2 | Whether observable state transitions are verified | Assertions should focus on **observable state transitions**, not superficial results |
| 3 | Whether assertions fail when core logic is broken | If assertions still pass after the core logic under test is broken, the assertion is **unacceptable** and must be strengthened to bind to business/state change |

**Verdict**: If the case does not cover any dimension in 1 (and that dimension exists for the method), or satisfies 3 (assertions pass despite logic error), mark as **assertion goal not met**.

**Context and content to observe for this section**:

| Review point | Context to observe | Content to observe |
|--------------|--------------------|---------------------|
| 1 Value-change dimensions | Source file of method under test; source of methods it calls (if readable) | In method body: assignments to **class fields / static variables / shared objects**; writes to **arguments** (e.g. setXxx, put, add, remove, clear); **return** expression and type (void or concrete, composite or not). List which of “non-local variable, argument change, return value” exist. |
| 2 Observable state transitions | Same | Whether assertions target **state changes** from those dimensions (e.g. field before/after, collection add/remove, return value content), not only “no exception”, “object not null”, etc. |
| 3 Assertions fail when logic broken | Implementation under test + assertion expressions in test | If core logic under test were changed incorrectly (e.g. wrong return value, no longer writing a field): would current assertions still pass; if yes, treat as “unrelated to state/business” or “existence only” and strengthen. |

---

## II. What Must Be Asserted (Preferred Assertions)

### 2.1 Non-local variables (external state changed by method execution)

**Goal**: Identify and verify state changed **outside the method** during execution (class fields, shared objects, dependency state, cache, repository, static/global holders, etc.).

| # | Review point | Description |
|---|--------------|-------------|
| 1 | Are changed fields asserted | Assertions must verify **which fields** changed, not only “call happened” or “no exception” |
| 2 | Are before/after values correct | Assertions must verify **correct before/after** (or expected final state) |
| 3 | Are structural changes verified | If there are collection add/remove, counter updates, persisted entities, written records, etc., assertions must cover these **structural updates** |
| 4 | Are observable side effects from dependencies verified | Observable side effects from dependencies (e.g. DB write, message send, cache write) should be reflected in assertions |

**Verdict**: If the method changes non-local variables but the case does not assert 1–4 above, mark as **insufficient non-local variable assertion**.

**Context and content to observe for this section**:

| Review point | Context to observe | Content to observe |
|--------------|--------------------|---------------------|
| Whether “non-local variable” change exists | Source file of method under test; source of methods it calls (if readable) | In method body and called methods: writes to **this class’s instance fields** (e.g. `this.field = ...`), **static fields**, **fields or methods of injected dependencies** (e.g. repository.save, cache.put, staticHolder.set); for external library calls, use **method name/docs** to decide if they write external state. |
| Whether 1–4 are covered in test | Test class file | After calling the method under test, does the case assert on the above written fields/objects (specific fields, before/after, collection size, persisted result, mock verify, etc.). |

---

### 2.2 Argument objects (input parameters modified by the method)

**Goal**: If the method under test **modifies argument objects by reference**, assertions must verify what changed inside the arguments.

| # | Review point | Description |
|---|--------------|-------------|
| 1 | Which fields inside arguments were modified | Assertions must verify **changes inside argument objects**, not only return value or “method did not throw” |
| 2 | Correctness of each modified field | For each modified field, assert **correctness** (consistent with expected contract) |
| 3 | Structural argument changes verified | If arguments are collections/Map/nested objects, assertions must cover **collection size change, Map updates, nested object changes** |

**Verdict**: If the method modifies arguments but the case does not assert argument field/structure changes, mark as **insufficient argument-change assertion**.

**Context and content to observe for this section**:

| Review point | Context to observe | Content to observe |
|--------------|--------------------|---------------------|
| Whether “arguments are modified” | Source file of method under test; source of methods it calls (if readable or inferable from docs) | In method body and called methods: write operations on **arguments** or **their fields/elements**, e.g. `param.setXxx(...)`, `param.put(...)`, `param.add(...)`, `param.remove(...)`, and framework methods filling fields of wrapper objects (e.g. MetaObject, Entity) passed as arguments. For dependency library methods, use **method signature/docs** to decide if they modify reference-type parameters. |
| Whether 1–3 are covered in test | Test class file | After calling the method under test, does the case assert on **the same argument object** (or its fields, collection size, Map keys/values), verifying modified fields/elements and their values. |

---

### 2.3 Return value (computed output)

**Goal**: Return value must be verified at **field level**; not only “exists” or “not null”.

| # | Review point | Description |
|---|--------------|-------------|
| 1 | Existence-only assertion | Using only `assertNotNull(result)` or `assertNull(result)` as the sole assertion on return value is **forbidden**; **field-level / content-level** assertions are required |
| 2 | Key business fields asserted | **Key business fields** and **derived/computed values** in the return value must be asserted |
| 3 | Nested properties and collection content verified | **Nested object properties** and **collection content** (and **order** when business-relevant) must be verified |
| 4 | Status code, error code, metadata verified | If return value includes status flags, error codes, metadata, etc., assertions should reflect them |

**Verdict**: If return value has only existence assertion and no content assertion from 2–4, mark as **insufficient return-value assertion** (weak assertion).

**Context and content to observe for this section**:

| Review point | Context to observe | Content to observe |
|--------------|--------------------|---------------------|
| Return type and structure | Source file of method under test | **Return type** in method signature (void / primitive / reference); expression in return (literal, single field, new object, collection). If object/collection, identify **business-meaningful fields or elements**. |
| Whether 1–4 are covered in test | Test class file | Does the case assert on **return value**: only assertNull/assertNotNull is insufficient; need assertEquals/assertTrue etc. on **content** (string content, numeric value, object fields, collection size/elements, order, status code, etc.). |

---

## III. What Must Be Avoided (Non-Preferred Assertions)

**Goal**: Identify assertions that cannot verify real behavior; they may still pass when core logic is wrong and must not be the main or only verification.

| # | Review point | Description |
|---|--------------|-------------|
| 1 | Existence-only assertion | Using **only** `assertNull(...)` or `assertNotNull(...)` with no later assertion on **content/fields/state** is insufficient; must be combined with field-level or behavior-level assertion |
| 2 | Fake assertion | `assertTrue(true)` or equivalent “always true” assertion verifies no actual behavior and **must be forbidden** |
| 3 | Assertion unrelated to state transition/change/business | Assertion does not target: state transition, change to arguments/return value/external state, business correctness; if assertion still passes when core logic is broken, **unacceptable** |

**Verdict**: If the case has 1 with no later content assertion, or satisfies 2/3, mark as **must-avoid assertion**; replace or add verification of value change/state.

**Context and content to observe for this section**:

| Review point | Context to observe | Content to observe |
|--------------|--------------------|---------------------|
| 1 Existence-only | Test class file | Presence of `assertNull(...)` or `assertNotNull(...)`; if present, whether the same case has later assertion on **the same object’s content/fields/state** (e.g. assertEquals, assertTrue(condition), verify). If only existence with no content assertion, mark. |
| 2 Fake assertion | Test class file | Presence of `assertTrue(true)`, `assertFalse(false)`, or assertTrue/assertFalse with **literal/constant** condition (e.g. assertTrue(constantTrue)). If present, mark. |
| 3 Unrelated to state/business | Source file of method under test + test class file | **Implementation**: what are the “value change” dimensions of the method (return value, argument change, non-local variable). **Test**: do assertion expressions refer to **return value of method under test, state of arguments after call, or external state written by method under test**; if assertion is literal comparison (e.g. assertEquals("updateTime","updateTime")), class name, constant that does not depend on SUT logic, or assertion without calling the method under test, mark as unrelated to state/business. |

---

## IV. Flux/Mono Reactive Assertions (Reactive Contract)

**Goal**: Unit tests for **Flux/Mono** must verify the **full reactive contract** (emitted elements, termination signal, error behavior, observable side effects), not only “has value” or implementation details.

### 4.1 Reactive contract completeness

| # | Review point | Description |
|---|--------------|-------------|
| 1 | Lifecycle signals verified | Reactive stream: onSubscribe → onNext(0..N) → (onComplete | onError | cancel); assertions must cover **emitted content, order, termination, whether error** |
| 2 | Only value verified, termination ignored | Verifying only emitted values and **not how the stream terminates** (onComplete/onError/cancel) is **incomplete** |
| 3 | Timing/retry/backpressure verified as needed | If business involves **timing, retry, backpressure**, assertions should reflect that (e.g. virtual time, request steps, retry count) |

**Verdict**: If it is a Flux/Mono test but termination signal or key behavior is not verified, mark as **incomplete reactive assertion**.

**Context and content to observe for this section**:

| Review point | Context to observe | Content to observe |
|--------------|--------------------|---------------------|
| Whether Flux/Mono test | Test class file | Whether type under test or return type of method under test is `Flux<T>` / `Mono<T>`; whether StepVerifier, TestPublisher, etc. are used. |
| 1–3 Lifecycle and termination | Test class file; source file of method under test (if needed to judge timing/retry/backpressure) | After **subscribing and consuming** the publisher, does the test assert both **emitted elements** (expectNext etc.) and **termination signal** (verifyComplete, expectError, thenCancel etc.); if production code has delay, retry, onBackpressureXxx, does the test use virtual time, request, retry count etc. for corresponding verification. |

---

### 4.2 Reactive assertion strategy reference (aligned with StepVerifier etc.)

| Assertion target | Recommended assertion | Review point |
|------------------|------------------------|--------------|
| Emit expected value and complete normally | `expectNext(...)` → `verifyComplete()` | Must assert both **emitted data** and **termination signal** |
| Mono success (single value) | `expectNext(value)` → `verifyComplete()` | Mono success contract: **one value + complete**, both must be asserted |
| Empty publisher | `verifyComplete()` or `expectNextCount(0)` → `verifyComplete()` | Explicitly verify **no emission** and **normal completion** |
| Multiple values, order matters | `expectNext(a, b, c)` | Use strict order assertion for order correctness |
| Multiple values, count only | `expectNextCount(n)` → `verifyComplete()` | Use only when value correctness is verified elsewhere; otherwise prefer explicit match |
| Predicate/complex object | `expectNextMatches(predicate)` or `assertNext(consumer)` | Prefer predicate or consumer for complex objects, not only equals |
| Error termination (type) | `expectError(SomeException.class)` | When failure is expected, verify **error type** |
| Error termination (details) | `expectErrorSatisfies(...)` | Can verify message, cause, domain fields; avoid over-reliance on exact string |
| Emit then fail | `expectNext(...)` → `expectError(...)` | Assert both emission before failure and failure signal |
| Cancel behavior | `thenCancel()` → `verify()` | Use when testing take, timeout, manual dispose, etc. |
| Backpressure/request control | `StepVerifier.create(publisher, 0)` → `thenRequest(n)` | Start with 0 demand to verify producer behavior precisely |
| Time-related operators | `withVirtualTime(...)` → `thenAwait(...)` | Prefer **virtual time** for determinism and speed |
| Timeout guard | `verifyTimeout(Duration)` | Avoid hanging tests; cap max execution time |
| Retry/resubscribe | StepVerifier + count or mock verification | Verify subscribe/retry count via observable side effects |
| Fallback/recovery path | Inject error source → assert fallback emission | Explicitly test onErrorResume etc. |
| Reactor Context | `contextWrite(...)` → `expectNext(...)` | Inject context and verify its effect on behavior |
| Scheduling/thread | Capture thread in doOnNext if needed | Prefer asserting observable behavior; assert thread only when scheduling is part of contract |

**Verdict**: When writing or reviewing Flux/Mono tests, check against the table that the strategy matches the scenario and that both **emission** and **termination** are covered.

**Context and content to observe for this section**:

| Review point | Context to observe | Content to observe |
|--------------|--------------------|---------------------|
| Strategy matches scenario | Test class file; source file of method/publisher under test | **Test**: StepVerifier call chain (expectNext, expectNextCount, verifyComplete, expectError, thenCancel, withVirtualTime, thenRequest, etc.). **Implementation**: how many values the publisher emits, whether it can error, whether it involves time/retry/backpressure. Use this to check “assert both emission and termination” and that the assertion style matches the scenario. |

---

## V. Experience and Typical Fixes (from review and modification practice)

Below are **experience** and **recommended fixes** abstracted from actual review and modification, for direct use when writing or revising cases and to avoid issues like “only verify without asserting return value” and “multiple calls without bound stub correspondence”.

| Scenario | Symptom | Principle | Recommended fix |
|----------|---------|-----------|-----------------|
| **Only verify, no return value assertion** | Case calls method under test but only has `verify(mock, times(n)).xxx()`, no assertion on return value. | Whenever **return value** is a value-change dimension of the method under test, **every** case that calls it must assert the return value at least once; cannot only verify “who was called” without “what was returned”. | Capture return value (e.g. `Type result = sut.method();`), before or after verify add: `assertNotNull(result)` / `assertNull(result)` and assertion consistent with expectation (e.g. `assertSame(stub object, result)`, `assertEquals(result.getClass(), Xxx.class)`). |
| **Branch returns “new instance”** | Method under test has a branch returning `new Xxx()`, case only does verify or assertNotNull, no assertion on observable fields of the returned “empty” object. | Observable result of the branch includes “returned new instance” and its observable state; explicitly assert non-null, correct type, and observable fields of the empty object (e.g. id unset then null). | After capturing return value add: `assertNotNull(result)`, `assertEquals(result.getClass(), Xxx.class)`; if returned “empty” object (e.g. new Xxx()), assert observable fields (e.g. `assertNull(result.getId())`). If same case has mock-returned object, add `assertNotSame(mock object, result)`. |
| **Multiple calls in same case, different stubs for different results** | Case calls method under test multiple times with different stubs (e.g. result1 from stubA, result2 from stubB), but only assertNotNull for each result, no verification that “which result corresponds to which stub”. | With multiple calls, besides existence, assert **correspondence of each return value to its stub (or new object)**; otherwise test may still pass when core logic is wrong (e.g. wrong return order, wrong branch). | For each result add binding to expected source: e.g. `assertSame(stubA, result1)`, `assertSame(stubB, result3)`; for result2 from `new Xxx()` use `assertNotSame(stubA, result2)` + `assertEquals(result2.getClass(), Xxx.class)`. I.e. existence + identity/type so assertions bind to business meaning. |
| **Return value is third-party type and internal not retrievable** | Method under test returns third-party type, or return value is determined by unmocked dependency (e.g. mapper.xxx()) and content is uncontrollable; case only assertNotNull and cannot reliably assert content. | **Correctness first**; if third-party internals or dependency behavior cannot be retrieved, **do not write assertions for that part**, assert only based on observable behavior of the class under test; avoid reflection or speculative assertions causing false positives. | Do not add speculative assertions on return value internals; keep `assertNotNull(return value)`; if implementation always `new` that type, can add `assertNotSame(first, second)`; in case or comment note “only assert observable result when dependency behavior not retrievable”. If third-party public API or mocked dependency **can** be confirmed, then add content/field assertions. |
| **Existence-only assertion (return value contract clear)** | Return value has clear contract (e.g. certain input maps to certain enum or value), but case only does `assertNotNull(result)` / `assertNotSame(null, result)`, or same contract as another case but only existence assertion. | Existence-only assertion forbidden (reference 2.3); when return value contract is clear, use **content/field-level** assertion; otherwise test may still pass when core logic is wrong. | Add content assertion: `assertEquals(expected, result)` and key fields (e.g. `assertEquals(expected enum, result)`, `assertEquals(expected code, result.getCode())`, `assertEquals(expected msg, result.getMsg())`); if duplicate of another case (same input same contract), unify to same content assertions and remove redundant existence-only. |
| **Fake assertion (e.g. assertTrue(true))** | Case has `assertTrue(true)` or equivalent “always true” (e.g. assertTrue(true) at end of try to mean “no exception”, or to mean “call succeeded”). | Fake assertion verifies no actual behavior and **must be forbidden** (reference III); replace with assertion on **observable result** of method under test (return value, exception, or “did not throw”). | Remove `assertTrue(true)`. **When there is return value**: in try assert return value (e.g. `boolean result = sut.method(...); assertFalse(result);`), in catch assert exception (e.g. `assertNotNull(e)`). **Void method, no assertable return value**: use `assertDoesNotThrow(() -> sut.method(...))` to assert “call does not throw”, not “always true”. If contract says “certain input must throw”, use `assertThrows(ExpectedException.class, () -> sut.method(...))`. |

**Summary**: For any case with a return-value dimension, **must** assert the return value; for multiple calls with different expected sources, **must** assert correspondence of each result to its expected source (identity/type) to avoid weak assertions or “verify call but not result”. When a branch returns a new empty object, besides assertNotNull assert observable fields (e.g. assertNull(result.getId())). When return value contract is clear, forbid existence-only assertion and use content assertion. When return value is third-party or determined by unmocked dependency and not retrievable, assert only observable behavior and note constraints explicitly (see Section VI). **Forbid** assertTrue(true) and similar fake assertions; replace with observable assertion on return value or exception.

---

## VI. Notes When Modifying (Tips)

When modifying or adding assertions, besides following Section V, follow the notes below and prioritize **correctness and stability**.

| Tip | Description |
|-----|-------------|
| **Correctness first** | When modifying or adding assertions, **correctness and stability override “strong assertion coverage”**. Do not introduce assertions that depend on unverified implementation details (e.g. reflection into third-party private fields) for the sake of content-level assertion, which can cause false positives or runtime errors on version or environment change. |
| **If not retrievable, do not assert** | If **internal structure or public API** of third-party/dependency (e.g. internal list of return value, getter names) cannot be learned via project source, docs, or available lookup, **do not write assertions for that part**; the “strong content-level assertion on return value internals” requirement may be skipped; assert only based on **behavior directly observable from the class under test’s own source** (e.g. return value not null, assertNotSame when always new). |
| **Assert only observable behavior** | Assertions on return value or external state should be limited to what is **readable and inferable within the project**; for third-party types, use only **exposed, stable public API** at the use site (e.g. method signature, documented getter). Avoid reflection, undocumented fields, or “looked up” internal implementation. |
| **Explicit constraint note** | When content-level assertion cannot be done for the above reasons, add a **comment** on the test class or case (e.g. “does not depend on third-party internals; only based on observable behavior of class under test”) for maintenance and review. |

---

## Usage

- **Must read before review**: First use the document’s **“Must read before review: context and content to observe (general)”** to decide which files to read (source file of method under test, called method definitions as needed, test class), then use each section’s **“Context and content to observe for this item”** to look at the right content in that context, then make the verdict. Do not infer “whether there is argument change / non-local variable change” etc. from test code or names without reading the implementation under test or called method definitions.
- This reference complements the DT assertion-validity review reference and the Huawei Cloud assertion-validity review reference: this one focuses on **assertion steps and assertion goals** (what to verify, what to avoid); the others focus on **existence/fake/exception/Mock** and other static/spec dimensions.
- Output dimensions should include: whether assertion goal covers value change, whether non-local variable/argument/return value assertions are sufficient, whether must-avoid assertions are present, whether Flux/Mono verifies full reactive contract.
- **Experience and fixes**: When reviewing or modifying cases, use **Section V “Experience and typical fixes”** to address “only verify without return value assertion”, “branch returns new instance without assertion”, “multiple calls without stub correspondence”, etc.
- **Notes when modifying**: When modifying or adding assertions, follow **Section VI “Notes when modifying (Tips)”**, especially **correctness first**, **do not assert when third-party content not retrievable**, **assert only observable behavior**, to avoid wrong or brittle assertions in pursuit of “strong assertions”.
- Implementation can combine static analysis, AST, StepVerifier usage pattern scanning to flag “return value only assertNotNull”, “assertTrue(true)”, “reactive only assert value not termination”, etc. automatically or semi-automatically.

---

*Source: Assertion Steps (4. Assertion Steps — Assertion Goal / Preferred / Non-Preferred / Flux-Mono) | Generated: 2026-03-10*
