# DT Assertion Validity Review Reference

This document summarizes review points related to DT (test) assertion validity for use by this Skill or other tools as reference.  
**Purpose**: Use as reference only; not the Skill body.

---

## I. Missing Assertions

**Goal**: Identify whether test cases contain effective assertions.

| # | Review point | Description |
|---|--------------|-------------|
| 1 | Class name is Assert | Detect use of assertion-related classes (e.g. `Assert`) |
| 2 | Call method name is Assert | Detect calls to assertion methods named Assert |
| 3 | Call method name is expect | Detect calls to `expect`-style methods (e.g. Spring MVC test) |
| 4 | Call method name is andExpect | Detect calls to `andExpect`-style methods |
| 5 | Mockito/PowerMockito verify | Detect calls to `Mockito.verifyXX`, `PowerMockito.verifyXX`, etc. |
| 6 | Native assert | Detect use of JDK native `assert` statement |
| 7 | Assertions in anonymous inner class | Whether anonymous inner classes contain any of 1–6 above |
| 8 | expected annotation | Whether test annotations include an `expected`-style annotation (e.g. `@Test(expected = ...)`) |

**Verdict**: If any of the above holds, the case **has assertions**; if none holds, there is **missing assertion** risk.

---

## II. Fake Assertions

**Goal**: Identify cases where assertion form exists but does not perform effective validation.

| # | Review point | Description |
|---|--------------|-------------|
| 1 | assertTrue argument | When the case contains `assertTrue`, check whether the argument is literal `true` or a constant; if so, may be fake assertion (no check of actual result) |
| 2 | assertFalse argument | When the case contains `assertFalse`, check whether the argument is literal `false` or a constant; if so, may be fake assertion |
| 3 | assertNotNull followed by assertion | When the case contains `assertNotNull`, check whether there is **at least one** content assertion on the object via `assertEquals`, `assertTrue`, or `assertFalse`; if only assertNotNull with no content assertion, may be fake/weak assertion |

**Verdict**: If any of the above “may be fake assertion” situations applies, mark as **fake assertion** for manual confirmation or automatic warning.

---

## III. Early Exit

**Goal**: Identify risk that test logic returns early in a branch/loop so that later assertions are never executed.

| # | Review point | Description |
|---|--------------|-------------|
| 1 | return inside loop/if | Check whether **loop bodies** or **if bodies** contain the `return` keyword; if so, later assertions in that branch may not run (early exit) |

**Verdict**: If `return` is found inside a loop or if block, determine from control flow whether **early exit** leaves some path without assertion coverage.

---

## Usage

- This reference can be used together with concrete implementation (e.g. static analysis, AST checks, annotation scanning).
- The Skill or scripts can reference the review-point list in this document to keep checks aligned with the spec.
- When implementing, output results separately for “missing assertions”, “fake assertions”, and “early exit” for reporting and traceability.

---

*Document version: initial | Review points source: DT assertion validity spec*
