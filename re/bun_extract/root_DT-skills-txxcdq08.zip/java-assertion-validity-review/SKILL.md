---
name: java-assertion-validity-review
description: Reviews a completed Java test file against two assertion-validity references (DT assertion validity checklist, DT assertion steps and goals), applies fixes step by step, and outputs the modified test file. Use when the user provides a Java test file path and asks for assertion-validity review, assertion validity review, modify test cases per spec, DT assertion checklist, remove fake assertions / add assertions / exception assertion spec, or requires test cases to comply with assertion validity; also prefer this skill when the user mentions "review tests", "strengthen assertions", or "modify test cases".
language: java
---

# Java Test Assertion Validity Review and Modification

According to three reference documents, read references, review the current Java test cases, and apply fixes in three sequential steps; finally output the modified test file.

## Input

- **java_file**: Path to the completed Java test file (e.g. `src/test/java/.../XxxTest.java`)
- **workspace_root**: Current project/workspace root (used to locate the test file and source under test; the three references are under this skill directory and need not be read from workspace root)

## Three References (under this skill’s reference directory)

The three documents are shipped with the skill at `reference/` + the English filenames in the table below. **You must read from that directory** when executing; do not rely on whether the workspace root has files with the same names.

| Step   | Filename | Focus |
|--------|----------|--------|
| Step 1 | [dt-assertion-validity-checklist.md](reference/dt-assertion-validity-checklist.md) | Static traits: missing assertions, fake assertions, early exit |
| Step 2 | [dt-assertion-steps-and-goals.md](reference/dt-assertion-steps-and-goals.md) | Assertion goals and steps: value-change dimensions, must-assert / must-avoid, Flux/Mono, experience and fixes, modification notes |

## Flow (execute strictly in order)

When you excute this flow, do not show text like "step1", "step2"
### Step 1: Static traits review and modification

1. **Read** the full text of this skill’s `reference/dt-assertion-validity-checklist.md`
2. **Review** the current test file (i.e. the version after Step 1) against:
   - I. Missing assertions (presence of Assert/expect/andExpect/verify/assert/expected, etc.)
   - II. Fake assertions (assertTrue(true), assertFalse(false), only assertNotNull without content assertion)
   - III. Early exit (return inside loop/if causing later assertions not to run)
3. **Modify**: Fix fake assertions, existence-only assertions without content, and removable early exits.
4. Keep the current version as the intermediate result after Step 2 and proceed to Step 3.

### Step 2: Assertion goals and steps review and modification (requires source under test)

1. **Locate source under test**: Infer the class under test from the test class name (e.g. `MockServiceTest` → `MockService` or `MockServiceImpl`), find the corresponding `.java` source in the workspace and read the method under test and its immediate context (methods called in the same file, instance/static fields).
2. **Read** the full text of this skill’s `reference/dt-assertion-steps-and-goals.md`.
3. **Review** the current test file together with **the source file of the method under test**, following the reference’s “Must read before review” and each section’s “Context and content to observe for this item”:
   - I. Assertion goals (value-change dimensions, observable state transitions, whether assertions fail when core logic is broken)
   - II. What must be asserted (non-local variables, input objects, field-level/content-level assertions on return value)
   - III. What must be avoided (existence-only, fake assertions, unrelated to state/business)
   - IV. Flux/Mono reactive assertions (lifecycle, termination signal, strategy aligned with the table)
   - V. Experience and typical fixes (only verify without asserting return value, branch returning new instance, multiple calls without bound stub, existence-only, fake assertions, etc.)
   - VI. Notes when modifying (correctness first, do not assert when not retrievable, assert only observable behavior, explicit constraint notes)
4. **Modify**: Apply the reference’s “Recommended fixes” and “Tips” for non-compliant items; do not introduce assertions that depend on unverified implementation details or third-party internals for the sake of stronger assertions.
5. Produce the final version.

## Output

1. **Modified test file**: Write the final version back to the user-provided `java_file` path (or to a path specified by the user). Output must be valid, compilable Java source; do not break syntax or introduce undefined symbols.
2. **Brief modification summary** (optional): In the conversation or in the same directory, briefly list what kinds of changes were made per the three references (e.g. added Then assertions, removed assertTrue(true), added return-value field-level assertions, added StepVerifier termination signal), for traceability.

## Conventions and notes

- The three steps must not be reordered: first spec clauses (Step 1), then static traits (Step 2), then assertion goals and steps (Step 3, which depends on source under test).
- If the source under test cannot be located in the workspace in Step 3, you may still make changes based only on the test code and Step 1/2 references, and note in the summary “Source under test not read; no value-change–based deep completion.”
- Prioritize **correctness and stability** when modifying; do not introduce dependencies on third-party internals, undocumented APIs, or reflection.
- Use forward slashes for all paths; read references from this skill directory’s `.reference/` to avoid Windows backslash issues.
- **You must** read all three references in order before reviewing and modifying; do not skip any step.

## References

- The detailed review points and criteria for the three references are defined **inside this skill’s .reference directory** in the three files above; this skill only specifies the reading order and input/output and does not repeat the review-point tables.
