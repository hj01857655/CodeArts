---
name: java-test-report
description: Generate a structured Java unit test report with coverage analysis, quality assessment, exception coverage detection, assertion validity, and naming convention checks. Trigger when user requests a test report or test quality summary.
allowed-tools: Read, Glob, Grep, CoverageAnalysis
language: java
---

# Java Test Report

After the user provides the unit test file and the signature of the target method, execute the following steps in sequence.

## Execution Steps

### Step 1: Analyze Coverage Data

1. Use the `CoverageAnalysis` tool, providing the test file path and the target method signature, to retrieve coverage data.
2. Analyze the returned coverage data.

### Step 2: Evaluate Test Quality

1. Use the `Read` tool with the test file path to load the test source code.
2. Evaluate the test code in terms of structure, naming conventions, assertion quality, and covered test scenarios.

### Step 3: Summarize Additional Check Results

Based on Step 1 and Step 2, supplement and summarize the following check results:

- Exception coverage detection: Whether exception handling paths in the tested code, especially `catch` blocks, are triggered and verified.
- Assertion validity check: Whether there are issues such as early exit, fake assertions, or missing assertions.
- Naming convention check: Whether test method naming, class/method JavaDoc, `@Description`, and Copyright comply with requirements.

If an existing report or prior analysis already includes relevant content, do not repeat the full description; only supplement status, differences, or unresolved issues.

### Step 4: Generate the Test Report

Based on the analysis and evaluation results from Step 1, Step 2, and Step 3, produce a structured and readable test analysis report.

The test analysis should follow these principles:

- Focus on coverage of business-critical execution paths
- Identify highly complex code with low coverage
- Distinguish meaningful coverage from superficial coverage
- Consider test maintainability and readability
- Include additional check results only once, without duplicating content already present in other sections

## Test Report Output Format

Generate the test report using the following structure:

### 1. Overview Summary

- Overall coverage metrics (line coverage, branch coverage, method coverage, class coverage)
- Total number of test cases and pass/fail statistics
- Key findings and risk level assessment

### 2. Detailed Coverage Analysis

- Coverage distribution by module/package
- Identification of low-coverage areas
- Uncovered critical code paths

### 3. Test Quality Assessment

- Test naming convention review
- Assertion effectiveness analysis
- Coverage of boundary conditions and exceptional scenarios
- Test isolation and independence evaluation

### 4. Additional Check Summary

Summarize the following checks in a concise checklist format:

| Check Item | Status | Findings | Fix Summary |
|------------|--------|----------|-------------|
| Exception Coverage Detection | ✅ Pass / 🔧 Fixed / ❌ Issues Found / ⚠️ No Data | Key findings on catch block coverage, exception handling assertions, etc. | Fixed content or no fix needed |
| Assertion Validity Check | ✅ Pass / ❌ Issues Found / ⚠️ No Data | Key findings on early exit, fake assertions, missing assertions, etc. | Fixed content, pending fixes, or no fix needed |
| Naming Convention Check | ✅ Pass / 🔧 Fixed / ❌ Issues Found / ⚠️ No Data | Key findings on naming, JavaDoc, `@Description`, Copyright, etc. | Fixed content or no fix needed |

Rules:

- If the same issue has already been described in the coverage or quality assessment sections, do not repeat the full details here.
- If this section contains the detailed finding, later recommendation sections should reference it instead of duplicating it.
- Do not output long rule explanations or sample templates unless explicitly requested.

### 5. Issues and Recommendations

- Identified test defects or shortcomings
- Prioritized improvement recommendations
- Suggested additional test cases
- Do not repeat issues already fully described in Additional Check Summary

### 6. Conclusion

- Overall test health score (A/B/C/D/F)
- Recommended next actions

## Error Handling

| Scenario | Handling |
|----------|----------|
| Test file not found | Output error message |
| Check result unavailable | Mark the corresponding item as `⚠️ No Data`, continue report generation |
| Coverage data unavailable | Report quality assessment only, note "Coverage data not available" |
