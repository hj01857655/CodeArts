---
name: generate-java-ut
description: This skill provides a structured approach to creating unit tests for Java functions, ensuring that context information is retrieved in an orderly manner, Mock objects are analyzed, and a comprehensive test plan is generated before producing the final unit test code. It is designed for scenarios where unit tests need to be generated for a target function that align with user specifications.
allowed-tools: Read, Write, Edit, Glob, Grep, CodeSemanticSearch
language: java
---
# Test Case Authoring

## Overview
When an Agent needs to create a test plan and generate unit tests for a target Java function, it should generally follow the workflow below:
Step 1: Dependency Information Collection  
Step 2: Context Information Collection  
Step 3: Mock Object Analysis  
Step 4: Assertion Quality Enforcement
Step 5: Test Class Code Output  
If the Agent detects that information required for a given phase is missing, it must refer to the corresponding phase workflow to complete the required information collection and output.

## Phase Directory

### Dependency Information Collection
Read `references/phase-1-dependencies.md`.

### Context Information Collection
Read `reference/phase-2-context.md`.

### Mock Object Analysis
Read `references/phase-3-mocking.md`.

### Assertion Quality Enforcement
Read `references/phase-4-assertions.md`.

### Test Class Code Output
Read `references/phase-5-output.md`.

## Global Constraints

### Tool Usage Constraints:
During unit test planning and authoring, you are restricted to using the following tools. You must strictly adhere to the tool names and parameter specifications:
- **Read**
- **Glob**
- **Grep**
- **CodeSemanticSearch**
- **Write**
- **Edit**

### Working Language:
ALWAYS use **ZH-CN(Simplified Chinese)** as your working language

### Working Output

The `generate-java-ut` working output MUST satisfy the following hard requirements.

---

## Unit Test Class Naming & Extension Rules (Hard Requirement)

The following rules are **non-negotiable** and apply to **all** unit test generation and modification.

### 1. Test Class Naming Rule (Mandatory)

For any target production class `X`, the corresponding unit test class name MUST be:

`XTest`

Alternative naming styles are **STRICTLY FORBIDDEN**, including but not limited to:

- `XTests`
- `TestX`
- `X_Test`
- `XUnitTest`
- `XTest1`
- `XTestV2`

If an existing test class already exists, the agent MUST:

- reuse the existing class
- MUST NOT create a differently named test class for the same production class

Any violation of this rule is considered **invalid test generation**.

---

### 2. Single Test Class per Production Class (Mandatory)

For a given production class `X`:

- all unit tests targeting methods of `X` MUST reside in the same test class, `XTest`

Creating multiple test classes for the same production class is **not allowed**.

---

### 3. Multiple Target Methods Handling Rule (Mandatory)

If the user request, either explicitly or implicitly, involves multiple methods of the **same** production class, the agent MUST:

- append new test methods to the **end** of the existing `XTest` class
- preserve all existing test methods unchanged unless fixing blocking issues

The agent MUST NOT:

- create a new test class
- split tests across multiple files
- reorder existing test methods unnecessarily

Appending new tests at the end of the test class is the **standard and expected practice**.

---

### 4. Cross-Class Targeting Guardrail

If multiple target methods belong to **different** production classes:

- each production class MUST have its own dedicated test class
- each test class MUST follow the `ClassNameTest` naming rule

Mixing tests for different production classes in a single test class is **strictly forbidden**.

---

## Test Case Comment Requirement (Mandatory)

Each individual unit test case MUST include a comment that clearly describes the **test scenario**.

The comment MUST:

- appear immediately above the test case, or at the beginning of the test case body
- describe what scenario is being tested
- be specific enough to distinguish the case from other test cases

The agent MUST NOT generate test cases without scenario comments.

### Example

```java
// Test scenario: returns empty result when the input list is null
@Test
public void testHandleNullInput() {
    ...
}


### Forbidden Actions:
- During all DT subagent operations, the code under test (including production classes, services,
  repositories, domain objects, and any non-test source files) is strictly read-only.
  - You MUST NOT modify, rewrite, refactor, or regenerate the code under test.
  - You MUST NOT create alternative implementations, wrapper classes, or modified copies
    of the code under test.
  - You MUST NOT adjust production code logic, method signatures, visibility, or behavior
    to accommodate unit tests.