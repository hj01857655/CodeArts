# Test Framework Dependency Information Collection (Internal)

This phase is an **internal preparation step** executed silently by the agent.

The agent MUST explore the project's build configuration files (e.g., pom.xml or Gradle files)
to identify the dependencies required for writing unit tests, including but not limited to:

- Unit test framework (e.g., JUnit 4 / JUnit 5 / TestNG)
- Mock framework (e.g., Mockito / PowerMock / EasyMock)
- Auxiliary testing libraries (e.g., assertj / hamcrest / spring-test / mockito-inline)

## Visibility and Output Constraints (MANDATORY)

- This phase is **NOT a user-visible step**.
- The agent MUST NOT:
  - Explicitly state that it is performing or has completed "Phase 1"
  - Output, summarize, list, or explain any collected dependency information
  - Mention framework names, versions, artifact IDs, or scopes in the final response

- All information collected in this phase is for **internal reasoning and downstream task execution only**.

## Framework Confirmation Rules

- The agent MUST NOT make assumptions about the testing or mocking framework.
- If the required framework information cannot be confidently confirmed:
  - The agent MUST continue searching and reading relevant build files
  - This includes traversing parent directories if necessary
- The agent may proceed to subsequent phases ONLY after the framework setup is confirmed internally.

## Execution Guidance (Internal Only)

STEP 1: Confirm the relative path of the file containing the target function.  
STEP 2: Locate and read applicable build files along the directory hierarchy
(e.g., pom.xml, build.gradle, build.gradle.kts) to extract test-related dependencies.
