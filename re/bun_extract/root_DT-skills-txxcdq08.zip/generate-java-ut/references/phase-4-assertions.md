# Phase 4: Assertion Quality Enforcement

## 4.1 Assertion Goal

To ensure assertions are **meaningful and effective**, tests MUST validate as many **value-changing** aspects of the method-under-test as possible, specifically across:

1. **Non-local variables** (state outside the method scope that changes during execution),

2. **Parameter values** (input objects whose internal fields are mutated),

3. **Return values** (output objects/structures whose fields reflect meaningful computation).

Assertions SHOULD focus on verifying **observable state transitions** rather than superficial outcomes.

## 4.2 Preferred Assertions (What MUST Be Asserted)

### 4.2.1 Non-local Variables (Mutated External State)

Identify any **non-local variable** whose value changes during execution (e.g., class fields, shared objects, dependency state, caches, repositories, static/global holders).

Assertions MUST verify:

* The **exact fields** that changed.
* Correct before/after values.
* Structural updates such as:

    * Added or removed collection elements
    * Updated counters
    * Persisted entities
    * Written records
* Observable side effects produced through dependencies.

**Goal:** Detect whether the method produced the intended external state change.

---

### 4.2.2 Parameter Values (Mutated Inputs)

If the method mutates input parameters (objects passed by reference), assertions MUST validate:

* Which **fields inside the parameter** changed.
* The correctness of each changed field.
* Structural mutations such as:

    * Collection size changes
    * Map updates
    * Nested object modifications

**Goal:** Ensure input mutations match the expected behavior contract.

---

### 4.2.3 Return Values (Computed Outputs)

Assertions MUST validate return values at the **field level**, not just existence.

Required checks include:

* Key business fields
* Derived / computed values
* Nested object properties
* Collection contents (and ordering when relevant)
* Status flags, error codes, and metadata

**Goal:** Confirm the returned object fully reflects the intended computation.

---

## 4.3 Non-Preferred Assertions (MUST Avoid)

Avoid assertions that do not validate real behavior, including:

* Existence-only assertions:

    * `assertNull(...)`
    * `assertNotNull(...)`
* Fake assertions:

    * `assertTrue(true)`
* Assertions unrelated to state transitions, mutations, or business correctness.

If an assertion would still pass when the core logic is broken, it is **not acceptable**.

## 4.3 Flux/Mono Situation

When writing unit tests for **Flux** and **Mono**, assertions MUST validate the full reactive contract ? including emitted elements, termination signals, error behavior, and observable side effects. Tests should focus on **behavioral correctness** rather than implementation details.

### 4.3.1 Assertion Objective

Reactive streams follow a strict signal lifecycle:
onSubscribe ? onNext (0..N) ? (onComplete | onError | cancel)

Assertions MUST verify:

* What was emitted
* In what order
* How the stream terminated
* Whether errors occurred
* Whether timing, retry, or backpressure behavior is correct

A test that validates only values but ignores termination is considered incomplete.

### 4.3.2 Assertion Strategy Reference

| Assertion Goal                      | Recommended Assertion                                           | Key Rule                                                                                                        |
| ----------------------------------- | --------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| Emit expected value(s) and complete | `expectNext(...)` ? `verifyComplete()`                          | Always assert both emitted data **and** the terminal signal to ensure the reactive contract is fully validated. |
| Mono success (single value)         | `expectNext(value)` ? `verifyComplete()`                        | Treat a successful `Mono` as a two-part contract: **one value + completion**.                                   |
| Empty publisher                     | `verifyComplete()` or `expectNextCount(0)` ? `verifyComplete()` | Explicitly verify **no emissions** and **normal completion**.                                                   |
| Multiple values (order-sensitive)   | `expectNext(a, b, c)`                                           | Use strict ordering when sequence correctness matters.                                                          |
| Multiple values (count only)        | `expectNextCount(n)` ? `verifyComplete()`                       | Only use when value correctness is validated elsewhere; otherwise prefer explicit matching.                     |
| Predicate-based matching            | `expectNextMatches(predicate)` or `assertNext(consumer)`        | Prefer predicate checks for complex objects instead of relying on `equals()`.                                   |
| Record and inspect emissions        | `recordWith(...)` ? `consumeRecordedWith(...)`                  | Record first when validating complex collections or aggregated properties.                                      |
| Error termination (type)            | `expectError(SomeException.class)`                              | Always verify the **error type** when failure is expected.                                                      |
| Error termination (details)         | `expectErrorSatisfies(...)`                                     | Validate message, cause, or domain fields without overfitting to exact strings.                                 |
| Emit values then fail               | `expectNext(...)` ? `expectError(...)`                          | Assert both the pre-error emissions and the failure signal.                                                     |
| Cancellation behavior               | `thenCancel()` ? `verify()`                                     | Use cancellation assertions when testing operators like `take`, `timeout`, or manual disposal.                  |
| Backpressure / request control      | `StepVerifier.create(publisher, 0)` ? `thenRequest(n)`          | Start with zero demand to precisely validate producer behavior.                                                 |
| Time-based operators                | `withVirtualTime(...)` ? `thenAwait(...)`                       | Prefer **virtual time** over real delays to keep tests deterministic and fast.                                  |
| Timeout protection                  | `verifyTimeout(Duration)`                                       | Prevent hanging tests by enforcing a maximum execution window.                                                  |
| Retry / re-subscription             | Combine StepVerifier with a counter or mock verification        | Validate the number of subscriptions or retries via observable side effects.                                    |
| Fallback / recovery path            | Inject error source ? assert fallback emission                  | Explicitly test recovery logic such as `onErrorResume`.                                                         |
| Reactor Context usage               | `contextWrite(...)` ? `expectNext(...)`                         | Inject context within the test and verify it influences behavior correctly.                                     |
| Scheduler / threading behavior      | Capture thread in `doOnNext` if required                        | Prefer asserting observable behavior; only verify threads when scheduling is part of the contract.              |


