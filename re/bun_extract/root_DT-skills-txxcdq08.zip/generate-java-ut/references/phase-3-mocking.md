# Phase 3: Mock Object Analysis

## 3.1 Value of Mocking

Replace dependencies that are difficult to construct or execute realistically (database/network/redis/file system, etc.) with Mock stubs to enable stable branch coverage.

---

## 3.2 Mock Decision Principles (Must Follow)

### 1) **Mock boundary dependencies**

#### Should Mock:

* database access layers (Repository / DAO)
* external API calls (HTTP Client)
* file system operations
* message queues
* cache services
* time-related dependencies (`Clock`)

#### Should NOT Mock:

* simple utility / helper methods
* pure computation logic
* value objects (Value Objects)
* **JDK standard library methods** (e.g., `java.lang`, `java.util`, `java.time`, `java.math`)

    * Examples include:

        * `String`, `Objects`, `Optional`
        * `Collections`, `List`, `Map`, `Set`
        * `Math`, `BigDecimal`
        * `LocalDate`, `Instant`, `Duration`
        * `System`
    * These methods are deterministic, stable, and well-tested, and mocking them
      usually reduces test readability and reliability rather than improving coverage.

---

### 2) **Minimize Mock scope**

Only Mock methods proven necessary; no need to mock everything.

Self-check principles:

* logic depends on infrastructure (database/Redis/message queue/file system)
* located at critical branch entry points and return construction is complex

---

### 3) **Do not Mock the class/method under test**

Mock exists only for branch coverage and external dependency isolation;
do not mock the class under test or the target method itself.

```java
// ???Mock ????
@Mock
private UserRepository userRepository;

// ??: ?????? Mock???@InjectMocks???????
@InjectMocks
private UserService userService;

// ????Mock ????????????????????????Mock????????????
@Spy
private UserService userService;  
```

---

## 3.3 Mock Prohibitions and Limitations

* **Prohibited**: Mocking private methods.
* **Prohibited**: Mocking `final` methods (unless the project explicitly supports and enables inline mocking, and this is confirmed in the POM).
* **Restricted**: Static mocking is only allowed if `mockito-inline` or Mockito **3.4+** is configured in the POM.
* If mocking is impossible due to framework limitations, you must adjust inputs or internal state to trigger the required branches.

---

## 3.4 Mock Coding Patterns (Choose per Scenario)

### 3.4.1 Static Method Mocking (Mockito static)

Use **only** when static mocking support is confirmed
(e.g., `mockito-inline` or Mockito 3.4+ is configured):

```java
try (MockedStatic<StringUtils> stringUtilsMock = mockStatic(StringUtils.class)) {
        // void ????
        stringUtilsMock.when(() -> StringUtils.setString(Mockito.anyString()))
        .thenAnswer(invocation -> null);

        // ? void ????
        stringUtilsMock.when(() -> StringUtils.getString("api.url"))
        .thenReturn("http://test-api.example.com");
}
```

---

### 3.4.2 Mocking Other Methods in the Class Under Test (spy + doReturn)

```java
UserService spyService = Mockito.spy(realService);
doReturn(true).when(spyService).validateUser(anyString());
```

---

### 3.4.3 Standard Dependency Mocking (when / thenReturn)

```java
when(dep.query(any())).thenReturn(result);
when(dep.query(any())).thenThrow(new RuntimeException("..."));
```

---

### 3.4.4 void Methods (doNothing / doThrow)

Important:
`doNothing()` and `doThrow()` must only be used for methods with a void return type.

These APIs are designed specifically for stubbing void methods.
Using them on methods that return a value is invalid and misleading.

```java
doNothing().when(dep).save(any());
doThrow(new IllegalStateException("...")).when(dep).save(any());
```

---

### 3.4.5 Chained Calls

```java
// When you need to mock chained calls
when(httpClient.get(anyString())
        .header(anyString(), anyString())
        .execute())
        .thenReturn(response);

// Or use RETURNS_DEEP_STUBS (use with caution)
@Mock(answer = Answers.RETURNS_DEEP_STUBS)
private HttpClient httpClient;
```

---

## 3.5 Execution Steps

STEP 1: **Locate function call definitions**
Search the project for function call definitions within the target function to understand return values, parameters, and logic.

STEP 2: **Analyze Mock necessity**
Decide whether the call should be mocked based on the rules in Sections **3.2** and **3.3**.

STEP 3: **Select an appropriate Mocking approach**
Choose the most suitable mocking style based on Section **3.4**.

