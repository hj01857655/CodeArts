# Phase 2: Context Information Collection

This phase is an **internal preparation step** executed silently by the agent.

The agent MUST explore the project's build configuration files (e.g., pom.xml or Gradle files)
to identify the dependencies required for writing unit tests, including but not limited to:

- Unit test framework (e.g., JUnit 4 / JUnit 5 / TestNG)
- Mock framework (e.g., Mockito / PowerMock / EasyMock)
- Auxiliary testing libraries (e.g., assertj / hamcrest / spring-test / mockito-inline)

## Visibility and Output Constraints (MANDATORY)

- This phase is **NOT a user-visible step**.
- The agent MUST NOT:
    - Explicitly state that it is performing or has completed "Phase 1"
    - Output, summarize, list, or explain any collected dependency information
    - Mention framework names, versions, artifact IDs, or scopes in the final response

- All information collected in this phase is for **internal reasoning and downstream task execution only**.


## 2.0 General Principle: Efficient Context Retrieval
Explore the project efficiently using the following steps:
- Step 1: If you find multiple context items introduced within the same method file, prioritize using the Read tool to inspect that file, which is a one-time read to obtain multiple context items.
  For single context queries, use:
- Step 2: If Step 1 does not yield the required identifier definition, use the Grep tool to locate occurrences of an identifier or code snippet, then use Read to inspect the relevant definition.
- Step 3: For parameters/variables/fields that are hard to construct or lack setters, consider using mocking/reflection (if supported) to construct and configure them.


## 2.1 Return Type Information Collection for the Target Function

### 2.1.1 Purpose
By exploring the project and dependency code, understand the return type?s **actual creation/construction path** (not just "how to new an object"), and collect key fields related to the return value and how they can be accessed/set. This provides a reliable basis for later assertion design and branch coverage.

### 2.1.2 Mandatory Requirements
- For return type construction/creation, you must confirm at least **one viable path** and note its prerequisites (e.g., required parameters, validation constraints, immutability).
- You must cover two categories:
    1) **How the return value is produced**: whether the function returns a newly created object, a factory result, a cached value, an aggregated collection result, a framework-built object, or a pass-through value/object.
    2) **Observable points**: which fields/properties/collection elements can be stably read for assertions (getter/record accessor/public field/toString), and whether those values are affected by defaults or computed logic.
- For "logic-related fields":
    - Collect only fields/properties directly tied to the function?s logic (conditional outcomes, aggregation counts, branch-dependent return content).
    - You must confirm **how to read** those fields (getter/accessor/public field/collection element/key lookup), not merely their existence.

### 2.1.3 Execution Steps
1) **Determine the return shape**
    - Record the static signature: T / Optional<T> / List<T> / Map<K,V> / Stream<T> / void, etc.
    - If generic: confirm actual type parameters come from method signature, class generics, or inferred sources (call site/field type).

2) **Locate the return type definition (including key dependencies)**
    - Read the return type definition: class/interface/record/enum, visible construction entry points, fields, and accessors.
    - If interface/abstract: locate likely implementation sources (project implementations, third-party implementations, factory-returned concrete classes).
    - If third-party: locate official construction entry points and immutability/default rules (based on source/docs).

3) **Confirm the "actual creation path" (core)**
    - In the target function, locate the return statement source and distinguish patterns (record internally):
        - Direct new / builder / factory creation and return
        - Pass-through of downstream method return
        - Retrieval from field/cache/singleton/context
        - Collection/Map/Stream aggregation return (collect/toList/toMap, etc.)
        - Conditional branches returning different subtypes/instances
        - Constants/enums/empty collections/Optional.empty, etc.

4) **Collect construction entry points (cover major possibilities)**
    - Direct construction:
        - Constructors (overloads, visibility restrictions)
        - setter / fluent setter
        - builder (Lombok @Builder/@SuperBuilder, or manual Builder)
        - static factories (of/valueOf/from/create/builder, etc.)
    - Immutable/special types (must cover):
        - record: canonical/compact constructor only
        - enum: fixed value set
        - Optional: empty/of/ofNullable
        - Collections: List.of/Set.of/Map.of, Collections.emptyXxx/singletonXxx, new ArrayList/HashMap
        - Stream: Stream.of/Collections.stream/IntStream, etc.
        - primitive/value/time types: LocalDate/Instant/Duration/BigDecimal/UUID, etc.
    - Framework/serialization creation (when necessary):
        - Jackson/Gson deserialization (ObjectMapper.readValue, etc.)
        - Spring binding/proxy objects (AOP proxy, @ConfigurationProperties binding)
    - Hard-to-construct types (must identify and record alternative strategy entry points, but do not output solutions):
        - No public constructors, final + complex invariants, strong validation objects (only via factory/parser/framework)
        - System-resource-dependent return objects (file/network/clock/thread): record injectable/mockable source points

5) **Collect logic-related observable fields/properties (collect only, do not output)**
    - Infer from target function logic which return contents vary: field values, collection size, Map key set, Optional presence, subtype differences.
    - Confirm access method for each observable point: getter/record accessor/key/iterator, etc.
    - If computed: confirm computation source (direct calculation/downstream return/default/constructor assignment).

6) **Collect field assignment and default rules**
    - For key fields: confirm whether the source is constructor params, builder params, setters, or internal computation/defaults.
    - If defaults/derived fields exist: confirm where defaults are applied (field init, constructor, builder default, @Builder.Default).

### 2.1.4 Errors to Avoid
- Do not assume a no-arg constructor or setters exist; verify via source.
- Do not assume a builder exists; locate the entry point and required fields.
- Do not assume collections are mutable; verify List.of (immutable) vs new ArrayList (mutable).


---

## 2.2 Input Parameter Information Collection for the Target Function

### 2.2.1 Purpose
Ensure unit tests can construct **compilable, runnable, branch-controllable** input objects; consolidate construction knowledge into reusable strategies for later test generation and coverage iteration.

### 2.2.2 Mandatory Requirements
- For each parameter type, confirm at least one viable construction/acquisition method and define its **minimum viable form** (passes compilation/validation/non-null constraints).
- Dimensions must cover:
    - **Parameter source**: how callers obtain the parameter (new/factory/container injection/static access/deserialization/framework injection).
    - **Construction method**: how to instantiate, set fields, satisfy validation/invariants.
    - **Key fields**: only fields likely to affect logic (conditions, loop bounds, exception triggers, external call inputs).
    - **Constraints**: @NotNull/@Size/@Min/@Max/enum ranges, pre-validation, format requirements (JSON/UUID/date).
    - **Dependencies**: consistency constraints between parameters (e.g., field A constrains legal range of field B).

### 2.2.3 Execution Steps
1) **List target function parameters**
    - Record: parameter name, type (with generics), nullability, varargs, whether collection/array/Optional.
    - If interface/abstract: note potential implementations (project impl, third-party impl, test doubles).

2) **Locate parameter type definitions**
    - Read: class/interface definition, fields, constructors, builder, factory methods, static methods, inheritance.
    - Read: annotation constraints (Bean Validation, Jackson, Lombok), default strategies (field init/constructor assignment).

3) **Collect constructible paths**
    - Direct construction:
        - constructors (public/protected/package-private)/overloads
        - setter / fluent setter
        - Lombok Builder (@Builder/@SuperBuilder)
        - factory methods (static of()/valueOf()/from()/create()/builder())
    - Container/framework paths (when necessary):
        - Spring/Guice injection acquisition (ApplicationContext/constructor-injected products)
        - configuration/properties binding objects (@ConfigurationProperties)
    - Deserialization/parsing paths (when necessary):
        - Jackson/Gson (ObjectMapper.readValue)
        - JSON/XML/Proto/Avro parsing
    - Collection/map/optional types:
        - minimal instances (empty/singleton/mutable)
        - Optional.empty/of
        - arrays and varargs construction
    - Enums/constants:
        - enum value set
        - recommended constant values
    - Time/value/id types:
        - typical construction patterns and format constraints (LocalDate/Instant/Duration/BigDecimal/UUID, etc.)
    - Hard-to-construct types (must cover):
        - final classes, no public constructors, complex invariants
        - objects created via factory/parser/framework
        - third-party objects (prefer official APIs)
        - I/O/system-resource-dependent objects (file/network/thread/clock) ? collect replacement points only (mock/fake/test double), do not output solutions

4) **Collect key fields**
    - Internally identify which fields may affect control flow/exceptions/external call inputs/boundary behavior
    - Collect: legal ranges, defaults, nullability, inter-field constraints

5) **Locate field construction/assignment methods**
    - For fields that cannot be directly set:
        - builder chain, constructor param mapping, withXxx methods, copy/clone, record construction
        - required params and default strategies of static factories
    - For nested objects:
        - recurse one level (only until constructable), avoid infinite expansion

6) **Form "minimum viable parameter construction strategies" (internal structured record)**
    - For each parameter, store internally (not shown to the user):
        - MVP construction method
        - alternative construction method(s)
        - key fields and constraints
        - dependency points that must be mocked (e.g., resource handles inside parameter)

---

## 2.3 Initialization Information Collection for the Class Under Test

### 2.3.1 Purpose
By exploring project code and runtime context, clarify **how the class under test is correctly created and initialized**, including construction strategy, dependency injection, lifecycle management, and required context conditions, providing reliable evidence for later test object creation, dependency replacement, and behavior control.

### 2.3.2 Required Information to Collect
- Whether the class under test is framework-managed:
    - Spring Bean annotations (@Component / @Service / @Repository / @Configuration, etc.)
    - AOP proxies or lifecycle callbacks (@PostConstruct, etc.)
- Instance creation entry points:
    - Available constructors (visibility, parameter list, overloads)
    - builder / factory / static getInstance
- Dependency injection strategies (confirm each):
    - constructor injection (preferred constructor, @Autowired constructor)
    - field injection (@Autowired/@Inject)
    - setter injection
    - framework auto-wiring (Spring/Guice)
- Dependency forms:
    - repository / client / service / util
    - interface / abstract / final class
- Static or implicit dependencies:
    - static fields / static methods
    - singleton / enum singleton
    - ThreadLocal / ContextHolder
- Special context requirements:
    - configuration (@Value / properties / yaml)
    - environment variables / system properties
    - clock / thread pool / I/O resources

### 2.3.3 Execution Steps
1) **Locate the class under test definition**
    - Locate source and record package path, modifiers, inheritance, implemented interfaces.
    - Note framework-related annotations (Spring, Jakarta, Lombok, etc.).

2) **Confirm whether the class is framework-managed**
    - Determine whether it is a Spring Bean or managed by other IoC containers.
    - If yes:
        - confirm scope (singleton/prototype/request, etc.)
        - note if it may be proxied (AOP/transactions/caching)

3) **Analyze constructors and instance creation strategy**
    - List all constructors:
        - parameter count
        - parameter types
        - visibility (public/protected/package-private)
    - Confirm the constructor actually used:
        - @Autowired constructor
        - only-one-constructor implicit injection
    - Locate whether there is:
        - builder
        - static factory (create/of/getInstance, etc.)

4) **Collect dependency injection info (collect only, do not output solutions)**
    - For each dependency field:
        - source (constructor param / field injection / setter)
        - type (interface / abstract / concrete)
        - replaceability (final/static?)
    - If dependencies come from parent classes:
        - include them as well

5) **Identify static and implicit dependencies (must cover)**
    - static util / static client
    - singleton access points (XxxHolder / Xxx.INSTANCE)
    - ThreadLocal / Context / SecurityContext, etc.
    - Record access entry points and lifecycle traits

6) **Collect initialization and lifecycle logic**
    - Whether it has:
        - @PostConstruct
        - init methods
        - important logic in constructor
    - Assess whether these affect the target function?s behavior or required pre-state

7) **Collect required runtime context conditions**
    - configuration sources (@Value / config classes / constants)
    - environment variables / system properties
    - external resource dependencies (file path, network address, etc.)
    - Only record dependency points; do not generate mock/stub solutions in this phase

### 2.3.4 Errors to Avoid
- Do not assume the class can be instantiated via a no-arg constructor.
- Do not ignore inherited or framework-injected implicit dependencies.
- Do not ignore static / singleton / ThreadLocal dependencies.
- Do not output Mock strategies or test code in this phase.

Note: Your goal in this phase is to **fully understand how the class under test is correctly created and becomes usable**, not how to construct it in tests. All conclusions must be based on code and configuration facts.