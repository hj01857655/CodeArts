# Phase 5: Test Class Code Output

## 5.1 Output Requirements (Mandatory)
Use the **Write** tool to create a unit test file from scratch, or use the **Edit** tool to incrementally update an existing unit test file.  
The final unit test file **must** include the following elements:
- package declaration
- import statements
- Test class definition corresponding to the class under test
- Setup / fixture method (@BeforeEach or @Before)
- All test methods

All generated unit test classes MUST be declared as public.

The class declaration MUST start with public class.

package-private, protected, or omitted access modifiers are strictly forbidden.

If a test class is not declared public, the output is considered invalid and must be regenerated.

Additional requirements:
- Use the testing and mocking frameworks confirmed in the project **POM** (e.g., JUnit4 vs. JUnit5, Mockito vs. PowerMock).
- Assertions should use the project?s preferred assertion library; if the POM does not explicitly specify one, default to basic JUnit / Mockito assertions.
- Maintain high readability: each test method must follow the **Arrange / Act / Assert** pattern and use clear, descriptive naming.
- Every test class **must be declared as a `public` class**.

## Recommended Code Structure (Optional but Recommended)
- @ExtendWith(MockitoExtension.class) (JUnit5 + Mockito)
- @Mock dependencies, @InjectMocks class under test (for clear constructor / field injection)
- Wrap static mocking with try-with-resources to avoid polluting other test cases.

## 5.2 Code Output Rules
?1?The final test code must be produced only via the Write tool or Edit tool.
?2?Do not output fragmented code or code missing import or package declarations.

## Failure and Fallback Strategies
(1) If at any phase you cannot confirm required type definitions, construction methods, or key field assignments, you must continue using tools to search and fill gaps. Do not proceed directly to test case design or code writing.
(2) When external dependencies cannot be mocked, try:
- Using real objects
- Adjusting input parameters, or
- Setting internal state to trigger the desired branches.