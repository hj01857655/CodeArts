# Coverage Problem Routing

Please match the rules in **top-to-bottom** order based on the characteristics of uncovered code in the coverage report. Once a match is found, immediately load the corresponding coverage strategy.

## No Test Cases

- **Trigger condition**: No TEST macros exist in the test file
- **Coverage strategy**: User needs to generate test cases first

## If Branch Not Covered

- **Trigger keywords**: `if`, `else`, `==`, `!=`, `>`, `<`, `>=`, `<=`
- **Other characteristics**:
  - Uncovered code lines are inside an if block
  - The true branch of the if condition is not covered
  - The false branch of the if condition (else branch) is not covered
  - Some branches in multi-way if-else if-else chains are not covered
  - Some branches in nested if statements are not covered
- **Coverage strategy**:
  - Construct positive and negative input data
  - Mock different return values to trigger different branches
  - Set different object states
  - Use different enum values
  - Use empty/non-empty container states

## Static Method Mock Limitation

- **Trigger keywords**: static utility class, `std::bind`, `std::function`
- **Other characteristics**:
  - Uncovered code lines involve calling static utility class methods
  - Static method behavior is difficult to verify
- **Coverage strategy**:
  - Use verify to validate calls instead of stub
  - For static methods with return values, stub return values as needed
  - Consider letting some methods execute with real implementation

## Private Method Not Covered

- **Trigger keywords**: (need to analyze the method name of uncovered methods in the coverage report)
- **Other characteristics**:
  - Uncovered code lines are inside a private method
  - The private method is not directly called by any test case
- **Coverage strategy**: Trigger private method execution indirectly through public methods
