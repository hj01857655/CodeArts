# Systematic Test Design Methodology

## Overview

Test design is the core of unit test quality. The following analysis must be completed before generating test code.

## Control Flow Analysis

1. Draw a control flow graph: mark each conditional branch point (if/else/switch), loop entry and exit, goto/return points
2. Calculate cyclomatic complexity: Cyclomatic Complexity = number of conditional branches + number of loops + 1
3. List all independent paths: each path must have at least one test case
4. Number of test cases ≥ cyclomatic complexity

## Data Flow Analysis

1. Identify key variables: input parameters, output parameters, return value variables, intermediate computation variables
2. Analyze variable lifecycle: definition point (assignment location), use point (read location), destruction point (release location)
3. Cover definition-use paths: ensure each variable's def-use path has test coverage

## Boundary Condition Analysis

Systematically test each input parameter according to the following matrix:

| Parameter Type | Boundary Value 1 | Boundary Value 2 | Boundary Value 3 | Boundary Value 4 | Special Value |
|----------------|-----------------|-----------------|-----------------|-----------------|--------------|
| int | 0 | 1 | INT_MAX | INT_MIN | -1 |
| uint32 | 0 | 1 | UINT32_MAX | 2 | UINT32_MAX-1 |
| pointer | NULL | valid address | - | - | alignment boundary |
| array | empty (0) | single element (1) | full | out of bounds (-1) | out of bounds (+1) |
| string | NULL | empty string ("") | single character | extra long | special characters |
| struct | all zeros | partial init | fully init | invalid field | boundary value combinations |
| bool | false | true | - | - | - |
| enum | valid value | invalid value | boundary value | - | - |

### State Boundary Analysis

- Uninitialized state call
- Initialized but not ready state
- Working/busy state
- Stopped/destroyed state
- Error/exception state
- State transition critical point

### Resource Boundary Analysis

- Memory: minimum allocation, maximum allocation, just exhausted, over-allocated
- File descriptors: 0 open, max open count, over limit
- Connections: 0 connections, single connection, full connection pool, over limit
- Queues: empty queue, single element, full queue, overflow

### Numerical Computation Boundaries

- Overflow detection: addition overflow, multiplication overflow, negative overflow
- Rounding boundary: rounding critical values
- Division: divide by 0, divide by 1, very large divided by very small
- Precision: floating-point precision critical values

### Multi-Parameter Boundary Combination Strategy

- Normal value + normal value (baseline)
- Boundary value + normal value (single-dimension boundary)
- Normal value + boundary value (single-dimension boundary)
- Boundary value + boundary value (multi-dimension boundary - high priority)
- Special value + special case (most extreme scenario)

## Exception Scenario Analysis

### Resource Allocation Failure Analysis

Identify all resource allocation points in the function, and design failure tests for each allocation point:

| Resource Type | Allocation Function Example | Failure Return Value | Failure Scenario Test Requirement |
|--------------|---------------------------|---------------------|----------------------------------|
| Memory allocation | malloc/calloc/zalloc | NULL | Must test |
| File open | fopen | NULL | Must test |
| Lock acquisition | pthread_mutex_lock | non-zero | Must test if there is error handling |
| Dynamic creation | xxx_create/init | NULL/error code | Must test |
| Socket creation | socket/connect | -1/error code | Must test |

**Key Strategy**: For each resource allocation, the following scenarios must be tested:
- First resource allocation fails
- Second resource allocation fails (if there are multiple allocations)
- Nth resource allocation fails (for allocations in loops)
- Last resource allocation fails

### External Call Failure Analysis

Identify all external function calls, and design failure tests for each call:

**Serialized failure scenarios** (multiple external call scenarios):
```
Assume the function calls A() -> B() -> C() -> D() in sequence:
- Test A() fails, verify B/C/D are not called
- Test A() succeeds, B() fails, verify A's resources are properly cleaned up
- Test A() succeeds, B() succeeds, C() fails, verify A and B's resources are properly cleaned up
- Test A() succeeds, B() succeeds, C() succeeds, D() fails, verify A, B, C's resources are properly cleaned up
```

### Parameter Exception Analysis

| Parameter Exception Type | Test Requirement |
|------------------------|-----------------|
| NULL pointer | All pointer parameters must be tested with NULL input |
| Empty array | Array input with length 0 |
| Invalid enum value | Values outside the enum range |
| Out-of-bounds index | Negative index, index exceeding maximum |
| Extra-long string | String exceeding buffer size |
| Incompatible parameter combinations | Invalid combinations of mutually exclusive or dependent parameters |

## Resource Leak Analysis

### Resource Inventory Establishment

Analyze all resources allocated in the function:

| Resource Type | Allocation Point | Release Point (Normal Path) | Release Point (Exception Path) | Release Verification Method |
|--------------|-----------------|---------------------------|-------------------------------|----------------------------|
| Memory block A | line 45 malloc | line 120 free | line 80 goto err | Mock free to verify call |
| Lock B | line 50 lock | line 115 unlock | line 85 goto err | Mock unlock to verify call |
| File C | line 55 fopen | line 110 fclose | line 90 goto err | Mock fclose to verify call |

### Exception Path Leak Check

**Core Rule**: Each goto err or return error code path must verify:
- All resources allocated before that point are fully released
- Release order is correct (last allocated is released first)
- State is fully rolled back to before the call

### Partial Failure Leak Check

For batch operations (loop creation, batch allocation, etc.):
- Test whether resources from the first N-1 successful operations are properly released when the Nth operation fails
- Test that each failure position has corresponding cleanup tests

## Decision Table Method

1. List all conditions (input conditions, environmental conditions, state conditions)
2. List all actions (return values, output parameter modifications, external function calls, state changes)
3. Build a decision table: each rule must have a test case

```
Rule ID | Condition 1 | Condition 2 | Condition 3 | Action 1 | Action 2 | Test Case
R1      | T          | T          | T          | Success  | Call A   | Must write
R2      | T          | T          | F          | Failure  | None     | Must write
R3      | T          | F          | -          | Failure  | None     | Must write
R4      | F          | -          | -          | Failure  | None     | Must write
```

## Business Scenario Deep Analysis

1. Identify business key paths: analyze the business purpose of the function (not just looking at code)
2. Enumerate business scenarios:

| Scenario Type | Business Description | Technical Implementation | Test Necessity |
|--------------|---------------------|------------------------|---------------|
| Normal flow | Complete business success path | All dependencies return success | Must |
| Shortcut path | Business optimization path | Triggered by specific conditions | Must |
| Fallback path | Business failure fallback | Error handling logic | Must |
| Special path | Business special handling | Specific parameter combinations | Must |

## Missing Scenario Checklist

Must check each item:

```
□ Control flow check
  □ All if statement true and false branches have tests
  □ All switch cases have tests (including default)
  □ All loops have tests for 0, 1, and multiple iterations
  □ All return paths have tests
  □ All goto/break/continue paths have tests

□ Boundary condition check
  □ All numeric parameters have tests for 0, 1, max, min
  □ All pointer parameters have NULL tests
  □ All arrays/strings have tests for empty, single element, full, out-of-bounds
  □ All enums have tests for valid and invalid values

□ Resource allocation failure check
  □ First resource allocation failure has tests
  □ Intermediate resource allocation failure has tests
  □ Last resource allocation failure has tests
  □ In-loop resource allocation failure has tests

□ External call failure check
  □ All external function call failure scenarios have tests
  □ Serialized external call each position failure has tests

□ Resource leak check
  □ Resource release verified for each error return path
  □ Release order correctness verified
  □ Preceding resource release verified for partial failure
  □ Global state rollback verified

□ Business logic check
  □ Business normal success path has tests
  □ Business failure fallback path has tests
  □ Business special condition path has tests
  □ Business shortcut path has tests
```

## UB Scenario Handling

When the function under test produces undefined behavior under certain inputs (such as divide by zero, null pointer dereference):

1. **Do not delete this test scenario**: Even if the production code has a bug, this scenario must be covered
2. **Use EXPECT_DEATH/ASSERT_DEATH**: Verify crash behavior, preserve coverage
3. **Annotate in test comments**: Explain that this is a production code bug, the test verifies crash behavior
4. **Example**:
```cpp
// Note: Division by zero with empty task list is a production code bug, using EXPECT_DEATH to verify crash behavior
TEST_F(TaskSchedulerTest, test_schedule_when_empty_list_then_crash) {
    TaskScheduler scheduler;
    scheduler.setTaskCount(0);
    EXPECT_DEATH(scheduler.schedule(), ".*");
}
```

## Priority Ranking

- **P0 - Must cover**: Business core paths, security-related checks, error handling paths, resource allocation failure scenarios
- **P1 - Should cover**: Boundary conditions, exception scenarios, branch coverage
- **P2 - Can cover**: Performance validation, stability testing, compatibility testing

P0 scenarios must be 100% covered, P1 scenarios at least 80% covered.

## Code Implementation-Oriented Test Design Method

The complete chain of analysis and design from code implementation to test cases: code structure analysis yields test guidance points, guidance points are used to construct test dimensions, coverage strategies are selected and applied based on test dimensions, and finally test cases targeting implementation logic are generated.

**Note**: This method is a complete full process. For some simple target modules, high-quality test cases may be designed without executing all the analysis processes described in this method.

### Step 1: Code Structure Analysis and Understanding

Use the `Structure-Behavior-Data` trinity analysis template:

#### 1. Static Structure Analysis (Structure)
- **Modules and dependencies**: Identify the module, class, function under test and their external dependencies
- **Interfaces and contracts**: Analyze function/method signatures (input parameters, return values, thrown exceptions)
- **Internal composition**: Organize key data structures, constant definitions, configuration items
- **Complexity metrics**: Cyclomatic complexity, lines of code, nesting depth, fan-in/fan-out

#### 2. Dynamic Behavior Analysis (Behavior)
- **Control flow**: Identify branch statements, loop statements
- **Key algorithms and logic**: Locate core business logic, computation processes, state transitions
- **Paths and scenarios**: Initially infer possible execution paths and trigger conditions
- **Side effects**: Analyze whether the function modifies external state

#### 3. Data Flow Analysis (Data)
- **Input sources**: Track the flow of parameters, configuration files, environment variables
- **Data transformation**: Identify assignment, computation, combination, and splitting processes of data within the function
- **Output and impact**: Clarify return values, modified state, generated files/network requests, etc.
- **Boundaries and special values**: Find data range judgments in the code

### Step 2: Test Dimension and Guidance Point Extraction

#### Logic Dimension Decomposition (Coverage-Driven)
- Statement guidance points → Mark all executable statements
- Branch guidance points → Mark True/False branches of all condition judgments
- Path guidance points → Mark several independent paths from entry to exit
- Condition combination guidance points → Mark value combinations of sub-conditions in compound conditions

#### Data Dimension Decomposition (Data-Driven)
- Input domain guidance points → Partition equivalence classes and boundary values based on parameter types and constraints
- Data flow guidance points → Track "definition-use" pairs
- State guidance points → Identify internal state variables and method call sequences that cause state changes
- Exception flow guidance points → Identify code locations that explicitly throw or may implicitly throw exceptions

#### Interaction and Integration Dimension Decomposition (Interaction-Driven)
- Dependency call guidance points → Mark all call points to external functions, APIs, databases
- Interface contract guidance points → Focus on interface input validation, output promises, exception declarations
- Resource management guidance points → Mark creation and release points of file handles, network connections, memory allocations

### Step 3: Coverage Strategy and Dimension Mapping Matrix

| Test Dimension | Recommended Coverage Strategy and Algorithm | Focus of Generated Cases |
|---------------|------------------------------------------|------------------------|
| Logic/branch dimension | Branch coverage, basic path method | Design inputs that cause the program to enter specific branches/paths |
| Condition combination dimension | Condition combination table, MCDC algorithm | Construct inputs that cause compound condition sub-items to take specific values |
| Data flow dimension | Definition-use path coverage | Construct inputs that cause variables to pass along specific def-use chains |
| Input domain dimension | Equivalence class partitioning, boundary value analysis | Select representative values, boundary values, illegal values as inputs |
| State transition dimension | State transition path coverage | Construct method call sequences to traverse state transitions |
| Exception flow dimension | Exception trigger point coverage | Construct exception inputs or environments to trigger specific exceptions |

### Test Case Design Checklist

- Each high-complexity function/method has a corresponding set of unit test cases
- Each extracted branch guidance point (True/False) has at least one case covering it
- Key data flow guidance points (important variable def-use pairs) are covered by test cases
- All explicit exception throw points have test cases that trigger them
- For calls to external dependencies, isolation and verification are performed through Mock/Stub in test cases
- The expected results of test cases strictly correspond to the code implementation logic
- Test cases can run independently and stably, without depending on external environments or specific execution orders
- Test case naming clearly reflects the code intent being tested
- Test cases should not call non-existent functions
