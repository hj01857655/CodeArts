# Test Case Generation Rules

## Naming Conventions

- Test case naming pattern: `test_{action}_when_{condition}_then_{result}`
- Simplified form (when condition is implied): `test_{action}_then_{result}`
- Test case descriptions use comments
- Prioritize referencing existing test files to maintain consistent code style
- **Naming accuracy**: If only verifying no crash, use `_NoThrow`/`_NoException` suffix; for state change verification use `_UpdatesState` descriptive suffix; for NULL condition verification use `_WhenXxxIsNull`
- **Boundary value naming**: Boundary test naming should reflect specific boundary conditions (e.g., `_AtMaxCapacity`, `_AtBoundary`)

## Code Organization Structure

```cpp
/*
 * Description: {Function under test} unit test
 * Create: {Date}
 */

// System header files
#include <gtest/gtest.h>
#include <stdint.h>

// Project header files
#include "module_error.h"

// Module under test header files - wrap with extern "C" when testing C from C++
extern "C" {
#include "module_target.h"
}

namespace module::testing {
using namespace ::testing;

class test_module : public ::testing::Test {
protected:
    void SetUp() override {
        // Common initialization
    }
    
    void TearDown() override {
        // Common cleanup
    }
    
    // Data construction helper functions
    void fill_default_param(param_t *param) { ... }
};

TEST_F(test_module, test_func_when_condition_then_result) {
    // Arrange
    param_t param = {};
    fill_default_param(&param);
    
    // Act
    int ret = module_func(&param);
    
    // Assert
    ASSERT_EQ(ret, MODULE_OK);
    
    // Cleanup
}

} // namespace
```

## Correct Usage of extern "C"

### Correct: Wrapping C header files

```cpp
extern "C" {
#include "module_target.h"
}
```

### Incorrect: Declaring extern "C" functions after include

```cpp
#include "module_target.h"
extern "C" int module_func(param_t *p);  // Error! Already declared in header file
```

### Incorrect: Forgetting extern "C" wrapper

```cpp
#include "module_target.h"  // C header files without extern "C" wrapper will cause link errors
```

## #define private public Usage Rules

**Core Principle**: Prefer testing through public interfaces. Only use #define private public when public interfaces are insufficient to verify expected behavior.

### Pre-use Judgment

1. Can the expected behavior be verified through public API return values/output parameters? → Prefer using public API
2. Can internal state be inferred through consecutive calls? → Prefer inference (e.g., state machines can infer state through consecutive calls)
3. Only use #define private public when none of the above works

### Correct Order

```cpp
// 1. gtest/gmock header files (must be before #define)
#include <gtest/gtest.h>
#include <gmock/gmock.h>

// 2. Other standard library header files (must be before #define)
#include <string>
#include <vector>

// 3. #define private public (before the header file under test)
#define private public

// 4. Header file under test
#include "target_class.h"

// 5. Restore private (optional)
#undef private
```

### Incorrect: Defining before standard library header files

```cpp
#define private public
#include <gtest/gtest.h>  // Error! gtest internal classes will also be affected
```

### Crash Handling

If segfault or undefined behavior occurs after using #define private public:
1. Immediately remove #define private public
2. Switch to public interface testing
3. Do not spend multiple rounds debugging issues caused by #define private public

### Macro Substitution Mock Injection Pattern

For scenarios requiring Mock by-value private members, correct include order:

```cpp
// 1. gtest/gmock header files
#include <gtest/gtest.h>
#include <gmock/gmock.h>

// 2. Dependency base class header files (without macro substitution)
#include "NetworkHandler.h"

// 3. Define Mock class
class MockNetworkHandler : public NetworkHandler {
public:
    MOCK_METHOD(bool, connect, (const std::string&), (override));
    MOCK_METHOD(void, disconnect, (), (override));
};

// 4. Macro substitution + private access
#define private public
#define NetworkHandler MockNetworkHandler

// 5. Header file under test (NetworkHandler will be replaced with MockNetworkHandler)
#include "NetworkManager.h"

// 6. Cleanup macros
#undef NetworkHandler
#undef private
```

**Key**: First include the base class header file and define the Mock class, then perform macro substitution and include the header file under test.

## Test Data Construction

### Struct Field-by-Field Assignment

```cpp
param_t param = {};  // Zero initialization
param.type = TYPE_NORMAL;
param.value = 100;
param.flags = 0;
param.name[0] = '\0';
```

### Pointer Initialization Standards

- Use `nullptr` instead of `NULL` (C++ type safety)
- Output pointer parameters must be initialized: `result_t result = {};`
- Array pointers: `uint8_t buffer[BUFFER_SIZE] = {};`

### Computation Helper Functions (Replace Hardcoded Binary Data)

For protocol parsing, CRC verification, frame building and other binary data processing scenarios, prefer using computation helper functions:

```cpp
class ProtocolTest : public ::testing::Test {
protected:
    uint16_t calculateExpectedCRC(const uint8_t* data, size_t len) {
        uint16_t crc = 0xFFFF;
        for (size_t i = 0; i < len; i++) {
            crc ^= data[i];
            for (int j = 0; j < 8; j++) {
                if (crc & 1) crc = (crc >> 1) ^ 0xA001;
                else crc >>= 1;
            }
        }
        return crc;
    }
    
    std::vector<uint8_t> buildTestFrame(uint8_t cmd, const uint8_t* payload, size_t len) {
        std::vector<uint8_t> frame;
        frame.push_back(0xAA);
        frame.push_back(cmd);
        frame.insert(frame.end(), payload, payload + len);
        uint16_t crc = calculateExpectedCRC(frame.data() + 1, frame.size() - 1);
        frame.push_back(crc & 0xFF);
        frame.push_back(crc >> 8);
        frame.push_back(0x55);
        return frame;
    }
};
```

### Prohibited: Hardcoded byte arrays

```cpp
// Error: CRC value is hardcoded; if an algorithm error is found, all cases need modification
uint8_t frame[] = {0xAA, 0x01, 0x02, 0x03, 0x45, 0x67, 0x55};
```

## Exploration Scope Constraints

After identifying the function under test, only read the following files:
- Source file containing the function under test
- Header file of the function under test
- Directly referenced type definitions/dependency header files

Skip unrelated files in the same directory. Use grep to locate the target function, then limit the read scope.

## C Module Static State Isolation Strategy

### Strategy 1: Directly include .c file (recommended, when the source file has no external dependencies)

```cpp
#include "db_operations.c"  // Note: not .h

class DbOperationsTest : public ::testing::Test {
protected:
    void SetUp() override {
        memset(database, 0, sizeof(database));
        record_count = 0;
    }
};
```

**Important**: When using #include .c, do not simultaneously compile and link that .c file, otherwise duplicate symbol errors (multiple definition) will occur.

Applicable conditions:
- Source file has no complex external dependencies
- Source file does not introduce compilation conflicts
- Need to access static global variables for state reset

### Strategy 2: Save and restore global state (when .c file cannot be included)

```cpp
#include "db_operations.h"

class DbOperationsTest : public ::testing::Test {
protected:
    void SetUp() override {
        saved_count = get_record_count();
    }
    void TearDown() override {
        while (get_record_count() > saved_count) {
            delete_last_record();
        }
    }
    int saved_count;
};
```

### Strategy 3: extern declaration (accessing non-static global variables)

```cpp
extern int g_module_state;
extern config_t g_config;
```

### Special Handling for static Pointer Pointing to static Local Variable

When a C module uses the `static double* ptr = nullptr;` pattern with `ptr = &local_var;` during initialization:

Incorrect: Only save and restore pointer
```cpp
void SetUp() override {
    saved_ptr = account_balance;
    account_balance = nullptr;
}
void TearDown() override {
    account_balance = saved_ptr;  // local_var's value has been modified by other tests!
}
```

Correct: Reset pointer and reset value
```cpp
void SetUp() override {
    account_balance = nullptr;  // Trigger re-initialization
    get_balance();              // Re-initialize
    *account_balance = 1000.0;  // Reset to known initial value
}
```

## SetUp Zero-Reset Pattern

For C modules using global state, SetUp must perform zero-reset:

Correct: Zero-reset + save and restore
```cpp
void SetUp() override {
    saved_process_count = process_count;
    process_count = 0;
    memset(process_table, 0, sizeof(process_table));
}
```

**Prefer reset functions**: If the module has init/reset functions (e.g., `init_pcb_table()`), prefer calling that function in SetUp rather than manual save/restore.

## GIVEN Phase Constraint (CRUD Interfaces)

For testing companion CRUD interfaces, follow the GIVEN phase constraint:

### Correct: Use add interface to construct test data

```cpp
TEST_F(DbTest, Query_WhenRecordExists_ThenReturnData) {
    // GIVEN: Use add interface to construct test data
    Record rec = {.id = 1, .data = "test"};
    add_record(&rec);
    
    // WHEN: Use query interface to verify
    Record result = {};
    int ret = query_record(1, &result);
    
    // THEN: Verify query result
    EXPECT_EQ(ret, 0);
    EXPECT_STREQ(result.data, "test");
}
```

### Incorrect: Mocking internal data structures of the query interface

```cpp
TEST_F(DbTest, Query_WhenRecordExists_ThenReturnData) {
    // Error: Mock the internal storage of the query interface
    EXPECT_CALL(mock_storage, find(1))
        .WillOnce(Return(Pointee(Record{1, "test"})));
    
    Record result = {};
    int ret = query_record(1, &result);
    EXPECT_EQ(ret, 0);
}
```

## Expected Value Batch Computation

Expected values for algorithm functions use a single script execution for batch computation:

```bash
python3 compute_expected_values.py
```

Multiple iterative single-query computations are prohibited.

## Fixture Inheritance

If the class under test already has a test Fixture base class, prefer inheriting from that base class rather than creating a new one:

```cpp
// Correct: Inherit existing base class
class ModuleAdvancedTest : public ExistingModuleTest {
protected:
    void SetUp() override {
        ExistingModuleTest::SetUp();
        // Additional initialization
    }
};

// Incorrect: Create new Fixture
class ModuleAdvancedTest : public ::testing::Test {
protected:
    Module module_;  // Duplicate definition
};
```

## Mock Architecture Simplification Principle

For gmock tests, prefer the simplest Mock architecture:

### Correct: Directly inherit and Mock the class under test

```cpp
class MockOrderProcessor : public OnlineOrderProcessor {
public:
    MOCK_METHOD(bool, validateOrder, (const Order&), (override));
    MOCK_METHOD(void, updateOrderStatus, (int, Status), (override));
};
```

### Incorrect: Two-layer delegation architecture

```cpp
// Unnecessarily complex architecture
class MockOrderProcessor : public OrderProcessor { ... };
class TestableOnlineOrderProcessor : public OnlineOrderProcessor {
    MockOrderProcessor mockBase;  // Extra delegation layer
    ...
};
```

**Principle**: Directly inherit the class under test and Mock its virtual methods, avoiding unnecessary delegation wrappers.

## Test Case Comment Standards

Each test case must have a comment at the top, formatted as scenario + expected:

```cpp
/**
 * Scenario: Scenario description
 * Expected: Expected behavior
 */
TEST_F(TestSuitName, TestCaseName)
```

**Check requirements**:
- Each case must have a comment
- Comment position is above TEST_F/TEST_P
- Comment must include scenario and expected
- Comments with only TCXXX_BriefDescription format are prohibited (missing scenario and expected description)
- Comments below the test case function are prohibited

## DISABLED_CASE Macro Disable Mechanism

When a test case cannot be fixed due to compilation/execution issues, use the DISABLED_CASE macro to disable it while preserving the complete case code:

```cpp
#ifdef DISABLED_CASE
TEST_F(FixtureName, CaseName) {
    // This case is disabled due to compilation/execution issues, auto-skipped
    // Problem reason explanation
    case code
    ...
}
#endif
```

**Prohibitions**:
- Do not delete case code (must preserve complete code for future fixes)
- Do not use comment style to disable cases (must use DISABLED_CASE macro wrapping)
- Do not modify or delete macro-definition disabled code (cases or code covered by #ifdef DISABLED_CASE and #endif)
- Must note the disable reason

## Test Case Naming Convention (Supplementary)

- Test suite (Fixture class) naming: Test + name of object under test (function/module/class name), UpperCamelCase style
- Test case naming: UpperCamelCase style, case name should include the case's key input and key output information
- Using UpperCamelCase instead of lowercase_with_underscores, mainly for two reasons: 1. gtest concatenates test suite name and test case name with underscores, which may cause naming conflicts if underscores are used; 2. Maintain consistency with business code naming style
- Test suite and case naming should be self-descriptive and self-documenting; test suite + test case name should read coherently
- Test case names should not use Chinese

## Test Code File Naming Convention

- Test case files: Use the name of the file/function/module under test + "_test" suffix, making it easier to understand the test target
- Test framework files: Equivalent to business functional code, use lowercase + underscore naming
- Mock files: Use the name of the mocked object + "_mock" suffix
- Stub files: Use the name of the stubbed object + "_stub" prefix
