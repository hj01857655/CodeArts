## Mock Strategy Design Principles

### 1. Risk-Adaptive Principle

Mock depth is proportional to the risk level of the dependency:

| Risk Level | Mock Strategy | Description |
|------------|--------------|-------------|
| High-risk dependency | Deep Mock (normal + exception + boundary) | Cover all critical paths |
| Medium-risk dependency | Selective Mock | Only Mock necessary exception branches |
| Low-risk dependency | Minimal Mock | Only Mock when necessary |

**Note**: If a branch cannot be Mocked due to framework limitations, you must trigger the target branch by adjusting input parameters or setting internal state. Do not skip branch coverage.

### 2. Scenario Matching Principle

Mock behavior must match the test case verification objectives:
- Do not Mock normal responses for exception scenarios
- Do not Mock normal responses for boundary scenarios

### 3. Minimal Mock Principle

Only Mock necessary dependencies/methods, preserving the real implementation of internal business logic.

### 4. Contract Consistency Principle

Mock return values/exceptions/call behavior must strictly conform to the real business contract of the dependency:
- Mock results must be consistent with the actual return format of the dependency
- Mock exception types must match real exception types
- Mock call rules must match the actual call rules of the dependency

### 5. Framework Adaptation Principle

Mock methods must match the test/Mock framework configured by the project.

## Mock Prohibitions and Restrictions

### Prohibited Object/Method Types for Mocking

| Type | Reason |
|------|--------|
| Simple utility classes/helper functions | High determinism, no external dependencies; Mocking reduces test readability |
| Linked list structure access methods (next/first/...) | High determinism, no external dependencies; Mocking reduces test readability |
| Pure computation logic | High determinism, no need to Mock |
| Value objects (struct POD types) | No behavior to Mock |
| C standard library methods (`<string.h>`, `<stdlib.h>`, `<stdio.h>`, `<math.h>`, etc.) | Officially well-tested, stable and reliable; Mocking is meaningless and prone to test distortion |
| C++ standard library methods (`<string>`, `<vector>`, `<map>`, `<optional>`, `<chrono>`, `<memory>`, etc.) | Includes `std::string`, `std::vector`, `std::map`, `std::optional`, `std::unique_ptr`, `std::chrono::steady_clock`, `std::thread`, `printf`, `malloc`, etc. |
| Class/function under test itself | Mock is only for isolating external dependencies; Mocking the test target makes the test lose business validation significance |
| Private member functions | Violates encapsulation, conventional Mock frameworks cannot implement; forced Mocking easily couples tests with code |

## Mock Configuration Mandatory Verification Points

Each Mock configuration must include the following verification points to ensure the tested code's calls to dependencies comply with business contracts:

| Verification Point | Description | Implementation |
|-------------------|-------------|----------------|
| **Call verification** | Whether the Mock object is called correctly | `.expects()` + `.will()` combination |
| **Parameter verification** | Whether call parameters match expectations | `.with(parameter constraints)` |
| **Count verification** | Whether call count is correct (once, multiple, zero) | `once()` / `never()` / `exactly(n)` / `atLeast(n)` / `atMost(n)` |
| **Sequence verification** | Whether call order is correct (e.g., A before B) | `.then()` chained calls |

**Example**:

```cpp
// Complete verification example: call verification + parameter verification + count verification
MOCKER(&DependencyFunc)
    .expects(once())                    // Count verification: exactly 1 call
    .with(eq(param1), any())            // Parameter verification: param1 exact match, param2 any
    .will(returnValue(expectedValue));  // Return value matches business contract

// Sequence verification example
MOCKER(&FuncA)
    .expects(once())
    .will(returnValue(1));
MOCKER(&FuncB)
    .expects(once())
    .will(returnValue(2));
// FuncA is called before FuncB (guaranteed by test case execution order)
```
