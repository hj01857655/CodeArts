# Mock Framework Selection and Usage Guide

## Framework Selection Decision Flow

Select a Mock framework according to the following decision flow:

1. **Does the function under test need to Mock external dependencies?**
   - No → Use pure gtest, do not introduce any Mock framework
   - Yes → Continue judgment

2. **Is the code under test C++ or C?**
   - C++ → Prefer gmock (MOCK_METHOD/EXPECT_CALL)
   - C → Continue judgment

3. **Does the project already have a Mock framework configured?**
   - Has binmock → Use binmock
   - Has AMock → Use AMock
   - Has mockcpp → Use mockcpp (note platform compatibility)
   - No configuration → Prefer gmock

4. **Windows/MinGW platform special handling**
   - mockcpp may not compile on Windows/MinGW (missing sys/mman.h)
   - Prefer gmock/binmock over mockcpp
   - If the function under test does not need Mock, use pure gtest

**Key Principle**: Do not introduce any Mock framework when the function under test does not need to Mock external dependencies. This avoids platform compatibility issues and unnecessary compilation dependencies of frameworks like mockcpp.

## Framework Comparison

| Framework | Applicable Scenario | Mock Method | Platform Compatibility |
|-----------|-------------------|-------------|----------------------|
| gtest/gmock | C++ virtual functions, interface classes | MOCK_METHOD macro, EXPECT_CALL | All platforms |
| binmock | C functions (extending gmock) | BINEXPECT_CALL, BINMOCKER | All platforms |
| AMock | Project C/C++ | AMOCKER macro, expects/with/will | All platforms |
| mockcpp | C functions (MOCKER macro) | MOCKER(func).stubs().will(returnValue(...)) | Linux first, Windows/MinGW may fail |

## Mock Layering Principle

| Mock Type | Placement | Applicable Scenario |
|-----------|-----------|-------------------|
| **Common Mock** | SetUp() | Basic Mock needed by all test cases, such as global variable initialization |
| **Scenario Mock helper functions** | Fixture class member functions | Specific scenario Mock shared by multiple test cases |
| **Specific Mock** | Inside test case | Mock needed only by the current case |

## Fine-grained Mock Control

- **Prefer WillOnce**: Precisely control return value and count for each call
- **Only use WillRepeatedly when count is uncertain**
- **Verify call count**: Use .Times(N) or default counting
- **Verify call parameters**: Check parameter values in lambda
- **Verify call order**: Use InSequence
- **Verify not called**: Use .Times(0)

## gtest/gmock Usage

### Virtual Function Mock (Direct Mock)

```cpp
class IService {
public:
    virtual int32_t ProcessData(const std::string& data) = 0;
};

class MockService : public IService {
public:
    MOCK_METHOD(int32_t, ProcessData, (const std::string& data), (override));
};
```

### Non-virtual Function Mock (Wrapper Layer Pattern)

When the code under test depends on non-virtual functions, create a Mock wrapper layer:

```cpp
// Step 1: Create virtual function interface class
class MockServiceInterface {
public:
    virtual ~MockServiceInterface() = default;
    virtual int32_t ProcessData(const std::string& data) = 0;
};

// Step 2: Create Mock class
class MockService : public MockServiceInterface {
public:
    MOCK_METHOD(int32_t, ProcessData, (const std::string& data), (override));
};

// Step 3: Create adapter
class ServiceAdapter : public OriginalService {
public:
    explicit ServiceAdapter(MockServiceInterface* mock) : mock_(mock) {}
    int32_t ProcessData(const std::string& data) override {
        return mock_->ProcessData(data);
    }
private:
    MockServiceInterface* mock_;
};
```

### EXPECT_CALL Usage

```cpp
// Precisely control single call
EXPECT_CALL(mockService, ProcessData(_))
    .WillOnce(Return(0));

// Precisely control multiple calls with different return values
EXPECT_CALL(mockService, ProcessData(_))
    .WillOnce(Return(&buffer1))
    .WillOnce(Return(&buffer2))
    .WillOnce(Return(nullptr));

// Verify call count
EXPECT_CALL(mockService, ProcessData(_)).Times(1);

// Verify not called
EXPECT_CALL(mockService, ProcessData(_)).Times(0);

// Verify call order
InSequence s;
EXPECT_CALL(mockA, func(_)).WillOnce(Return(0));
EXPECT_CALL(mockB, func(_)).WillOnce(Return(-1));
```

## binmock Usage

### Basic Mock

```cpp
BINEXPECT_CALL((&malloc), (_)).WillOnce(Return(nullptr));
```

### Serialized Calls

```cpp
InSequence s;
auto &mocker = BINMOCKER(&ring_create);
EXPECT_CALL(mocker, stub(_, _, _, _)).Times(1).WillOnce(Return(&this->ring));
EXPECT_CALL(mocker, stub(_, _, _, _)).Times(1).WillOnce(Return(nullptr));
```

### Lambda Modifying Return Parameters

```cpp
BINEXPECT_CALL((&external_func), (_))
    .Times(1)
    .WillOnce([this](param_t *p) {
        p->value = 100;
        p->status = STATUS_OK;
        return 0;
    });
```

## AMock Usage

### Basic Structure

```cpp
AMOCKER(function_name)
.expects(call_count)        // optional
.with(parameter_matching)  // optional
.will(return_value_control) // optional
```

### Call Count Control

- `expects(exactly(n))` - exactly n calls
- `expects(atLeast(n))` - at least n calls
- `expects(atMost(n))` - at most n calls
- `expects(never())` - should not be called

### Parameter Matching

- `eq(value)` - expect input parameter equal to value
- `neq(value)` - expect input parameter not equal to value
- `any()` - input parameter can be any value
- `outBoundP(&st, sizeof(st))` - control output parameter
- `follow(checkFunc)` - use custom function to verify input parameter

### Return Value Control

- `returnValue(value)` - control return value to value
- `returnObjectList(v1, v2, v3)` - control return values for multiple calls
- `invoke(func)` - replace original function with func
- `ignoreReturnValue()` - ignore return value

### Notes

1. AMock keyword order should not be reversed: `AMOCKER -> expects/times -> with -> will -> before/after`
2. At least one keyword must be used
3. Use `LLT_GLOBALOBJMOCKER::verify()` to verify call count
4. outBoundP, mirror, mask pointer parameters must be valid addresses

## mockcpp Usage

### Basic Usage

```cpp
#include <mockcpp/mockcpp.h>

// Mock external function
MOCKER(external_func)
    .stubs()
    .will(returnValue(0));

MOCKER(external_func)
    .expects(exactly(1))
    .with(eq(expected_param))
    .will(returnValue(-1));
```

### Cleanup

```cpp
// Cleanup at the end of each test case
GlobalMockObject::verify();
```

### Platform Compatibility

- mockcpp depends on sys/mman.h, may not compile on Windows/MinGW
- If mockcpp compilation fails, do not modify mockcpp source code, record the limitation and use alternative solutions
- Alternative solutions: manually construct test data, use gtest/gmock's binmock extension, directly verify NULL handling logic

## malloc Failure Test Alternative Strategy

**Problem**: Mocking malloc/free/printf is prohibited on Windows/MinGW because gtest internally calls them, leading to infinite recursion.

**Alternative Strategies** (select by priority):

### Strategy 1: Mock the allocation function actually called by the function under test

If the function under test calls strdup instead of malloc directly, Mock strdup:
```cpp
// Code under test calls strdup
MOCKER(strdup).stubs().will(returnValue((char*)nullptr));
```

### Strategy 2: Manually construct NULL state and verify subsequent behavior

If the allocation function cannot be Mocked, manually set the allocation result to NULL and verify:
```cpp
TEST_F(DeviceTest, test_init_when_device_null_then_handle_correctly) {
    init_devices();  // Normal call
    // Manually set a device to NULL to simulate malloc failure
    devices[0] = NULL;
    // Verify subsequent functions handle NULL correctly
    EXPECT_EQ(check_device_status(0), DEVICE_STATUS_INVALID);
}
```

### Strategy 3: Include .c file to directly access static variables

For C modules using static global variables, directly include the .c file to access static variables:
```cpp
// Directly include .c file to access static variables
#include "db_operations.c"  // Note: not .h

TEST_F(DbTest, test_add_when_null_entry_then_reject) {
    // Can directly access static variables to reset state
    memset(database, 0, sizeof(database));
    record_count = 0;
    // Test
}
```

### Strategy 4: Record limitation and skip

If none of the above strategies are feasible, record the limitation in test_design.md, noting that the malloc failure path cannot be tested on the current platform.

## Hardware I/O Mock Strategy

### Memory Mapping Method (Recommended)

Use VirtualAlloc (Windows) or mmap (Linux) to allocate physical memory to simulate hardware registers:

```cpp
class HardwareIOTest : public ::testing::Test {
protected:
    void* hw_base = nullptr;
    
    void SetUp() override {
#ifdef _WIN32
        hw_base = VirtualAlloc(nullptr, 4096, MEM_COMMIT, PAGE_READWRITE);
#else
        hw_base = mmap(nullptr, 4096, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
#endif
        memset(hw_base, 0, 4096);
    }
    
    void TearDown() override {
#ifdef _WIN32
        VirtualFree(hw_base, 0, MEM_RELEASE);
#else
        munmap(hw_base, 4096);
#endif
    }
};
```

### Why Not Link Stubs

Link-time replacement (ld --wrap or linking stub functions) copies production code logic into tests, with high maintenance costs and easy desynchronization with production code. Memory mapping is more reliable.

## mockcpp Detailed Usage Guide

When the project uses mockcpp as the Mock framework, **must** read references/mockcpp-guidance.md for the complete usage guide, including:

- MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL/MOCK_METHOD selection decision flow
- Scenario-based usage (C functions, static member functions, regular member functions, virtual functions, template functions)
- Advanced usage (call count verification, sequential calls, parameter constraints, output parameter setting)
- Special scenario handling

### mockcpp Special Scenarios

**Scenario 1: Function under test internally traverses collections/containers/result sets**

Rule: Do not Mock traversal operation functions (HasNext/FetchNext/GetNext/Next, etc.); instead Mock data provider functions and fill test data in output parameters.

Method:
- Traversal operations (HasNext/FetchNext/GetNext/Next, etc.): Do not Mock, use real implementation
- Data provider operations (ExecQuery/Fetch/GetAll, etc.): Can be Mocked, return test data through output parameters

Example:
```cpp
// Incorrect: Mock traversal function
MOCKER_CPP(&DataSource::FetchNext)  // Traversal operation function, do not Mock
    .stubs()
    .will(returnValue(true));

// Correct: Mock data provider function, fill output parameters
ErrorCode DataProviderStub(
    ...,
    DataContainer& outResult)
{
    Row row;
    row.push_back(Value(1));
    row.push_back(Value(2));
    outResult.AddRow(row);
    return ErrorCode::SUCCESS;
}
MOCKER_CPP(&DataSource::ExecuteQuery, Sig)
    .stubs()
    .will(invoke(DataProviderStub));
```

Key points:
- The iterator is the "consumer", the data provider function is the "producer"
- Mock the producer, not the consumer
- Test data is filled through the container structure of output parameters (e.g., push_back/AddRow/append, etc.)

**Scenario 2: Function under test internally obtains instance through singleton getter, then calls instance methods**

Rule: Do not Mock singleton getter functions (GetInstance/sInstance/GetSingleton, etc.); directly Mock the instance methods.

Method:
- Singleton getter functions (GetInstance/sInstance/GetSingleton, etc.): Do not Mock, use real implementation
- Instance methods (other methods called inside the function under test): Can be Mocked

Example:
```cpp
// Incorrect 1: Mock singleton getter function
MOCKER_CPP(&SingletonManager::GetInstance)
    .stubs()
    .will(returnValue(&mockObj));

// Incorrect 2: Arbitrary function pointer type cast
MOCKER_CPP(&SingletonManager::GetInstance)
    .stubs()
    .will(returnValue(reinterpret_cast<SingletonManager*>(0x1))); // Arbitrary cast, prohibited

// Correct: Directly Mock the called instance method
MOCKER_CPP(&DataService::ProcessData)
    .stubs()
    .will(invoke(DataProcessStub));
```

### mockcpp Common Issues

When encountering mockcpp compilation/runtime issues, **must first** check the solutions in references/mockcpp-debug-experience.md to avoid repeatedly solving the same problems. Common issues include:

1. MOCKER_CPP/MOCKER_CPP_VIRTUAL not using & to take address when mocking member functions
2. Not specifying template instantiation type when mocking template functions
3. Stub function's first parameter not set as class object pointer
4. Using MOCKER_CPP for virtual functions causing runtime segfault
5. Stub function return value type inconsistent with the Mocked function's return value type
6. Not specifying function signature when mocking overloaded functions causing Mock to not take effect

For more detailed solutions, please refer to references/mockcpp-debug-experience.md.
