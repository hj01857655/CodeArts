# DT Code Writing Core Constraints

## Code Change Requirements

* Keep test cases concise and efficient.
* When implementing code generation, focus on **minimal necessary changes** to solve the problem.
* Before making any changes, you must first thoroughly **understand the codebase structure** through exploration.
* Understand the codebase structure, related files, and context. Do not edit directly without understanding the context.
* If a large amount of code is added to a function or file, consider splitting it into smaller logical units (such as helper functions or sub-modules) to improve maintainability.

## Test Case Writing Requirements

- **Test case names should not use Chinese. Please refer to the naming conventions of existing test cases in the project**
- Test case file header comments should follow this format:
  ```cpp
    // Description: {Function under test} unit test
    // Create: {Current date} (format yyyy-MM-dd)
  ```

- Each test case header comment should follow this format:
  ```cpp
    /**
    * Scenario: Scenario description
    * Expected: Expected behavior
    */
    TEST_F(TestSuitName, TestCaseName)
  ```

- Write code in a **minimal, focused** manner; do not overcomplicate simple problems
- Ensure the semantics of each test case code align with the test design description requirements
- Combine the implementation of the test target's business code and the writing conventions of existing test cases in the current repository to apply appropriate stubbing methods in test code
- Annotate each test case's ID information in the test code for traceability
- Must strictly reference test cases under the `test case save path` and nearby test cases' design and implementation based on path proximity

## Compatibility Resolution
- Even if the file under test is a .c file, the generated test file must be a .cpp file (requires the googletest framework)

## Test Case Assertion Core Constraints

### [Mandatory] Prohibited Pattern List

| Pattern Category | Prohibited Pattern | Reason | Correct Pattern |
|------------------|-------------------|--------|-----------------|
| **Empty test case** | `TEST_F{...}` with no EXPECT_/ASSERT_ inside | No verification at all | **Must** add at least 1 assertion |
| Always-true assertion | `EXPECT_TRUE(true)` | Always true, no verification value | `EXPECT_TRUE(expr)` where expr contains variables |
| Empty success | `SUCCEED()` | No verification | Remove or replace with concrete assertion |
| Only non-null pointer | `EXPECT_NE(ptr,nullptr)` | Only verifies non-null, does not verify content | `EXPECT_EQ(ptr->field, expected)` |
| Only non-empty container | `EXPECT_FALSE(x.empty())` | Only verifies non-empty, does not verify content | `EXPECT_EQ(x.size(), N)` + element validation |
| Only no-throw | `EXPECT_NO_THROW(func())` | Only verifies no exception, does not verify result | `EXPECT_EQ(func(), expected)` |
| Redundant boolean comparison | `EXPECT_EQ(expr, true)` | Redundant, poor readability | `EXPECT_TRUE(expr)` |
| Redundant boolean comparison | `EXPECT_EQ(expr, false)` | Redundant, poor readability | `EXPECT_FALSE(expr)` |
| Container without content validation | `ASSERT_FALSE(list.empty())` | Only verifies non-empty, does not verify elements | `ASSERT_EQ(list.size(), N)` + element traversal |
| Container only lower bound | `ASSERT_GE(list.size(), 3)` | Cannot detect extra elements | `ASSERT_EQ(list.size(), N)` |
| Always-true expression | `EXPECT_TRUE(x > 0 \|\| x <= 0)` | Always true | Remove or replace with concrete condition |
| **Duplicate with if condition** | `if (result != X) { ASSERT_TRUE(result != X); }` | Assertion duplicates if condition, always true | Directly assert expected value: `EXPECT_EQ(result, expected)` |
| **Duplicate with if condition** | `if (ret == SUCCESS) { ASSERT_EQ(ret, SUCCESS); }` | Only verifies success branch | Full branch coverage: `ASSERT_EQ(ret, SUCCESS)` |
| Always-true expression | `EXPECT_TRUE(x > 0 \|\| x <= 0)` | Always true | Remove or replace with concrete condition |
| SKIP case | `GTEST_SKIP` | No valid information in the test case | Keep test case code, disable using macro definition |

### [Mandatory] Field-Level Validation Rules

| Return Type | Validation Requirement | Correct Example |
|------------|----------------------|-----------------|
| struct/class | **Must** validate field by field | `EXPECT_EQ(field, expected)` × N |
| Pointer return | Non-null check **+** field validation | `ASSERT_NE(ptr, nullptr)` + `EXPECT_EQ(ptr->field, value)` |
| vector/list | size validation **+** element validation | `ASSERT_EQ(vec.size(), N)` + iterate elements |
| map | size validation **+** key-value validation | `ASSERT_EQ(map.size(), N)` + `EXPECT_EQ(map[key], value)` |
| string | Content validation | `EXPECT_STREQ(str.c_str(), "expected")` |
| enum | Value validation | `EXPECT_EQ(enumVal, ExpectedEnum::Value)` |
| bool | Semantic validation | `EXPECT_TRUE(expr)` or `EXPECT_FALSE(expr)` |
| int/numeric | Specific value validation | `EXPECT_EQ(value, expected)` |
| void | State change validation | `EXPECT_TRUE(checkStateChange())` |

## Test Case Coding Core Constraints

### [Mandatory] Prohibited Coding Methods

| Pattern Category | Prohibited Pattern | Reason | Correct Pattern |
|------------------|-------------------|--------|-----------------|
| Rewriting test target class | Writing a completely new test target class from scratch, using the new class as the test object | The test object lacks authenticity, test results are invalid | Use real business code for testing |
