# Coverage Analysis Method

## Overview

Uses the gcov capability provided by gtest, through compile-time instrumentation technology, to analyze the .gcda files generated after test case execution, obtain the code lines covered by test cases, and provide coverage improvement strategies and suggestions for uncovered code lines.

## Prerequisites

1. Coverage flags added at compile time: `-fprofile-arcs -ftest-coverage`
2. Coverage flags added at link time: `--coverage -lgcov`
3. Test cases have been successfully executed

## Execution Steps

### Step 1: Check Required Files

#### 1.1 Read the test class file, check if it contains TEST_F or TEST macros

- **Has TEST_F/TEST** → Continue execution
- **No TEST_F/TEST** → Output prompt and end

#### 1.2 Check if gcda file exists

```bash
find . -name "*.gcda" | grep {TARGET_SOURCE_FILE}
```

- **Exists** → Continue execution
- **Does not exist** → Output prompt and end

Set the found gcda file path as `TARGET_GCDA_PATH`

### Step 2: Execute gcov to Generate Coverage Report

```bash
mkdir -p /tmp/ut-cpp/gcov_output && cd /tmp/ut-cpp/gcov_output && gcov {TARGET_GCDA_PATH} > /dev/null 2>&1
```

**Note**: gcov generates .gcov files in the current directory; must execute in a temporary directory.

### Step 3: Analyze Coverage

#### 3.1 Analyze Uncovered Code

Use grep "#####:" to find truly uncovered code lines:

```bash
cat xxx.cpp.gcov | grep "#####:"
```

| Format | Meaning |
|--------|---------|
| `number: line:` | This line was executed (number = execution count) |
| `#####: line:` | This line was never executed, needs test supplementation |
| `-: line:` | Non-executable code (comments, blank lines, etc.) |
| `=====: line:` | Special line marker, no test supplementation needed |

**Note**: Only analyze uncovered lines marked with "#####"; no need to analyze other information.

#### 3.2 Use Coverage Problem Routing

Based on the characteristics of uncovered code, refer to references/coverage-route.md to match the corresponding coverage strategy.

Execution steps:
1. Read references/coverage-route.md file, match in priority order
2. Check if the coverage report contains corresponding trigger keywords or characteristics
3. Once a match is found, immediately load the corresponding coverage strategy
4. **Must execute**: Each priority level must be checked

#### 3.3 Generate Coverage Improvement Strategy Report

**Function-level report** (when TARGET_FUNCTION is specified):
```
==========================================
          Coverage Analysis Report (Function-level)
==========================================

Target function: {TARGET_FUNCTION}
Test file: xxx.cpp

Function lines: line {START_LINE} - {END_LINE}
Total function lines: {TOTAL_LINES}
Covered lines: {COVERED_LINES}
Line coverage: XX% ({COVERED_LINES}/{TOTAL_LINES})

==========================================
Uncovered code (confirmed using #####: marker)
==========================================
- Line {UNCOVERED_LINE}: {code snippet}

==========================================
Improvement Strategy
==========================================
1. Line {N}: {suggestion}
```

**Full-file report** (when TARGET_FUNCTION is not specified):
```
==========================================
              Coverage Analysis Report
==========================================

Test file: xxx.cpp

==========================================
Line Coverage Statistics
==========================================
Line coverage: XX% (covered lines/executable lines)

==========================================
Uncovered code (confirmed using #####: marker)
==========================================
- FunctionA (lines 10-20): function never called
- Line {N}: {code snippet}

==========================================
Improvement Strategy
==========================================
1. FunctionA - function never called, needs to be triggered through XXX scenario
```

### Step 4: Environment Cleanup

The /tmp/ut-cpp/gcov_output directory created in Step 2 is a temporary path and should be deleted after running to prevent residue.

## Error Handling

| Scenario | Handling |
|----------|----------|
| Test executable does not exist | Output error message |
| gcda file does not exist | Output error message |
| gcov execution failed | Output error details |
| No test cases | Output prompt and end |
| Target function does not exist | Output error message, optionally list all functions in the file for selection |
