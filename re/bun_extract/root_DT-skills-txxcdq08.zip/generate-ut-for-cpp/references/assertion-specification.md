# Eight Assertion Standards and Data Cleanup Standards

## Eight Assertion Standards

### Standard 1: Missing Assertions — Prohibit test cases without assertions

Incorrect:
```cpp
TEST_F(Test, CreateUser) {
    userService->CreateUser("John", "john@example.com");
    // No assertions at all
}
```

Correct:
```cpp
TEST_F(Test, CreateUser_Success) {
    auto result = userService->CreateUser("John", "john@example.com");
    EXPECT_TRUE(result.success);
    EXPECT_EQ(result.user_id, 123);
}
```

### Standard 2: Simple Assertions — Prohibit only checking existence; must verify specific business attributes

Incorrect:
```cpp
EXPECT_NE(user, nullptr);  // Only checks non-null
```

Correct:
```cpp
ASSERT_NE(user, nullptr);
EXPECT_EQ(user->id, 123);
EXPECT_EQ(user->name, "John");
EXPECT_EQ(user->status, UserStatus::Active);
```

### Standard 3: Invalid Assertions — Prohibit always-true assertions

Incorrect:
```cpp
EXPECT_EQ(1, 1);  // Always true, meaningless
EXPECT_TRUE(true);
```

Correct:
```cpp
int initial_value = counter->GetValue();
counter->Increment();
EXPECT_EQ(counter->GetValue(), initial_value + 1);
```

### Standard 4: Complex Test Logic — Prohibit cases with ≥5 logic keywords

Incorrect: A case containing multiple if/for/while
Correct: Split into multiple independent cases, each verifying one scenario

### Standard 5: Mid-exit — Prohibit return or goto early exit in test cases

Incorrect:
```cpp
if (!service->Initialize()) {
    return;  // Mid-exit
}
```

Correct: Split into two cases, one testing initialization success path, one testing initialization failure path

### Standard 6: Single Scenario — A single case verifies only one scenario

Incorrect: One case verifies multiple different inputs
Correct: Each case verifies one specific scenario

### Standard 7: Inappropriate Line Count — Test case code should be 3-50 lines

Cases exceeding 50 lines should be split into multiple test cases.

### Standard 8: Hard Wait — Prohibit using sleep and other hardcoded waits

Incorrect:
```cpp
std::this_thread::sleep_for(std::chrono::seconds(2));
```

Correct: Use event listeners, callback mechanisms, or future/promise

## void Method Assertion Mandatory Standards

**Core Rule**: void methods must verify observable state changes; do not use only EXPECT_NO_THROW.

### Incorrect: Only EXPECT_NO_THROW

```cpp
TEST_F(EngineTest, SetGlobalSettings_NoThrow) {
    engine.setGlobalSettings(10, 100);
    // Only verifies no crash, does not verify any business attributes
}
```

### Correct: Verify global variable state changes

```cpp
TEST_F(EngineTest, SetGlobalSettings_UpdatesState) {
    engine.setGlobalSettings(10, 100);
    EXPECT_EQ(max_tasks, 10);       // Verify global variable modified
    EXPECT_EQ(time_slice, 100);     // Verify global variable modified
}
```

### Correct: Verify class member state changes

```cpp
TEST_F(EngineTest, AddTask_UpdatesCount) {
    int original_count = engine.getTaskCount();
    engine.addTask(task);
    EXPECT_EQ(engine.getTaskCount(), original_count + 1);
}
```

### Correct: Verify output parameters

```cpp
TEST_F(EngineTest, GetStats_WritesToOutput) {
    Stats stats = {};
    engine.getStats(&stats);
    EXPECT_GT(stats.total_count, 0);
    EXPECT_DOUBLE_EQ(stats.avg_time, expected_avg);
}
```

**Exception**: If a void method truly does not modify any observable state (pure log output, etc.), the name must use the `_NoThrow` suffix and the reason must be explained in comments.

## Assertion Coupling Minimization Principle

When verifying operation results, use the most direct available method, avoiding indirect verification through other methods.

Incorrect: Using complex query methods for indirect verification
```cpp
auto shapes = processor.getShapesByArea(0, INT_MAX);
EXPECT_EQ(shapes.size(), 1);
```

Correct: Using the most direct verification method
```cpp
EXPECT_DOUBLE_EQ(processor.calculateTotalArea(), expected_area);
```

## Special Scenario Assertion Guidance

### Division by Zero Scenarios

```cpp
#include <cmath>

// x/0.0 (x!=0) → Inf
double result1 = divide(1.0, 0.0);
EXPECT_TRUE(std::isinf(result1));

// 0.0/0.0 → NaN
double result2 = divide(0.0, 0.0);
EXPECT_TRUE(std::isnan(result2));

// 0.0/negative → -0.0 (not NaN or Inf!)
double result3 = divide(0.0, -1.0);
EXPECT_NEAR(result3, 0.0, 0.001);  // Use EXPECT_NEAR

// General safe mode: check both NaN and Inf
EXPECT_TRUE(std::isinf(result) || std::isnan(result));
```

**Important**: 0.0 divided by a negative number equals -0.0, not NaN or Inf. For floating-point division by zero, prefer std::isnan/std::isinf; do not default to EXPECT_DEATH (floating-point division by zero typically does not crash).

### Floating-Point Assertions

- Exact results: Use `EXPECT_DOUBLE_EQ`
- Approximate results: Use `EXPECT_NEAR(result, expected, tolerance)`

### Memory Layout Verification

For memory management functions, verify memory block content rather than just checking pointers:
```cpp
EXPECT_EQ(memcmp(buffer, expected_data, data_size), 0);
```

### void Function State Assertions

For void return value functions, must verify global variable/class member state changes; do not rely solely on cout output verification:

Incorrect: Only verify cout output
```cpp
testing::internal::CaptureStdout();
taskScheduler.schedule();
std::string output = testing::internal::GetCapturedStdout();
EXPECT_NE(output.find("scheduled"), std::string::npos);
```

Correct: Verify state changes
```cpp
int original_count = g_task_count;
taskScheduler.schedule();
EXPECT_EQ(g_task_count, original_count + 1);
EXPECT_EQ(g_current_task_status, STATUS_SCHEDULED);
```

### NULL Pointer Explicit Testing

When the task or expectation involves "NULL pointer operations", the test must explicitly set the pointer to nullptr, and the test name must reflect the NULL condition:

Incorrect: Relying on implicit initial NULL state
```cpp
double balance = get_balance();
EXPECT_DOUBLE_EQ(balance, 1000.0);
```

Correct: Explicitly set NULL and verify, name reflecting the condition
```cpp
TEST_F(Test, GetBalance_ReturnsDefault_WhenAccountBalanceIsNull) {
    account_balance = nullptr;  // Explicitly set NULL
    double balance = get_balance();
    EXPECT_DOUBLE_EQ(balance, 1000.0);
}
```

**Naming Rule**: NULL pointer test names must include condition descriptions like `WhenXxxIsNull` or `_NullPointer`, making the test intent self-documenting.

### EXPECT_DEATH Usage

When production code produces undefined behavior (crash) under certain inputs:
```cpp
TEST_F(SchedulerTest, Schedule_WhenEmptyList_ThenCrash) {
    TaskScheduler scheduler;
    scheduler.setTaskCount(0);
    EXPECT_DEATH(scheduler.schedule(), ".*");
}
```

**Note**: Floating-point division by zero typically produces NaN/Inf rather than a crash; use std::isnan/std::isinf instead of EXPECT_DEATH.

### Test Naming Accuracy

Test naming must accurately reflect what is being verified:

| Verification Method | Naming Suffix | Example |
|--------------------|--------------|---------|
| Verify state change | `_UpdatesState` / `_SetsValue` | `SetConfig_UpdatesGlobalVars` |
| Verify return value | `_ReturnsXxx` | `Calculate_ReturnsExpected` |
| Only verify no crash | `_NoThrow` | `Execute_NoThrow` |
| Verify NULL handling | `_WhenXxxIsNull` | `GetBalance_WhenPointerIsNull` |
| Verify boundary values | `_AtBoundary` | `Process_AtMaxCapacity` |

Incorrect: Name implies behavior verification but actually only verifies no crash
```cpp
TEST_F(Test, Configure_Success) {  // "Success" implies behavior verification
    engine.configure(settings);
    EXPECT_NO_THROW;  // Actually only verifies no crash
}
```

Correct: Name accurately reflects verification content
```cpp
TEST_F(Test, Configure_NoThrow) {  // "NoThrow" accurately describes
    engine.configure(settings);
}
```

## Data Cleanup Standards

### Mock Cleanup

Mocked methods in each test case must be cleaned up within the current case after the case ends:

```cpp
TEST_F(Test, test_func) {
    EXPECT_CALL(mockObj, func(_)).WillOnce(Return(0));
    // Execute test...
    ::testing::Mock::VerifyAndClearExpectations(&mockObj);
}
```

**Strictly prohibited** using global cleanup methods in TearDown().

### Fixture State Tracking and TearDown Cleanup

```cpp
class DeviceManagerTest : public ::testing::Test {
protected:
    std::set<int> added_device_ids;
    void TearDown() override {
        for (int id : added_device_ids) {
            remove_device(id);
        }
        added_device_ids.clear();
    }
    void add_tracked_device(int id) {
        add_device(id);
        added_device_ids.insert(id);
    }
};
```

### SetUp Zero-Reset Pattern

For C modules using global state, SetUp must first save the original state, then explicitly zero-reset:

Incorrect: Only save and restore, may propagate dirty state
```cpp
void SetUp() override {
    saved_count = process_count;
    memcpy(saved_table, process_table, sizeof(process_table));
}
```

Correct: Zero-reset + save and restore combination
```cpp
void SetUp() override {
    saved_count = process_count;
    memcpy(saved_table, process_table, sizeof(process_table));
    process_count = 0;
    memset(process_table, 0, sizeof(process_table));
}
```

**Prefer reset functions**: If the module has init/reset functions (e.g., `init_pcb_table()`), prefer calling that function in SetUp rather than manual save/restore. Reset functions are simpler and equally effective.

### #include .c File Duplicate Symbol Warning

When using `#include "source.c"` to directly include a source file, **do not** simultaneously compile and link that .c file:

Incorrect: Simultaneous include and link
```bash
g++ ... build/module.o build/test_module.o ...  # module.o already included via #include
```

Correct: Include then do not link
```bash
g++ ... build/test_module.o ...  # test_module.cpp already includes module.c via #include
```

## Expected Value Batch Computation

Expected values for algorithm functions use a single script execution for batch computation; multiple iterative single-query computations are prohibited:

```bash
python3 -c "
SI = 1000 * 0.05 * 3
CI = 1000 * (1 + 0.05/4)**(4*3)
print(f'SI={SI}, CI={CI}')
"
```

For complex algorithms (CRC, scheduling logic, etc.), prefer using external scripts to compute expected values rather than manually tracing execution paths.

## Extended Assertion Prohibited Patterns

### [Mandatory] Prohibited Pattern List (Supplementary)

| Pattern Category | Prohibited Pattern | Reason | Correct Pattern |
|------------------|-------------------|--------|-----------------|
| Empty success | `SUCCEED()` | No verification | Remove or replace with concrete assertion |
| Only non-empty container | `EXPECT_FALSE(x.empty())` | Only verifies non-empty, does not verify content | `EXPECT_EQ(x.size(), N)` + element validation |
| Container only lower bound | `ASSERT_GE(list.size(), 3)` | Cannot detect extra elements | `ASSERT_EQ(list.size(), N)` |
| Duplicate with if condition | `if (result != X) { ASSERT_TRUE(result != X); }` | Assertion duplicates if condition, always true | Directly assert expected value: `EXPECT_EQ(result, expected)` |
| Duplicate with if condition | `if (ret == SUCCESS) { ASSERT_EQ(ret, SUCCESS); }` | Only verifies success branch | Full branch coverage: `ASSERT_EQ(ret, SUCCESS)` |
| SKIP case | `GTEST_SKIP` | No valid information in the test case | Keep test case code, disable using macro definition |

### [Mandatory] Field-Level Validation Rules

| Return Type | Validation Requirement | Correct Example |
|------------|----------------------|-----------------|
| struct/class | **Must** validate field by field | `EXPECT_EQ(field, expected)` × N |
| Pointer return | Non-null check **+** field validation | `ASSERT_NE(ptr, nullptr)` + `EXPECT_EQ(ptr->field, value)` |
| vector/list | size validation **+** element validation | `ASSERT_EQ(vec.size(), N)` + iterate elements |
| map | size validation **+** key-value validation | `ASSERT_EQ(map.size(), N)` + `EXPECT_EQ(map[key], value)` |
| string | Content validation | `EXPECT_STREQ(str.c_str(), "expected")` |
| enum | Value validation | `EXPECT_EQ(enumVal, ExpectedEnum::Value)` |
| bool | Semantic validation | `EXPECT_TRUE(expr)` or `EXPECT_FALSE(expr)` |
| int/numeric | Specific value validation | `EXPECT_EQ(value, expected)` |
| void | State change validation | `EXPECT_TRUE(checkStateChange())` |

### [Mandatory] Prohibited Coding Methods

| Pattern Category | Prohibited Pattern | Reason | Correct Pattern |
|------------------|-------------------|--------|-----------------|
| Rewriting test target class | Writing a completely new test target class from scratch, using the new class as the test object | The test object lacks authenticity, test results are invalid | Use real business code for testing |
| Pointer cast | Using reinterpret_cast<ClassName*>(0x1) to cast an arbitrary value to a pointer | Pointers need to be dereferenced; an arbitrary address may cause a crash | Use constructor to construct objects |
