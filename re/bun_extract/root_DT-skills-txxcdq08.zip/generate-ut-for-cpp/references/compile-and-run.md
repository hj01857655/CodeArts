# Compilation and Execution Method

## Mandatory Requirements

**The compilation step is mandatory** and must not be skipped for the following reasons:
- Complex project, many dependencies
- Unfamiliar build system
- Initial compilation failure

**Continue fixing until success**: When compilation fails, continue fixing until compilation succeeds or an unsolvable problem is encountered (such as missing necessary libraries, environment configuration issues). Record issues when unsolvable problems are encountered.

## Build Strategy Priority

Attempt compilation in the following priority order, with a maximum of 2 attempts per strategy.

**Key Constraint: CMake full build prohibited**. `cmake --build` must include the `--target` parameter to specify a specific target; full builds without a target are prohibited. Large project full builds may time out or fail due to compilation errors in unrelated source files.

### Strategy D: User Custom Build Command (Highest Priority, Must Be Used First)

**Mandatory Rule**: If the user provides a build command or script in the prompt, **must use the user-provided command first**, without trying other strategies.

Applicable scenarios:
- User explicitly specified a build command in the prompt (e.g., "Use ./build.sh test to compile")
- Project has a custom build.sh, build.py, etc. build script, and the user provided the specific command
- User explicitly specified build parameters or steps

**Execution Method**:
```bash
# Example: User-provided custom build command
./build.sh test_module
# or
python build.py --target test_runner
# or user-specified specific command
gcc -std=c11 -c src/module.c -o build/module.o
g++ build/test.o build/module.o -o build/test_runner
```

**Notes**:
- If the user-provided command fails, must enter the fix loop (see "Progressive Fix Flow")
- Continue fixing until success or encountering an unsolvable problem
- Record issues when unsolvable problems are encountered

### Strategy A: CMake Build Specific Target

```bash
# First build dependency libraries (specify target, full build prohibited)
cmake --build build --target gtest gtest_main gmock gmock_main

# Then link test files
g++ -std=c++20 -static -I src -I libs/googletest/googletest/include \
    build/test_file.o build/source_file.o build/lib/libgtest.a build/lib/libgtest_main.a \
    --coverage -o build/test_runner.exe
```

Applicable scenario: Project has CMakeLists.txt and CMake is available.

**When to fall back to Strategy B**:
- CMake full build fails due to compilation errors in unrelated source files (e.g., pointer_compare.cpp error)
- CMake build times out (large project full build may exceed 120 seconds)
- Third-party library (e.g., mockcpp) fails to compile on current platform
- CMake specific target build fails after 2 attempts

### Strategy B: Target Compilation

```bash
# Only compile test files and source files under test
# Note: .c files use gcc, .cpp files use g++
gcc -std=c11 -c -I src \
    src/source_file.c -o build/source_file.o

g++ -std=c++20 -c -I src -I libs/googletest/googletest/include \
    tests/test_file.cpp -o build/test_file.o

# Link using dependency libraries built by Strategy A
g++ -std=c++20 -static \
    build/test_file.o build/source_file.o \
    build/lib/libgtest.a build/lib/libgtest_main.a \
    --coverage -o build/test_runner.exe
```

Applicable scenario: Strategy A failed due to unrelated file errors, but dependency libraries were built via Strategy A.

### Strategy C: Complete Manual Compilation

```bash
# Manually compile all dependencies
g++ -std=c++20 -c -I libs/googletest/googletest/include \
    libs/googletest/googletest/src/gtest-all.cc -o build/gtest_all.o

# Compile test files and source files
g++ -std=c++20 -c -I src -I libs/googletest/googletest/include \
    tests/test_file.cpp -o build/test_file.o

gcc -std=c11 -c -I src \
    src/source_file.c -o build/source_file.o

# Link
g++ -std=c++20 -static \
    build/test_file.o build/source_file.o build/gtest_all.o \
    --coverage -o build/test_runner.exe
```

Applicable scenario: Strategy A/B are both unavailable.

## Compiler Selection Rules

**Mandatory Rule**: Select compiler based on source file extension to avoid C symbol C++-ification causing link errors.

| Source File Extension | Compiler | Reason |
|----------------------|----------|--------|
| `.c` | `gcc` | Preserve C symbol names, avoid C++ name mangling |
| `.cpp` / `.cc` / `.cxx` | `g++` | C++ compilation |

### Incorrect: g++ compiling C source files

```bash
# Error: g++ will add name mangling to C functions, causing link errors when finding C symbols
g++ -std=c++20 -c src/module.c -o build/module.o
# Link time will show undefined reference to 'module_func'
```

### Correct: gcc compiling C source files

```bash
gcc -std=c11 -c src/module.c -o build/module.o
# Preserve C symbol names, correct matching at link time
```

**Note**: Use g++ uniformly for the link phase, since gtest/gmock are C++ libraries.

## Coverage Flags

If the project uses coverage analysis, corresponding flags must be added at compile and link time:

### Compile Phase

```bash
gcc -std=c11 -fprofile-arcs -ftest-coverage -c src/module.c -o build/module.o
g++ -std=c++20 -fprofile-arcs -ftest-coverage -c tests/test_file.cpp -o build/test_file.o
```

### Link Phase

```bash
g++ -std=c++20 -static \
    build/test_file.o build/source_file.o build/lib/libgtest.a build/lib/libgtest_main.a \
    --coverage -lgcov -o build/test_runner.exe
```

### Flag Consistency

- Compile and link coverage flags must be consistent
- If gtest libraries built with CMake have coverage flags, test files must also have coverage flags when compiled
- `undefined reference to __gcov_init` error indicates inconsistent coverage flags

## Windows/MinGW Platform Adaptation

### Static Linking

Always use the `-static` flag in Strategy B/C:
```bash
g++ -std=c++20 -static ... -o build/test_runner.exe
```

### -static and CMake Coordination

Enable static linking in CMake:
```cmake
set(CMAKE_EXE_LINKER_FLAGS "${CMAKE_EXE_LINKER_FLAGS} -static")
```

Or via command line:
```bash
cmake -DCMAKE_EXE_LINKER_FLAGS="-static" ..
```

### Windows ERROR Macro Conflict

When including `<windows.h>`, if the code has an enum value named ERROR, add after include:
```cpp
#include <windows.h>
#undef ERROR  // Avoid conflict with enum value ERROR
```

A constexpr alias can provide a safer alternative:
```cpp
constexpr auto STATE_ERROR = SystemState::ERROR;
```

### Path Separator

When running executables in MinGW bash, **must use forward slash paths**:

```bash
# Correct: Use forward slashes
./build/test_runner.exe

# Incorrect: Use backslashes (MinGW bash does not support)
.\build\test_runner.exe
```

Similarly, use forward slashes when passing path parameters in bash commands.

## DLL Problem Diagnosis

### exit code 127 or 0xC0000135

Indicates missing DLL. Diagnostic steps:

1. Use ldd to check dependencies:
```bash
ldd build/test_runner.exe
```

2. Prefer recompiling with -static rather than debugging PATH

3. If dynamic linking must be used, set the correct PATH:
```bash
PATH="/d/Program Files/CppLT/mingw64/bin:$PATH" ./build/test_runner.exe
```

### Maximum 3 attempts for the same runtime error

If more than 3 attempts, switch to -static rebuild, stop debugging PATH issues.

## mockcpp Platform Compatibility Handling

### Known Issues

mockcpp may fail to compile on Windows/MinGW due to:
- Missing sys/mman.h (UnixCodeModifier.cpp)
- CMake conditional checks not including MINGW (IF(MSVC) → needs IF(MSVC OR MINGW))

### Handling Strategy

1. **Do not modify mockcpp source code**: Even if modifying CMakeLists.txt could fix compilation, do not modify third-party libraries
2. **Record limitation**: Record in test_design.md that mockcpp is unavailable on the current platform
3. **Use alternative solutions**:
   - Use gtest/gmock's binmock extension
   - Manually construct test data to verify NULL handling logic
   - Use mockcpp alternative Mock strategies (see mock-framework-guide.md)
4. **Exclude mockcpp at build time**: Do not link mockcpp in Strategy B/C

## Build Completion Determination

Once Strategy B/C successfully compiles and tests pass, **do not retry CMake full build**.

Common error patterns:
- Strategy A fails → Strategy B succeeds → Try going back to Strategy A full build → Fails again (wasting time)
- Correct approach: Strategy B/C success is considered build complete, continue to subsequent steps

## Common Problem Handling

### Compilation Errors

| Error | Cause | Solution |
|-------|-------|---------|
| undefined reference to WinMain | Missing gtest_main | Link libgtest_main.a or add main function |
| undefined reference to __gcov_init | Inconsistent coverage flags | Ensure gtest libraries built with CMake have consistent flags |
| multiple definition of xxx | Duplicate header file definition | Use include guards or #pragma once |
| expected ';' before 'xxx' | Incorrect extern "C" usage | Confirm C header files are inside extern "C" {} |
| undefined reference to C function | g++ compiled .c file | Use gcc to compile .c files |
| redefinition of 'xxx' | #include .c file conflict | Ensure #include .c appears in only one compilation unit |

### Runtime Errors

| Error | Cause | Solution |
|-------|-------|---------|
| STATUS_DLL_NOT_FOUND | Missing DLL | Recompile with -static |
| exit code 127 | Executable not found | Check path, use ./ prefix and forward slashes |
| Segmentation fault | Null pointer dereference | Check test data initialization |
| exit code 0xC0000135 | Missing DLL dependency | Recompile with -static |

## Progressive Fix Flow (Mandatory Execution)

**Must enter fix loop for both compilation and execution failures**, continue fixing until success or encountering an unsolvable problem.

**Mandatory Constraints**:
- **No early exit**: Must not skip directly; must continue fixing until success
- **No skipping due to complexity**: Must not skip compilation step due to project complexity or many dependencies
- **Each round must be complete**: Analyze → fix → compile/execute, must not skip any step
- **When encountering unsolvable problems**: Such as missing necessary libraries, environment configuration issues, record the problem

### Compilation Failure Fix Loop Flow

```
Continue looping until compilation succeeds:
  1. Analyze compilation error cause (syntax error, link error, missing header file, etc.)
  2. Fix test code (do not modify production code)
  3. Recompile
  4. If successful → Enter test execution flow
  5. If failed → Continue next round of fixes (loop execution)
  6. If encountering unsolvable problems → Record the problem
```

### Execution Failure Fix Loop Flow

**Mandatory Requirement**: When execution fails (runtime error, test assertion failure), must continue fixing, do not end the task directly.

```
Continue looping until tests pass:
  1. Analyze execution failure cause:
     - Parameter validation failure (e.g., ptask!=nullptr assertion)
     - Mock type matching error
     - Test assertion failure
     - Runtime crash (null pointer, array out of bounds, etc.)
  2. Fix test code:
     - Parameter validation failure → Check test data initialization, ensure valid parameters are passed instead of nullptr
     - Mock type matching error → Check if Mock function signature matches actual call, adjust Mock configuration
     - Assertion failure → Analyze expected vs actual value differences, adjust test data or assertions
     - Runtime crash → Check null pointer, array out of bounds, etc., fix test code
  3. Recompile and execute tests
  4. If successful → Tests pass, enter summary flow
  5. If failed → Continue next round of fixes (loop execution)
  6. If encountering unsolvable problems → Record the problem
```

### Common Execution Failure Types and Fix Strategies

| Failure Type | Typical Error Message | Fix Strategy |
|-------------|----------------------|--------------|
| Parameter validation failure | `ptask!=nullptr` assertion failed | Check test data initialization, ensure valid parameters are passed instead of nullptr |
| Mock type matching error | `no matching function for mock` | Check if Mock function signature matches actual call, adjust parameter types |
| Assertion failure | `Expected: X, Actual: Y` | Analyze expected vs actual value differences, adjust test data or fix assertions |
| Runtime crash | `Segmentation fault` | Check null pointer, array out of bounds, etc., fix test code |
| Test timeout | `Test timed out` | Check infinite loops, blocking calls, etc., optimize test logic |

### Recording Requirements

When encountering unsolvable problems, must include in the task summary:
- Failure phase (compilation failure or execution failure)
- Failure summary
- Main error type
- Fix solutions already attempted
- Suggestion: Need user to provide more detailed build configuration or dependency information

## Fix Strategy

### Problem Fix Steps

#### Step 1. Collect Information

Collect error information based on compilation/runtime logs

#### Step 2. Problem Classification

Classify the problem based on error information:

| Problem Type | Classification Basis |
|------------|---------------------|
| Program crash | "core dumped" in test case runtime logs |
| Runtime timeout | Test case has no response for a long time after running, until timeout exit |
| mockcpp compilation issue | Compilation error shows MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL macro errors |
| mockcpp runtime issue | After analyzing runtime errors, the function behavior mocked using MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL macros is abnormal |

#### Step 3. Strategy Selection

Load the corresponding experience document based on problem type to select the corresponding solution strategy:

| Problem Type | Experience Document |
|------------|-------------------|
| Program crash | Use gdb to assist localization |
| Runtime timeout | Use gdb to assist localization |
| mockcpp compilation issue | references/mockcpp-debug-experience.md |
| mockcpp runtime issue | references/mockcpp-debug-experience.md |

**Prioritize querying experience base**: Read references/mockcpp-debug-experience.md, match the scenario and solution for the current problem, avoid repeatedly solving the same problem.

#### Step 4. Solve the Problem

Fix the problematic code

#### Step 5. Fix Verification

Rerun the compile/run command, confirm whether the problem is resolved

### Allowed Fix Scope (Without Modifying Test Case Logic)

| Phase | Error Type | Fix Method |
|-------|-----------|-----------|
| Compile | Missing header file path | Add -I option |
| Compile | Missing library file path | Add -L option |
| Compile | Missing link library | Add -l option |
| Compile | Link order issue | Adjust link order |
| Compile | Missing macro definition | Add -D option |
| Compile | Missing compile option | Add necessary compile options |
| Execute | Missing dynamic library path | Set LD_LIBRARY_PATH |
| Execute | Missing file dependency | Use mock files or temporary directory |
| Execute | Missing environment variable | Set necessary environment variables |
| Execute | Path issue | Use absolute path or fix path configuration |
| Execute | Resource contention | Increase timeout |
| Execute | Singleton state pollution | Clean state in SetUp/TearDown |
| Execute | Mock not taking effect | Fix mock function parameters |
| Assertion | Assertion value mismatch | Fix expected value or adjust test input data |
| Assertion | Test data issue | Adjust test input data |

### Prohibited Fix Scope (Would Modify Test Case Logic)

- Modifying internal logic of test functions
- Deleting or commenting out test code
- Modifying the implementation of the function under test

### Experience Accumulation

After successful fixes, **must** extract the experience of solving this problem, record in the task summary, to avoid repeatedly solving the same problem.

Experience template:
```
[Problem Scenario]
[Error Message]
[Problem Cause]
[Solution]
[Code Example]
```

### Attempt Limit Handling

- Compilation verification: Maximum 10 attempts
- Runtime verification: Maximum 5 attempts
- After reaching the attempt limit, use DISABLED_CASE macro to disable unfixable test cases, stop running compile/run commands and modifying code
- Do not modify script permissions; if direct execution fails, use sh script.sh form to execute
