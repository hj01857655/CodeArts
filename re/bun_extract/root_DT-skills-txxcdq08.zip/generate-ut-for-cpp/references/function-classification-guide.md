# Function Classification and Test Strategy Guide

## Overview

This guide helps identify the type of the function under test and select the optimal test strategy for it. Different types of functions require different testing focuses and Mock strategies.

## Function Type Classification

### 1. Simple Computation Functions

**Characteristics**: No external dependencies, pure logic computation
**Examples**: CRC verification, mathematical operations, string processing
**Test Strategy**:
- Focus on algorithm correctness and boundary values
- No Mock needed
- Algorithm-intensive testing: 100K calls for performance validation

**Test Focus**:
- Return value correctness for normal inputs
- Boundary values (0, max, min, overflow)
- Special inputs (NULL pointer, empty string, negative numbers)
- Use helper programs to batch-compute expected values

### 2. Single-Dependency Functions

**Characteristics**: Depend on 1-2 external functions
**Examples**: Call a single API to get data, then process
**Test Strategy**:
- Verify both success and failure scenarios for the dependency
- Mock external function to return success and failure
- Verify error propagation

**Test Focus**:
- Normal path when dependency succeeds
- Error handling when dependency fails
- Behavior when dependency returns NULL/error code
- Correct propagation of error codes

### 3. Multi-Dependency Functions

**Characteristics**: Depend on multiple external functions, require serialized Mock
**Examples**: Initialization functions that call multiple APIs in sequence
**Test Strategy**:
- Verify dependency combinations, call order, error propagation
- Serialized Mock, verify call order
- Each dependency failure must be tested individually

**Test Focus**:
- Normal path with all dependencies succeeding
- Error handling for each individual dependency failure
- Serialized failure scenarios (A succeeds B fails, A succeeds B succeeds C fails...)
- Resource cleanup verification on failure

### 4. State Machine Functions

**Characteristics**: Involve state transitions, need to cover all state paths
**Examples**: Connection management, protocol state machines
**Test Strategy**:
- Cover all state transition paths, exception state handling
- Mock state transition trigger conditions
- Verify state variable changes

**Test Focus**:
- All valid state transitions
- Handling of illegal events in current state
- State transition trigger conditions
- Exception state recovery

### 5. Callback Functions

**Characteristics**: Need to verify callback parameters and call timing
**Examples**: Event handlers, async completion callbacks
**Test Strategy**:
- Verify callback parameters, call timing, call count
- Mock callback triggering and execution
- Use lambda to capture callback behavior

**Test Focus**:
- Callback is called correctly
- Callback parameters are correct
- Callback timing is correct
- Callback count verification

### 6. Business Process Functions

**Characteristics**: Implement complete business processes, multiple branches and paths
**Examples**: Order processing, request dispatch
**Test Strategy**:
- Cover business success path, failure fallback path, special path
- Mock business dependency success and failure
- Verify business rule condition combinations

**Test Focus**:
- Business normal success path
- Business failure fallback path
- Business special condition path (shortcut path)
- Business boundary conditions
- All decision table rules

### 7. Data Conversion Functions

**Characteristics**: Data format conversion or encapsulation
**Examples**: Serialization/deserialization, protocol encapsulation
**Test Strategy**:
- Verify input-output mapping, boundary data, special data
- May need to Mock data source or target
- Focus on data integrity

**Test Focus**:
- Normal data conversion correctness
- Boundary data (empty data, max data, min data)
- Special data (invalid format, partial initialization)
- Data integrity verification

## Complexity Assessment

| Dimension | Low Complexity | Medium Complexity | High Complexity |
|-----------|---------------|-------------------|-----------------|
| Cyclomatic complexity | 1-5 | 6-10 | >10 |
| Lines of code | <30 | 30-100 | >100 |
| Number of parameters | 1-2 | 3-5 | >5 |
| External dependencies | 0-1 | 2-4 | >4 |

**Complexity Impact on Test Strategy**:
- Low complexity: 2-5 test cases for sufficient coverage
- Medium complexity: 5-15 test cases, requires systematic design
- High complexity: 15+ test cases, must use decision tables and missing scenario checklists

## Mock Strategy Decision

| Function Type | Needs Mock | Mock Strategy |
|--------------|-----------|---------------|
| Simple computation | No | Do not introduce Mock framework |
| Single dependency | Yes | Mock external function success/failure |
| Multi dependency | Yes | Serialized Mock, verify call order |
| State machine | Maybe | Mock state trigger conditions |
| Callback | Yes | Mock callback triggering and execution |
| Business process | Yes | Mock business dependencies |
| Data conversion | Maybe | Mock data source/target |

## Notes

- A function may have characteristics of multiple types simultaneously; classify by primary characteristics
- Complex functions should be split into multiple test dimensions for separate coverage
- Identifying function type is the first step in test design and cannot be skipped
