# MockCpp Usage Guide

## Table of Contents

1. [Overview](#1-overview)
2. [Acquisition and Reference](#2-acquisition-and-reference)
3. [Mock Object Types](#3-mock-object-types)
4. [Core Keywords](#4-core-keywords)
5. [Scenario-Based Usage](#5-scenario-based-usage)
6. [Advanced Usage](#6-advanced-usage)
7. [Mock Strategy Design Principles](#7-mock-strategy-design-principles)
8. [Mock Prohibitions and Restrictions](#8-mock-prohibitions-and-restrictions)
9. [Decision Flowchart](#9-decision-flowchart)
10. [Best Practices](#10-best-practices)

---

## 1. Overview

### 1.1 What is MockCpp

MockCpp is an open-source C/C++ mock framework for unit testing. It can:

- **Change function call behavior**: Modify return values, call stub functions (i.e., stubbing)
- **Validate function input parameters**
- **Set function output parameters**

Similar mock frameworks include Google's gmock and mockpp.

### 1.2 Capability Overview

#### Function Type Support

| Function Type | Support | Notes |
|--------------|---------|-------|
| C language functions | Supported | Does not support variadic functions |
| C++ static member functions | Supported | Does not support variadic functions |
| C++ class member functions | Supported | Does not support variadic |
| C++ virtual functions | Supported | Does not support variadic |
| C++ overloaded functions | Supported | Does not support variadic |
| Variadic functions | Not supported | - |

#### Platform Support

| Platform Type | 32-bit | 64-bit |
|--------------|--------|--------|
| X86 | Supported | Supported |
| ARM | Supported | Supported |

---

## 2. Acquisition and Reference

### Import Method

```cpp
#include <llt_MockCpp.h>

// Link the corresponding library file
// 32-bit: libdtcenter.a
// 64-bit: libdtcenter64.a
```

---

## 3. Mock Object Types

| Object Type | Supported Stubbing Scope | Notes |
|------------|------------------------|-------|
| `MOCKER` | C language functions, C++ class static member functions | - |
| `MOCKER_CPP` | Regular class non-overloaded member functions, overloaded member functions, template functions, template class member functions, overloaded functions, template functions | Class member functions only support public member functions |
| `MOCKER_CPP_VIRTUAL` | C++ class virtual function members | Takes effect for all objects of the class |
| `MOCK_METHOD` | C++ class virtual function members | Stubs member functions of a specific instance of the class, only takes effect for instance member functions |

**Usage Recommendations**:

- For stubbing virtual functions, `MOCKER_CPP_VIRTUAL` interface is more recommended
- `MOCK_METHOD` scope is instance-level, suitable for scenarios requiring stubbing for specific instances

---

## 4. Core Keywords

### 4.1 Call Count Constraint Keywords (`.expects()`)

| Keyword | Description |
|---------|-------------|
| `once()` | Constrain verification count to once |
| `never()` | Constrain to no calls |
| `exactly(n)` | Constrain verification count to n times |
| `atLeast(n)` | Constrain minimum call count to n times |
| `atLeastOnce()` | Constrain minimum call count to 1 time |
| `atMost(n)` | Constrain maximum call count to n times |
| `atMostOnce()` | Constrain maximum call count to 1 time |

### 4.2 Function Behavior Keywords (`.will()`)

| Keyword | Description |
|---------|-------------|
| `returnValue(val)` | Return specified value |
| `invoke(stubFunc)` | Replace with stub function |
| `ignoreReturnValue()` | Ignore return value |
| `throws(ex)` | Throw exception |
| `outboundP(val)` / `outbound(val)` | Set output parameters |
| `returnObjectList(v1, v2, ...)` | Return multiple values in sequence |
| `increase(n)` | Each call's return value increases by n |
| `repeat(n, val)` | Return val n times |
| `then()` | In expects scenario, the Nth call returns the Nth stub's value |

**Common Combinations**:

- `.stubs()` + `.will(returnValue(val))` - Modify return value, no count verification
- `.stubs()` + `.will(invoke(func))` - Replace with stub function
- `.expects(...)` + `.will(returnValue(val))` - Specify behavior and verify count

### 4.3 Parameter Constraint Keywords (`.with()`)

| Keyword | Description |
|---------|-------------|
| `eq()` | Equality constraint (for int, char, float, bool, enum) |
| `neq()` | Inequality constraint |
| `gt()` / `lt()` | Greater than/less than constraint |
| `any()` | Any value constraint |
| `mirror()` | Strict equality of memory content |
| `startWith()` | String prefix constraint |
| `endWith()` | String suffix constraint |
| `contains()` | String contains constraint |
| `outbound()` / `outBoundP()` | Set output parameters |
| `checkWith()` | Custom input parameter check |
| `die()` | Simulate function call crash |
| `spy()` | Object content monitoring |

---

## 5. Scenario-Based Usage

### 5.1 C Language Function Stubbing

Use the `MOCKER` keyword for stubbing:

```cpp
int GetMax(int a, int b) {
    return a > b ? a : b;
}

TEST_F(Test_Func_suit, TestCase) {
    EXPECT_EQ(3, GetMax(2, 3));
    
    // Modify return value
    MOCKER(&GetMax).stubs().will(returnValue(0));
    EXPECT_EQ(0, GetMax(2, 3));
    
    // Replace with stub function
    MOCKER(&GetMax).stubs().will(invoke(GetMaxStub));
    
    // Verify call count
    MOCKER(&GetMax).expects(once()).will(returnValue(0));
    
    GlobalMockObject::verify();
}
```

### 5.2 C++ Static Member Function Stubbing

Also uses the `MOCKER` keyword:

```cpp
class TestClass1 {
public:
    static int GetMax(int a, int b) {
        return a > b ? a : b;
    }
};

TEST_F(Test_Func_suit, TestCase) {
    MOCKER(&TestClass1::GetMax).stubs().will(returnValue(0));
    EXPECT_EQ(0, TestClass1::GetMax(2, 3));
    GlobalMockObject::verify();
}
```

### 5.3 C++ Regular Member Function Stubbing

Use the `MOCKER_CPP` keyword. The first parameter type of the stub function is a pointer to the stubbed class:

```cpp
class TestClass2 {
public:
    int GetMax(int a, int b) {
        return a > b ? a : b;
    }
};

// Stub function signature: RetType Stub(ClassName* obj, Param1, Param2...)
int GetMaxStub(TestClass2* obj, int a, int b) {
    return a > b ? a : b;
}

TEST_F(Test_Func_suit, TestCase) {
    TestClass2 obj;
    MOCKER_CPP(&TestClass2::GetMax)
        .stubs()
        .will(invoke(GetMaxStub));
    EXPECT_EQ(3, obj.GetMax(2, 3));
    GlobalMockObject::verify();
}
```

### 5.4 C++ Virtual Function Stubbing

#### MOCKER_CPP_VIRTUAL (Global Effect)

Takes effect for all objects of the class:

```cpp
class TestClass4 {
public:
    virtual int GetMax(int a, int b) {
        return a > b ? a : b;
    }
};

int GetMaxStub(TestClass4* obj, int a, int b) {
    return a > b ? a : b;
}

TEST_F(Test_Func_suit, TestCase) {
    TestClass4 obj1;
    MOCKER_CPP_VIRTUAL(obj1, &TestClass4::GetMax, int (TestClass4::*)(int, int))
        .stubs()
        .will(invoke(GetMaxStub));
    EXPECT_EQ(2, obj1.GetMax(1, 2));    // Replaced by stub function
}
```

#### MOCK_METHOD (Instance-Level Effect)

Only takes effect for specific instances:

```cpp
MockObject<TestClass5> mocker1;
MOCK_METHOD(mocker1, GetMax).stubs().will(invoke(GetMaxStub));
EXPECT_EQ(3, mocker1->GetMax(2, 3));
mocker1.verify();
```

**Recommended**: For stubbing virtual functions, `MOCKER_CPP_VIRTUAL` interface is more recommended.

### 5.5 Template Function Stubbing

Use `MOCKER_CPP` and specify the template instantiation type:

```cpp
template<typename T>
T GetMax(T t1, T t2) {
    return t1 > t2 ? t1 : t2;
}

TEST_F(Test_Func_suit, TestCase) {
    // Stub the template function instance with typename as int
    MOCKER_CPP(&GetMax, int (*)(int, int))
        .stubs()
        .will(returnValue(0));
    EXPECT_EQ(0, GetMax(1, 2));
}
```

### 5.6 Mocking Functions Called Inside Macros

If a macro definition internally calls other functions, just mock the called function directly:

```cpp
#define MAX(a, b) GetMax(a, b)

TEST_F(Test_Func_suit, TestCase) {
    MOCKER(&GetMax).stubs().will(returnValue(0));
    EXPECT_EQ(0, MAX(2, 3));  // Macro expands to GetMax(2,3)
    GlobalMockObject::verify();
}
```

---

## 6. Advanced Usage

### 6.1 Verifying Function Call Count

```cpp
// Expect exactly one call
MOCKER(&func1).expects(once()).will(returnValue(0));

// Expect two calls
MOCKER(&func1).expects(exactly(2)).will(returnValue(0));

// Expect never called
MOCKER(&func1).expects(never()).will(returnValue(0));

// Expect at least two calls
MOCKER(&func1).expects(atLeast(2)).will(returnValue(0));
```

### 6.2 Sequential Calls (`.then()`)

In `.expects(exactly(n))` scenarios, use `.then()` to return the Nth stub's value on the Nth call:

```cpp
MOCKER(TestFunc)
    .expects(exactly(2))
    .then(returnValue(999))  // 1st call returns 999
    .then(returnValue(888)); // 2nd call returns 888

EXPECT_EQ(999, TestFunc());  // 1st call
EXPECT_EQ(888, TestFunc());  // 2nd call
```

### 6.3 Constraining Function Input Parameters

```cpp
MOCKER(&func)
    .expects(once())
    .with(eq(1), eq(2))  // Verify input parameters are 1 and 2
    .will(returnValue(3));

MOCKER(&func)
    .expects(once())
    .with(any(), any())  // Any parameters match
    .will(returnValue(100));
```

### 6.4 Setting Function Output Parameters

```cpp
void getValue(int* output);

TEST_F(Test_Func_suit, TestCase) {
    int value = 0;
    MOCKER(&getValue)
        .expects(once())
        .will(outboundP(100));  // Set output parameter to 100
    getValue(&value);
    EXPECT_EQ(100, value);
    GlobalMockObject::verify();
}
```

### 6.5 Stub Types and Priority

| Type | Description |
|------|-------------|
| `.stubs()` | Specify function behavior, no count verification |
| `.defaults()` | Define a default mock behavior specification |
| `.expects()` | Specify function behavior and verify call count |

**Priority**: `.stubs()` > `.defaults()` > `.expects()`

---

## 7. Mock Strategy Design Principles

### 7.1 Risk-Adaptive Principle

Mock depth is proportional to the risk level of the dependency:

| Risk Level | Mock Strategy | Description |
|------------|--------------|-------------|
| High-risk dependency | Deep Mock (normal + exception + boundary) | Cover all critical paths |
| Medium-risk dependency | Selective Mock | Only Mock necessary exception branches |
| Low-risk dependency | Minimal Mock | Only Mock when necessary |

**Note**: If a branch cannot be Mocked due to framework limitations, must trigger the target branch by adjusting input parameters or setting internal state. Do not skip branch coverage.

### 7.2 Scenario Matching Principle

Mock behavior must match the test case verification objectives:
- Do not Mock normal responses for exception scenarios
- Do not Mock normal responses for boundary scenarios

### 7.3 Minimal Mock Principle

Only Mock necessary dependencies/methods, preserving the real implementation of internal business logic.

### 7.4 Contract Consistency Principle

Mock return values/exceptions/call behavior must strictly conform to the real business contract of the dependency:
- Mock results consistent with actual return format of the dependency
- Mock exception types consistent with real exception types
- Mock call rules consistent with actual call rules of the dependency

### 7.5 Framework Adaptation Principle

Mock methods must match the test/Mock framework configured by the project.

---

## 8. Mock Prohibitions and Restrictions

### Prohibited Object/Method Types for Mocking

| Type | Reason |
|------|--------|
| Simple utility classes/helper functions | High determinism, no external dependencies; Mocking reduces test readability |
| Linked list structure access methods (next/first/...) | High determinism, no external dependencies; Mocking reduces test readability |
| Pure computation logic | High determinism, no need to Mock |
| Value objects (struct POD types) | No behavior to Mock |
| C standard library methods (`<string.h>`, `<stdlib.h>`, `<stdio.h>`, `<math.h>`, etc.) | Officially well-tested, stable and reliable; Mocking is meaningless and prone to test distortion |
| C++ standard library methods (`<string>`, `<vector>`, `<map>`, `<optional>`, `<chrono>`, `<memory>`, etc.) | Includes `std::string`, `std::vector`, `std::map`, `std::optional`, `std::unique_ptr`, `std::chrono::steady_clock`, `std::thread`, `printf`, `malloc`, etc. |
| Class/function under test itself | Mock is only for isolating external dependencies; Mocking the test target makes the test lose business validation significance |
| Private member functions | Violates encapsulation, conventional Mock frameworks cannot implement; forced Mocking easily couples tests with code |

### Mock Configuration Mandatory Verification Points

Each Mock configuration must include the following verification points:

| Verification Point | Description | Implementation |
|-------------------|-------------|----------------|
| **Call verification** | Whether the Mock object is called correctly | `.expects()` + `.will()` combination |
| **Parameter verification** | Whether call parameters match expectations | `.with(parameter constraints)` |
| **Count verification** | Whether call count is correct | `once()` / `never()` / `exactly(n)` / `atLeast(n)` / `atMost(n)` |
| **Sequence verification** | Whether call order is correct | `.then()` chained calls |

---

## 9. Decision Flowchart

### Step 1: Select Mocker Type

```
Is it a C function or C++ static member function?
├── Yes → Use MOCKER(&func)
└── No
    Is it a C++ virtual function?
    ├── Yes
    │   ├── Need global effect (all instances)? → Use MOCKER_CPP_VIRTUAL
    │   └── Only need specific instance effect? → Use MOCK_METHOD
    └── No
        Is it a template function?
        ├── Yes → Use MOCKER_CPP + signature to specify template instantiation type
        └── No
            Is it an overloaded function?
            ├── Yes → Use MOCKER_CPP + signature
            └── No → Use MOCKER_CPP
```

### Step 2: Select Mock Behavior

```
Need to verify call count?
├── Yes → Use .expects(count constraint)
│       ├── Only expect specific count → once() / exactly(n)
│       ├── At least/at most → atLeast(n) / atMost(n)
│       └── Need sequential different values? → Add .then()
└── No → Use .stubs()

Need to verify input parameters?
├── Yes → Use .with(parameter constraint)
│       ├── Exact match → eq(val)
│       ├── Any value → any()
│       └── String constraint → startWith / contains
└── No → Omit .with()

Need to change function behavior?
├── Yes → Use .will(behavior)
│       ├── Return fixed value → returnValue(val)
│       ├── Replace with stub function → invoke(stubFunc)
│       ├── Set output parameter → outboundP(val)
│       ├── Throw exception → throws(ex)
│       └── Return multiple values in sequence → returnObjectList or .then()
└── No → Omit .will()
```

---

## 10. Best Practices

### 10.1 Stub Reset

After each test case ends, must call `GlobalMockObject::reset()` or `GlobalMockObject::verify()` to clear stub behavior:

```cpp
GlobalMockObject::reset();   // Clear stubs, no verification
GlobalMockObject::verify();  // Clear stubs and verify call count
```

### 10.2 Select Appropriate Mock Object Type

| Scenario | Recommended |
|----------|------------|
| C language functions | `MOCKER` |
| C++ static member functions | `MOCKER` |
| C++ regular member functions (no virtual functions) | `MOCKER_CPP` |
| C++ virtual functions (global effect) | `MOCKER_CPP_VIRTUAL` |
| C++ virtual functions (instance effect) | `MOCK_METHOD` |

### 10.3 Overloaded Function Stubbing

For overloaded functions, additional specification of the parameter list is needed to accurately obtain the function address:

```cpp
MOCKER_CPP(&Func, ReturnType (*)(ParamType1, ParamType2))
    .stubs()
    .will(...);
```

### 10.4 Common Behavior Keywords

Master the three keywords `returnValue()`, `ignoreReturnValue()` and `invoke()`, which can handle 90%+ of function call behavior scenarios.

### 10.5 Stub Function Signature

For class member function stub functions, the first parameter must be a pointer to the corresponding class:

```cpp
// Class member function stub function signature
ReturnType StubFunc(ClassName* obj, Param1Type p1, Param2Type p2) {
    // ...
}
```

---

## Quick Reference

| Function Type | Usage | Notes |
|--------------|-------|-------|
| C language functions | `MOCKER(&func)` | - |
| C++ static member functions | `MOCKER(&Class::Func)` | - |
| C++ regular member functions | `MOCKER_CPP(&Class::Func)` | Stub function's first parameter is `Class*` |
| C++ virtual functions (global effect) | `MOCKER_CPP_VIRTUAL(obj, &Class::Func, sig)` | Takes effect for all instances |
| C++ virtual functions (instance-level) | `MOCK_METHOD(mockObj, Func)` | Only takes effect for specific instances |
| Overloaded functions | `MOCKER_CPP(&func, sig)` | Must specify function signature |
| Template functions | `MOCKER_CPP(&func, sig)` | Specify template instantiation type |

**Core Syntax**:
```
Basic pattern: MOCKER_XXX(func).expects(...).with(...).will(...)
Must call after each test case: GlobalMockObject::verify() or GlobalMockObject::reset()
```

## Special Scenarios

Scenario: Function under test internally traverses collections/containers/result sets
Rule: Do not Mock traversal operation functions (HasNext/FetchNext/GetNext/Next, etc.); instead Mock data provider functions and fill test data in output parameters
Method:
  - Traversal operations (HasNext/FetchNext/GetNext/Next, etc.): Do not Mock, use real implementation
  - Data provider operations (ExecQuery/Fetch/GetAll, etc.): Can be Mocked, return test data through output parameters
Example:
  ```cpp
  // Incorrect: Mock traversal function
  MOCKER_CPP(&DataSource::FetchNext)  // Traversal operation function, do not Mock
      .stubs()
      .will(returnValue(true));

  // Correct: Mock data provider function, fill output parameters
  ErrorCode DataProviderStub(          // Data provider function, can be Mocked
      ...,
      DataContainer& outResult)        // Output parameter, stores query results
  {
      Row row;                          // A row of data
      row.push_back(Value(1));          // Column 1
      row.push_back(Value(2));          // Column 2
      outResult.AddRow(row);            // Add a row to the container
      return ErrorCode::SUCCESS;
  }
  MOCKER_CPP(&DataSource::ExecuteQuery, Sig)  // Data provider function
      .stubs()
      .will(invoke(DataProviderStub));
  ```
Key points:
  - The iterator is the "consumer", the data provider function is the "producer"
  - Mock the producer, not the consumer
  - Test data is filled through the container structure of output parameters (e.g., push_back/AddRow/append, etc.)

---

Scenario: Function under test internally obtains instance through singleton getter, then calls instance methods
Rule: Do not Mock singleton getter functions (GetInstance/sInstance/GetSingleton, etc.); directly Mock the instance methods
Method:
  - Singleton getter functions (GetInstance/sInstance/GetSingleton, etc.): Do not Mock, use real implementation
  - Instance methods (other methods called inside the function under test): Can be Mocked

Example:
  ```cpp
  // Incorrect 1: Mock singleton getter function
  MOCKER_CPP(&SingletonManager::GetInstance)
      .stubs()
      .will(returnValue(&mockObj));

  // Incorrect 2: Arbitrary function pointer type cast
  MOCKER_CPP(&SingletonManager::GetInstance)
      .stubs()
      .will(returnValue(reinterpret_cast<SingletonManager*>(0x1))); // Arbitrary cast, prohibited

  // Correct: Directly Mock the called instance method
  MOCKER_CPP(&DataService::ProcessData)
      .stubs()
      .will(invoke(DataProcessStub));
  ```
