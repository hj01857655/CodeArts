# Transitive Dependency Analysis Method

## Overview

When the function under test calls member functions of the same class or internal functions of the same module, analyzing only one level of calls is insufficient to identify all external dependencies. Dependency analysis must also be performed on the called internal functions to ensure complete Mock coverage.

## Core Rules

### Rule 1: Same-Class Member Functions Must Be Analyzed

If the function under test calls other member functions of the same class, these member functions must undergo dependency analysis at the same depth as the function under test.

**Example**:

```cpp
class ServerManager {
public:
    RadiusServer* GetRadiusServer(const std::string& key) {
        // Calls a same-class member function
        if (!IsInitialized()) return nullptr;  // ← Must analyze IsInitialized's dependencies
        auto it = server_map_.find(key);
        return (it != server_map_.end()) ? it->second : nullptr;
    }

private:
    bool IsInitialized() {
        return config_loader_->IsLoaded();  // ← Depends on config_loader_
    }
    
    ConfigLoader* config_loader_;  // ← External dependency, needs Mock
    std::map<std::string, RadiusServer*> server_map_;
};
```

**Analysis Requirements**:
- Identify that GetRadiusServer calls IsInitialized
- Analyze that IsInitialized depends on config_loader_
- Conclusion: GetRadiusServer's external dependencies include config_loader_, needs Mock

### Rule 2: Constructor Dependencies Must Be Analyzed

If the constructor of the class under test calls external dependencies (such as database queries, network connections), these dependencies must be identified and Mocked.

**Example**:

```cpp
class UserManager {
public:
    UserManager() {
        db_connection_ = Database::Connect();  // ← External dependency in constructor
        cache_ = CacheManager::GetInstance();  // ← External dependency in constructor
    }
    
    User GetUser(int id) {
        return db_connection_->Query(id);  // ← Direct dependency
    }
};
```

**Analysis Requirements**:
- Identify Database::Connect and CacheManager::GetInstance in the constructor
- Must Mock or handle these dependencies in the test Fixture's SetUp
- Otherwise the test will hang or crash during construction

### Rule 3: Database/External Service Dependency Identification

When the code uses database operations (SQL queries, connection pools, etc.), identify database dependencies and determine the Mock strategy:

1. **If there is a database interface class**: Mock the interface class
2. **If using SQL API directly**: Mock the SQL API functions
3. **If using static data structures to simulate a database**: No need to Mock, directly manipulate data structures

**Key Judgment**: Do not Mock the internal data structures of query interfaces. If add/delete/modify/query are companion interfaces, prefer using the add interface to construct data, then use the query interface for verification.

### Rule 4: Iterator/Collection Traversal Dependencies

When the code uses iterators to traverse collections (e.g., ClassIterator), analyze whether the iterator depends on external state:

```cpp
void processDevices() {
    ClassIterator it(MITManager::Instance()->GetRoot(), "Device", NOT_LOCK, 1);
    while (it) {
        // Process device
        ++it;
    }
}
```

**Analysis Requirements**:
- Identify MITManager::Instance() as an external dependency
- Identify that GetRoot()'s return value affects traversal results
- Need to Mock MITManager or set test data

## Analysis Process

1. List all direct calls of the function under test
2. For each internal call (same-class member function, same-module function), recursively analyze its external dependencies
3. Merge all transitive dependencies to form a complete Mock requirement list
4. Record transitive dependency analysis results in test_design.md

## Output Template

```
Function under test: GetRadiusServer
Direct calls: IsInitialized, server_map_.find
Transitive dependencies:
  - IsInitialized → config_loader_->IsLoaded() → Need to Mock config_loader_
External dependency summary:
  - config_loader_ (ConfigLoader*) → Need to Mock
Mock strategy:
  - Use MockConfigLoader to replace config_loader_
  - Test both scenarios where IsInitialized returns true and false
```
