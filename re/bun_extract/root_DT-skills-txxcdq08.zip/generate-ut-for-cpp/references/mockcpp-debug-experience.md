# Compilation Errors When Using MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL

---

Error case: Using MOCKER_CPP or MOCKER_CPP_VIRTUAL causes error: invalid use of non-static member function
Error cause: When mocking class member functions with MOCKER_CPP/MOCKER_CPP_VIRTUAL, the function address must be taken using &
Solution: Modify the parameters when calling MOCKER_CPP/MOCKER_CPP_VIRTUAL, add the & symbol to the function
Code example:
```cpp
    class Calculator {
    public:
        int Add(int a, int b);
        int Subtract(int a, int b);
        std::string GetResultAsString(int value);
    };

    MOCKER_CPP(Calculator::Add) // Incorrect: no & to take function address when mocking class member functions
        .stubs()
        .will(returnValue(100));

    MOCKER_CPP(&Calculator::Add) // Correct: using & to take function address when mocking class member functions
        .stubs()
        .will(returnValue(100));
```

---

Error case: When using MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL to mock template functions, error: no matching function for call to 'mockcpp::mockAPI<mockcpp::mockAPIauto>::get(const char [5], const char [1], <unresolved overloaded function type>)
Cause: When mocking template functions, the template instantiation type was not specified using <>, causing the template function to not be correctly resolved
Solution: When calling MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL, specify the template instantiation type using <> in the parameters
Code example:
```cpp
    template<typename T>
    T Max(T a, T b)
    {
        return a > b ? a : b;
    }

    MOCKER_CPP(&Max) // Incorrect: not using <> to specify the instantiation type when mocking template functions
    .stubs()
    .will(invoke(MaxStub<int>));

    MOCKER_CPP(&Max<int>, int (*)(int, int)) // Correct: using <> to specify the instantiation type when mocking template functions
        .stubs()
        .will(invoke(MaxStub<int>));
```

---

Error case: When using MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL to mock template functions, error: 'template<class T> class TemplateCalculator' used without template arguments
Cause: When mocking class member template functions, the template instantiation type was not specified using <>
Solution: When calling MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL, specify the template instantiation type using <> in the parameters for the class member template function to be mocked
Code example:
```cpp
    template<typename T>
    T TemplateCalculator<T>::Compare(T a, T b)
    {
        return a > b ? a : b;
    }

    MOCKER_CPP(&TemplateCalculator::Compare) // Incorrect: not using <> to specify the instantiation type when mocking class member template functions
        .stubs()
        .will(returnValue(999));

    MOCKER_CPP(&TemplateCalculator<int>::Compare, int (TemplateCalculator<int>::*)(int, int)) // Correct: using <> to specify the instantiation type when mocking class member template functions
        .stubs()
        .will(returnValue(999));
```

---

# Runtime Errors When Using MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL

---

Error case: Test case execution fails, and the runtime log contains C++ exception with description "Parameter 1 mismatch, required: [xx] actual: [yy*]"
Error cause: When mocking class member functions with MOCKER_CPP/MOCKER_CPP_VIRTUAL, the first parameter of the stub function should be a pointer to the class
Solution: Modify the stub function's parameter type, add the class object pointer as the first parameter
Code example:
```cpp
    class Calculator {
    public:
        int Add(int a, int b);
        int Subtract(int a, int b);
        std::string GetResultAsString(int value);
    };

    int AddStub(int a, int b) // Incorrect: the first parameter of the stub function for a member function is not a class object pointer
    {
        return a + b + 100;
    }

    int AddStub(Calculator* obj, int a, int b) // Correct: the first parameter of the stub function for a member function is a class object pointer
    {
        return a + b + 100;
    }
```

---

Error case: Using MOCKER_CPP to mock a virtual function causes a segfault crash during runtime
Error cause: When mocking virtual functions, only MOCKER_CPP_VIRTUAL can be used
Solution: Change the Mock function from MOCKER_CPP to MOCKER_CPP_VIRTUAL
Code example:

```cpp
    class CalculatorBase {
    public:
        virtual int Multiply(int a, int b) = 0;
        virtual int Divide(int a, int b) = 0;
        virtual ~CalculatorBase() {}
    };

    class CalculatorImpl : public CalculatorBase {
    public:
        virtual int Multiply(int a, int b) override;
        virtual int Divide(int a, int b) override;
    };

    MOCKER_CPP(&CalculatorImpl::Multiply, int (CalculatorImpl::*)(int, int)) // Incorrect: using MOCKER_CPP to mock a virtual function
        .expects(once())
        .will(returnValue(999));

    MOCKER_CPP_VIRTUAL(calc, &CalculatorImpl::Multiply, int (CalculatorImpl::*)(int, int)) // Correct: using MOCKER_CPP_VIRTUAL to mock a virtual function
        .expects(once())
        .will(returnValue(999));
```

---

Error case: Test case execution fails, and the runtime log contains C++ exception with description "Returned type does NOT match the method declaration"
Error cause: The return type of the STUB function does not match the return type of the MOCKed function
Solution: Change the STUB function's return type according to the MOCKed function's return type
Code example:
```cpp
    int CalculatorImpl::Multiply(int a, int b)
    {
        return a * b;
    }

    MOCKER_CPP(&CalculatorImpl::Multiply)
        .stubs()
        .will(invoke(MultiplyStub));

    bool MultiplyStub(CalculatorImpl* obj, int a, int b) // Incorrect: STUB function return type is bool, MOCKed function return type is int
    {
        return (a * b) + 1000;
    }

    int MultiplyStub(CalculatorImpl* obj, int a, int b) // Correct: both STUB function and MOCKed function return types are int
    {
        return (a * b) + 1000;
    }
```


---

# Mock Not Taking Effect When Using MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL

---

Error case: The external dependency to be Mocked has multiple overloaded functions, and the function signature was not specified when writing the Mock code, causing the Mock to not take effect
Error cause: Overloaded functions have multiple function signatures; when Mocking, the specific overload to be Mocked must be specified, otherwise the Mock framework does not know which one to Mock, and the Mock will fail
Solution: When calling MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL, specify the signature of the overloaded function to be Mocked in the parameters
Code example:
```cpp
    class Calculator {
    public:
        int Add(int a, int b);
        int Add(int a, int b, int c);
        double Add(double a, double b);
        int Subtract(int a, int b);
        std::string GetResultAsString(int value);
    };

    MOCKER_CPP(&Calculator::Add) // Incorrect: not specifying the function signature when mocking overloaded functions
        .stubs()
        .will(invoke(AddStub));

    MOCKER_CPP(&Calculator::Add, int (Calculator::*)(int, int)) // Correct: specifying the function signature when mocking overloaded functions
    .stubs()
    .will(invoke(AddStub));

```

---
