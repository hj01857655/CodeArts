## Call Chain Analysis Workflow for Target Functions

This workflow corresponds to SKILL.md Step 3.2 (Call Chain and Dependency Identification) and is a prerequisite step for context acquisition. After completing call chain analysis, Step 3.4 (Targeted Context Acquisition) can be executed to ensure precise context acquisition scope.

### Processing Flow

```
Input: Function name
  │
  ▼
1. Find function definition location (file:line)
  │
  ▼
2. Call scripts/extract-function-callees.py to extract direct callees
  │
  ▼
3. For each internal dependency function:
   ├── Recursively execute steps 1-3
   └── For external dependency functions: stop tracking
   │
   ▼
4. Pass results to Step 3.3 (Transitive Dependency Analysis) and Step 3.4 (Targeted Context Acquisition)
```

### Script Description

#### Script Parameters

The `extract-function-callees.py` script supports the following parameters:

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `source_file` | Positional | Yes | Source file path (.cpp file, cannot use .h file) |
| `-l` | int | Yes | Line number where the function is defined |
| `-c` | string | Yes | Path to compile_commands.json file, used to get compilation parameters. **Note**: Although marked as required, the script will error and exit if this parameter is missing, so it is effectively mandatory |

**Usage Example**:

```
bash tool:
- command: python {skill-path}/scripts/extract-function-callees.py /path/to/file.cpp -l 232 -c /path/to/compile_commands.json
- workdir: Current working directory
```

#### Script Output Description

**Output Format**:
```
function_name /path/to/file.cpp:123 (internal dependency)
function_name /path/to/file.h:456 (internal dependency) [need to find implementation location]
function_name /path/to/header.h:78 (external dependency)
```

Note: When an internal dependency shows `[need to find implementation location]`, it means the function is implemented in another .cpp file and needs further lookup.

### Recursion Description

Process based on the `(internal dependency)` / `(external dependency)` labels in the script output:
- **(external dependency)**: Stop recursion, record as Mock target candidate
- **(internal dependency)**:
  - Functions defined in .cpp: directly call the script recursively using that location
  - Functions in .h with `[need to find implementation location]` label: search for implementation location in other .cpp files of the same class before recursing

### Call Chain Output Format
```
function_a() [file_a.cpp:10]
  └── function_b() [file_a.cpp:25] (internal dependency)
      ├── function_c() [file_a.cpp:40] (internal dependency)
      │   └── external_lib_a() [/path/to/file_b.cpp] (external dependency)
      │   └── external_lib_b() [/path/to/file_b.cpp] (external dependency)
      └── function_d() [file_b.h:18] (internal dependency)
      │   └── [This function is defined in a header file, not expanded for analysis]
```

### How Results Are Passed to Subsequent Steps

- **→ Step 3.3 (Transitive Dependency Analysis)**: The internal dependency list from the call chain serves as input for transitive dependency analysis, ensuring no omissions in recursive analysis
- **→ Step 3.4 (Targeted Context Acquisition)**: The external dependency list determines which function signatures and type definitions need to be acquired; internal dependencies do not need context acquisition

### Key Constraints
**Must find function location before calling the script** - The script requires file path and line number, cannot use function name directly, cannot use header files as file paths, the script will error
**Only internal dependencies are recursive** - External dependencies are marked and stopped directly
**Avoid duplicate processing** - Use a set to record processed functions, avoid loops
**Pay attention to `[need to find implementation location]` label** - Internal dependencies with this label need function implementation lookup; if not found, stop recursive processing
