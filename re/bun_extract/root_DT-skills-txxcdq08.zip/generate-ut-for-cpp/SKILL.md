---
name: generate-ut-for-cpp
description: C/C++ Unit Test Generation Expert. Generates high-quality unit tests for C/C++ code, covering the full workflow including function analysis, transitive dependency analysis, call chain extraction, systematic test design, test case generation, compilation fixing, execution verification, case review, and coverage analysis. Supports multiple test frameworks (gtest/gmock/binmock/AMock/mockcpp). Applicable to scenarios such as C/C++ function unit test generation, new code test coverage, boundary condition coverage, resource leak detection, exception path validation, test coverage improvement, test generation based on code changes, and legacy code test supplementation.
language: c,c++
---

# C/C++ Unit Test Generator

Generates high-quality unit tests for C/C++ code, emphasizing analysis before coding, anti-pattern protection, on-demand reading, build system elastic fallback, and code quality assurance.

## Core Principles

1. **Analysis Before Coding**: Must complete function characteristic analysis, control flow/data flow/boundary condition analysis before generating code. Each step's analysis results must explicitly record key conclusions in TodoWrite; must not only "think inline" without outputting
2. **Do Not Modify Code Under Test**: Strictly prohibited from modifying production code, CMakeLists.txt, third-party library files; only add new test files, fixtures, stubs; if modification is needed, must first ask the user and obtain consent
3. **Context Isolation**: After step 3.4 is completed, subsequent steps are prohibited from directly reading the source file under test; only read the refined context document
4. **Data Cleanup Mandatory**: Each test case must clean up Mock, restore state, and release resources internally
5. **Assertion Quality Assurance**: No assertions, always-true assertions, and NoThrow-only assertions are prohibited; must verify specific business attributes or observable state changes
6. **Strict Process Execution and Progressive Fix**: Use TodoWrite to track the process; do not skip steps; when compilation/execution fails, continue fixing until success or encountering unsolvable problems; **the compilation step is mandatory and must not be skipped**
7. **On-Demand Reading**: Prioritize using grep/semantic search to locate target functions; read reference files on demand, do not force reading all; generate intermediate artifacts on demand

## Anti-Pattern Prohibitions (Mandatory Enforcement)

### Mock Misuse Prohibitions

1. **Prohibit Circular Mock**: Mock targets must be external functions actually called by the function under test. Prohibited from creating wrapper functions in the test file and then Mocking them
2. **Prohibit Mocking the Class/Function Under Test Itself**: Mock is only for isolating external dependencies; Mocking the test target makes the test lose business validation significance
3. **Prohibit Mocking Standard Library Functions**: C standard library (string.h/stdlib.h/stdio.h/math.h) and C++ standard library (string/vector/map/optional/chrono/memory, etc.) are sufficiently tested and stable; Mocking is meaningless and prone to test distortion
4. **Prohibit Mocking Private Member Functions**: Violates encapsulation, conventional Mock frameworks cannot implement; forced Mocking easily couples tests with code
5. **Prohibit Mocking libc Core Functions (Windows/MinGW)**: Prohibited from Mocking malloc/free/printf on Windows/MinGW—gtest internally calls them too, causing infinite recursion. Use alternative strategies (see "malloc Failure Test Alternative Strategy" in references/mock-framework-guide.md)
6. **Prohibit Meaningless Mock**: If the function under test does not call external dependencies, do not introduce any Mock framework—unless the task explicitly requires implementing an isolation mechanism (such as volatile registers, hardware I/O, etc.), in which case implement isolation per task requirements rather than skipping
7. **Prohibit Dead Code Mock**: Prohibited from writing platform #ifdef-protected Mock tests that never actually execute on the current platform
8. **Prohibit Static Function Stubbing**: Treat its logic as part of the function under test; prohibited from Mocking static functions
9. **Prohibit Mocking Traversal Functions**: Prohibited from Mocking traversal operation functions (HasNext/FetchNext/GetNext/Next, etc.); should Mock data provider functions and fill test data in output parameters
10. **Prohibit Mocking Singleton Getters**: Prohibited from Mocking singleton getter functions (GetInstance/sInstance/GetSingleton, etc.); should directly Mock instance methods

### Assertion Misuse Prohibitions

11. **Prohibit Indirect Assertion Coupling**: When verifying operation results, use the most direct verification method; prohibited from using complex query methods with sentinel values
12. **Prohibit NoThrow-Only Assertions**: void methods must verify observable state changes (global variables/class members/output parameters); prohibited from using only EXPECT_NO_THROW. If the state is truly not observable, the name must use the _NoThrow suffix and explain in comments
13. **Prohibit GTEST_SKIP**: The test case has no valid information. Preserve the test case code and disable using macro definitions

### Coding Misuse Prohibitions

14. **Prohibit Hardcoded Binary Test Data**: For protocol parsing, binary data processing, and other scenarios, prefer using computation helper functions (such as CRC calculators, frame builders) over hardcoded byte arrays
15. **Prohibit #define private public as First Choice**: Prefer testing through public interfaces. Only use #define private public when public interfaces are insufficient to verify expected behavior, and must follow the include order rules in references/test-generation-rules.md. If #define private public causes a crash, immediately remove it and switch to public interfaces
16. **Prohibit Rewriting the Class Under Test**: Prohibited from writing a completely new test target class as the test object. The test object lacks authenticity, test results are invalid. Must use real business code for testing
17. **Prohibit Arbitrary Pointer Casts**: Prohibited from using reinterpret_cast<ClassName*>(0x1) to cast arbitrary values to pointers; pointers need to be dereferenced, arbitrary addresses may cause crashes. Should use constructors to construct objects

### Code Modification Prohibitions

18. **Prohibit Ignoring Task-Code Mismatch**: If the function described in the task does not exist in the source code, must annotate the mismatch in the output, test the closest existing function, and prohibited from creating wrappers to simulate non-existent functions. The output summary must include an expectation-test mapping table
19. **Prohibit Modifying Third-Party Libraries**: Do not modify any files under libs/, vendor/, even to fix build errors
20. **Prohibit Static Global Variable Assignment**: Can only use initial values; prohibited from modifying the static global variables of the module under test in tests
21. **Prohibit Test File Global Variable Definitions**: Prohibited from defining global variables in test case files; can only declare through extern

## Workflow

### Step Execution Standards (Mandatory Compliance)

- **No Silent Skipping**: If any step skips some sub-steps due to a fast track or preconditions already being met, must record in TodoWrite:
    1. Which sub-steps were skipped
    2. Reason for skipping (e.g., "User already provided complete information")
    3. Information source used
- **At Least One Output Per Step**: Even if a step completes in 1 second, must output the key conclusions of that step. For example, step 1 must output the function under test signature, step 2 must output the test framework selection result, step 3 must output the dependency classification summary and context file list
- **Skip Declaration Format**: Append `[Skipped: sub-steps X-Y, reason: xxx]` marker to the corresponding step entry in TodoWrite
- **Unsolvable Problem Skip**: When encountering unsolvable problems (such as missing necessary libraries, environment configuration issues), record the problem and skip subsequent steps

Use TodoWrite to strictly follow the steps below:

### Step 1: Function Under Test Identification

**User Directly Specifies** — The user explicitly provides the function under test code, name, or file path, directly proceed to step 2

**Search Strategy**: Prioritize using grep/semantic search to locate the target function, avoiding broad enumeration (glob full-file scan). Only use glob when needing to understand project structure.

**Function Existence Verification Gate**: After identifying the function under test, confirm the function actually exists in the source code. If the function described in the task does not exist:
1. Use grep to search the entire project to confirm the function does not exist
2. Use glob to search for similarly named modules/files
3. Annotate the mismatch in the output
4. Test the closest existing function
5. Include an expectation-test mapping table in the output summary

**Must Output the Following Information**:
- Complete signature of the function under test
- Information source (user-provided/search-located)
- Reason for skipping search (e.g., "User already provided function name and file path in prompt")

### Step 2: Project Environment and Test Framework Identification

1. **Prioritize Checking User Prompt**: Check if the user prompt already specifies the build command, project root directory, test framework, etc. If the user has provided complete information, use it directly without inference
2. **Build Configuration Acquisition**: If not provided in the user prompt, infer build configuration from project structure:
    - Check CMakeLists.txt, Makefile, build.sh, build.py, and other build files
3. **Configuration Information Reading**: Read the inference results, obtain: project root directory, module where the file under test is located, test framework version and configuration, UT project directory, build command, Mock framework type
4. **Framework Selection Decision** (per references/mock-framework-guide.md):
    - Function under test does not need Mock external dependencies → Use pure gtest, do not introduce any Mock framework
    - Needs Mock → Select appropriate Mock framework per decision flow
5. **Check Existing Test Patterns**: Read existing test files in the project, analyze Fixture base classes, Mock usage patterns, data construction helper functions, maintain style consistency

**Must Output the Following Information**:
- Build command
- Test framework selection
- Mock framework selection
- Information source (user-provided/project-inferred)
- Skipped sub-steps and reasons (e.g., "User provided build command, skipping build configuration acquisition")

### Step 3: Dependency Identification and Context Acquisition (Mandatory Execution)

#### 3.1 Determine Test File Path

If the user provided one, use it directly; otherwise determine per path derivation rules (find existing test directory, observe naming patterns, derive per the same pattern).

#### 3.2 Call Chain and Dependency Identification (Prerequisite Step, Must Precede Context Acquisition)

**Core Logic**: First clarify who the function under test calls and which are external dependencies, then decide what context to acquire. Avoid blindly extracting context without knowing dependency relationships.

**Script Extraction (Recommended)**: If libclang is available in the environment, prioritize using the scripts/extract-function-callees.py script to automatically extract function call chains. See references/callstack-workflow.md for specific flow:
1. Use grep/semantic search to locate the function under test definition location (file path + line number)
2. Call the script: `python scripts/extract-function-callees.py <source_file> -l <line> -c <compile_commands.json>`
3. Parse the output, distinguish internal dependencies (same-class member functions/same-module functions) and external dependencies (Mock targets)
4. Recursively call the script for internal dependencies until all external dependencies are identified

**Manual Inference (Fallback)**: When libclang is unavailable, manually analyze call relationships by reading source code. Annotate in output: `[Skipped: Call chain script extraction, reason: libclang unavailable, switched to manual inference]`

**Script Key Constraints**:
- Must find function location before calling the script (script requires file path + line number)
- Cannot use .h header file as source_file parameter (script will error)
- Use set to record processed functions, avoid circular recursion
- compile_commands.json is effectively a mandatory parameter (script errors and exits if missing)

#### 3.3 Transitive Dependency Analysis (Rule Supplement)

**When to Execute**: Must execute when the function under test calls same-class member functions or same-module internal functions. See references/transitive-dependency-analysis.md for specific rules.

**Relationship with 3.2**: 3.2 provides precise call facts (who called whom), 3.3 supplements deep dependencies that the script cannot discover:
- Rule 1 (Must check): Same-class member functions must recursively analyze their external dependencies
- Rule 2 (Must check for C++ classes): External dependencies in constructors must be identified (e.g., Database::Connect())
- Rule 3 (Check when database exists): Database/external service dependency identification and Mock strategy
- Rule 4 (Check when traversal exists): Implicit external dependencies of iterators/collection traversal

**Merge Results**: Merge 3.2's call chain results with 3.3's transitive dependency results to form a complete dependency classification:
- Internal dependency list (do not Mock): same-class member functions, same-module internal functions
- External dependency list (must Mock): functions whose implementations are not in this class or this file
- Strictly prohibited from misclassifying internal dependencies as external dependencies

Skip when the function under test has no internal calls, annotate: `[Skipped: Transitive dependency analysis, reason: Function under test has no same-class member functions or same-module internal calls]`

#### 3.4 Targeted Context Acquisition

**Core Logic**: Based on the dependency classification results from 3.2+3.3, precisely acquire the context needed to write tests, avoiding blind broad-net casting.

**Precise Acquisition Scope** (only acquire the following):
- Function under test body (must see function implementation to write tests)
- External dependency function signatures (must know function signatures and return types for Mock)
- Type definitions of input/output parameters (must know struct/class/enum fields to construct test data)
- Header file of the function under test (includes and declarations)
- Do NOT acquire internal dependency function bodies (not Mock targets, no need to acquire)
- Do NOT acquire unrelated files in the same directory

**Exploration Scope Constraints**: Only read the file containing the function under test, its header file, directly referenced types/dependencies. Skip unrelated files in the same directory.

**Context Isolation**: Prohibited from directly reading the full source file under test for analysis in step 4 and subsequent steps; only read the refined context document. If source code details are needed, complete within step 3 scope.

**Must Output the Following Information**:
- Test file path
- Call chain extraction method (script extraction/manual inference) and result summary
- Transitive dependency analysis result summary (identified internal and external dependencies)
- Dependency classification summary (internal dependency list + external dependency/Mock target list)
- Context acquisition method (script extraction/manual reading) and acquired context file list
- Skipped sub-steps and reasons

### Step 4: Function Characteristic Analysis and Test Design (Mandatory Execution)

**Must complete the following analysis before generating code**.

#### 4.1 Function Characteristic Analysis

Execute per references/function-classification-guide.md:

1. **Function Type Identification** (classified by 7 types):
    - Simple computation functions: Focus on algorithm correctness, boundary values
    - Single-dependency functions: Verify both success and failure scenarios for dependencies
    - Multi-dependency functions: Verify dependency combinations, call order, error propagation
    - State machine functions: Cover all state transition paths
    - Callback functions: Verify callback parameters, call timing, call count
    - Business process functions: Cover business success/failure/special paths
    - Data conversion functions: Verify input-output mapping, boundary data

2. **Complexity Assessment**: Cyclomatic complexity, lines of code, number of parameters, number of external dependencies

3. **Input-Output Analysis**: Parameter classification, output analysis, boundary condition identification

4. **Control Flow Tracing**: For each test scenario, trace the exact control flow path of the function, paying special attention to early returns and short-circuit exit paths. Confirm the actual output produced by that path before writing assertions

5. **Parameter Type Definition Extraction**: For structs, enums, unions, and class types involved in input/output parameters, must locate their type definitions and extract field-by-field information; this type information is the foundation for subsequent test data construction

#### 4.2 Systematic Test Design

Execute per references/test-design-methodology.md:

1. **Control Flow Analysis**: List all independent paths
2. **Data Flow Analysis**: Cover definition-use paths
3. **Boundary Condition Analysis**: Systematically test each input parameter per the boundary matrix, including median and boundary negative values
4. **Exception Scenario Analysis**: Identify all resource allocation points and external call points, design failure scenarios
5. **Resource Leak Analysis**: Verify resource release on normal/exception paths
6. **Decision Table Construction**: List all conditions and actions
7. **Business Scenario Analysis**: Enumerate all business scenarios
8. **Missing Scenario Check**: Execute the checklist
9. **Priority Ranking**: P0 (must cover), P1 (should cover), P2 (can cover)

When the function under test has low complexity, may skip inapplicable sub-steps based on function type, annotating skip reasons (e.g., "Function under test has no resource allocation, skipping resource leak analysis").

#### 4.3 Mock Strategy and Verification Design

**Relationship with 4.2**: 4.2 produces candidate case list, 4.3 determines Mock scheme and verification method for each case; the two can iterate—if 4.3 finds that some scenarios cannot be implemented due to Mock limitations, should backtrack to 4.2 to adjust case design.

1. **Mock Target Verification Gate**: Verify each item in the external dependency/Mock target list output from step 3, confirming that each Mock target is a function actually called in the code path of the function under test. If the function under test does not directly call that function, do not Mock it

2. **External Dependency Extraction**: From the dependency classification results of step 3, distinguish internal dependencies (do not Mock) and external dependencies (must Mock). Internal dependencies are same-class member functions or same-module internal functions; external dependencies are functions whose implementations are not in this class or this file. Strictly prohibited from misclassifying internal dependencies as external dependencies

3. **Mock Strategy Design** (per references/mock-strategy.md):
    - Risk-adaptive principle: High-risk dependencies deeply Mocked (normal + exception + boundary), medium-risk selectively Mocked, low-risk minimally Mocked
    - Scenario matching principle: Exception scenarios do not Mock normal responses, boundary scenarios do not Mock normal responses
    - Minimal Mock principle: Only Mock necessary dependencies/methods, preserving the real implementation of internal business logic
    - Contract consistency principle: Mock return values/exceptions/call behavior must strictly conform to the real business contract of dependencies

4. **Mock Limitation Scenario Handling**: When an external dependency cannot be Mocked due to framework limitations, must trigger the target branch through alternative solutions, do not skip branch coverage:
    - Preferred solution: Adjust input parameters or set internal state to trigger the target branch
    - Secondary solution: Mock the allocation function actually called by the function under test (e.g., Mock strdup instead of Mock malloc)
    - Fallback solution: Manually construct state and verify subsequent behavior (e.g., manually set device to NULL to simulate malloc failure)
    - Windows/MinGW special limitation: Prohibited from Mocking malloc/free/printf (gtest internally calls them, causing infinite recursion), see "malloc Failure Test Alternative Strategy" in references/mock-framework-guide.md

5. **UB Scenario Handling**: If the function under test produces undefined behavior under certain inputs (such as division by zero, null pointer dereference), use EXPECT_DEATH/ASSERT_DEATH to verify crash behavior; prohibited from deleting that test scenario. Floating-point division by zero prefers std::isnan/std::isinf verification

6. **Result Verification Strategy Design**: Design verification scheme for each case:
    - Mandatory verification: return value verification, output parameter verification
    - Optional verification: Mock call count verification/key Mock input parameter verification, global/static variable state verification, member variable change verification, side effect verification

Skip 4.3.1-4.3.4 when there are no external dependencies, annotate: `[Skipped: Mock strategy design, reason: Function under test has no external dependencies]`

#### 4.4 Case Count Control and Filtering

After 4.2 produces candidate cases and 4.3 determines Mock schemes, execute 3 rounds of filtering to produce the final case list:

1. **Invalid Case Removal**: Pure null-check returns, safety function wrappers, pure logging, simple assignment returns, inlined simple Getters (unless they are combined with important business logic)

2. **Same-Branch Merging**: Merge branches corresponding to the same if/else, switch, or null-check logic into the same test case

3. **Mock Limitation Filtering**: Filter scenarios that cannot be implemented due to Mock framework limitations. For branches that cannot be Mocked but must be covered, backtrack to 4.3.4 to find alternative solutions; when alternatives are also not feasible, annotate the scenario as "Mock limitation, cannot cover" and record in the output

4. **Count Control**: After P0/P1 are covered, assess whether P2 cases are needed. If P0/P1 already cover all branches, only add P2 cases when they provide additional boundary values or business value. Avoid generating redundant cases for the same branch that differ only in data but have the same control flow. After merging, the total number of cases for a single function must not exceed max(10, cyclomatic complexity). If the count limit is exceeded, prioritize preserving normal paths and core business branches, trimming edge scenarios

5. **Final Case List**: Output the categorized final case list, each case including: case name, verification scenario, priority (P0/P1/P2), required Mock configuration, verification scheme

**Must Output the Following Information**:
- Function type identification result (e.g., "multi-dependency function")
- Complexity assessment result (cyclomatic complexity, lines of code, number of external dependencies)
- Number and list of identified independent control flow paths
- External dependency list (distinguishing internal and external dependencies)
- Mock target list and Mock strategy summary
- Test case design summary (P0/P1/P2 case count, covered scenario list)
- Mock limitation scenarios and handling schemes (if any)
- Final case list
- Skipped analysis sub-steps and reasons


### Step 5: Test Case Generation

#### 5.1 Preparation Phase: File Reading and Framework Confirmation

1. **Required File Reading**: Context files acquired in step 3.4, assets/ut-knowledge.md, existing test files in the project (reference by path proximity)
2. **Mock Framework Confirmation**: Confirm Mock framework per step 2's framework selection decision, read the corresponding reference:
    - Pure gtest (no external dependencies) → Do not introduce Mock framework, do not read Mock-related references
    - gmock → references/mock-framework-guide.md §gtest/gmock
    - binmock → references/mock-framework-guide.md §binmock
    - AMock → references/mock-framework-guide.md §AMock + assets/ut-knowledge.md §AMOCKER
    - mockcpp → Must read references/mockcpp-guidance.md (complete usage guide, including MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL/MOCK_METHOD selection decision flow, scenario-based usage, special scenario handling)
3. **Existing Test Style Reference**: Must strictly reference test cases under the test case save path and nearby test cases' design and implementation based on path proximity

#### 5.2 Test Structure Setup

Execute per references/test-generation-rules.md §Code Organization Structure:

1. **File Header Comments**:
     ```cpp
     // Description: {Function under test} unit test
     // Create: {Current time} (format yyyy-MM-dd)
     ```
2. **Include Organization**: System header files → Project header files → Module under test header files (wrap with `extern "C" {}` when testing C from C++, prohibited from declaring extern "C" functions after include)
3. **#define private public**: Only use when public interfaces are insufficient to verify expected behavior; include order per references/test-generation-rules.md. If it causes a crash, immediately remove
4. **Fixture Class Definition**:
    - SetUp(): Common initialization, global state save and zero-reset
    - TearDown(): Systematic cleanup (use std::set to track added resources)
    - Helper functions: Data construction (fill_default_param), computation helpers (calculateExpectedCRC)
    - Existing Fixture base class inheritance: If the class under test has an existing test Fixture base class, prefer inheriting from that base class
5. **Mock Class Definition** (when Mock is needed): Create Mock class per the framework confirmed in step 2, reference examples/mock_wrapper_example.h
6. **Test File Constraint**: Even if the file under test is a .c file, the generated test file must be a .cpp file; prohibited from defining global variables in test files, can only declare through extern

#### 5.3 Case Generation (Per 4.4 Final List One by One)

Execute per references/assertion-specification.md and references/test-generation-rules.md:

1. **Incremental Verification Strategy**: First write 1 normal path test case, compile and run successfully, then supplement the remaining cases per the 4.4 final list. Avoid writing all cases before discovering basic compilation/link/data construction errors. If a production code bug is discovered during testing, spend at most 1 round investigating, adjust test assertions to match actual behavior and record the bug in the output. Do not spend multiple rounds debugging production code

2. **Case Generation Four Phases**: Generate each case in the following order:
    - **Mock Configuration** (per 4.3 Mock strategy): Common Mock in SetUp(), scenario Mock in Fixture member functions, specific Mock in cases
    - **Execute Call**: Construct test data (struct field-by-field assignment, pointers use nullptr, output parameters zero-initialized) → Call function under test. CRUD companion interfaces prefer using add interface to construct test data then query and verify, rather than Mocking internal data structures. Protocol parsing/CRC verification and other scenarios prefer creating computation helper functions in Fixture, prohibited from hardcoding byte arrays
    - **Assertion Verification** (per references/assertion-specification.md): Return value verification, output parameter verification, field-level verification (struct field-by-field, pointer non-null + field, container size + elements)
    - **Data Cleanup**: Mock cleanup (gmock: VerifyAndClear / mockcpp: GlobalMockObject::verify(), **clean up within the case, prohibited from global cleanup in TearDown()**)

3. **Assertion Standards** (strictly execute per references/assertion-specification.md eight standards):
    - Prohibited from no assertions, always-true assertions, NoThrow-only assertions
    - Assertion coupling minimization: Use the most direct available method to verify operation results
    - Boundary value coverage: Test lower bound, upper bound, and median for range conditions; explicitly test NULL/empty value scenarios
    - void functions must verify state changes (global variables/class members/output parameters), prohibited from relying solely on cout output or EXPECT_NO_THROW
    - Explicit NULL pointer testing: When the task involves "NULL pointer operations", must explicitly set nullptr and verify behavior, naming reflecting NULL conditions (e.g., `_WhenPointerIsNull`)

4. **Naming and Comment Standards** (per references/test-generation-rules.md):
    - Test suite naming: Test + name of object under test, UpperCamelCase; case naming: UpperCamelCase, including key input and output
    - Naming accuracy: Use `_NoThrow` suffix for only verifying no crash, use `_UpdatesState` for state change verification
    - Each case must have a comment at the top:
    ```cpp
    /**
     * Scenario: Scenario description
     * Expected: Expected behavior
     */
    TEST_F(TestSuitName, TestCaseName)
    ```

5. **Expected Value Batch Computation**: Expected values for algorithm functions use a single script execution for batch computation; multiple iterative single-query computations are prohibited

6. **Generation Requirements**: Single-file delivery, header file extern "C" wrapping, struct field-by-field assignment, pointer initialization standards

#### 5.4 C Module Special Pattern Handling

1. **C Module Static State Isolation**: For C modules using static global variables, prefer using `#include "source.c"` to directly include the source file to access static variables for state reset. **Note**: When using #include .c, do not simultaneously compile and link that .c file, otherwise duplicate symbol errors will occur. If the source file has external dependencies and cannot be directly included, use Fixture's SetUp/TearDown to save and restore global state. Prohibited from modifying the module under test's static global variables in tests; can only use initial values

2. **SetUp Zero-Reset Pattern**: For C modules using global state, SetUp must first save the original state, then explicitly zero-reset, rather than just saving and restoring. Zero-reset + save/restore combination ensures test isolation. Prefer using the module's reset function (e.g., init_pcb_table())

**Must Output the Following Information**:
- Generated test file path
- Total number of test cases and list (name and verification scenario of each case)
- Mock framework used and Mock target list

### Step 6: Compilation, Execution, and Fixing

**Mandatory Requirement**: The compilation step is mandatory and must not be skipped due to project complexity, many dependencies, etc. Must continue fixing until compilation succeeds or encountering unsolvable problems (such as missing necessary libraries, environment configuration issues). Only fix test-side issues, do not modify production code.

Execute per references/compile-and-run.md:

#### 6.1 Build Configuration and First Compilation

**Before the first compilation, confirm the following configuration at once**:

1. **Build Strategy Selection** (try by priority, **user-provided build command is highest priority**):
    - **Strategy D** (highest priority): If the user provided a build command or script in the prompt, **must use the user-provided command first**, no need to try other strategies
    - **Strategy A**: Use CMake to build specific targets (cmake --build build --target gtest gtest_main gmock gmock_main), maximum 2 attempts. **Prohibited** from using cmake --build without target for full build
    - **Strategy B**: If Strategy A fails due to unrelated source file errors, fall back to target compilation (gcc for .c files, g++ for .cpp files), using dependency libraries built by Strategy A
    - **Strategy C**: If Strategy A/B are both unavailable, use complete manual compilation

2. **Compiler Selection**: .c files use gcc, .cpp files use g++ (g++ compiling .c files causes C symbol name mangling, undefined reference at link time)

3. **Coverage Flags**: Add `-fprofile-arcs -ftest-coverage` at compile time, add `--coverage -lgcov` at link time (compile and link flags must be consistent, otherwise `undefined reference to __gcov_init`)

4. **Windows/MinGW Adaptation**: Always use `-static` flag in Strategy B/C; enable static linking via `CMAKE_EXE_LINKER_FLAGS` in CMake; when including `<windows.h>` if code has ERROR enum value, add `#undef ERROR` after include

5. **mockcpp Platform Compatibility Preprocessing**: If mockcpp fails to compile on the current platform (e.g., missing sys/mman.h), do not modify mockcpp source code. Record the limitation, use other Mock solutions (see references/mock-framework-guide.md), do not link mockcpp in Strategy B/C

6. **Execute First Compilation**: Execute compilation per the selected build strategy, proceed to 6.2 or 6.3

#### 6.2 Compilation Failure Fix Loop (Maximum 10 Rounds)

When compilation fails, **must** enter the fix loop, continue fixing until success:

1. **Prioritize Querying Experience Base**: Read `references/mockcpp-debug-experience.md`, match the scenario and solution for the current compilation error, avoid repeatedly solving the same problem

2. **Error Classification and Fix Strategy**:
    - Syntax errors/missing header files → Fix includes, add -I paths
    - Link errors (undefined reference) → Check link order, add -l/-L; if g++ mistakenly compiled .c files, switch to gcc
    - mockcpp compilation issues → Check references/mockcpp-debug-experience.md to match scenarios
    - Inconsistent coverage flags → Ensure compile and link flags are consistent

3. **Fix Constraints**: Only fix test code, do not modify production code, CMakeLists.txt, third-party libraries

4. **Recompile**:
    - If successful → Proceed to 6.3 to execute tests
    - If failed → Continue next round of fixes

**No Early Exit**: Each fix round must be fully executed (query experience base → analyze → fix → compile), must not skip directly. When encountering unsolvable problems, record the issue.

#### 6.3 Execute Tests and Failure Fix Loop (Maximum 10 Rounds)

After successful compilation, execute the test executable:

1. **Execute Tests**: When running the executable in MinGW bash, use forward slash paths (`./build/test_runner.exe`)

2. **Execution Problem Diagnosis** (Windows/MinGW):
    - exit code 127 or 0xC0000135 → Use ldd to check DLL dependencies, prefer -static recompilation
    - Maximum 3 attempts for the same runtime error, then switch to -static rebuild

3. **Execution Failure Fix Loop**: When execution fails (runtime error, test assertion failure, Mock type matching error, etc.), **must** enter the fix loop:
    - **Prioritize Querying Experience Base**: Read `references/mockcpp-debug-experience.md`, match the scenario and solution for the current execution error
    - Analyze execution failure cause (null pointer assertion, Mock type mismatch, test data error, logic error, etc.)
    - Fix test code (adjust test data, modify Mock configuration, correct assertions, etc., do not modify production code)
    - Recompile and execute tests
    - If successful → Tests pass, proceed to step 7 coverage analysis
    - If failed → Continue next round of fixes

4. **After Reaching Attempt Limit**: Use DISABLED_CASE macro to disable unfixable cases, preserving complete case code and noting the reason:
   ```cpp
   #ifdef DISABLED_CASE
   TEST_F(FixtureName, CaseName) {
       // This case is disabled due to compilation/execution issues, auto-skipped
       // Problem reason explanation
       case code
       ...
   }
   #endif
   ```
   **Prohibitions**: Prohibited from deleting case code, prohibited from modifying the function under test implementation, prohibited from modifying or deleting macro-definition disabled code

#### 6.4 Build Completion Determination and Output Summary

1. **Build Completion Determination**: Once Strategy B/C succeeds and tests pass, do not retry CMake full build. Common error pattern: Strategy A fails → Strategy B succeeds → tries to go back to Strategy A full build → fails again (wasting time)

2. **Experience Accumulation After Successful Fix**: After successful fix, extract the experience of solving this problem, record in the task summary, to avoid repeatedly solving the same problem

**Must Output the Following Information**:
- Build strategy used (Strategy A/B/C/D) and selection reason
- Compilation result (success/failure, failure reason summary)
- Number of compilation fix rounds (if the fix loop was experienced)
- Execution result (pass/fail, failed cases and reasons)
- List of cases disabled by DISABLED_CASE and disable reasons (if any)
- Unsolvable problems encountered (if any)

### Step 7: Coverage Analysis and Improvement (Mandatory Execution)

**Mandatory Requirement**: Coverage analysis is a mandatory step; must check that coverage reaches 80% or above. If it does not reach, must fix code to improve coverage until the requirement is met. Coverage analysis is the **natural continuation** of step 6 compilation and execution, using the coverage data generated during step 6 compilation and runtime.

Execute per references/coverage-analysis.md:

#### 7.1 Pre-check and Coverage Data Collection

1. **Check Test File**: Confirm the test file contains TEST_F or TEST macros (if no test cases, coverage analysis cannot proceed, output prompt and end)

2. **Check gcda File**: Use `find . -name "*.gcda" | grep {TARGET_SOURCE_FILE}` to check if coverage data files exist (if not, it means coverage instrumentation or runtime has issues, output prompt and end). Record the found gcda path as `TARGET_GCDA_PATH`

3. **Execute gcov to Generate Coverage Report**: Execute gcov in a temporary directory to avoid polluting the project directory:
   ```bash
   mkdir -p /tmp/ut-cpp/gcov_output && cd /tmp/ut-cpp/gcov_output && gcov {TARGET_GCDA_PATH} > /dev/null 2>&1
   ```
   gcov generates `.gcov` files in the current directory (e.g., `xxx.cpp.gcov`)

#### 7.2 Uncovered Code Analysis and Strategy Matching

1. **Extract Uncovered Code**: Use `grep "#####:"` to find code lines never executed from gcov output. gcov marker meanings: `number:`=executed, `#####:`=never executed (needs attention), `-:`=non-executable, `=====:`=special marker (all do not need attention)

2. **Coverage Problem Routing**: Based on uncovered code characteristics, match coverage strategies per references/coverage-route.md in **top-to-bottom order**. Each priority must be checked; the same uncovered code may match multiple rules and require comprehensive application

3. **Generate Coverage Improvement Strategy Report**: Generate report per references/coverage-analysis.md §Step 3.3 template, including line coverage statistics, uncovered code and line numbers, matched coverage strategies

#### 7.3 Coverage Pass Determination and Follow-up Handling

1. **Coverage Pass Determination**: Line coverage ≥ 80% → Pass, proceed to step 8 quality check

2. **Coverage Fail Handling**: Line coverage < 80% → Must supplement test cases and recompile/execute (backtrack to step 6), until coverage reaches the requirement, then proceed to step 8

3. **Environment Cleanup**: Delete the `/tmp/ut-cpp/gcov_output` temporary directory to prevent residue

**Must Output the Following Information**:
- Line coverage percentage
- Uncovered code lines and cause analysis
- Coverage improvement strategy (if not passing)
- Whether to backtrack to step 6 to supplement cases

### Step 8: Case Quality Check (Mandatory Execution)

After coverage passes, all cases must undergo quality check as the **final gate** to ensure output code complies with standards. Execute per the standards in references/constraints.md:

#### 8.1 Case Quality Check

Check the following 5 items one by one; all must pass before proceeding to 8.2:

1. **Case Count Check**: Based on the 4.4 final case list, check whether the test code case count is consistent with the design (cases disabled by macro definitions are counted normally)

2. **Case Assertion Check**:
    - Check whether all cases' assertions are missing per the 4.3 verification scheme
    - Check against the **Assertion Prohibited Pattern List** in references/constraints.md item by item (empty cases, always-true assertions, NoThrow-only, non-null pointer/container only, duplicate with if condition, etc., 14 prohibited patterns)
    - Check return value verification per the **Field-Level Validation Rules** in references/constraints.md (struct/class field-by-field, pointer non-null + field, container size + elements, map key-value, etc., 9 types)

3. **Case Disable Check**: Disabled cases must be wrapped with DISABLED_CASE macro and preserve complete case code; must note the disable reason

4. **Case Comment Check**: Each case must have a comment, comment position above TEST_F/TEST_P, comment must include scenario and expected

**Check Fail Handling**: If any item fails, must fix the issue and re-check until all pass before proceeding to 8.2.

#### 8.2 Task Summary Output

After quality check passes, output the final task summary:

- Function under test: Complete function signature
- Number of test cases: Count of cases generated this time
- Test functions: List all test case signatures and descriptions
- Verification scope: Covered normal paths, boundary conditions, exception scenarios
- Coverage estimate
- Compilation/execution status
- Case check results
- Unresolved issues (if any)
- **Expectation-Test Mapping Table** (if there is a task-code mismatch)

## Bundled Resources

### references/

- **test-design-methodology.md**: Systematic test design methodology. Used in step 4.2.
- **function-classification-guide.md**: Function classification and test strategy guide. Used in step 4.1.
- **mock-framework-guide.md**: Mock framework selection and usage guide, including framework selection decision flow. Used in step 2 and step 5 (read when Mock is needed).
- **mockcpp-guidance.md**: Complete mockcpp usage guide, including MOCKER/MOCKER_CPP/MOCKER_CPP_VIRTUAL/MOCK_METHOD selection decision flow, scenario-based usage, special scenario handling (traversal function Mock, singleton Mock). Used in step 5 (must read when project uses mockcpp).
- **mockcpp-debug-experience.md**: Common mockcpp compilation/runtime issues and solutions. Used in step 6.2 and 6.3 (referenced when encountering mockcpp issues during compilation/runtime).
- **mock-strategy.md**: Mock strategy design principles, including risk adaptation, scenario matching, minimal Mock, contract consistency principles. Used in step 4.3 and step 5.
- **assertion-specification.md**: Eight assertion standards and data cleanup standards, including special scenario assertion guidance. Used in step 5.
- **test-generation-rules.md**: Test case generation rules, including naming conventions, #define private public order, C module static state isolation, GIVEN phase constraints. Used in step 5.
- **compile-and-run.md**: Compilation and execution methods, including build strategy priority, compiler selection, coverage flags, Windows/MinGW platform adaptation, progressive fix flow. Used in steps 6.1-6.3.
- **transitive-dependency-analysis.md**: Transitive dependency analysis method. Used in step 3.3.
- **callstack-workflow.md**: Call chain extraction workflow, used with the extract-function-callees.py script. Used in step 3.2.
- **constraints.md**: Core coding constraints, including assertion prohibited pattern list, field-level validation rules, prohibited coding methods. Used in step 5 and step 8.1.
- **coverage-analysis.md**: Coverage analysis method, including gcov usage, uncovered line analysis, report templates. Used in steps 7.1-7.2.
- **coverage-route.md**: Coverage problem routing, matches coverage strategies based on uncovered code characteristics. Used in step 7.2.

### examples/

- **test_example.cpp**: Complete test case example. Referenced in step 5.
- **mock_wrapper_example.h**: Virtual function Mock wrapper layer example. Referenced in step 5.

### scripts/

- **extract-function-callees.py**: libclang-based function call chain extraction script. Used in step 3.2.

### assets/

- **ut-knowledge.md**: UT knowledge base. Referenced in step 5.
