/*
 * Description: Complete test case example
 * Includes basic structure, Mock usage, data cleanup, assertion examples, Fixture state tracking,
 * void function state verification, EXPECT_DEATH usage, #include .c file pattern,
 * SetUp zero-reset pattern, computation helper function pattern, #define private public order,
 * GIVEN phase constraint, explicit NULL pointer testing
 */

#include <gtest/gtest.h>
#include <gmock/gmock.h>

#include <cstdint>
#include <cmath>
#include <set>
#include <vector>
#include <cstring>

// Correct usage of extern "C" when testing C from C++
extern "C" {
#include "financial_operations.h"
#include "device_manager.h"
#include "protocol_parser.h"
}

using namespace ::testing;

// ============================================================
// Example 1: Basic test structure (pure computation function)
// ============================================================

class FinancialOperationsTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Common initialization
    }

    void TearDown() override {
        // Common cleanup
    }
};

// Normal path test
TEST_F(FinancialOperationsTest, test_calculate_interest_when_valid_input_then_correct_result) {
    double result = calculate_interest(1000.0, 0.05, 1);
    EXPECT_DOUBLE_EQ(result, 50.0);  // Use EXPECT_DOUBLE_EQ for exact results
}

// Boundary condition test
TEST_F(FinancialOperationsTest, test_calculate_interest_when_zero_principal_then_zero_result) {
    double result = calculate_interest(0.0, 0.05, 1);
    EXPECT_DOUBLE_EQ(result, 0.0);
}

// Division by zero scenario test
TEST_F(FinancialOperationsTest, test_calculate_interest_when_zero_time_then_inf_result) {
    double result = calculate_interest(1000.0, 0.05, 0);
    EXPECT_TRUE(std::isinf(result));  // Division by zero verification
}

// Floating-point division boundary: 0.0/negative = -0.0 (not NaN/Inf)
TEST_F(FinancialOperationsTest, test_divide_when_zero_divided_by_negative_then_negative_zero) {
    double result = divide(0.0, -5.0);
    EXPECT_DOUBLE_EQ(result, -0.0);  // Note: 0.0/negative = -0.0
    EXPECT_TRUE(std::signbit(result));  // Verify sign bit is negative
}

// ============================================================
// Example 2: Fixture state tracking and TearDown cleanup
// ============================================================

class DeviceManagerTest : public ::testing::Test {
protected:
    std::set<int> added_device_ids;  // State tracking

    void SetUp() override {
        // Save global state
        saved_device_count = get_device_count();
    }

    void TearDown() override {
        // Systematically cleanup all added devices
        for (int id : added_device_ids) {
            remove_device(id);
        }
        added_device_ids.clear();
    }

    // Helper function: add device and track
    int add_tracked_device(const char* name) {
        int id = add_device(name);
        if (id >= 0) {
            added_device_ids.insert(id);
        }
        return id;
    }

    int saved_device_count;
};

TEST_F(DeviceManagerTest, test_add_device_when_valid_name_then_success) {
    int id = add_tracked_device("test_device");
    EXPECT_GE(id, 0);
    EXPECT_EQ(get_device_count(), saved_device_count + 1);  // Verify state change
}

// ============================================================
// Example 3: void function state verification (not relying on cout output)
// ============================================================

extern int g_task_count;
extern int g_current_status;

class TaskSchedulerTest : public ::testing::Test {
protected:
    int saved_task_count;
    int saved_status;

    void SetUp() override {
        saved_task_count = g_task_count;
        saved_status = g_current_status;
    }

    void TearDown() override {
        g_task_count = saved_task_count;
        g_current_status = saved_status;
    }
};

// Correct: Verify global variable state change
TEST_F(TaskSchedulerTest, test_schedule_when_task_available_then_count_increased) {
    g_task_count = 0;
    g_current_status = STATUS_IDLE;

    schedule_task();  // void function

    // Verify state change, not relying on cout
    EXPECT_EQ(g_task_count, 1);
    EXPECT_EQ(g_current_status, STATUS_SCHEDULED);
}

// Incorrect: Only verify cout output (insufficient)
// testing::internal::CaptureStdout();
// schedule_task();
// std::string output = testing::internal::GetCapturedStdout();
// EXPECT_NE(output.find("scheduled"), std::string::npos);

// ============================================================
// Example 4: EXPECT_DEATH usage (production code has UB/crash)
// ============================================================

TEST_F(TaskSchedulerTest, test_schedule_when_empty_list_then_crash) {
    g_task_count = 0;
    // Note: Division by zero with empty task list is a production code bug
    // Using EXPECT_DEATH to verify crash behavior, preserve coverage
    EXPECT_DEATH(schedule_task(), ".*");
}

// ============================================================
// Example 5: #include .c file pattern + SetUp zero-reset pattern (C module static state isolation)
// ============================================================

// When a C module uses static global variables and has no external dependencies,
// directly include the .c file to access static variables for state reset

// Assume db_operations.c has:
// static Record database[MAX_RECORDS];
// static int record_count = 0;

/*
#include "db_operations.c"  // Directly include .c file

class DbOperationsTest : public ::testing::Test {
protected:
    int saved_record_count;

    void SetUp() override {
        // 1. Save original state
        saved_record_count = record_count;

        // 2. Zero-reset (ensure test isolation)
        memset(database, 0, sizeof(database));
        record_count = 0;
    }

    void TearDown() override {
        // Restore original state
        record_count = saved_record_count;
    }
};

TEST_F(DbOperationsTest, test_add_record_when_valid_then_count_increased) {
    Record rec = {.id = 1, .data = "test"};
    int ret = add_record(&rec);
    EXPECT_EQ(ret, 0);
    EXPECT_EQ(record_count, 1);  // Directly access static variable to verify
}
*/

// ============================================================
// Example 6: Computation helper function pattern (replaces hardcoded binary data)
// ============================================================

/*
// Assume protocol_parser.h defines frame parsing functions
// Frame format: [header 0xAA] [cmd] [payload...] [CRC16] [tail 0x55]

class ProtocolParserTest : public ::testing::Test {
protected:
    // Computation helper function: only need to modify one place when CRC error found
    uint16_t calculateExpectedCRC(const uint8_t* data, size_t len) {
        uint16_t crc = 0xFFFF;
        for (size_t i = 0; i < len; i++) {
            crc ^= data[i];
            for (int j = 0; j < 8; j++) {
                if (crc & 1) crc = (crc >> 1) ^ 0xA001;
                else crc >>= 1;
            }
        }
        return crc;
    }

    // Frame builder: unified test frame construction
    std::vector<uint8_t> buildTestFrame(uint8_t cmd, const uint8_t* payload, size_t len) {
        std::vector<uint8_t> frame;
        frame.push_back(0xAA);  // header
        frame.push_back(cmd);
        frame.insert(frame.end(), payload, payload + len);
        uint16_t crc = calculateExpectedCRC(frame.data() + 1, frame.size() - 1);
        frame.push_back(crc & 0xFF);
        frame.push_back(crc >> 8);
        frame.push_back(0x55);  // tail
        return frame;
    }
};

TEST_F(ProtocolParserTest, test_parse_when_valid_frame_then_return_payload) {
    uint8_t payload[] = {0x01, 0x02, 0x03};
    auto frame = buildTestFrame(0x10, payload, sizeof(payload));

    parse_result_t result = {};
    int ret = parse_frame(frame.data(), frame.size(), &result);

    EXPECT_EQ(ret, 0);
    EXPECT_EQ(result.cmd, 0x10);
    EXPECT_EQ(result.payload_len, 3);
}

TEST_F(ProtocolParserTest, test_parse_when_crc_error_then_return_error) {
    uint8_t payload[] = {0x01, 0x02, 0x03};
    auto frame = buildTestFrame(0x10, payload, sizeof(payload));
    frame[4] ^= 0xFF;  // Corrupt CRC

    parse_result_t result = {};
    int ret = parse_frame(frame.data(), frame.size(), &result);

    EXPECT_EQ(ret, PARSE_ERR_CRC);
}
*/

// Prohibited: Hardcoded CRC byte array
// uint8_t frame[] = {0xAA, 0x10, 0x01, 0x02, 0x03, 0x45, 0x67, 0x55};
//                              CRC ^^^^ ^^^^ If algorithm is wrong, need to modify each case individually

// ============================================================
// Example 7: #define private public usage order
// ============================================================

/*
// Correct order: gtest → standard library → #define private public → header file under test
#include <gtest/gtest.h>
#include <string>
#include <vector>

#define private public  // Define before header file under test
#include "secret_class.h"
#undef private  // Optional: restore private

class SecretClassTest : public ::testing::Test {
protected:
    SecretClass obj;
};

TEST_F(SecretClassTest, test_process_when_internal_state_set_then_correct_result) {
    obj.internal_counter_ = 5;  # Access private member
    EXPECT_EQ(obj.process(), 5);
}
*/

// ============================================================
// Example 8: GIVEN phase constraint (CRUD interfaces)
// ============================================================

/*
// Correct: Use add interface to construct test data, then query and verify
TEST_F(DbOperationsTest, test_query_when_record_exists_then_return_data) {
    // GIVEN: Use add interface to construct test data
    Record rec = {.id = 1, .data = "test"};
    add_record(&rec);

    // WHEN: Use query interface to verify
    Record result = {};
    int ret = query_record(1, &result);

    // THEN: Verify query result
    EXPECT_EQ(ret, 0);
    EXPECT_STREQ(result.data, "test");
}

// Incorrect: Mock the internal storage of the query interface
// EXPECT_CALL(mock_storage, find(1))
//     .WillOnce(Return(Pointee(Record{1, "test"})));
// This verifies the Mock, not the real business process
*/

// ============================================================
// Example 9: Explicit NULL pointer testing
// ============================================================

/*
class PointerOpsTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Initialize non-null pointer
    }
};

// Correct: Explicitly set pointer to nullptr
TEST_F(PointerOpsTest, test_process_when_null_input_then_return_error) {
    int result = process_data(nullptr);
    EXPECT_EQ(result, ERR_NULL_PTR);
}

// Incorrect: Rely on implicit initial state (may not be nullptr)
// data_t* ptr;  // Uninitialized, not guaranteed to be nullptr
// int result = process_data(ptr);
*/

// ============================================================
// Example 10: Assertion coupling minimization
// ============================================================

class ShapeProcessorTest : public ::testing::Test {
protected:
    // ...
};

// Correct: Use the most direct verification method
TEST_F(ShapeProcessorTest, test_add_shape_when_valid_then_total_area_updated) {
    ShapeProcessor processor;
    processor.addShape(CIRCLE, 10.0);
    // Directly use calculateTotalArea to verify addShape
    EXPECT_DOUBLE_EQ(processor.calculateTotalArea(), 314.1592653589793);
}

// Incorrect: Using complex query methods for indirect verification
// auto shapes = processor.getShapesByArea(0, INT_MAX);
// EXPECT_EQ(shapes.size(), 1);

// ============================================================
// Example 11: Mock usage and data cleanup
// ============================================================

class MockExternalService {
public:
    virtual ~MockExternalService() = default;
    virtual int fetchData(int id) = 0;
};

class MockService : public MockExternalService {
public:
    MOCK_METHOD(int, fetchData, (int id), (override));
};

class ServiceClientTest : public ::testing::Test {
protected:
    MockService mockService;
    ServiceClient* client;

    void SetUp() override {
        client = new ServiceClient(&mockService);
    }

    void TearDown() override {
        delete client;
    }
};

TEST_F(ServiceClientTest, test_process_when_fetch_success_then_return_data) {
    EXPECT_CALL(mockService, fetchData(100))
        .WillOnce(Return(42));

    int result = client->process(100);
    EXPECT_EQ(result, 42);

    // Clean up Mock in the current case
    ::testing::Mock::VerifyAndClearExpectations(&mockService);
}

TEST_F(ServiceClientTest, test_process_when_fetch_fails_then_return_error) {
    EXPECT_CALL(mockService, fetchData(100))
        .WillOnce(Return(-1));

    int result = client->process(100);
    EXPECT_EQ(result, -1);

    ::testing::Mock::VerifyAndClearExpectations(&mockService);
}

// ============================================================
// Example 12: Test naming accuracy (void function no-crash test)
// ============================================================

// Correct: Use _NoThrow suffix when only verifying no crash
// TEST_F(SomeTest, test_init_when_invalid_config_then_NoThrow) {
//     EXPECT_NO_THROW(init(invalid_config));
// }

// Incorrect: Use a name implying behavior verification but actually only verifying no crash
// TEST_F(SomeTest, test_init_when_invalid_config_then_Configured) {
//     EXPECT_NO_THROW(init(invalid_config));
//     // Name implies "configured", but actually only verifies no crash
// }
