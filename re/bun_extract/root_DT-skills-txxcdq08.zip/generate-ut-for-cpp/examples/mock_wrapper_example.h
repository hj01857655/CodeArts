/*
 * Description: Virtual function Mock wrapper layer example
 * Used when the code under test depends on non-virtual functions, requiring a Mock wrapper layer
 */

#ifndef MOCK_WRAPPER_EXAMPLE_H
#define MOCK_WRAPPER_EXAMPLE_H

#include <gmock/gmock.h>
#include <string>
#include <cstdint>

// ============================================================
// Original class (non-virtual functions)
// ============================================================

class OriginalService {
public:
    // Non-virtual functions - cannot be directly Mocked
    int32_t ProcessData(const std::string& data);
    int32_t SendRequest(const std::string& endpoint);
    bool IsConnected() const;
};

// ============================================================
// Step 1: Create virtual function interface class
// ============================================================

class MockServiceInterface {
public:
    virtual ~MockServiceInterface() = default;
    virtual int32_t ProcessData(const std::string& data) = 0;
    virtual int32_t SendRequest(const std::string& endpoint) = 0;
    virtual bool IsConnected() const = 0;
};

// ============================================================
// Step 2: Create Mock class
// ============================================================

class MockService : public MockServiceInterface {
public:
    MOCK_METHOD(int32_t, ProcessData, (const std::string& data), (override));
    MOCK_METHOD(int32_t, SendRequest, (const std::string& endpoint), (override));
    MOCK_METHOD(bool, IsConnected, (), (const, override));
};

// ============================================================
// Step 3: Create adapter
// ============================================================

class ServiceAdapter : public OriginalService {
public:
    explicit ServiceAdapter(MockServiceInterface* mock) : mock_(mock) {}

    int32_t ProcessData(const std::string& data) override {
        return mock_->ProcessData(data);
    }

    int32_t SendRequest(const std::string& endpoint) override {
        return mock_->SendRequest(endpoint);
    }

    bool IsConnected() const override {
        return mock_->IsConnected();
    }

private:
    MockServiceInterface* mock_;
};

// ============================================================
// Usage example in test cases
// ============================================================

/*
#include "mock/mock_service.h"

class ServiceTest : public ::testing::Test {
protected:
    MockService mockService;
    ServiceAdapter adapter{&mockService};
};

TEST_F(ServiceTest, test_process_when_success_then_return_ok) {
    EXPECT_CALL(mockService, ProcessData(_))
        .WillOnce(Return(0));

    int32_t ret = adapter.ProcessData("test");
    EXPECT_EQ(ret, 0);

    ::testing::Mock::VerifyAndClearExpectations(&mockService);
}
*/

#endif // MOCK_WRAPPER_EXAMPLE_H
