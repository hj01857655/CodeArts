#!/usr/bin/env python3
"""Extract function calls in C++ code using libclang"""

import clang.cindex as ci
import json
import os
import re
import sys
from typing import TypedDict, Optional


STDLIB_NAMES = frozenset({
    '__va_list_tag',
})


def _arg_requires_skip(arg: str) -> bool:
    # -c: compile option (compile only, no link), not needed by clang
    # -include: precompiled header, GCC PCH is incompatible with clang
    return arg in ('-c', '-o', '-Winvalid-pch') or arg == '-include'


def _arg_is_unneeded(arg: str) -> bool:
    # -Wl: linker option, passed to linker, not needed when clang parses
    # PCH file: GCC precompiled header, cannot be used by clang
    return arg.startswith('-Wl,') or arg == '-Wl' or arg.endswith('.hxx') or arg.endswith('.h.gch') or arg.endswith('.pch')


def _filter_compile_args(command: str) -> list[str]:
    args = re.findall(r'(?:[^\s,"]|"(?:[^"\\]|\\.)*")+', command)
    filtered = []
    skip_next = False
    for arg in args[1:]:
        if skip_next:
            skip_next = False
            continue
        if _arg_requires_skip(arg):
            skip_next = True
            continue
        if _arg_is_unneeded(arg):
            continue
        filtered.append(arg)
    return filtered


class CalleeInfo(TypedDict):
    name: str
    class_name: str | None
    is_internal: bool
    defined_in_file: str | None
    defined_at_line: int | None
    is_member: bool
    declared_in_header: bool


class CppCallExtractor:
    _libclang_initialized = False

    def __init__(self, libclang_path: 'Optional[str]' = None):
        self.libclang_path = libclang_path
        self._ensure_libclang_initialized()

    def _ensure_libclang_initialized(self):
        if CppCallExtractor._libclang_initialized:
            return
        if self.libclang_path is None:
            self.libclang_path = self._find_libclang()
        if not os.path.exists(self.libclang_path):
            raise FileNotFoundError(f"libclang.so not found at {self.libclang_path}")
        ci.Config.set_library_file(self.libclang_path)
        CppCallExtractor._libclang_initialized = True

    def _find_libclang(self) -> str:
        import subprocess
        is_windows = sys.platform == 'win32'
        libclang_name = 'libclang.dll' if is_windows else 'libclang.so'
        libdir_path = self._llvm_config_libdir_path(libclang_name)
        if libdir_path:
            return libdir_path
        found = self._search_libclang_paths(is_windows)
        if found:
            return found
        raise FileNotFoundError(f"Cannot find {libclang_name}, please specify --libclang-path")

    def _llvm_config_libdir_path(self, libclang_name) -> str:
        import subprocess
        try:
            result = subprocess.run(['llvm-config', '--libdir'], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                libdir = result.stdout.strip()
                so_path = os.path.join(libdir, libclang_name)
                if os.path.exists(so_path):
                    return so_path
        except (subprocess.SubprocessError, FileNotFoundError):
            pass
        return ""

    def _search_libclang_paths(self, is_windows) -> str:
        import glob as glob_module
        if is_windows:
            search_paths = [
                os.path.join(os.environ.get('ProgramFiles', r'C:\Program Files'), 'LLVM', 'bin', 'libclang.dll'),
                os.path.join(os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)'), 'LLVM', 'bin', 'libclang.dll'),
                os.path.join(os.environ.get('MSYS2_ROOT', r'C:\msys64'), 'mingw64', 'bin', 'libclang.dll'),
                os.path.join(os.environ.get('MSYS2_ROOT', r'C:\msys64'), 'ucrt64', 'bin', 'libclang.dll'),
            ]
            env_path = os.environ.get('LLVM_INSTALL_DIR', '')
            if env_path:
                search_paths.insert(0, os.path.join(env_path, 'bin', 'libclang.dll'))
            return next((p for p in search_paths if os.path.exists(p)), "")
        search_paths = [
            '/usr/lib/llvm*/lib/libclang.so',
            '/usr/lib64/llvm*/lib/libclang.so',
            '/opt/buildtools/llvm-*/lib/libclang.so',
        ]
        for pattern in search_paths:
            matches = glob_module.glob(pattern)
            if matches:
                return sorted(matches)[-1]
        return ""

    def _find_clang_resource_dir(self) -> Optional[str]:
        import subprocess
        is_windows = sys.platform == 'win32'
        prefix_dir = self._clang_resource_dir_from_prefix()
        if prefix_dir:
            return prefix_dir
        libclang_dir = self._clang_resource_dir_from_libclang()
        if libclang_dir:
            return libclang_dir
        return self._search_clang_resource_dirs(is_windows)

    def _clang_resource_dir_from_prefix(self) -> Optional[str]:
        import subprocess
        import glob as glob_module
        try:
            result = subprocess.run(['llvm-config', '--prefix'], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                prefix = result.stdout.strip()
                clang_include_pattern = os.path.join(prefix, 'lib', 'clang', '*', 'include')
                matches = glob_module.glob(clang_include_pattern)
                if matches:
                    return os.path.dirname(matches[0])
        except (subprocess.SubprocessError, FileNotFoundError):
            pass
        return None

    def _clang_resource_dir_from_libclang(self) -> Optional[str]:
        import glob as glob_module
        libclang_path = self.libclang_path or self._find_libclang()
        if not libclang_path:
            return None
        clang_include = os.path.join(os.path.dirname(os.path.dirname(libclang_path)), 'lib', 'clang', '*', 'include')
        matches = glob_module.glob(clang_include)
        if matches:
            return os.path.dirname(matches[0])
        return None

    def _search_clang_resource_dirs(self, is_windows) -> Optional[str]:
        if is_windows:
            search_paths = []
            llvm_dir = os.environ.get('LLVM_INSTALL_DIR', '')
            if llvm_dir:
                search_paths.append(os.path.join(llvm_dir, 'lib', 'clang', '*', 'include'))
            program_files = os.environ.get('ProgramFiles', r'C:\Program Files')
            search_paths.append(os.path.join(program_files, 'LLVM', 'lib', 'clang', '*', 'include'))
            return self._first_glob_dir(search_paths, last=True)
        return self._first_glob_dir([
            '/opt/buildtools/llvm-*/lib/clang/*/include',
            '/usr/lib/llvm*/lib/clang/*/include',
        ], last=True)

    def _first_glob_dir(self, patterns, last=False) -> Optional[str]:
        import glob as glob_module
        for pattern in patterns:
            matches = glob_module.glob(pattern)
            if matches:
                return os.path.dirname(matches[-1] if last else matches[0])
        return None

    def _is_stdlib_name(self, name: str) -> bool:
        if not name:
            return True
        if name.startswith('operator'):
            return True
        for prefix in STDLIB_NAMES:
            if name.startswith(prefix):
                return True
        return False

    def _is_system_location(self, cursor) -> bool:
        abs_path = self._cursor_abs_path(cursor)
        if abs_path is None:
            return False
        if sys.platform == 'win32':
            return self._is_windows_system_path(abs_path)
        return abs_path.startswith('/usr/') or abs_path.startswith('/opt/')

    def _cursor_abs_path(self, cursor) -> str:
        try:
            loc = cursor.location
            if loc and loc.file:
                filename = loc.file.name
                if filename:
                    return os.path.realpath(filename)
        except Exception:
            pass
        return None

    def _is_windows_system_path(self, abs_path) -> bool:
        abs_path_lower = abs_path.lower()
        system_dirs = [
            os.environ.get('ProgramFiles', r'C:\Program Files').lower(),
            os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)').lower(),
            os.environ.get('SystemRoot', r'C:\Windows').lower(),
        ]
        return any(abs_path_lower.startswith(d) for d in system_dirs)

    def _is_valid_function_call(self, cursor) -> bool:
        try:
            kind = cursor.kind
        except Exception:
            return False
        valid_kinds = [
            ci.CursorKind.CALL_EXPR,
            ci.CursorKind.CXX_METHOD,
            ci.CursorKind.OVERLOADED_DECL_REF,
            ci.CursorKind.TEMPLATE_REF,
        ]
        cxx_member_call = getattr(ci.CursorKind, 'CXX_MEMBER_CALL_EXPR', None)
        if cxx_member_call is not None:
            valid_kinds.append(cxx_member_call)
        if kind not in valid_kinds:
            return False
        callee = cursor.referenced
        if not callee or not callee.spelling:
            return False
        if callee.kind == ci.CursorKind.CONSTRUCTOR:
            return False
        return True

    def _is_member_function(self, cursor) -> bool:
        callee = cursor.referenced
        if not callee:
            return False
        valid_member_kinds = [ci.CursorKind.CXX_METHOD, ci.CursorKind.OVERLOADED_DECL_REF]
        return callee.kind in valid_member_kinds

    def _get_compile_args(self, file_path: str, compile_commands_path: str) -> list[str]:
        if not compile_commands_path:
            return []
        with open(compile_commands_path, 'r') as f:
            compile_commands = json.load(f)
        for entry in compile_commands:
            if os.path.normpath(entry['file']) == os.path.normpath(file_path):
                return _filter_compile_args(entry['command'])
        return []

    def _get_parent_class_name(self, cursor) -> str:
        parent = cursor.semantic_parent
        while parent:
            if parent.kind in (ci.CursorKind.CLASS_DECL, ci.CursorKind.STRUCT_DECL):
                return parent.spelling
            parent = parent.semantic_parent
        return ""

    def _is_in_function_ranges(self, cursor_loc, func_ranges) -> bool:
        if not func_ranges:
            return False
        if not cursor_loc or not cursor_loc.file:
            return False
        cursor_file = os.path.realpath(cursor_loc.file.name)
        return any(self._in_single_range(cursor_loc, func_start, func_end, cursor_file)
                   for func_start, func_end, _, _ in func_ranges)

    def _in_single_range(self, cursor_loc, func_start, func_end, cursor_file) -> bool:
        if os.path.realpath(func_start.file.name) != cursor_file:
            return False
        if cursor_loc.line < func_start.line:
            return False
        if cursor_loc.line == func_start.line and cursor_loc.column < func_start.column:
            return False
        if cursor_loc.line > func_end.line:
            return False
        if cursor_loc.line == func_end.line and cursor_loc.column > func_end.column:
            return False
        return True

    def _parse_source(self, source_code: str, filename: str, compile_commands_path: str) -> ci.TranslationUnit:
        index = ci.Index.create()
        args = ['-std=c++17', '-fsyntax-only']
        if compile_commands_path:
            compile_args = self._get_compile_args(filename, compile_commands_path)
            if compile_args:
                args = compile_args
        return index.parse(filename, args=args, unsaved_files=[(filename, source_code)])

    def _should_skip_callee(self, node, func_ranges, callee, name, callee_info) -> bool:
        """Determine whether this function call should be skipped"""
        # Call location not within target function range
        if not self._is_in_function_ranges(node.location, func_ranges):
            return True
        # System location or standard library function
        if self._is_system_location(callee) or self._is_stdlib_name(name):
            return True
        # Already processed, avoid duplication
        if name in callee_info:
            return True
        return False

    def _get_callee_definition_location(self, callee, local_defs, callee_class=None) -> tuple:
        """Get the definition location of the called function (file + line number)"""
        declared_in_file = None
        declared_at_line = None
        if callee.location and callee.location.file:
            declared_in_file = callee.location.file.name
            declared_at_line = callee.location.line
        def_key = f"{callee_class}::{callee.spelling}" if callee_class else callee.spelling
        if def_key in local_defs:
            return local_defs[def_key]
        return declared_in_file, declared_at_line

    def _process_call_expr(self, node, func_ranges: list[tuple], filename: str,
                           func_class: str, callee_info: dict[str, CalleeInfo],
                           local_defs: dict[str, tuple]):
        callee = node.referenced
        name = callee.spelling
        if self._should_skip_callee(node, func_ranges, callee, name, callee_info):
            return
        is_member = self._is_member_function(node)
        callee_class = self._get_parent_class_name(callee) if is_member else None
        defined_in_file, defined_at_line = self._get_callee_definition_location(callee, local_defs, callee_class)
        def_key = f"{callee_class}::{name}" if callee_class else name
        is_defined_locally = def_key in local_defs
        is_same_class = is_member and bool(func_class) and callee_class == func_class
        declared_in_header = defined_in_file.endswith('.h') if defined_in_file else False
        callee_info[name] = CalleeInfo(
            name=name,
            class_name=callee_class,
            is_internal=is_defined_locally or is_same_class,
            defined_in_file=defined_in_file,
            defined_at_line=defined_at_line,
            is_member=is_member,
            declared_in_header=declared_in_header
        )

    def _parse_and_collect(self, source_code: str, filename: str,
                           compile_commands_path: str, target_line: int) -> tuple[dict[str, CalleeInfo], str]:
        index = ci.Index.create()
        args = self._build_parse_args(filename, compile_commands_path)
        tu = index.parse(filename, args=args, unsaved_files=[(filename, source_code)])

        local_defs, func_ranges, func_class, all_call_exprs = self._collect_defs_and_ranges(tu, filename, target_line)

        callee_info: dict[str, CalleeInfo] = {}
        for node in all_call_exprs:
            self._process_call_expr(node, func_ranges, filename, func_class, callee_info, local_defs)

        return callee_info, func_class

    def _build_parse_args(self, filename: str, compile_commands_path: str) -> list[str]:
        args = ['-std=c++17', '-fsyntax-only', '-ferror-limit=0']
        if compile_commands_path:
            compile_args = self._get_compile_args(filename, compile_commands_path)
            if compile_args:
                args = compile_args + ['-ferror-limit=0']
        if not any('resource-dir' in a for a in args):
            resource_dir = self._find_clang_resource_dir()
            if resource_dir:
                args = ['-resource-dir', resource_dir] + args
        return args

    def _collect_defs_and_ranges(self, tu, filename: str, target_line: int) -> tuple:
        local_defs: dict[str, tuple] = {}
        func_ranges: list[tuple] = []
        func_class = ""
        all_call_exprs: list = []

        for node in tu.cursor.walk_preorder():
            if self._is_function_decl(node):
                self._record_local_def(node, filename, local_defs)
                if self._is_target_function(node, filename, target_line):
                    target_range = self._target_range(node)
                    if target_range is not None:
                        func_class, func_ranges = target_range
            elif self._is_valid_function_call(node) and func_ranges:
                all_call_exprs.append(node)

        return local_defs, func_ranges, func_class, all_call_exprs

    def _is_function_decl(self, node) -> bool:
        return node.kind in (ci.CursorKind.CXX_METHOD, ci.CursorKind.FUNCTION_DECL, ci.CursorKind.CONSTRUCTOR, ci.CursorKind.FUNCTION_TEMPLATE)

    def _record_local_def(self, node, filename: str, local_defs: dict) -> None:
        loc = node.location
        if not (loc and loc.file and os.path.normpath(loc.file.name) == os.path.normpath(filename)):
            return
        def_key = self._local_def_key(node, loc)
        if def_key is not None:
            local_defs[def_key] = (loc.file.name, loc.line)

    def _is_target_function(self, node, filename: str, target_line: int) -> bool:
        loc = node.location
        if not (loc and loc.file):
            return False
        return os.path.normpath(loc.file.name) == os.path.normpath(filename) and loc.line == target_line

    def _target_range(self, node) -> tuple:
        func_range = node.extent
        if not func_range:
            return None
        return self._get_parent_class_name(node), [(func_range.start, func_range.end, None, None)]

    def _local_def_key(self, node, loc) -> str:
        func_name = node.spelling
        if not func_name:
            return None
        node_class = self._get_parent_class_name(node)
        return f"{node_class}::{func_name}" if node_class else func_name

    def callees(self, source_code: str, filename: str,
                compile_commands_path: str = "",
                target_line: int = 0) -> tuple[list[CalleeInfo], str]:
        if target_line <= 0:
            raise ValueError("target_line must be specified")
        abs_filename = os.path.abspath(filename)
        callee_info, func_class = self._parse_and_collect(source_code, abs_filename, compile_commands_path, target_line)
        return list(callee_info.values()), func_class


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Extract function calls in C++ code')
    parser.add_argument('source_file', help='Source file path')
    parser.add_argument('--compile-commands', '-c', default='', help='Path to compile_commands.json')
    parser.add_argument('--libclang-path', '-L', default=None, help='Path to libclang.so')
    parser.add_argument('--line', '-l', type=int, required=True,         help='Line number of the function')
    args = parser.parse_args()

    if not args.compile_commands or not os.path.isfile(args.compile_commands):
        print(f"Error: compile_commands.json file not found: {args.compile_commands}")
        print("Please check if the path is correct")
        exit(1)

    with open(args.source_file, 'r', encoding='utf-8', errors='ignore') as f:
        source_code = f.read()

    extractor = CppCallExtractor(libclang_path=args.libclang_path)
    result, func_class = extractor.callees(
        source_code,
        args.source_file,
        compile_commands_path=args.compile_commands,
        target_line=args.line
    )
    callee_list: list[CalleeInfo] = result

    if not callee_list:
        print("No function calls found")
    for item in callee_list:
        location = f"{item['defined_in_file']}:{item['defined_at_line']}"
        tag = "(internal dependency)" if item['is_internal'] else "(external dependency)"
        extra = ""
        if item['is_internal'] and item['declared_in_header']:
            extra = " [need to find implementation location]"
        class_prefix = f"{item['class_name']}::" if item['class_name'] else ""
        print(f"{class_prefix}{item['name']} {location} {tag}{extra}")
