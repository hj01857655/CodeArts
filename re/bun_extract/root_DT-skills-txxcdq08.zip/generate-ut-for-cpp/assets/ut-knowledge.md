# UT Knowledge Base

This document provides detailed usage instructions and notes for all 4 Mock frameworks (AMOCKER, MOCKER, gtest/gmock, binmock).

## General Stubbing Knowledge

Macro definitions cannot be stubbed. If a macro definition renames a function, the wrapped function needs to be stubbed.

---

## AMOCKER

### 1. Return Value Handling

#### 1.1. Non-void Return Value and No Output Parameters

Return values must be explicitly cast to the function's return type (basic types also need casting):

```c
// If dynamic memory, allocate externally and save as static pointer type, then return in AMOCKER
AMOCKER($Function_Name).stubs().will(returnValue(($returnValueType)$returnValue));
```

**Example**:
```c
// Return integer
AMOCKER(get_count).stubs().will(returnValue((int)10));

// Return pointer
static StructXXX* static_ptr = nullptr;
AMOCKER(get_struct).stubs().will(returnValue((StructXXX*)static_ptr));
```

#### 1.2. void Return Value and No Output Parameters

```c
AMOCKER($Function_Name).stubs().will(ignoreReturnValue());
```

**Example**:
```c
AMOCKER(log_message).stubs().will(ignoreReturnValue());
```

#### 1.3. With Output Parameters

Return must be explicitly cast to the function's return type (basic types and null pointers also need explicit casting):

```c
// Initialize variable $init_var
// Convert variable $init_var to static variable $static_var, note this variable name should not be the same as parameter names
static $OutputParamType $static_var = $init_var;
AMOCKER($Function_Name).stubs().will(invoke(+[]($input_parameters, $output_param1, $output_param2) {
    $output_param1 = $static_var;
    $output_param2 = $static_var;
    $returnValueType $returnValue = $static_var;
    return ($returnValueType)$returnValue;
}));
```

**Example**:
```c
static int static_result = 100;
AMOCKER(process_data).stubs().will(invoke(+[](int input, int* output) {
    *output = static_result;
    return (int)0;
}));
```

### 2. Multiple Calls with Different Return Values

```c
AMOCKER($Function_Name).stubs()
    .will(returnValue(...) | invoke(...))      // First call stubbing uses will
    .then(returnValue(...) | invoke(...))      // Second call stubbing uses then
    .then(returnValue(...) | invoke(...));     // Third call stubbing uses then, subsequent ones all use then
```

**Example**:
```c
AMOCKER(get_status).stubs()
    .will(returnValue((int)0))     // First returns 0 (success)
    .then(returnValue((int)-1))    // Second returns -1 (failure)
    .then(returnValue((int)1));    // Third returns 1 (special status)
```

### 3. Verifying Call Count

Use expects(never()) or expects(exactly(n)) to replace stubs(), n indicates the expected call count:

```c
// Expect $Function_A to be called 0 times
AMOCKER($Function_A).expects(never()).will(...);

// Expect $Function_B to be called 3 times
AMOCKER($Function_B).expects(exactly(3)).will(...);
```

Add `LLT_GLOBALOBJMOCKER::verify();` at the end of the test case for verification.

**Example**:
```c
TEST_F(test_module, test_func)
{
    AMOCKER(external_func).expects(never()).will(returnValue((int)0));
    
    int ret = module_func();
    
    ASSERT_EQ(ret, 0);
    
    LLT_GLOBALOBJMOCKER::verify();  // Verify call count
}
```

### 4. Parameter Matching

```c
AMOCKER($Function_Name).stubs().with(eq($value));           // Parameter equals specified value
AMOCKER($Function_Name).stubs().with(any());                // Parameter is any value
AMOCKER($Function_Name).stubs().with(outBoundP($ptr, $size)); // Output parameter
```

**Example**:
```c
// Parameter matching
AMOCKER(process).stubs().with(eq(5)).will(returnValue((int)10));

// Output parameter
static StructXXX st;
AMOCKER(get_data).stubs().with(outBoundP(&st, sizeof(StructXXX)));
```

### 5. Call Order Verification

```c
AMOCKER($Function_A).id("A");                   // Set ID
AMOCKER($Function_B).id("B").before("A");       // B must be called before A
AMOCKER($Function_C).id("C").after("A");        // C must be called after A
```

### AMOCKER Notes

1. `($returnValueType)$returnValue` means casting $returnValue to $returnValueType type
2. When encountering scenarios requiring stubbing to return error codes, if they exist in the context, use the ones in the context; otherwise use negation `!` or similar operations to fabricate an incorrect integer return
3. If you don't know the correct return from the context, assume the correct return is 0

---

## MOCKER (from mockcpp.h)

### 1. Return Value Handling

#### 1.1. Non-void Return Value and No Output Parameters

Return values must be explicitly cast to the function's return type:

```c
// If dynamic memory, allocate externally and save as static pointer type, then return in MOCKER
MOCKER($Function_Name).stubs().will(returnValue(($returnValueType)$returnValue));
```

**Example**:
```c
// Return integer
MOCKER(get_count).stubs().will(returnValue((int)10));

// Return pointer
static StructXXX* static_ptr = nullptr;
MOCKER(get_struct).stubs().will(returnValue((StructXXX*)static_ptr));
```

#### 1.2. void Return Value and No Output Parameters

```c
MOCKER($Function_Name).stubs().will(ignoreReturnValue());
```

**Example**:
```c
MOCKER(log_message).stubs().will(ignoreReturnValue());
```

#### 1.3. With Output Parameters

```c
// Initialize variable $init_var
// Convert variable $init_var to static variable $static_var
static $OutputParamType $static_var = $init_var;
MOCKER($Function_Name).stubs().will(invoke(+[]($input_parameters, $output_param1, $output_param2) {
    $output_param1 = $static_var;
    $output_param2 = $static_var;
    $returnValueType $returnValue = $static_var;
    return ($returnValueType)$returnValue;
}));
```

**Example**:
```c
static int static_result = 100;
MOCKER(process_data).stubs().will(invoke(+[](int input, int* output) {
    *output = static_result;
    return (int)0;
}));
```

### 2. Multiple Calls with Different Return Values

```c
MOCKER($Function_Name).stubs()
    .will(returnValue(...) | invoke(...))      // First call stubbing uses will
    .then(returnValue(...) | invoke(...))      // Second call stubbing uses then
    .then(returnValue(...) | invoke(...));     // Third call stubbing uses then, subsequent ones all use then
```

**Example**:
```c
MOCKER(get_status).stubs()
    .will(returnValue((int)0))
    .then(returnValue((int)-1))
    .then(returnValue((int)1));
```

### 3. Verifying Call Count

```c
// Expect $Function_A to be called 0 times
MOCKER($Function_A).expects(never()).will(...);

// Expect $Function_B to be called 3 times
MOCKER($Function_B).expects(exactly(3)).will(...);
```

Add `LLT_GLOBALOBJMOCKER::verify();` at the end of the test case for verification.

### 4. Parameter Matching

```c
MOCKER($Function_Name).stubs().with(eq($value));  // Parameter equals specified value
MOCKER($Function_Name).stubs().with(any());       // Parameter is any value
```

### MOCKER Notes

1. `($returnValueType)$returnValue` means casting $returnValue to $returnValueType type
2. When encountering scenarios requiring stubbing to return error codes, if they exist in the context, use the ones in the context; otherwise use negation `!` or similar operations to fabricate an incorrect integer return
3. If you don't know the correct return from the context, assume the correct return is 0

---

## gtest/gmock (Standard C++ Testing Framework)

### 1. Mock Virtual Functions

```cpp
// Define Mock class
class MockService : public IService {
public:
    MOCK_METHOD(int, ProcessData, (const std::string& data), (override));
    MOCK_METHOD(void*, Allocate, (size_t size), (override));
    MOCK_METHOD(bool, IsValid, (), (const, override));  // const method
};
```

### 2. Basic Call Setup

```cpp
// Set call return value
EXPECT_CALL(mockService, ProcessData(_))
    .WillOnce(Return(0));

// Set multiple calls with different return values
EXPECT_CALL(mockService, ProcessData(_))
    .WillOnce(Return(0))
    .WillOnce(Return(1))
    .WillOnce(Return(-1));

// Set call to return dynamic values
EXPECT_CALL(mockService, ProcessData(_))
    .WillOnce(Return(0))
    .WillRepeatedly(Return(-1));  // All subsequent calls return -1
```

### 3. Call Count Verification

```cpp
// Expect 1 call
EXPECT_CALL(mockService, ProcessData(_))
    .Times(1)
    .WillOnce(Return(0));

// Expect N calls
EXPECT_CALL(mockService, ProcessData(_))
    .Times(N);

// Expect 0 calls (not called)
EXPECT_CALL(mockService, ProcessData(_))
    .Times(0);

// Expect at least N calls
EXPECT_CALL(mockService, ProcessData(_))
    .Times(AtLeast(N));

// Expect at most N calls
EXPECT_CALL(mockService, ProcessData(_))
    .Times(AtMost(N));
```

### 4. Parameter Matchers

```cpp
// Any parameter
EXPECT_CALL(mockService, ProcessData(_));

// Parameter equals specified value
EXPECT_CALL(mockService, ProcessData(StrEq("test")));

// Other common matchers
EXPECT_CALL(mockService, ProcessData(StrNe("other")));       // Not equal
EXPECT_CALL(mockService, ProcessData(StrCaseEq("Test")));     // Case-insensitive equal
EXPECT_CALL(mockService, ProcessData(ContainsRegex("test"))); // Contains regex match
EXPECT_CALL(mockService, ProcessData(StartsWith("te")));      // Starts with
EXPECT_CALL(mockService, ProcessData(EndsWith("st")));        // Ends with

// Numeric matchers
EXPECT_CALL(mockService, ProcessNumber(Eq(5)));      // Equal to 5
EXPECT_CALL(mockService, ProcessNumber(Ne(5)));      // Not equal to 5
EXPECT_CALL(mockService, ProcessNumber(Gt(5)));      // Greater than 5
EXPECT_CALL(mockService, ProcessNumber(Ge(5)));      // Greater than or equal to 5
EXPECT_CALL(mockService, ProcessNumber(Lt(5)));      // Less than 5
EXPECT_CALL(mockService, ProcessNumber(Le(5)));      // Less than or equal to 5

// Pointer matchers
EXPECT_CALL(mockService, ProcessPointer(IsNull()));          // NULL pointer
EXPECT_CALL(mockService, ProcessPointer(NotNull()));         // Non-NULL pointer
EXPECT_CALL(mockService, ProcessPointer(Pointee(Eq(5)));    // Pointed value equals 5
```

### 5. Output Parameter Setup

```cpp
// Set output parameters
EXPECT_CALL(mockService, GetData(_, _))
    .WillOnce(DoAll(SetArgPointee<0>(10),    // Set first output parameter
                    SetArgPointee<1>(20),    // Set second output parameter
                    Return(0)));

// Use Invoke to set output parameters
EXPECT_CALL(mockService, GetData(_, _))
    .WillOnce(Invoke([](int input, int* output) {
        *output = input * 2;
        return 0;
    }));
```

### 6. Call Order Verification

```cpp
// Use InSequence to verify call order
{
    InSequence seq;
    
    EXPECT_CALL(mockService, Init());
    EXPECT_CALL(mockService, ProcessData(_));
    EXPECT_CALL(mockService, Cleanup());
}
```

### 7. Complex Behavior Setup

```cpp
// Use Invoke to execute complex logic
EXPECT_CALL(mockService, ProcessData(_))
    .WillOnce(Invoke([](const std::string& data) {
        if (data.empty()) {
            return -1;
        }
        return 0;
    }));

// Use DoAll to combine multiple actions
EXPECT_CALL(mockService, ProcessData(_))
    .WillOnce(DoAll(SaveArg<0>(&saved_data),  // Save parameter
                    Return(0)));
```

### 8. Mock Cleanup

```cpp
// Clean up Mock within test case
Mock::VerifyAndClearExpectations(&mockService);

// Prohibited from using global cleanup in TearDown()
```

### gtest/gmock Notes

1. Can only Mock virtual functions; non-virtual functions require creating a wrapper layer
2. Use WillOnce to precisely control each call
3. Clean up Mock within test cases; global cleanup is prohibited
4. Parameter matchers need to match function parameter types

---

## binmock (C Scenario Interface Extension)

### 1. Mock C Functions

```cpp
// Mock C function
BINEXPECT_CALL((&malloc), (_)).WillOnce(Return(nullptr));

// Mock function with parameters
BINEXPECT_CALL((&memcpy), (eq(dest), eq(src), eq(size)))
    .WillOnce(Return(dest));
```

### 2. Multiple Calls with Different Return Values

```cpp
// Serialized calls
BINEXPECT_CALL((&malloc), (_))
    .WillOnce(Return(ptr1))
    .WillOnce(Return(ptr2))
    .WillOnce(Return(nullptr));

// All subsequent calls return the same value
BINEXPECT_CALL((&malloc), (_))
    .WillOnce(Return(ptr1))
    .WillRepeatedly(Return(nullptr));
```

### 3. Parameter Matching

```cpp
// Parameter equals specified value
BINEXPECT_CALL((&func), (eq(5))).WillOnce(Return(10));

// Parameter is any value
BINEXPECT_CALL((&func), (_)).WillOnce(Return(10));

// Multi-parameter matching
BINEXPECT_CALL((&func), (eq(5), eq(10))).WillOnce(Return(20));
```

### 4. Verifying Call Count

```cpp
// Use Times to verify call count
BINEXPECT_CALL((&malloc), (_))
    .Times(3)
    .WillOnce(Return(ptr1))
    .WillOnce(Return(ptr2))
    .WillOnce(Return(nullptr));
```

### 5. Call Order Verification

```cpp
// Use InSequence to verify call order
{
    InSequence seq;
    
    BINEXPECT_CALL((&init), (_));
    BINEXPECT_CALL((&process), (_));
    BINEXPECT_CALL((&cleanup), ());
}
```

### binmock Notes

1. Function names need to use the & symbol (e.g., (&malloc))
2. No need to write stub functions, directly Mock C functions
3. Parameter matchers are enclosed in parentheses
4. Suitable for C scenario interface extensions

---

## Mock Framework Selection Decision Tree

```
Start
├─ Is it a virtual function?
│  ├─ Yes → Use gtest/gmock
│  └─ No → Is it a C function?
│     ├─ Yes → Is it in an embedded environment?
│     │  ├─ Yes → Use AMock
│     │  └─ No → No need to write stub functions?
│     │     ├─ Yes → Use binmock
│     │     └─ No → Use mockcpp
│     └─ No (non-virtual C++ function) → Create virtual function wrapper layer + gtest/gmock
```

---

## Mock Framework Comparison Table

| Feature | gtest/gmock | binmock | AMock | mockcpp |
|---------|------------|---------|-------|---------|
| Applicable language | C++ | C | C | C/C++ |
| Virtual function support | Yes | - | - | - |
| C function support | - | Yes | Yes | Yes |
| Static method support | - | - | - | Yes |
| Embedded-friendly | - | - | Yes | - |
| No stub function needed | - | Yes | - | - |
| Parameter matchers | Rich | Basic | Basic | Basic |
| Call order verification | Yes | Yes | Yes | - |

---

## Stubbing Notes

1. **Type casting**: `($returnValueType)$returnValue` means casting $returnValue to $returnValueType type
   - For example: casting nullptr to struct StructXXX pointer: `(StructXXX *)nullptr`
   - For example: casting 8 to uint type: `(uint)8`

2. **Error code scenarios**: When encountering scenarios requiring stubbing to return error codes
   - If they exist in the context, use the error codes in the context
   - Otherwise use negation `!` or similar operations to fabricate an incorrect integer return
   - If you don't know the correct return from the context, assume the correct return is 0

3. **Macro definition stubbing**: Macro definitions cannot be stubbed; if a macro definition renames a function, the wrapped function needs to be stubbed

4. **Static function stubbing**: Prohibited from stubbing static functions; treat their logic as part of the function under test

5. **Mock cleanup**: Clean up Mock within test cases; prohibited from using global cleanup methods in TearDown()
