---
name: generate-ut-for-python
description: "Generate pytest unit tests for complex Python functions achieving >=90% line coverage. Trigger: prompt asks to generate unit tests for a specific file path and function name. Covers branch analysis, method call inventory with argument verification, guard clause dual-path testing, compound condition sub-cases, multi-exception handling, sequential workflow ordering, decorator-with-optional-args, closure/callback capture, weakref.proxy patterns, contextmanager-factory testing, and coverage gap recovery. Auto-detects or creates a Python virtual environment with pytest/coverage dependencies. Handles any Python project (web frameworks, microservices, standalone scripts, etc.). Not for integration tests or test refactoring."
language: python
---

# Python Unit Test Generation for Complex Functions

## Overview

Generate unit tests for Python functions with complex logic (20-100 lines). Achieve >=90% line coverage measured by pytest-cov. The workflow enforces systematic branch analysis, method call inventory with argument verification, guard clause dual-path testing, non-trivial assertions, and a hard coverage gate with explicit recovery paths for common failure modes.

**Context**: Prompt format is typically a file path and function name. Work in the task directory, not the main project. Python environment is detected and prepared in the Environment Setup phase below.

## Environment Setup (runs once before Step 1)

Detect or create a working Python interpreter with test dependencies. Record the resolved path as `PYTHON` and use it in ALL subsequent commands throughout the workflow. If no usable environment can be established, set `ENV_MODE=offline` — the workflow proceeds in **offline mode** (tests generated but not executed, coverage estimated statically).

### Detect existing interpreter

Check in priority order — use the **first** that succeeds:

| Priority | Source | Detection command |
|----------|--------|-------------------|
| 1 | Task-dir venv (Windows) | `test -f .venv/Scripts/python.exe && .venv/Scripts/python.exe --version` |
| 2 | Task-dir venv (Linux/macOS) | `test -f .venv/bin/python && .venv/bin/python --version` |
| 3 | Parent-project venv (Windows) | `test -f ../.venv/Scripts/python.exe && ../.venv/Scripts/python.exe --version` |
| 4 | Parent-project venv (Linux/macOS) | `test -f ../.venv/bin/python && ../.venv/bin/python --version` |
| 5 | System `python3` | `python3 --version` |
| 6 | System `python` | `python --version` |
| 7 | Windows launcher | `py -3 --version` |

- If a **venv is found** (priority 1–4): set `PYTHON` to the venv interpreter path, proceed to dependency check.
- If a **system interpreter is found** (priority 5–7) but no venv: attempt to create one in the task directory:
  ```bash
  <system_python> -m venv .venv
  ```
  - If venv creation **succeeds**: set `PYTHON` to the new venv interpreter:
    - Windows: `PYTHON=".venv/Scripts/python.exe"`
    - Linux/macOS: `PYTHON=".venv/bin/python"`
  - If venv creation **fails** (missing `venv` module, permission denied, etc.): fall back to using the system interpreter directly:
    - Set `PYTHON` to the system interpreter path resolved in priority 5–7.
    - Install dependencies with `--user` flag to avoid system-wide pollution: `$PYTHON -m pip install --user pytest pytest-cov coverage pytest-timeout`
    - If `pip` module is also missing: run `$PYTHON -m ensurepip --user`, then retry.
    - If `ensurepip` also fails: Set `ENV_MODE=offline`. Warn user: "No pip available — tests will be generated but not executed, coverage will be statically estimated." Proceed to Step 1.
    - **Caveat**: Using the system interpreter directly may cause `ModuleNotFoundError` for project-specific dependencies that are only installed in a project venv. If this occurs during Step 4, attempt `$PYTHON -m pip install <missing_package>` and retry.
- If **no interpreter at all** is found (all checks fail): Set `ENV_MODE=offline`. Warn user: "No Python interpreter detected — tests will be generated but not executed, coverage will be statically estimated. Install Python 3.8+ and retry to enable execution and precise coverage." Proceed to Step 1.

### Install dependencies

```bash
$PYTHON -m pip install --quiet pytest pytest-cov coverage pytest-timeout
```

- If `pip` module is missing: run `$PYTHON -m ensurepip --upgrade`, then retry the install.
- If install fails due to network or permission: retry once. If still failing, set `ENV_MODE=offline`. Warn user: "Dependency installation failed — tests will be generated but not executed, coverage will be statically estimated." Proceed to Step 1.

### Verify

```bash
$PYTHON -c "import pytest, coverage, pytest_timeout; print('env ready')"
```

- If verification fails: retry install once. If still failing, set `ENV_MODE=offline`. Proceed to Step 1.

### Platform notes

- On Windows, use forward slashes (`/`) in all bash commands — backslashes are escape characters.
- `$PYTHON` is a placeholder: substitute the actual resolved path in every command throughout Steps 1–6.
- If the target project has its own `requirements.txt` or `pyproject.toml` with test dependencies, install them too: `$PYTHON -m pip install -e <project_dir>[test]` or `$PYTHON -m pip install -r <project_dir>/requirements.txt`.

### Offline mode (`ENV_MODE=offline`)

When set, the workflow continues through Steps 1–6 but with alternate paths:
- **Step 3**: Test generation proceeds normally — all mock/branch analysis from Step 2 still applies. Skip the syntax check command (no interpreter); instead, **statically validate** by reading back the file and checking for balanced `def`/`class` blocks, matching quotes, and valid indentation.
- **Step 4**: Skip pytest execution. Mark all tests as "unverified — generated in offline mode".
- **Step 5**: Replace runtime coverage with **static coverage estimation** (see Step 5 offline path).
- **Step 6**: Report estimated coverage and unverified test status to the user.

## Workflow

### Step 1: Parse and Locate

1. Extract file path and function name from prompt
2. Locate function with grep, read with offset/limit for large files
3. Detect project type and dependencies from imports — identify external I/O, framework objects, and injected dependencies that require mocking (see `references/project-type-strategies.md`)
4. Record function start/end lines for coverage validation
5. Place test file in `<task_root>/tests/`; use `_unit.py` suffix if file exists
6. **Do NOT read the project's own `test/` directory files** — they use integration-style testing and waste tokens. Only read task `tests/` files if they contain fixtures to import
7. **Quick-scan for applicable patterns**: After reading the target function, identify which conditional patterns (Step 2 conditional section) are present. Only read matching reference files

### Step 2: Analyze Branches and Plan Tests

**Branch identification** (for ALL functions):
1. List every branch: if/elif/else, loops, try/except, raise, early returns, decorator behavior
2. Plan one test per raise — assert error type AND complete message content
3. For compound conditions (`if a and b`): plan separate tests per sub-condition
4. For compound conditions (`if a or b`): plan tests for (a-only true), (b-only true), (both true), (neither true). **Clarification**: (both true) means a single input satisfying BOTH conditions simultaneously, NOT that both conditions coexist independently
5. Read dependent helper functions to understand their trigger conditions
6. **Verify line numbers**: After branch analysis, confirm start/end lines match the actual function by checking the source
7. **Verify exception handling behavior**: Before writing `pytest.raises`, check whether each `except` block re-raises or suppresses. If suppressed, verify the function returns normally and side effects occur instead

**Method call inventory** (for ALL functions):
1. List every method call in the function body — include logging calls when they differentiate branches, and standard-library/framework utility calls (e.g., `inspect.getmembers`, `copy.deepcopy`, `os.path.exists`)
2. Plan argument verification for each call using `assert_called_once_with()` or equivalent
3. Do not assume verifying a downstream call covers an upstream call — each needs independent verification
4. For 3+ sequential calls with ordering dependencies not implied by data flow: plan a dedicated ordering test (see `references/sequential-workflow-testing.md` Section 1). For 2-step sequences, plan a merged test with `mock_calls` verification to confirm call order
5. Include `super()` calls in the inventory — use `patch.object(ActualClass, 'method')` where ActualClass is the MRO-resolved class that actually defines the method (verify with `[c for c in TargetClass.__mro__ if method in c.__dict__]`)
6. For standard-library/framework utility calls: plan a dedicated test that patches the call and verifies its arguments
7. **Injected dependency calls are ALWAYS verified**: Method calls on injected dependencies (pool, gt, queue, exchange, etc.) MUST have `assert_called_once_with()` or `assert_called_with()` verification — even if they don't differentiate branches. Exception: when verifying a call requires mocking framework internals that are difficult to mock correctly (e.g., greenlet.throw), prefer integration-style testing with real objects and verify behavior rather than call arguments
8. **Self-call vs other-call mock strategy**: For `self.method()` calls within the target function, use instance-level mock assignment (`obj.method = MagicMock()`) — NOT `patch.object(ClassName, 'method')` which intercepts the initial call too. For calls to OTHER classes or parent classes (super()), use `patch.object(OtherClass, 'method')`.
9. **Callback argument verification**: For callback registration calls (e.g., `gt.link(callback)`), capture the callback from `mock.call_args[0][0]`, invoke it with appropriate arguments, and verify ALL downstream side effects via `assert_called_with`. Verifying only the callback name is insufficient
10. **Negative assertions on dependency methods**: After listing all calls that ARE made, identify dependency methods that should NOT be called in certain branches (e.g., `Event.send` in early-return paths). Plan `assert_not_called()` for each. Enumerate ALL public methods on each mocked dependency and determine which should NOT be called

**Conditional patterns** — only if the function exhibits these (see `references/conditional-patterns-index.md` for full guidance):

| Pattern | Reference |
|---------|-----------|
| State mutations (`del`, `dict.pop`, `self.attr = val`) | `conditional-patterns-index.md` → State Mutations |
| Sequential guard clauses / 3+ ordered calls / state flags | `sequential-workflow-testing.md` Sections 1–6 |
| Multiple exception types with different handling | `sequential-workflow-testing.md` Section 3 |
| Recursive data traversal / deeply nested logic | `sequential-workflow-testing.md` Sections 4–5 |
| Attribute-access edge cases / resource-lifecycle / while-loops / generators | `attribute-and-lifecycle-patterns.md` Sections 1–4 |
| Decorator-with-optional-args / closure-callback / contextmanager-factory | `decorator-and-closure-patterns.md` Sections 1–3 |
| isinstance chain / type-dispatch | `conditional-patterns-index.md` → Type Dispatch |
| Guard clause dual-path testing (ALL functions with guard clauses) | `conditional-patterns-index.md` → Guard Clause Dual-Path |
| Execution order testing (sequential call dependencies) | `conditional-patterns-index.md` → Execution Order |

**Efficiency rules** (see `conditional-patterns-index.md` → Efficiency Rules for full list):
- Merge method call verification into branch tests when the merged test still performs explicit `assert_called_once_with()`
- Prefer flat test functions for <15 tests; class-based for >=15 tests or shared setup
- Do not read reference files for patterns not present in the target function
- **Do not use todowrite or task tracking tools** — they add overhead without improving output quality

> **Checkpoint**: Every branch has a planned test. Every method call (including stdlib calls) has planned argument verification. Injected dependency calls have explicit assert_called_with plans. Guard clauses have both positive and negative tests. Negative assertions planned for skipped dependency methods. Caching/guard transitions have two-call tests. Exception handling behavior (re-raise vs suppress) verified. Planned test count >= identified branch count.

### Step 3: Generate Tests

1. Generate imports: pytest, target function, unittest.mock
2. Generate test cases: 1 test per unique branch path; separate tests per named exception type; cover all branches upfront (happy-path AND error-path)
3. **Non-trivial assertions**: assert computed values, verify call arguments, check state transitions. See `references/mock-patching-rules.md` → Assertion Quality for full checklist
4. Apply dependency-aware mocking based on detected imports (see `references/project-type-strategies.md`)
5. Use `with patch(...)` context managers — not `@patch` decorators — when combining with pytest fixtures
6. When a mock needs both tracking and a return value: use a side_effect function that returns the value. Do not set both `return_value` and `side_effect` on the same mock
7. **Mock patching rules** (items 7–28): exception identity, property override, framework isinstance, attribute init, super() args, recursive functions, blocking primitives, dict-like attributes, `__import__` patching, weakref.proxy, contextmanager-factory, compound `or`, real built-in objects, framework registries — **see `references/mock-patching-rules.md`** for the full 21-rule checklist. Consult during test code generation
8. **Write test file**: Use the write tool first. If RangeError, use bash cat heredoc as primary fallback. If heredoc also fails or truncates, use Python `open().write()` via bash in a single invocation — construct the complete content as one string variable and write once, do NOT append incrementally

**Immediately after writing**, run syntax check:

**If `ENV_MODE` is NOT `offline`** (interpreter available):
```bash
$PYTHON -c "import ast; ast.parse(open('<test_file>').read()); print('Syntax OK')"
```

**If `ENV_MODE=offline`** (no interpreter):
- Read back the generated test file
- Statically validate:
  1. Every `def` has a colon and indented body
  2. All string literals have matching quotes (single/double/triple)
  3. All parentheses, brackets, braces are balanced
  4. No tabs mixed with spaces in indentation
  5. All `with`, `for`, `while`, `if`, `try`, `class` blocks have colons and bodies
- If any issue found: apply a targeted fix and re-validate. Max 3 static-fix attempts.

> `$PYTHON` is the interpreter resolved in Environment Setup.

**If syntax check fails**: Re-read the generated file, identify the syntax error line from the traceback, apply a targeted fix to that line, and re-run the syntax check. Maximum 3 syntax fix attempts.

**If all 3 syntax-fix attempts fail**: Log the function as unrecoverable, skip coverage validation for that file, and include it in a failure summary at the end of Step 4 so the user can manually intervene. Do NOT proceed to Step 4 test execution with known-broken syntax — the test execution will fail with confusing errors and waste iterations.

**If Step 4 also fails due to an unresolved syntax error**: Rewrite the test file from scratch focusing only on the simplest passing tests first (basic happy-path and one error-path test), then iteratively add complexity. Do not continue debugging the broken file - a clean rewrite from a minimal base is more reliable than patching persistent syntax errors.

**Post-write completeness verification**: Count `def test_` functions in the written file and compare against planned test count from Step 2. If fewer tests exist than planned, the file was likely truncated — rewrite or append missing tests.

**Post-write verification**: Read back the test file and verify it contains at least one `def test_` function. If not, rewrite the file.

**Post-generation method call audit**: After generating all branch tests, verify EVERY stdlib/framework utility call has a dedicated test with `assert_called_once_with()` argument verification. If any are missing, add targeted tests before proceeding.

> **Checkpoint**: Syntax check passes. Every test has a non-trivial assertion. Test file contains test functions. Test count matches planned count. Every stdlib/framework utility call has argument verification test.

### Step 4: Execute and Fix

**If `ENV_MODE=offline`**: Skip test execution entirely. Mark all generated tests as "unverified — generated in offline mode (no Python interpreter available)". Proceed directly to Step 5 (offline coverage estimation). Do not attempt mock fixes or import fixes — they cannot be validated without execution.

**If `ENV_MODE` is NOT `offline`** (normal path):

1. Run: `$PYTHON -m pytest <test_file> -v --tb=short --timeout=10` from task directory (use workdir)
   - `$PYTHON` is the interpreter resolved in Environment Setup. If tests fail with `ModuleNotFoundError` for a project dependency, install it: `$PYTHON -m pip install <package>`. Max 2 dependency-fix attempts.
   - On Windows, use forward slashes (/) in bash commands — backslashes are interpreted as escape characters.
2. If tests fail, apply **targeted edits** (not full rewrite) to fix only failing tests. For the full fix matrix and failure branches (import errors, mock setup failures, test timeout, fixture conflicts), see `references/failure-recovery-strategies.md`. Key fixes:
   - Import/mock errors → check patch targets; for class attributes use `patch.object(ClassName, 'attr')`
   - isinstance failures → replace patched framework class with real objects
   - Fixture ordering → replace `@patch` decorators with `with patch(...)` context managers
   - side_effect/return_value conflict → combine into single side_effect function
   - Self-call interception → use instance-level assignment (`obj.method = MagicMock()`)
   - pytest.raises DID NOT RAISE → except block suppresses; verify function returns normally
   - MagicMock(spec=TargetClass) → replace with `TargetClass.__new__(TargetClass)` + manual attributes
   - Blocking primitives → always mock Event.wait() and similar blocking calls
   - While-loop hangs → use `side_effect` lists (e.g., `[None, Exception()]`) to ensure termination
**Failure Branch: Import Errors** (see references/failure-recovery-strategies.md):
- ModuleNotFoundError → install missing package via `$PYTHON -m pip install <package>`, or add `sys.path` at test file top
- ImportError: cannot import name → re-read source to verify exact import path and names
- Max 3 import-fix iterations within the Step 4 budget

**Failure Branch: Mock Setup Failures / AttributeError** (see references/failure-recovery-strategies.md):
- MagicMock has no attribute X → remove spec= or use `__new__` + manual attributes
- Mock object is not callable → use `PropertyMock` with `new_callable` for properties
- AttributeError on real object → use `__new__` + manual attribute assignment to bypass `__init__`
- Max 3 mock-fix iterations within the Step 4 budget

**Failure Branch: Test Timeout or Fixture Conflict** (see references/failure-recovery-strategies.md):
- Test hangs → add `--timeout=10`, mock all blocking primitives (Event.wait, Queue.get, sleep)
- While-loop hangs → use `side_effect` lists to ensure termination
- Fixture teardown → replace `@patch` with `with patch(...)` context managers
- Max 3 timeout-fix iterations within the Step 4 budget

3. Verify file syntax before re-running
4. Maximum 3 fix iterations total. If tests still fail after 3 iterations, accept current state and proceed to Step 5 - report remaining failures in the final output. Do not loop indefinitely on unfixable tests.

> **Checkpoint**: All tests pass, OR 3 fix iterations exhausted with remaining failures documented.

### Step 5: Validate Coverage (HARD GATE)

**If `ENV_MODE=offline`**: Skip runtime coverage. Perform **static coverage estimation** instead (see Step 5 Offline below).

**If `ENV_MODE` is NOT `offline`** (normal path) — Run coverage:
```bash
$PYTHON -m coverage run --rcfile=NUL -m pytest <test_file> -v
$PYTHON -m coverage json -o coverage.json --rcfile=NUL
```

Fallback only if primary fails:
```bash
$PYTHON -m pytest <test_file> --cov=<source_module> --cov-report=term-missing --cov-report=json -v
```

**If both coverage commands fail**: Check for import errors in the test output. Fix imports and retry. If the coverage package itself is missing, re-run Environment Setup dependency installation.

Do not modify `.coveragerc`, `setup.cfg`, `pyproject.toml`, or any project configuration file.

**Parse coverage.json** — use `scripts/parse_coverage.py`:
```bash
$PYTHON scripts/parse_coverage.py <coverage.json> <function_name> <start_line> <end_line> <source_file_path>
```
Always provide `source_file_path` to prevent cross-file contamination.

**HARD GATE**:
- `pass: true` (>=90%) AND `total_executable_lines > 0` → Proceed to Step 6
- `pass: false` OR `total_executable_lines == 0` → Continue to Step 5.1
- If `total_executable_lines == 0`: re-run coverage, then re-run parse_coverage.py
- If parse_coverage.py reports unexpected results but direct coverage.json inspection confirms >=90%, accept the direct evidence

### Step 5 Offline: Static Coverage Estimation (`ENV_MODE=offline` only)

When no interpreter is available, estimate coverage by mapping planned tests to source branches identified in Step 2.

**Procedure**:

1. **Re-read the target function** and enumerate every executable line (exclude blank lines, comments, docstrings).
2. **List all branches** from Step 2 analysis: if/elif/else, for/while, try/except, raise, early returns, with blocks.
3. **Map each generated test to the branches it covers**:
   - A test targeting `if condition == X` covers the `if` body when `True` and the `else` body when `False` (or implicit fall-through).
   - A test targeting a `raise` covers the raise line AND any lines preceding it in that branch.
   - A test targeting an `except` block covers the except body AND the try-body lines that lead to the exception.
   - A parametrized test with N variants covers N branch sub-paths.
4. **Identify uncovered lines**:
   - Any branch from Step 2 with no corresponding test is uncovered.
   - Lines within a partially-covered branch (e.g., early return in the middle) need a dedicated test for the non-early-return path.
5. **Compute estimated coverage**:
   ```
   estimated_coverage = covered_lines / total_executable_lines * 100
   ```
6. **If estimated coverage < 90%**: Apply the same Step 5.1 targeted-test-addition logic — create one test per uncovered branch, then re-estimate. Max 3 cycles.
7. **Record** the result as `estimated_coverage` (not runtime-verified) with the list of covered/uncovered branches.

**Limitations of static estimation**:
- Cannot detect dead code (unreachable branches that runtime coverage would flag).
- Cannot verify that mocks actually trigger the intended branch — mock setup errors are only caught at runtime.
- Estimated coverage is an **upper bound** — actual runtime coverage may be lower if mocks misfire or imports fail.

> **Checkpoint**: Estimated coverage >= 90% OR 3 estimation cycles exhausted with uncovered branches documented.

### Step 5.1: Targeted Test Addition (only if Step 5 <90%)

1. Read uncovered lines from parse_coverage.py output
2. Map each to its branch condition
3. Create exactly ONE targeted test per uncovered branch
4. Try alternatives: direct function call with patches → PropertyMock → integration approach → mock.patch on blocking primitives
5. Maximum 3 cycles, then consult `references/failure-recovery-strategies.md`
6. **Terminal fallback**: If all recovery strategies are exhausted without reaching >=90%, report the following to the user: (a) the achieved coverage percentage, (b) the list of uncovered lines mapped to their branch conditions, (c) a summary of recovery strategies attempted for each uncovered branch. Suggest that the user manually review the uncovered branches — they may require runtime state, framework internals, or environment conditions that cannot be simulated in unit tests. Do not silently finalize below the gate.

**Failure Branch: Coverage Shortfall After Tests Pass** (see references/failure-recovery-strategies.md):
- Run with --cov-report=term-missing to get exact uncovered lines
- For each uncovered branch, identify WHY existing tests do not cover it:
  - Missing branch test: create a targeted test
  - Mock interception: use real objects or adjust mock scope
  - Dead code: document as dead code
  - Framework-managed code: try integration approach
- Create ONE targeted test per uncovered branch (not per uncovered line)
- Maximum 3 coverage-improvement cycles
- Terminal fallback: report achieved coverage %, uncovered lines, and strategies attempted

### Step 6: Finalize

**Quality check** (verify before finalizing — both online and offline):
1. Coverage >=90% [online: runtime-verified; offline: statically estimated] AND total_executable_lines > 0
2. All tests pass [online: executed; offline: marked "unverified — generated in offline mode"]
3. Every raise statement has a test verifying complete error message content
4. Every method call (including stdlib calls) has at least one test verifying its call arguments
5. For sequential workflows: ordering test includes ALL calls (including super()) and covers ALL branch paths
6. Multi-step mutations to the same data structure have dedicated per-step verification
7. Dict storage assertions verify both key existence AND value equality
8. Constructor assertions verify type and arguments (not just `is not None`)
9. Guard clauses have both positive and negative tests
10. Warning/deprecation assertions verify complete message content (name + version + alternative)
11. Caching/guard transitions tested with two-call pattern
12. Exception handling behavior verified (re-raise vs suppress)
13. isinstance chain functions have both inclusion and exclusion tests per type branch
14. Test file in task directory; no scope expansion
15. [offline only] Static syntax validation passed (balanced blocks, matching quotes, valid indentation)

**If any check fails**: Fix before finalizing.

**Provide**: Test file content, coverage percentage [offline: clearly labeled as static estimate], test count, covered scenarios. [offline: append prominent notice: "Tests generated in offline mode — not runtime-verified. Install Python and re-run to verify execution and obtain precise coverage."]

### Cleanup

After finalizing (both online and offline modes), remove intermediate artifacts generated during Step 5:

```bash
rm -f coverage.json .coverage
```

- Also remove any `__pycache__/` directories created during test execution in the task directory.
- Do NOT remove the generated test file (`<test_file>`) or `parse_coverage.py` — only clean up coverage data artifacts.
- If cleanup fails (permission denied, file locked): warn the user and continue — do not block on cleanup.

## Gotchas

> Many gotchas have been moved to `references/mock-patching-rules.md` → Gotchas and `references/conditional-patterns-index.md`. Below are only items not covered elsewhere.

- **Over-writing working tests**: If tests pass and coverage >=90%, stop. Do not add redundant tests or integration classes. Source: analyzer
- **Bash path on Windows**: Use forward slashes (`/`) in bash commands, not backslashes (`\`). Source: analyzer
- **Unconditional intermediate state tests**: Only create dedicated intermediate state tests when the mutation is in a separate code path. Otherwise, verify within the branch test. Source: analyzer
- **Exception suppress vs re-raise**: Before writing `pytest.raises`, verify whether the except block re-raises or suppresses. Many except blocks suppress exceptions — `pytest.raises` for suppressed exceptions always fails. Source: analyzer

## Bundled Resources

- `references/conditional-patterns-index.md`: Consolidated index of conditional test-planning patterns — state mutations, sequential/guard patterns, attribute/lifecycle patterns, decorator/closure patterns, type dispatch, guard clause dual-path, execution order testing, and efficiency rules. Use during Step 2 when matching patterns are detected.
- `references/mock-patching-rules.md`: Mock patching and assertion quality rules (21-rule checklist), plus unique gotchas not covered in SKILL.md. Use during Step 3 for test code generation.
- `references/project-type-strategies.md`: Generic dependency-aware mocking strategies for any Python project. Covers detecting external I/O and framework dependencies from imports, mock selection rules, call-order verification, blocking primitive mocking, and cross-cutting patterns. Use during Steps 1 and 3.
- `references/branch-coverage-matrix.md`: Branch coverage matrix templates with method call columns, intermediate state tracking, collection mutation verification, guard clause priority, multi-step mutation override precedence, and constructor verification. Use during Step 2.
- `references/sequential-workflow-testing.md`: Techniques for sequential workflows, state-flagged execution, multi-exception error handling, recursive data traversal, deeply nested logic, and guard clause priority. Use during Step 2 only when complex patterns are detected.
- `references/failure-recovery-strategies.md`: Recovery strategies for test failures and coverage gaps, including mock patching error patterns, exception identity, property override, terminal failure guidance, and explicit failure branches for import errors, mock setup failures/AttributeError, test timeout/fixture conflicts, and coverage shortfall after tests pass. Use during Steps 4 and 5.1 after iteration limits or when failure branches are triggered.
- `references/attribute-and-lifecycle-patterns.md`: Testing strategies for attribute-access edge cases, resource-lifecycle testing, while-loop termination, and generator function testing. Use during Step 2 only when these patterns are detected.
- `references/decorator-and-closure-patterns.md`: Decorator-with-optional-args, closure/callback capture, contextmanager-factory. Use in Step 2 when these patterns detected.
- `examples/test-patterns.md`: Reusable test patterns for mocking, parametrization, exception testing, call-order verification, state-at-call-time, recursive calls, side_effect/return_value, exception identity, property override, constructor verification, and intermediate state verification. Use during Step 3.
- `scripts/parse_coverage.py`: Function-specific coverage parser with path-segment matching. Use during Step 5. Always provide source_file_path argument.
