---
name: generate-ut-for-go
description: Generate high-coverage unit tests for Go functions. Use when the user wants to create, add, or enhance unit tests for Go functions — including requests to generate tests for a specific function, raise coverage, or mock-isolate external dependencies. Uses feature-driven mock tier selection (F1-F13) + probe validation + coverage-first generation with -race verification. NOT for integration tests. No real external services.
language: go
---

## Overview

Generate >90% line coverage **unit tests** for complex Go functions. All external deps isolated via mock/fake. Integration tests are NOT a coverage fallback.

**Hard Constraints** (non-negotiable):
1. >90% line coverage on target function body, measured by `go test -coverprofile` — 90.0% is NOT sufficient, must exceed 90%
2. Unit-test scope only — no real external services
3. Source code is read-only — no changing visibility, signatures, or implementations

## Workflow

### Step 1: Parse + Target Analysis + Tier Selection

1. Parse prompt: extract file path and function name.
2. Run `go version` (30s timeout). Exit 0 → Go available. Timeout/non-zero → see `references/go-unavailable-mode.md`.
3. Read target function. Count executable lines. Enumerate ALL branches: success paths, error paths, edge cases, concurrent scenarios, callback/function-field conditionals inside error-handling paths.
4. **Existing test discovery** (before generating code):
   - Glob `*_test.go` in target package.
   - Grep for target function name in existing test files.
   - Grep for package-level variable declarations (`var ctx`, `var buf`) that might conflict with names in the new test file.
   - Test file naming: `<source_filename>_test.go` (e.g., source `conn.go` → `conn_test.go`). Do NOT name after the target function.
   - If a matching `<source_filename>_test.go` already exists → APPEND to that file.
   - If no matching test file exists → create NEW file named `<source_filename>_test.go`.
   - Use same-package (`package X`, not `package X_test`) when testing unexported functions.
5. **Pre-existing mock discovery**: Search `*_test.go` in same package for existing mock factories, hook patterns, or test helpers. If a simpler, already-debugged pattern exists → prefer it over gomonkey.
6. **Mock tier selection** using Feature Decision Matrix (read `references/mock-tier-guide.md` for full F1-F13 table):

| Level | Name | When |
|---|---|---|
| L1 | Pre-constructed state | Internal state loader, pure logic |
| L2 | Interface mock | Dependency is interface type |
| L3 | Struct field injection | Struct has func/interface field |
| L4 | Fake protocol server | Routing predicate IN target body + err from protocol parser |
| L5 | gomonkey patch | Concrete-type method, no interface/field, NON-routing |

   **Tier rule**: Use the tier that achieves >90% coverage with minimal test complexity. When L5 provides a simpler, more direct mock than L1/L3, prefer L5 for simplicity and reliability. If coverage ≤90% after L1-L3 attempts, escalate to L5 before classifying lines as unreachable.

7. **Fast Path**: If matrix locates ONLY L1/L2 tiers AND target has <5 branches → skip Steps 1.1-1.3, proceed directly to Step 2.

### Step 1.1: Dependency Traversal (only when private methods have external deps)

Private methods that are pure logic (Class A) → skip, covered naturally. Only Class B methods (external deps) trigger traversal. See `references/mock-tier-guide.md` for traversal procedure.

### Step 1.2: Probe Test (when tier is ambiguous)

Write ONE minimal probe test (5-10 lines): construct target + inject mock + call once. Compile + run. If panic → re-scan matrix. Max 2 re-probes. Delete probe test after validation — do not leave orphaned test files on disk.

### Step 1.3: gomonkey Pre-Probe (when L5 located)

1. Check `go.mod` for `agiledragon/gomonkey`. Missing → `go get github.com/agiledragon/gomonkey/v2`. If `go get` fails → document failure and attempt L4/L3/L1 fallback explicitly (see `references/go-unavailable-mode.md` gomonkey-unavailable sub-mode).
2. Write + run probe test confirming gomonkey patches work. Use `-gcflags=all=-l` on ALL `go test` commands when gomonkey is used.
3. If gomonkey genuinely unavailable → fallback: L4 for network anchors, L3 via `export_test.go`, L1 pre-constructed state.

### Step 2: Generate Tests

**Phase 0 — Mock validation**: Write 1-2 core-path tests (simplest success + simplest error). Compile + run. If fail → fix mock strategy HERE.

**Phase 1 — Coverage-first**: Generate remaining tests to reach >90%. Key rules:
- **Branch enumeration**: List ALL execution paths. One test per branch minimum, aim 1.2x for edge cases. Create table: Line, Branch, Mock strategy, Test name. Pay special attention to conditional callback/function-field blocks inside error-handling paths.
- Call target through public entry point. No real external connections.
- Mock injection before target call. Pre-constructed state: construct correct state rather than patching state-loader.
- **Dispatcher and type-assertion patterns**: See `references/mock-tier-guide.md` for dispatcher patching, type-assertion dispatch, and intermediate argument verification.
- **Error-path tests should verify error content** using `strings.Contains(err.Error(), expected)` or `errors.Is` — bare `err != nil` provides weak verification.
- **Success-path tests should verify output correctness** — not just `err == nil`. Prefer verifying at least one non-error output property (return value, mutated state, call count).
- Disable non-determinism: set retry/timeout fields to minimal values (e.g., `RetryInterval: -1`, `DialTimeout: time.Second`). Read the target's config struct to find the correct field names.
- Concurrent test: ONLY when target uses mutex or modifies shared state. Use `sync.WaitGroup`. For gomonkey closure thread-safety, see `references/concurrent-safety.md`.
- Table-driven tests for error/validation scenarios.
- Before calling any constructor function in test code, grep for the constructor name to verify it is exported. If private, construct the struct directly with explicit field initialization.
- Before constructing target-adjacent structs with embedded fields, verify the field path by reading the struct definition.
- Tolerate temporary omission of: var _ checks, t.Helper(), test-intent comments.

**Coverage gate** (before Phase 2):
```
go test -gcflags=all=-l -coverprofile cov.txt -run TestFuncName -count=1
go tool cover "-func=cov.txt" | Select-String "FuncName$"
```
>90% → Phase 2. ≤90% → Step 2.1.

**Phase 2 — Quality harden**: Add deferred items (var _ checks, t.Helper(), test-intent comments, strings.Contains assertions). Delete all probe tests. Re-measure coverage after hardening.

### Step 2.1: Coverage Gap Attribution (when ≤90%)

1. Generate line-level coverage, list UNCOVERED line numbers in target body.
2. Filter to target body only (ignore downstream private methods).
3. Per-line attribution using F1-F13 matrix. Fix in cost order: F8 (missing test) + L1/L2/L3 first. Only if still ≤90%, escalate L4 for F4, L5 for F5/F7.
4. Before classifying a branch as unreachable, verify that gomonkey injection could not cover it — escalate to L5 first (see `references/coverage-measurement.md` for unreachable escalation rules).
5. Before classifying any line as unreachable (U1/U9), write a minimal probe test to verify unreachability empirically. If the probe shows the line IS reachable, write a proper test case.
6. Re-measure after each batch. Repeat until >90% or all lines covered/attributed-unreachable.

**Attribution table** (required completion artifact):
```
L<line#> -> F<x>/L<x> -- <tier + test name>
L<line#> -> U<x> (<reason>) -- excluded from denominator
```

### Step 3: Final Verification

1. **Compile gate**: `go vet ./...` then `go test -gcflags=all=-l -run NONE -count=1 ./...`
2. **Coverage measurement** (use space-separated flags on Windows, `.txt` extension, avoid `.out`):
   ```
   go test -gcflags=all=-l -coverprofile cov.txt -run TestFuncName -count=1
   go tool cover "-func=cov.txt" | Select-String "FuncName$"
   ```
3. **Race detection gate**:
   ```
   go test -gcflags=all=-l -race -run TestFuncName -count=1
   ```
   All tests must pass with `-race`. If any race detected → fix before proceeding. See `references/concurrent-safety.md`.
4. If coverage ≤90% → Step 2.1.
5. Write `coverage_report.txt` with actual measured values + attribution table.

### Step 3.5: Completion Gate

Answer ALL four (any NO → go back):
1. Did I run `go test -coverprofile`? — YES / NO
2. What is the REAL percentage? → ____% (must be >90%)
3. Did I run `go test -race`? — YES / NO
4. Is the attribution table produced? — YES / NO

## Verification Requirements

Before finalizing, confirm these checks (see `references/test-patterns.md` for patterns):
- Error-path tests verify specific error content (`strings.Contains` or `errors.Is`), not just `err != nil` (recommended).
- Success-path tests that mutate output parameters verify the mutated state, not just `err == nil` (recommended).
- When a function has both typed error checks and string-prefix fallback checks, both paths are tested.
- No probe test files remain on disk.
- Coverage is strictly above 90% (not at the boundary).

## Gotchas

- **Coverage should exceed 90%.** 90.0% is at the boundary — continue generating tests to push above 90%.
- **Estimate coverage only when Go is genuinely unavailable.** When `go version` succeeds, fix compile/test errors and measure actual coverage.
- **Source code is read-only.** No changing visibility, signatures, or implementations. Use gomonkey/struct-field injection instead.
- **"go.mod lacks gomonkey" is not "cannot mock".** Run `go get`. Adding test-only deps is industry-standard. If `go get` fails, use L4/L3/L1 fallback.
- **Concurrent gomonkey closures require atomic/mutex for shared state.** Bare `callCount++` in a concurrent gomonkey closure is a DATA RACE. Use `atomic.Int32`.
- **Windows: use space-separated flags and `.txt` extension.** `go test -coverprofile cov.txt` (space) not `go test -coverprofile=cov.out` (=). PowerShell parses `=` differently.
- **Test file naming follows source filename.** Name test files as `<source_filename>_test.go` (e.g., `conn.go` → `conn_test.go`), NOT after the target function. Append to existing matching test file when present; create new only when absent.
- **Replace `t.Skip` for infrastructure deps with mock/fake.** `t.Skip` masks missing isolation in unit tests.
- **Dispatcher and type-assertion patterns live in references.** For dispatcher patching, type-assertion dispatch, and intermediate argument verification, see `references/mock-tier-guide.md`.
- **Lower tier number does not necessarily mean simpler implementation.** Hook injection (L1/L3) may require more test infrastructure than a direct gomonkey patch (L5). Prefer the approach that is simpler and more reliable for the specific dependency.
- **Mock the channel consumer by draining the channel.** When target launches goroutines that send to a channel consumed by a patched method, the mock should drain the channel (`for range results {}`) to ensure all producer goroutines complete before assertions run.
- **Use `ApplyPrivateMethod` for unexported methods.** `ApplyMethod` fails on unexported methods with "retrieve method by name failed" panic. Check if the method name starts with a lowercase letter before choosing the API.
- **Verify struct field hierarchy before writing struct literals.** Go struct embedding can make field paths non-obvious (e.g., `Derived` embeds `Base`, so field `X` is accessed via `Derived{Base: &Base{X: ...}}`). Read the struct definition first.

## Bundled Resources

- `references/mock-tier-guide.md`: Full F1-F13 Feature Decision Matrix with detection signals and post-hoc root-cause mapping, dependency traversal procedure, gomonkey Windows guide, tier escalation rules, dispatcher patching pattern, type-assertion dispatch pattern, intermediate argument verification pattern, embedded-type patching, tier simplicity rule. Read in Step 1 (item 6) and Step 2.1.
- `references/concurrent-safety.md`: Thread-safety rules for gomonkey closures, atomic.Int32 usage, -race gate procedure, goroutine lifecycle priority, channel-draining patterns, concurrent test scaffolding for state-transition functions, simplicity-first guidance. Read when target uses mutex, goroutines, or concurrent tests are needed.
- `references/coverage-measurement.md`: Coverage commands (Windows + Unix), attribution table format, coverage_report.txt template, unreachable-line patterns (U1-U5), coverage boundary rule (>90% threshold). Read in Step 3.
- `references/test-patterns.md`: Table-driven testing, observable verification (callCount, spyLogger, captured fields), business-rule testing, mock helper patterns, error content verification, dual-path error testing, output parameter verification, recommended patterns. Read in Step 2.
- `references/mock-strategy-errors.md`: Common mock strategy error diagnosis table (14 symptoms with root causes and fixes), error recovery patterns, assertNoError pattern. Read on-demand when mock tests fail.
- `references/go-unavailable-mode.md`: Go-unavailable workflow with estimation procedure. Read in Step 1 if Go unavailable.
- `scripts/check-test-quality.py`: Validates mock injection, callCount patterns, var _ checks, WaitGroup usage, error content verification, probe test cleanup. Run as advisory check in Phase 2 (not a blocking gate).
- `scripts/verify-coverage-report.py`: Validates coverage report consistency and format. Run as advisory check in Step 3 (not a blocking gate).
