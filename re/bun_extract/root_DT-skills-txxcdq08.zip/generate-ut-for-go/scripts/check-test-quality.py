#!/usr/bin/env python3
"""
Test quality validation script for generate-ut-for-go skill.
Validates mock patterns, observable verification, and test structure.

Usage: python scripts/check-test-quality.py <test_file_path>

Exit codes:
  0: All checks passed
  1: Critical issues found (mock injection missing, boolean flags)
  2: Warning issues found (missing comments, var _ checks incomplete)
"""

import sys
import re
import os

# ---------------------------------------------------------------------------
# Shared context: regex results reused across checks
# ---------------------------------------------------------------------------

def _compute_stats(content):
    """Compute regex results shared by multiple checks."""
    lines = content.split('\n')
    return {
        'lines': lines,
        'test_functions': re.findall(r'func Test(\w+)\(t \*testing\.T\)', content),
        'mock_structs': re.findall(r'type mock(\w+) struct', content, re.IGNORECASE),
        'injection_patterns': re.findall(r'(\w+)\.\w+ = mock\w+', content),
        'tier0_patterns': re.findall(
            r'net\.Listen\(|httptest\.NewServer\(|httptest\.NewTLSServer\(|'
            r'newFake\w*Server\(|newTest\w*(?:Client|Server)\w*\(|'
            r'\.Addr\(\)|holder\.state\.Store\(|\.state\.Store\(|'
            r'\.Commands\(\)|\.CallCount\(\)|\.WatchCallCount\(\)',
            content
        ),
        'var_checks': re.findall(r'var _ \w+ = &mock\w+\{\}', content, re.IGNORECASE),
        'waitgroup_usage': re.findall(r'wg\.Add\(|wg\.Wait\(|sync\.WaitGroup', content),
        'test_intent_comments': _count_test_intent_comments(lines),
        'strings_contains': re.findall(r'strings\.Contains\(err\.Error\(\)', content),
        'is_integration_file': re.search(r'//go:build integration|// +build integration', content),
        'gomonkey_import': bool(re.search(r'"github.com/agiledragon/gomonkey"', content)),
        'test_func_ranges': _compute_test_func_ranges(lines),
    }


def _count_test_intent_comments(lines):
    count = 0
    for i, line in enumerate(lines):
        if re.match(r'func Test\w+\(t \*testing\.T\)', line):
            if i > 0 and lines[i - 1].strip().startswith('//'):
                count += 1
    return count


def _compute_test_func_ranges(lines):
    ranges = []
    for i, line in enumerate(lines):
        if re.match(r'func Test\w+\(t \*testing\.T\)', line):
            start = i
            end = start + 1
            while end < len(lines) and not (end > start and re.match(r'^func ', lines[end])):
                end += 1
            ranges.append((start, end, line))
    return ranges


# ---------------------------------------------------------------------------
# Individual checks (each returns (errors, warnings))
# ---------------------------------------------------------------------------

# Check 1: Mock injection presence in tests with dependencies
def _check_mock_injection(content, stats):
    errors, warnings = [], []
    mock_structs = stats['mock_structs']
    injection_patterns = stats['injection_patterns']
    tier0_patterns = stats['tier0_patterns']
    missing_injection = mock_structs and len(injection_patterns) < len(mock_structs)
    if not missing_injection:
        return errors, warnings
    if not tier0_patterns:
        errors.append(
            f"CRITICAL: Mock structs defined ({len(mock_structs)}) but injection patterns found ({len(injection_patterns)}) "
            f"and no L4 fake-server patterns. Possible mock-definition-only gap."
        )
    else:
        warnings.append(
            f"WARNING: Mock structs ({len(mock_structs)}) exceed field-injection patterns ({len(injection_patterns)}), "
            f"but L4 fake-server patterns detected ({len(tier0_patterns)}). "
            f"Verify the L4 server is wired into the client BEFORE each target call."
        )
    return errors, warnings


# Check 2: Boolean flags instead of int callCount
def _check_boolean_flags(content, stats):
    errors, warnings = [], []
    boolean_fields = re.findall(r'(called|used|done|executed|processed)\s+bool', content, re.IGNORECASE)
    if boolean_fields:
        errors.append(
            f"CRITICAL: Boolean flags found instead of int callCount fields: {boolean_fields}. "
            f"Use int counters for observable verification."
        )
    return errors, warnings


# Check 3: var _ Interface checks for mock structs
def _check_var_interface(content, stats):
    errors, warnings = [], []
    mock_structs = stats['mock_structs']
    var_checks = stats['var_checks']
    if mock_structs and len(var_checks) < len(mock_structs):
        warnings.append(
            f"WARNING: Mock structs ({len(mock_structs)}) exceed var _ checks ({len(var_checks)}). "
            f"Add var _ Interface = &mockStruct{{}} for EVERY mock."
        )
    return errors, warnings


# Check 4: time.Sleep usage (prohibited, EXCEPT Priority 3 legal fallback)
# Priority 3 allows runtime.Gosched()+time.Sleep(100ms) for uncontrollable private-method goroutines.
def _check_time_sleep(content, stats):
    errors, warnings = [], []
    time_sleep = re.findall(r'time\.Sleep\(|time\.After\(', content)
    if not time_sleep:
        return errors, warnings
    has_goroutine_launch = bool(re.findall(r'go func\(|go \w+\(', content))
    has_gosched = bool(re.search(r'runtime\.Gosched\(\)', content))
    if has_gosched or has_goroutine_launch:
        warnings.append(
            f"WARNING: time.Sleep/time.After found ({len(time_sleep)} occurrences) with goroutine/Gosched context. "
            f"If this is Priority 3 (uncontrollable private-method goroutine), document WHY WaitGroup/context are impossible. "
            f"Otherwise use sync.WaitGroup."
        )
    else:
        errors.append(
            f"CRITICAL: time.Sleep/time.After found ({len(time_sleep)} occurrences) with no goroutine context. "
            f"Use sync.WaitGroup for goroutine synchronization."
        )
    return errors, warnings


# Check 5: sync.WaitGroup usage for concurrent tests
def _check_waitgroup(content, stats):
    errors, warnings = [], []
    goroutine_launches = re.findall(r'go func\(', content)
    if goroutine_launches and not stats['waitgroup_usage']:
        errors.append(
            f"CRITICAL: Goroutines launched ({len(goroutine_launches)}) but no sync.WaitGroup found. "
            f"Use WaitGroup for deterministic synchronization."
        )
    return errors, warnings


# Check 6: Test intent comments above test functions
def _check_test_intent_comments(content, stats):
    errors, warnings = [], []
    test_functions = stats['test_functions']
    test_intent_comments = stats['test_intent_comments']
    if test_functions and test_intent_comments < len(test_functions):
        warnings.append(
            f"WARNING: Test functions ({len(test_functions)}) exceed test intent comments ({test_intent_comments}). "
            f"Add comment above EVERY test: // TestFunctionName: verifies [behavior] when [condition] (covers line X-Y, branch Z)"
        )
    return errors, warnings


# Check 7: strings.Contains / errors.Is for error verification
def _check_error_verification(content, stats):
    errors, warnings = [], []
    error_checks = re.findall(r'err\s*!=\s*nil', content)
    valid_error_checks = stats['strings_contains'] + re.findall(
        r'errors\.Is\(|errors\.As\(|assert\.ErrorContains\(|assert\.ErrorIs\(|require\.ErrorIs\(|require\.ErrorContains\(',
        content
    )
    if error_checks and len(valid_error_checks) < len(error_checks):
        warnings.append(
            f"WARNING: err!=nil checks ({len(error_checks)}) exceed error-content checks ({len(valid_error_checks)}: "
            f"strings.Contains/errors.Is/assert.ErrorIs). Use strings.Contains(err.Error(), 'expected') or errors.Is for observable error verification."
        )
    return errors, warnings


# Check 8: capturedReq/capturedRes/capturedCtx for field verification
def _check_captured_fields(content, stats):
    errors, warnings = [], []
    captured_fields = re.findall(r'captured(Req|Res|Ctx|Args|Reply|Data)', content, re.IGNORECASE)
    if stats['mock_structs'] and not captured_fields:
        warnings.append(
            "WARNING: No capturedReq/capturedRes/capturedCtx fields found. Add captured fields for observable parameter verification."
        )
    return errors, warnings


# Check 9: Placeholder tests (TODO without implementation)
def _check_placeholders(content, stats):
    errors, warnings = [], []
    todo_placeholders = re.findall(r'// TODO:|t\.Skip\("not implemented"\)', content)
    if todo_placeholders:
        errors.append(
            f"CRITICAL: Placeholder tests found ({len(todo_placeholders)}). Every test must contain actual target call."
        )
    return errors, warnings


# Check 10: Function uses mutex - concurrent test required
# NOTE: fake protocol servers (L4) legitimately use sync.Mutex for thread-safe
# CallCount/Commands — that mutex belongs to the TEST HELPER, not the target function.
# Skip this warning when L4 fake-server patterns are present.
def _check_mutex(content, stats):
    errors, warnings = [], []
    mutex_usage = re.findall(r'\.mu\.Lock\(|\.mu\.RLock\(|sync\.Mutex|sync\.RWMutex', content)
    concurrent_test = re.search(r'Test\w+Concurrent|Test\w+Race|Test\w+Mutex', content, re.IGNORECASE)
    no_concurrency_evidence = not concurrent_test and not stats['waitgroup_usage'] and not stats['tier0_patterns']
    if mutex_usage and no_concurrency_evidence:
        warnings.append(
            "WARNING: Target function may use mutex. Concurrent safety test with sync.WaitGroup should be generated."
        )
    return errors, warnings


# Check 11: Real infrastructure connections in unit tests (CRITICAL)
def _check_infra_connections(content, stats):
    errors, warnings = [], []
    infra_connection_patterns = re.findall(
        r'New\w*Client\(|New\w*Server\(|sql\.Open\(|net\.Dial\(|http\.Client\{',
        content
    )
    if infra_connection_patterns and not stats['is_integration_file']:
        errors.append(
            f"CRITICAL: Real external service connections found in unit test file ({len(infra_connection_patterns)} occurrences): "
            f"NewXxxClient/sql.Open/net.Dial/http.Client. "
            f"Unit tests MUST use L4 fake server (net.Listen) / L1-L3 mocks instead of real connections. "
            f"Local fake server (net.Listen 127.0.0.1:0) is ALLOWED — only real external services are forbidden. "
            f"If real infrastructure is required, move tests to *_integration_test.go with //go:build integration tag."
        )
    return errors, warnings


# Check 12: t.Skip guarding infrastructure dependencies (CRITICAL)
def _check_skip_infra(content, stats):
    errors, warnings = [], []
    skip_infra_patterns = re.findall(
        r't\.Skipf?\([^)]*(?:not available|infrastructure not available|server not available|database not available|service not available)',
        content, re.IGNORECASE
    )
    ping_skip_pattern = re.findall(
        r'\.Ping\(ctx\)\.Err\(\);\s*err[^;]*t\.Skip',
        content
    )
    if (skip_infra_patterns or ping_skip_pattern) and not stats['is_integration_file']:
        errors.append(
            f"CRITICAL: t.Skip guarding infrastructure dependencies in unit test "
            f"(skip_infra={len(skip_infra_patterns)}, ping_skip={len(ping_skip_pattern)}). "
            f"This indicates the test requires real infrastructure and is NOT a unit test. "
            f"Either rewrite using gomonkey patches, or move to *_integration_test.go with //go:build integration tag. "
            f"See SKILL.md Gotchas."
        )
    return errors, warnings


# Check 13: Target function retreat pattern (CRITICAL)
def _check_target_retreat(content, stats):
    errors, warnings = [], []
    test_name_prefixes = re.findall(r'func Test(\w+?)(?:_|$)', content)
    target_prefix = _most_common_prefix(test_name_prefixes)
    if target_prefix is None:
        return errors, warnings
    target_call_patterns = _collect_target_call_patterns(content, target_prefix)
    pure_func_calls = re.findall(
        r'parse\w+\s*\(|validate\w+\s*\(|format\w+\s*\(|calculate\w+\s*\(|compute\w+\s*\(',
        content
    )
    has_any_method_call = bool(re.findall(r'\.\w+\s*\(', content))
    total_tests = len(stats['test_functions'])
    if total_tests > 0 and len(target_call_patterns) < total_tests * 0.5:
        if stats['tier0_patterns'] or has_any_method_call:
            warnings.append(
                f"WARNING: Target function call heuristic detected '{target_prefix}' called in {len(target_call_patterns)} places "
                f"across {total_tests} tests, but L4 fake-server patterns ({len(stats['tier0_patterns'])}) or method calls exist — "
                f"heuristic likely mis-guessed the target name. "
                f"Manually verify at least 50% of tests call the real target function."
            )
        else:
            errors.append(
                f"CRITICAL: Target function retreat pattern detected. "
                f"Target function '{target_prefix}' is called in only {len(target_call_patterns)} places, "
                f"but there are {total_tests} test functions and NO L4 patterns / method calls found. "
                f"At least 50% of tests MUST call the target function. "
                f"Pure helper function calls ({len(pure_func_calls)} found) should be SUPPLEMENTARY, not PRIMARY. "
            )
    return errors, warnings


def _most_common_prefix(test_name_prefixes):
    prefix_counts = {}
    for prefix in test_name_prefixes:
        # Find the longest common prefix that appears in multiple test names
        for length in range(len(prefix), 2, -1):
            candidate = prefix[:length]
            if candidate not in prefix_counts:
                prefix_counts[candidate] = 0
            prefix_counts[candidate] += 1
    if not prefix_counts:
        return None
    return max(prefix_counts, key=prefix_counts.get)


def _collect_target_call_patterns(content, target_prefix):
    target_call_patterns = re.findall(
        rf'\b{target_prefix.lower()}\b\s*\(|\b{target_prefix}\b\s*\(|\.\b{target_prefix.lower()}\b\s*\(|\.\b{target_prefix}\b\s*\(',
        content, re.IGNORECASE
    )
    # Split camelCase prefix to also match the actual method name
    # (e.g. "MyHandlerFunc" -> "Handler", since tests call c.Handler(...) not c.MyHandlerFunc(...))
    camel_parts = re.findall(r'[A-Z][a-z]+|[A-Z]+(?=[A-Z]|$)|\d+', target_prefix)
    method_candidates = {target_prefix} | (set(camel_parts) if camel_parts else set())
    for cand in method_candidates:
        if len(cand) >= 3 and cand != target_prefix:
            target_call_patterns += re.findall(rf'\.{cand}\s*\(|\b{cand}\s*\(', content, re.IGNORECASE)
    return target_call_patterns


# Check 14: gomonkey supplementation reason comment (CRITICAL for coverage-driven framework selection)
# Every test function using gomonkey.ApplyMethod/ApplyFunc must have a
# "// Supplementation reason:" comment explaining why baseline framework was insufficient
def _check_gomonkey_reason(content, stats):
    errors, warnings = [], []
    if not stats['gomonkey_import']:
        return errors, warnings
    lines = stats['lines']
    gomonkey_tests_without_reason = []
    for start, end, func_line in stats['test_func_ranges']:
        func_body = '\n'.join(lines[start:end])
        if re.search(r'gomonkey\.ApplyMethod\(|gomonkey\.ApplyFunc\(', func_body):
            # Check for supplementation reason comment in the function body or 3 lines above
            comment_area = '\n'.join(lines[max(0, start - 3):end])
            if not re.search(r'Supplementation reason:', comment_area, re.IGNORECASE):
                func_name_match = re.search(r'func (Test\w+)', func_line)
                func_name = func_name_match.group(1) if func_name_match else "unknown"
                gomonkey_tests_without_reason.append(func_name)
    if gomonkey_tests_without_reason:
        errors.append(
            f"CRITICAL: gomonkey used in {len(gomonkey_tests_without_reason)} test function(s) "
            f"without 'Supplementation reason:' comment: {gomonkey_tests_without_reason}. "
            f"Every gomonkey usage MUST document why baseline framework was insufficient. "
            f"Format: // Supplementation reason: baseline framework [X] cannot [Y]; gomonkey needed."
        )
    return errors, warnings


# Check 15: Framework pollution — mixed mock frameworks without justification (CRITICAL)
# If file imports both gomonkey and testify/mock (or gomock), all gomonkey
# usage must have supplementation reason, and no test function may mix two mechanisms
def _check_framework_pollution(content, stats):
    errors, warnings = [], []
    if not stats['gomonkey_import']:
        return errors, warnings
    other_mock_imports = re.findall(
        r'"github.com/stretchr/testify/mock"|"go.uber.org/mock"|"github.com/golang/mock"',
        content
    )
    if not other_mock_imports:
        return errors, warnings
    supp_comments = re.findall(r'Supplementation reason:', content, re.IGNORECASE)
    if not supp_comments:
        errors.append(
            f"CRITICAL: Framework pollution detected. File imports both gomonkey and "
            f"other mock framework(s) {other_mock_imports} but has ZERO 'Supplementation reason:' comments. "
            f"gomonkey MUST be introduced ONLY for branches where baseline framework cannot reach >=90% coverage. "
            f"See SKILL.md Gotchas."
        )
    lines = stats['lines']
    for start, end, func_line in stats['test_func_ranges']:
        func_body = '\n'.join(lines[start:end])
        has_gomonkey = re.search(r'gomonkey\.ApplyMethod\(|gomonkey\.ApplyFunc\(', func_body)
        has_other_mock = re.search(r'\.EXPECT\(|gomock\.NewController\(|mock\.Mock', func_body)
        if has_gomonkey and has_other_mock:
            func_name_match = re.search(r'func (Test\w+)', func_line)
            func_name = func_name_match.group(1) if func_name_match else "unknown"
            errors.append(
                f"CRITICAL: Test function '{func_name}' mixes gomonkey with another mock framework. "
                f"Same test function must NOT mix two mock mechanisms. "
                f"If gomonkey is needed for one anchor, use gomonkey for all mocks in that function."
            )
    return errors, warnings


# Check 16: gomonkey stubbing a network method's error (POTENTIAL false coverage)
# Per the two-condition test: false coverage for the TARGET function occurs IFF
# (a) the routing predicate (errorTypeCheck/shouldRetry/...) is in the TARGET function body, AND
# (b) the error comes from a gomonkey stub errors.New bypassing the protocol parser.
# If the routing predicate lives in a DOWNSTREAM private method, this is NOT false coverage
# for the target function (Step 3 boundary rule) — so this is a WARNING requiring manual
# confirmation, not a hard error.
def _check_gomonkey_network_stub(content, stats):
    errors, warnings = [], []
    if not stats['gomonkey_import']:
        return errors, warnings
    NETWORK_METHODS = r'Connect|Dial|Query|Exec|Do|Request|Call|Execute|Process|Send|Fetch'
    # gomonkey patch on a network method that returns errors.New
    gomonkey_network_stub = re.findall(
        rf'gomonkey\.Apply(?:Method|Func)[^}}]*?(?:{NETWORK_METHODS})[^}}]*?errors\.New\(',
        content
    )
    # gomonkey patch whose body mentions redirect/retry keywords (common protocol error indicators)
    gomonkey_stub_redirect = re.findall(
        rf'gomonkey\.Apply(?:Method|Func)[^}}]*?(?:redirect|retry|retryable|unavailable|busy)',
        content, re.IGNORECASE
    )
    if gomonkey_network_stub or gomonkey_stub_redirect:
        warnings.append(
            f"WARNING: gomonkey appears to stub a network method's error "
            f"(network_stub={len(gomonkey_network_stub)}, redirect_stub={len(gomonkey_stub_redirect)}). "
            f"Apply the TWO-CONDITION test: false coverage for the TARGET function occurs ONLY IF "
            f"(a) the routing predicate (errorTypeCheck/shouldRetry/...) is in the TARGET function body itself, AND "
            f"(b) the error comes from this gomonkey stub. If the routing predicate lives in a DOWNSTREAM private "
            f"method, this is NOT false coverage for the target (Step 3 boundary rule) — lighter tiers are valid. "
            f"If condition (a) holds, replace with a L4 fake server returning the raw protocol error frame. "
            f"See references/mock-tier-guide.md (L4 Completeness Check)."
        )
    return errors, warnings


# Check 18: Validation probe tests MUST be deleted from deliverable file
# Probe tests are temporary validation scaffolds — they MUST be
# deleted after validation. Only header comments should remain as audit trail.
def _check_probe_tests(content, stats):
    errors, warnings = [], []
    probe_patterns = re.findall(
        r'func\s+(TestGomonkeyProbe|TestProbeTierValidation|TestProbeDependency'
        r'|TestProbe\w*|TestGomonkey\w*|Test\w*DryRun\w*)\s*\(',
        content
    )
    if probe_patterns:
        errors.append(
            f"Validation probe tests found in deliverable file: {', '.join(probe_patterns)}. "
            f"These are temporary validation scaffolds (Step 1.1/1.2/1.3) — they MUST be DELETED "
            f"after validation. Keep only header comments (e.g. '// gomonkey: L5 available') as audit trail."
        )
    return errors, warnings


# Check 17 was informational-only (no-op by design): network-client tests do NOT
# automatically require L4 — coverage-driven tier selection makes L4 optional
# unless Check 16 already flagged a target-body routing-predicate stub. Omitted
# intentionally to avoid dead code; behavior unchanged.


CHECKS = [
    _check_mock_injection,
    _check_boolean_flags,
    _check_var_interface,
    _check_time_sleep,
    _check_waitgroup,
    _check_test_intent_comments,
    _check_error_verification,
    _check_captured_fields,
    _check_placeholders,
    _check_mutex,
    _check_infra_connections,
    _check_skip_infra,
    _check_target_retreat,
    _check_gomonkey_reason,
    _check_framework_pollution,
    _check_gomonkey_network_stub,
    _check_probe_tests,
]


def _run_checks(content, stats):
    errors = []
    warnings = []
    for check in CHECKS:
        check_errors, check_warnings = check(content, stats)
        errors.extend(check_errors)
        warnings.extend(check_warnings)
    return errors, warnings


# ---------------------------------------------------------------------------
# Output / fix instructions (table-driven to avoid if-chain)
# ---------------------------------------------------------------------------

FIX_INSTRUCTIONS = [
    ("errors", "Boolean flags", [
        "- Replace boolean flags with int callCount fields:",
        "  type mockPlugin struct { callCount int }",
        "  func (m *mockPlugin) Method() { m.callCount++ }",
        "  assert.Equal(t, 1, mock.callCount)",
    ]),
    ("errors", "time.Sleep", [
        "- Replace time.Sleep with sync.WaitGroup:",
        "  var wg sync.WaitGroup",
        "  wg.Add(1)",
        "  go func() { defer wg.Done(); target.Function() }()",
        "  wg.Wait()",
    ]),
    ("errors", "mock-definition-only", [
        "- Add mock injection BEFORE target call:",
        "  target.Dependency = mockDep",
        "  target.Function(ctx, req)",
    ]),
    ("errors", "Placeholder tests", [
        "- Replace TODO placeholders with actual test implementation:",
        "  Every test must contain target call with mock injection and assertions",
    ]),
    ("warnings", "var _ checks", [
        "- Add var _ Interface check after each mock struct:",
        "  var _ InterfaceName = &mockStruct{}",
    ]),
    ("warnings", "test intent comments", [
        "- Add comment above each test function:",
        "  // TestFunctionName: verifies [behavior] when [condition] (covers line X-Y, branch Z)",
    ]),
    ("errors", ("infrastructure connections", "external service"), [
        "- Replace real external service connections with L4 fake server or mocks:",
        "  WRONG: client := NewXxxClient(&Options{Addr: '127.0.0.1:XXXXX'})",
        "  CORRECT (L4): srv := newFakeTestServer(t) + wire client to srv.Addr()",
        "  CORRECT (L1-L3): target := &TargetType{} + struct field injection / pre-constructed state",
        "  NOTE: Local fake server (net.Listen 127.0.0.1:0) is ALLOWED — only real external services are forbidden",
        "  OR move to *_integration_test.go with //go:build integration tag",
    ]),
    ("errors", "t.Skip guarding", [
        "- Remove t.Skip infrastructure guards and rewrite as proper unit tests:",
        "  WRONG: if err := client.Ping(ctx).Err(); err != nil { t.Skip('service not available') }",
        "  CORRECT: Use gomonkey patches to control infrastructure behavior without real connections",
        "  See SKILL.md Gotchas for detailed recovery steps",
    ]),
    ("errors", "retreat pattern", [
        "- Target function must be the PRIMARY test subject (at least 50% of tests call it):",
        "  WRONG: Only testing parseXxx because targetXxx is 'too complex to mock'",
        "  CORRECT: Apply gomonkey Instability Fallback Strategy to test the target:",
        "    1. Struct field injection (sf.onCall = mockFunc)",
        "    2. Lightweight fake struct (&TargetType{Base: &BaseType{}})",
        "    3. Test boundary narrowing (patch helperMethod to return error)",
        "  Pure helper function tests are SUPPLEMENTARY, not PRIMARY",
        "  See SKILL.md Gotchas for detailed recovery steps",
    ]),
    ("errors", "Validation probe tests", [
        "- DELETE all validation probe tests from the deliverable file:",
        "  TestGomonkeyProbe, TestProbeTierValidation, TestProbeDependency, Test*DryRun*",
        "  These are temporary scaffolds (Step 1.1/1.2/1.3) — NOT deliverable tests",
        "  Keep only header comments as audit trail, e.g.:",
        "  // gomonkey: L5 available (TestGomonkeyProbe passed)",
        "  // Probe: Fx->Lx validated (TestProbeTierValidation passed)",
    ]),
]


def _marker_in(marker, haystack):
    if isinstance(marker, tuple):
        return any(m in haystack for m in marker)
    return marker in haystack


def _print_fix_instructions(errors, warnings):
    issues = {'errors': str(errors), 'warnings': str(warnings)}
    for target, marker, instruction_lines in FIX_INSTRUCTIONS:
        if _marker_in(marker, issues[target]):
            for line in instruction_lines:
                print(line)


def _print_results(errors, warnings, stats):
    print("=" * 80)
    print("TEST QUALITY VALIDATION RESULTS")
    print("=" * 80)

    if errors:
        print("\nCRITICAL ERRORS (must fix):")
        for error in errors:
            print(f"  ❌ {error}")

    if warnings:
        print("\nWARNINGS (should fix):")
        for warning in warnings:
            print(f"  ⚠️  {warning}")

    if not errors and not warnings:
        print("\n✅ OK - Test file passes all quality checks")
        print(f"  - Test functions: {len(stats['test_functions'])}")
        print(f"  - Mock structs: {len(stats['mock_structs'])}")
        print(f"  - Mock injections: {len(stats['injection_patterns'])}")
        print(f"  - var _ checks: {len(stats['var_checks'])}")
        print(f"  - WaitGroup usage: {len(stats['waitgroup_usage'])}")
        print(f"  - Test intent comments: {stats['test_intent_comments']}")
        print(f"  - strings.Contains checks: {len(stats['strings_contains'])}")
        return

    print("\n" + "=" * 80)
    print("FIX INSTRUCTIONS:")
    print("=" * 80)
    _print_fix_instructions(errors, warnings)


def check_test_quality(test_file_path):
    """Validate test file quality."""
    if not os.path.exists(test_file_path):
        print(f"ERROR: Test file not found: {test_file_path}")
        return 1

    with open(test_file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    stats = _compute_stats(content)
    errors, warnings = _run_checks(content, stats)
    _print_results(errors, warnings, stats)

    if errors:
        return 1
    if warnings:
        return 2
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scripts/check-test-quality.py <test_file_path>")
        sys.exit(1)

    test_file_path = sys.argv[1]
    exit_code = check_test_quality(test_file_path)
    sys.exit(exit_code)
