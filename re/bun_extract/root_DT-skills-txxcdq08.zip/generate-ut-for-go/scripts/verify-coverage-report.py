#!/usr/bin/env python3
"""
Coverage report validation script for generate-ut-for-go skill.
Validates mathematical consistency, format correctness, and disclaimer presence.

Usage: python scripts/verify-coverage-report.py <coverage_report_path>

Exit codes:
  0: All validations passed
  1: Critical issues found (mathematical inconsistency, missing disclaimer)
  2: Format issues found (missing labels, wrong format)
"""

import sys
import re
import os

# ---------------------------------------------------------------------------
# Report parsing (one small extractor per field, driven by a single loop)
# ---------------------------------------------------------------------------

def _extract_line_total(line, line_lower, stats):
    if 'lines total' in line_lower or 'total executable lines' in line_lower:
        match = re.search(r'(\d+)', line)
        if match:
            stats['total_lines'] = int(match.group(1))


def _extract_covered_lines(line, line_lower, stats):
    if 'lines covered' in line_lower or 'covered lines' in line_lower:
        match = re.search(r'(\d+)', line)
        if match:
            stats['covered_lines'] = int(match.group(1))


def _extract_percentage(line, line_lower, stats):
    if 'coverage percentage' in line_lower or 'after' in line_lower:
        if 'estimated' in line_lower:
            stats['has_disclaimer'] = True
        match = re.search(r'(\d+\.?\d*)%', line)
        if match:
            stats['coverage_percentage'] = float(match.group(1))


def _extract_uncovered_label(line_lower, stats):
    if 'uncovered' in line_lower:
        stats['uncovered_label_present'] = True


def _extract_unreachable_count(line, line_lower):
    # If line says "None", unreachable_count = 0
    if 'none' in line_lower:
        return 0
    # Count comma-separated line numbers, or extract an explicit count
    nums = re.findall(r'\d+', line)
    if not nums:
        return None
    # Heuristic: if line contains an explicit "count=N" use that;
    # otherwise count the line numbers in the list.
    count_match = re.search(r'count\s*[:=]\s*(\d+)', line_lower)
    if count_match:
        return int(count_match.group(1))
    return len(nums)


def _extract_unreachable(line, line_lower, stats):
    if 'unreachable' in line_lower and 'excluded from denominator' in line_lower:
        count = _extract_unreachable_count(line, line_lower)
        if count is not None:
            stats['unreachable_count'] = count


def _parse_report(lines):
    stats = {
        'total_lines': None,
        'covered_lines': None,
        'coverage_percentage': None,
        'has_disclaimer': False,
        'uncovered_label_present': False,
        'unreachable_count': None,
    }
    for line in lines:
        line_lower = line.lower().strip()
        _extract_line_total(line, line_lower, stats)
        _extract_covered_lines(line, line_lower, stats)
        _extract_percentage(line, line_lower, stats)
        _extract_uncovered_label(line_lower, stats)
        _extract_unreachable(line, line_lower, stats)
    return stats


# ---------------------------------------------------------------------------
# Individual validations (each appends to errors/warnings; prints in order)
# ---------------------------------------------------------------------------

# Validation 1: Mathematical consistency — with unreachable denominator correction
def _validate_math_consistency(errors, total_lines, covered_lines, coverage_percentage, unreachable_count):
    if not (total_lines and covered_lines and coverage_percentage):
        return
    # Effective denominator = total - unreachable (if unreachable lines declared)
    if unreachable_count is not None and unreachable_count > 0:
        effective_total = total_lines - unreachable_count
        calculated_percentage = (covered_lines / effective_total) * 100 if effective_total > 0 else 0.0
        denom_note = f" [denominator corrected: {total_lines} total - {unreachable_count} unreachable = {effective_total} effective]"
    else:
        calculated_percentage = (covered_lines / total_lines) * 100
        denom_note = ""
    # Allow small rounding difference (0.1%)
    if abs(calculated_percentage - coverage_percentage) > 0.1:
        errors.append(f"CRITICAL: Mathematical inconsistency. Coverage percentage {coverage_percentage}% does not match calculated ({covered_lines}/{total_lines}{('- ' + str(unreachable_count) + ' unreachable') if unreachable_count else ''})*100 = {calculated_percentage:.1f}%{denom_note}")
    else:
        print(f"✅ Mathematical consistency verified: ({covered_lines}/{total_lines}{(' - ' + str(unreachable_count) + ' unreachable') if unreachable_count else ''})*100 = {calculated_percentage:.1f}%{denom_note}")


# Validation 1b: Unreachable count sanity (cannot exceed total, cannot be negative)
def _validate_unreachable_sanity(errors, unreachable_count, total_lines, covered_lines):
    if unreachable_count is None or total_lines is None:
        return
    if unreachable_count > total_lines:
        errors.append(f"CRITICAL: Unreachable line count ({unreachable_count}) exceeds total lines ({total_lines}). Denominator correction is invalid.")
    if unreachable_count > 0 and covered_lines is not None:
        # covered lines cannot exceed effective total
        effective_total = total_lines - unreachable_count
        if covered_lines > effective_total:
            errors.append(f"CRITICAL: Covered lines ({covered_lines}) exceed effective total ({effective_total} = {total_lines}-{unreachable_count}). Denominator correction is invalid.")


# Validation 1c: Unreachable lines require a reason (abuse guard)
def _validate_unreachable_reason(warnings, content, unreachable_count):
    if unreachable_count is None or unreachable_count <= 0:
        return
    has_reason = bool(re.search(r'\bU[1-5]\b|pattern\s*U|reason', content, re.IGNORECASE))
    if not has_reason:
        warnings.append("WARNING: Unreachable lines declared but no pattern reason (U1-U5) found. Every unreachable claim must cite a concrete pattern (Step 3 unreachable-line rule) to prevent inflating coverage.")


# Validation 2: Disclaimer for estimated coverage
def _validate_estimated_disclaimer(errors, warnings, content, has_disclaimer):
    has_estimated_label = re.search(r'\(estimated', content, re.IGNORECASE)
    has_verified_label = re.search(r'\(verified\)', content, re.IGNORECASE)
    # If estimated label found, check disclaimer
    if has_estimated_label:
        if 'go toolchain unavailable' in content.lower() or 'go unavailable' in content.lower():
            has_disclaimer = True
            print("✅ Estimated coverage disclaimer verified: (estimated - Go toolchain unavailable)")
        else:
            warnings.append("WARNING: Estimated coverage label found but missing reason disclaimer. Add: (estimated - Go toolchain unavailable)")
    # If verified label found, ensure it's NOT for estimated coverage
    if has_verified_label and has_estimated_label:
        errors.append("CRITICAL: Both (verified) and (estimated) labels found. Use (estimated) with disclaimer for estimated coverage, (verified) for actual measurement only.")
    return has_disclaimer


# Validation 3: Uncovered line numbers label
def _validate_uncovered_label(warnings, uncovered_label_present):
    if not uncovered_label_present:
        warnings.append("WARNING: Missing 'Uncovered line numbers:' label. Script requires 'uncovered' substring in line. Use exact label: 'Uncovered line numbers: line numbers or \"All lines covered\"'")
    else:
        print("✅ Uncovered line numbers label present")


# Validation 4: No PENDING values (use word-boundary regex to avoid false positives from identifiers like "XPending")
def _validate_no_pending(errors, content):
    pending_values = re.findall(r'\bPENDING\b|\bTBD\b|\b待定\b', content, re.IGNORECASE)
    if pending_values:
        errors.append(f"CRITICAL: PENDING values found ({len(pending_values)}). Coverage report must have numeric percentages with mathematical consistency.")


# Validation 5: Required fields present
REQUIRED_FIELDS = ['function:', 'before:', 'after:', 'lines total', 'lines covered', 'coverage percentage']


def _validate_required_fields(warnings, content):
    content_lower = content.lower()
    for field in REQUIRED_FIELDS:
        if field.lower() not in content_lower:
            warnings.append(f"WARNING: Missing required field '{field}'. Coverage report must include: Function, Before, After, Lines total, Lines covered, Coverage percentage, Uncovered line numbers")


# Validation 6: Coverage >= 90% (warning only)
def _validate_coverage_threshold(warnings, coverage_percentage):
    if coverage_percentage and coverage_percentage < 90.0:
        warnings.append(f"WARNING: Coverage {coverage_percentage}% below 90% threshold. Add tests for uncovered branches.")


# ---------------------------------------------------------------------------
# Orchestration / output / fix instructions
# ---------------------------------------------------------------------------

def _run_validations(content, stats):
    errors = []
    warnings = []
    _validate_math_consistency(errors, stats['total_lines'], stats['covered_lines'], stats['coverage_percentage'], stats['unreachable_count'])
    _validate_unreachable_sanity(errors, stats['unreachable_count'], stats['total_lines'], stats['covered_lines'])
    _validate_unreachable_reason(warnings, content, stats['unreachable_count'])
    stats['has_disclaimer'] = _validate_estimated_disclaimer(errors, warnings, content, stats['has_disclaimer'])
    _validate_uncovered_label(warnings, stats['uncovered_label_present'])
    _validate_no_pending(errors, content)
    _validate_required_fields(warnings, content)
    _validate_coverage_threshold(warnings, stats['coverage_percentage'])
    return errors, warnings


FIX_INSTRUCTIONS = [
    ("errors", "Mathematical inconsistency", [
        "- Recalculate coverage percentage:",
        "  percentage = (covered_lines / total_lines) * 100",
        "  Example: (37/40)*100 = 92.5%",
        "  Ensure header matches calculation exactly",
    ]),
    ("warnings", "disclaimer", [
        "- Add disclaimer for estimated coverage:",
        "  Coverage percentage: (M/N)*100 = YY.Y% (estimated - Go toolchain unavailable)",
        "  NEVER use (verified) label for estimated values",
    ]),
    ("warnings", "Uncovered line numbers", [
        "- Add uncovered line numbers section with exact label:",
        "  Uncovered line numbers: line numbers or \"All lines covered\"",
        "  Script checks for 'uncovered' substring in line_lower",
    ]),
    ("errors", "PENDING values", [
        "- Replace PENDING/TBD with numeric values:",
        "  Calculate actual percentage with formula",
        "  Use estimated values with disclaimer if Go unavailable",
    ]),
    ("warnings", "below 90%", [
        "- Add tests for uncovered branches:",
        "  Identify uncovered lines from coverage report",
        "  Generate tests with mock injection and observable verification",
        "  Iterate until coverage >= 90%",
    ]),
]


def _marker_in(marker, haystack):
    if isinstance(marker, tuple):
        return any(m in haystack for m in marker)
    return marker in haystack


def _print_fix_instructions(errors, warnings):
    issues = {'errors': str(errors), 'warnings': str(warnings)}
    for target, marker, instruction_lines in FIX_INSTRUCTIONS:
        if _marker_in(marker, issues[target]):
            for line in instruction_lines:
                print(line)


def _print_results(errors, warnings, stats):
    print("=" * 80)
    print("COVERAGE REPORT VALIDATION RESULTS")
    print("=" * 80)

    if errors:
        print("\nCRITICAL ERRORS (must fix):")
        for error in errors:
            print(f"  ❌ {error}")

    if warnings:
        print("\nWARNINGS (should fix):")
        for warning in warnings:
            print(f"  ⚠️  {warning}")

    if not errors and not warnings:
        print("\n✅ OK - Coverage report passes all validation checks")
        print(f"  - Total lines: {stats['total_lines']}")
        print(f"  - Covered lines: {stats['covered_lines']}")
        print(f"  - Coverage percentage: {stats['coverage_percentage']}%")
        print(f"  - Mathematical consistency: verified")
        print(f"  - Uncovered label: present")
        print(f"  - Disclaimer: {stats['has_disclaimer']}")
        return

    print("\n" + "=" * 80)
    print("FIX INSTRUCTIONS:")
    print("=" * 80)
    _print_fix_instructions(errors, warnings)


def verify_coverage_report(coverage_report_path):
    """Validate coverage report format and mathematical consistency."""
    if not os.path.exists(coverage_report_path):
        print(f"ERROR: Coverage report not found: {coverage_report_path}")
        return 1

    with open(coverage_report_path, 'r', encoding='utf-8') as f:
        content = f.read()

    stats = _parse_report(content.split('\n'))
    errors, warnings = _run_validations(content, stats)
    _print_results(errors, warnings, stats)

    if errors:
        return 1
    if warnings:
        return 2
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scripts/verify-coverage-report.py <coverage_report_path>")
        sys.exit(1)

    coverage_report_path = sys.argv[1]
    exit_code = verify_coverage_report(coverage_report_path)
    sys.exit(exit_code)
