# Test Patterns: Observable Verification, Table-Driven, Business Rules, Mock Helpers

## Error Content Verification

Error-path tests MUST verify the specific error content using `strings.Contains(err.Error(), expected)` or `errors.Is(err, target)`. Bare `err != nil` checks are insufficient — they can pass even when the wrong error is returned.

```go
// WRONG: Bare err != nil
if err == nil { t.Fatal("expected error") }

// CORRECT: Verify error content
if err == nil || !strings.Contains(err.Error(), "expected substring") {
    t.Fatalf("expected error containing 'expected substring', got %v", err)
}

// CORRECT: Type assertion
if !errors.Is(err, context.Canceled) {
    t.Fatalf("expected context.Canceled, got %v", err)
}
```

## Success-Path Output Verification

Success-path tests MUST verify at least one non-error output property — not just `err == nil`. This applies especially to functions that mutate output parameters or aggregate data.

```go
// WRONG: Only checking err == nil
if err != nil { t.Fatal(err) }

// CORRECT: Verify output correctness
if err != nil { t.Fatal(err) }
if output.Value != "expected" { t.Errorf("output.Value = %q, want %q", output.Value, "expected") }
```

For functions that mutate an output parameter (e.g., `cmd`), verify the mutated state after the call, not just that no error was returned.

## Dual-Path Error Testing

When a function has both typed error checks (e.g., `errors.Is`, type-assertion-based checks) and string-prefix fallback checks, tests MUST cover BOTH paths:

1. **Typed errors** via typed constructors — exercises the typed check path
2. **Plain string errors** via `errors.New()` — exercises the string-prefix fallback path

```go
// Typed path test
result := targetFunc(typedError)
if !result { t.Error("expected true for typed error") }

// String fallback path test
result = targetFunc(errors.New("error message"))
if !result { t.Error("expected true for string fallback") }
```

String-prefix fallback branches exist for backward compatibility and are NOT unreachable — they must be tested independently.

## Observable Verification Patterns

### Pattern 1: int callCount (prefer over boolean flags)

```go
type mockDependency struct {
    callCount int  // or atomic.Int32 for concurrent tests
}
func (m *mockDependency) Method(ctx context.Context) (Result, error) {
    m.callCount++
    return Result{}, nil
}
// Assert: if m.callCount != 1 { t.Errorf("callCount = %d, want 1", m.callCount) }
```

### Pattern 2: capturedReq/capturedRes/capturedCtx for field verification

```go
var capturedCtx context.Context
sf.onUpdate = func(ctx context.Context) {
    capturedCtx = ctx
}
// Assert: if capturedCtx != expectedCtx { t.Errorf("context mismatch") }
```

### Pattern 3: strings.Contains for error content verification (prefer over bare err!=nil)

```go
if err != nil && !strings.Contains(err.Error(), "expected substring") {
    t.Fatalf("unexpected error: %v", err)
}
```

For success-path tests, `if err != nil { t.Fatalf("unexpected: %v", err) }` is acceptable — no need to verify error content when no error is expected.

### Pattern 4: atomic.LoadInt32 before/after for counters

```go
var callCount atomic.Int32
before := callCount.Load()
result := targetFunc(ctx)
after := callCount.Load()
if after-before != 1 { t.Errorf("callCount delta = %d, want 1", after-before) }
```

### Pattern 5: spyLogger with int errorLogCalls field for panic recovery

```go
type spyLogger struct {
    errorLogCalls int
}
func (l *spyLogger) Printf(format string, v ...interface{}) {
    l.errorLogCalls++
}
```

### Pattern 6: var _ Interface = &mockStruct{} (for every interface mock)

```go
type mockDependency struct {
    onCall func(string) string
}
var _ DependencyInterface = &mockDependency{}  // Compile-time interface check
```

### Pattern 7: t.Helper() for mock helper functions

```go
func newTestTarget(t *testing.T, opts ...Option) *TargetType {
    t.Helper()
    // ... setup
}
```

## Table-Driven Tests

Use table-driven tests for error collection, validation, or parameter variation scenarios:

```go
func TestFunction_InvalidInputs(t *testing.T) {
    tests := []struct {
        name    string
        input   interface{}
        wantErr string
    }{
        {"nil input", nil, "nil"},
        {"wrong type", 42, "wrong type"},
        {"empty string", "", "empty"},
    }
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            err := targetFunc(tt.input)
            if err == nil || !strings.Contains(err.Error(), tt.wantErr) {
                t.Errorf("expected error containing %q, got %v", tt.wantErr, err)
            }
        })
    }
}
```

## Business Rule Testing

### MultiError handling
Test that error collection aggregates multiple errors and returns them via `.Errors()` or similar.

### Enum boundaries
Test valid range (min, max, just inside) + invalid range (below min, above max).

### State transitions
Test each valid transition path + invalid transition (should return error or no-op).

## Recommended Patterns Summary

| Pattern | When | Enforcement |
|---------|------|-------------|
| `int callCount` over boolean flags | Observable mock verification | Recommended |
| `sync.WaitGroup` over `time.Sleep` | Goroutine synchronization | Recommended |
| `strings.Contains(err.Error())` over bare `err!=nil` | Error content verification | Required for error-path tests |
| Verify output correctness, not just `err==nil` | Success-path tests | Required |
| Dual-path testing (typed + string fallback) | Error handlers with fallback | Required when both paths exist |
| `var _ Interface = &mockStruct{}` | Every interface mock | Recommended |
| `atomic.Int32` for concurrent counters | Concurrent gomonkey closures | Required when concurrent |
| `t.Helper()` for mock helpers | Mock setup functions | Recommended |
