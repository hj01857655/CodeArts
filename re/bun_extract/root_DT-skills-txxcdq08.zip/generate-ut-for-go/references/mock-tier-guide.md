# Mock Tier Guide: Feature Decision Matrix + Tier Selection + gomonkey

## Feature Decision Matrix (F1-F13)

| # | Dependency feature | Detect signal | Level | Post-hoc root-cause (Step 2.7) |
|---|---|---|---|---|
| F1 | Internal state loading | state-loading method call + state struct same-package (e.g., `c.state.Get`, `loadXxx`) | **L1** | State/config dependency |
| F2 | Dependency is interface type | param/field type is `interface` OR project has `fakeXxx` | **L2** | Error-return branch (stubbable via interface) |
| F3 | Struct has func/interface fields | `func(...)` field, `SomeInterface` field (e.g., `onUpdate func(...)`, `nowFunc func()`) | **L3** | Function-field dispatch |
| F4 | Routing predicate IN target body + err from protocol/parser | target body has error-type-check + parser-error switch (e.g., `isXxxError`, `shouldRetry`, HTTP-status switch) | **L4** | Routing predicate in target body |
| F5 | Concrete-type public method, no interface/field, NON-routing | `reflect.TypeOf(&X{})` + method name, no `interface` indirection | **L5** | Patch-capability gap |
| F7 | Embedded type inherited method | method on embedded `*baseType`, not `*TargetType` | **L5** | Patch-capability gap (patch BASE type) |
| F8 | Missing test case (no dependency issue) | Branch reachable with current mocks but no test written | **—** | Missing test case (write test, no tier change) |
| F9 | Unreachable defensive code | Post-nil-check recheck / mutually-exclusive / constant-false | **—** | Unreachable (exclude from denominator) |
| F10 | Connection-pool callback pattern | target body has connection-acquisition-with-callback (e.g., `c.withConn(ctx, func(...) {...})`) | **L5** | Connection-pool callback |
| F11 | Reader/decoder parameter | target function takes `*Reader`, `*Decoder` or calls `r.ReadLine()`/`r.Decode()` | **L5** | Reader-based branch |
| F12 | Package-level factory function in goroutine/loop | `NewXxx()`/`XxxClient()` called inside `go func()` or `for` loop | **L5** | Factory-function patch (ApplyFunc) |
| F13 | Unexported method on same-package struct | `c.privateMethod()`, `c.internalXxx()` | **L5** | Use `gomonkey.ApplyPrivateMethod` |

## Decision Procedure

1. **Scan**: For each dependency, read type signature + usage. Check F1→F13 top-down. First match wins.
2. **Locate**: Matched Level = tier for that dependency. Record: `dependency → Fx → Lx`.
3. **Generate**: Write tests using located tier. Mock injection BEFORE target call.
4. **Verify**: Measure coverage. >90% → done. ≤90% → Step 2.7 per-line attribution.

## Tier Definitions

### L1 — Pre-constructed state / real pure logic (lowest cost)
Directly construct the correct internal state to bypass state-loading methods, OR use the real implementation for pure logic with no side effects. Frequently sufficient alone for 100% coverage.

### L2 — Interface mock
Implement a fake struct satisfying the dependency interface. Lowest cost for stubbing error returns.

### L3 — Struct field injection
Inject mock implementations via struct field assignment (`sf.callback = mockFunc`). Bypasses gomonkey entirely, goroutine-safe.

### L4 — Fake Protocol Server (CONDITIONAL — only for F4 routing-predicate gaps)
Launch a local TCP server via `net.Listen("tcp", "127.0.0.1:0")` that speaks the target protocol. Escalate to L4 ONLY when: (a) a target-body line is uncovered, AND (b) Step 2.7 attributes it to a routing predicate that inspects an error from the protocol parser. Do NOT mandate L4 for network-client functions whose routing logic lives in a DOWNSTREAM private method.

### L5 — gomonkey patch
**Role A — Direct-located baseline tier**: When matrix matches F5, F7, F12, or F13 → L5 IS the baseline tier. Proceed to Step 1.3 gomonkey availability probe, then generate L5 tests directly.

**Role B — Supplementary tier**: When matrix located L1-L4 but Step 2.7 attributes an uncovered line to a patch-capability gap (F5/F7 post-hoc), THEN L5 supplements the lighter tier. L5 is forbidden for error-routing branches on network clients (those use L4).

API selection:
- `gomonkey.ApplyPrivateMethod` — unexported methods (PREFERRED for same-package internals)
- `gomonkey.ApplyMethod` — exported methods on concrete types
- `gomonkey.ApplyFunc` — package-level functions

"Concrete type, not interface" is NOT "unmockable" — gomonkey's purpose is patching concrete-type methods.

## Tier Simplicity Rule

Lower tier number does not always mean simpler implementation. When both L1/L3 and L5 can achieve the same coverage, prefer the approach that requires less test infrastructure and is more reliable:

- **L5 is simpler when**: The target already uses gomonkey for other methods (consistency), or the dependency can be patched with a single `ApplyMethod`/`ApplyPrivateMethod` call vs. constructing hook-injected client instances with multiple setup steps.
- **L1/L3 is simpler when**: The dependency is a pure config field or interface that can be set with one assignment.

Example: For `Client.Execute` in a concurrent test, `gomonkey.ApplyMethod` (L5) is simpler than hook-based initialization (L1) because it avoids constructing hook-injected client instances, managing channel draining in aggregate mocks, and using atomic counters for method call tracking.

## Dependency Traversal (Step 1.1)

**Trigger**: Target function calls private methods with external dependencies.

**Pre-filter**: Classify each private method:
- **Class A — Pure internal logic** (no external deps): Skip traversal, covered naturally.
- **Class B — Contains external deps** (DB, HTTP, network, goroutine side effects): Proceed with traversal.

For each Class B method:
1. Expand call chain, classify each internal call:
   - Public method on exported type → patchable via `gomonkey.ApplyMethod`
   - Inherited method from embedded type → patch the BASE type
   - Still private → recurse until reaching public methods
   - Stdlib / requires real connection → terminal with alternative strategy (L4, L3, L1)
2. Generate traversal map. No terminal call may be marked "unpatchable" without a recovery strategy.

**Decision shortcut**: If ALL private method calls are Class A → skip Step 1.1 entirely.

## gomonkey on Windows

Use `-gcflags=all=-l` on ALL `go test` commands when gomonkey is used — without it, patches silently fail due to inlining. No CGO/MinGW needed (verified gomonkey v2.14.0 + Go 1.24, Windows/amd64).

| Build flag | gomonkey compatibility |
|------------|------------------------|
| (none, default) | Inlining causes silent patch failure |
| `-gcflags="all=-l"` | Recommended — disables inlining only |
| `-gcflags="all=-N -l"` | `-N` breaks symbol matching, do NOT combine |
| `CGO_ENABLED=0` | Pure-Go mode, gomonkey completely unusable |
| `CGO_ENABLED=1` + gcc + `-l` | Full gomonkey support on Windows |

**gomonkey API for unexported methods**:
```go
patches := gomonkey.ApplyPrivateMethod(reflect.TypeOf(&TargetType{}), "privateMethod",
    func(_ *TargetType) ReturnType { return mockValue })
defer patches.Reset()
```

## Probe Test Pattern (feature-ambiguous dependencies only)

```go
func TestProbeDependency(t *testing.T) {
    sf := &TargetStruct{}
    _ = sf.TargetFunc(ctx)
}
```
Run `go test -gcflags=all=-l -run TestProbeDependency -count=1`. After disambiguation, DELETE TestProbeDependency.

## L4 Completeness Check (only when L4 was escalated to)

For EACH error-routing branch in the TARGET function body, verify at least one test drives it via a fake-server raw protocol error frame — NOT a gomonkey-returned `errors.New`. `errors.New("PROTOCOL_ERROR")` is a plain `*errors.errorString` — the type-check predicate (e.g., `isXxxError`) returns false. The fake server must return the raw protocol error frame that the parser recognizes.

## Tier Escalation Rule

When coverage ≤90% after using lighter tiers (L1-L3), escalate to L5 (gomonkey) for uncovered branches BEFORE classifying them as unreachable. The >90% coverage hard constraint takes priority over tier preference.

## Dispatcher Patching Pattern

When the target function is a **dispatcher** (switch/case or if/else chain routing to private methods), directly patch those private methods via `gomonkey.ApplyPrivateMethod` — NOT lower-level methods they call internally.

**Why**: Patching the dispatched method directly is simpler, more reliable, and produces correct assertions. Patching lower-level methods creates a mismatch between what the test asserts and what the mock actually returns, leading to failed assertions and fix cycles.

**Example** — `dispatchRequest` routes to `handleDefault`, `handleBatch`, etc.:
```go
// CORRECT: Patch the dispatched methods directly
patches := gomonkey.ApplyPrivateMethod(
    reflect.TypeOf(&DispatcherType{}), "handleDefault",
    func(_ *DispatcherType, ctx context.Context, request RequestType) error {
        return nil
    },
)

// WRONG: Patching a lower-level, indirect method
patches := gomonkey.ApplyMethod(
    reflect.TypeOf(&BaseType{}), "Execute",
    func(_ *BaseType, request RequestType) error { ... },
)
```

## Type-Assertion Dispatch Pattern

When the target function uses a **type assertion** (e.g., `if concreteObj, ok := obj.(*ConcreteType)`) to dispatch to different methods, do NOT create a mock struct implementing the interface to test the ConcreteType-specific path.

**Why**: The type assertion will fail for the mock struct (it's not `*ConcreteType`), causing the test to exercise the wrong branch. The test may pass and report coverage, but the intended branch is not actually tested.

**Correct approach**: Use `gomonkey.ApplyMethod` on the ConcreteType's method directly so the type assertion succeeds and the correct branch is exercised.

```go
// CORRECT: Patch the method on the concrete type
patches := gomonkey.ApplyMethod(
    reflect.TypeOf(&ConcreteType{}), "ConcreteMethod",
    func(_ *ConcreteType, ...) error {
        return errors.New("test error")
    },
)

// WRONG: Creating a mock struct that implements the interface
type mockErrorImpl struct { SomeInterface }
// The type assertion obj.(*ConcreteType) FAILS for mockErrorImpl
```

## Intermediate Argument Verification Pattern

When expectations require verifying **arguments passed to a downstream method** (not just final output), escalate to L5 interception for that method — even if L1 achieves coverage.

**Why**: L1 can achieve coverage by letting the real downstream method run, but it cannot intercept and verify the arguments the target passes to it. L5 interception lets you assert intermediate state.

**Example** — `processResults` calls `aggregateByKey`:
```go
// L5 interception verifies keyGroup and order arguments
patches := gomonkey.ApplyPrivateMethod(
    reflect.TypeOf(c), "aggregateByKey",
    func(_ *TargetType, keyGroup map[string]*Result, order []string) error {
        // Verify intermediate arguments
        if keyGroup["key1"].Value != "val1" {
            t.Errorf("unexpected keyGroup")
        }
        return nil
    },
)
```

## Embedded-Type Patching

When a method is inherited from an embedded type (F7), patch the BASE type, not the derived type:

```go
// WRONG: Patching derived type
patches := gomonkey.ApplyPrivateMethod(
    reflect.TypeOf(&DerivedType{}), "inheritedMethod", ...)

// CORRECT: Patching base type where method is defined
patches := gomonkey.ApplyPrivateMethod(
    reflect.TypeOf(&BaseType{}), "inheritedMethod", ...)
```

Identify the base type by searching for the method definition: `grep -r "func (c *BaseType) inheritedMethod"`.

## Code Feature → Reference Mapping

| Feature | Detection signal | Action |
|---------|-----------------|--------|
| Connection-pool callback | target body has connection-acquisition-with-callback (e.g., `c.withDependency(ctx, func(...) {...})`) | F10 → L5 ApplyPrivateMethod on callback method |
| Reader/decoder param | `rd.ReadLine()`/`rd.Decode()` | F11 → L5 bytes.Buffer-based reader |
| Factory in goroutine/loop | `NewXxx()` in `go func()`/`for` | F12 → L5 ApplyFunc returns fake struct |
| Embedded type | struct embeds `*anotherType` | F7 → L5 patch BASE type |
| Goroutine in private method | `go` in unexported method | WaitGroup > context > Gosched+sleep |
| Time dependency | time.Now/time.Since | Inject `nowFunc` field if available |
| Dispatcher function | switch/case routing to private methods | L5 ApplyPrivateMethod on dispatched methods |
| Intermediate arg verification | Need to verify args passed to downstream call | L5 interception on downstream method |
| Type-assertion dispatch | `if x, ok := obj.(*ConcreteType)` | L5 ApplyMethod on ConcreteType directly |
