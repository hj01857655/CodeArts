# Coverage Measurement Guide

## Commands

### Windows (PowerShell)

```powershell
# Measure coverage (space-separated flags, .txt extension)
go test -gcflags=all=-l -coverprofile cov.txt -run TestFuncName -count=1

# View function-level coverage
go tool cover "-func=cov.txt" | Select-String "FuncName$"

# View line-level coverage
go tool cover "-html=cov.txt" -o coverage.html
```

### Unix (bash)

```bash
# Measure coverage
go test -gcflags=all=-l -coverprofile=cov.txt -run TestFuncName -count=1

# View function-level coverage
go tool cover -func=cov.txt | grep -E "FuncName$"
```

## Windows Quirks

1. **Use space-separated flags**: `go test -coverprofile cov.txt` (space) NOT `go test -coverprofile=cov.out` (=). PowerShell parses `=` differently.
2. **Never use `.out` extension**: Use `.txt` or `.cov` instead. PowerShell may interpret `.out` as a package path.
3. **`Select-String` with `$` anchor**: Required to match function name at end-of-line so `doWork` does NOT also match `doWorkAll`.

## Coverage Boundary Rule

The >90% target applies to the **TARGET function body only** — the function explicitly named in the user prompt, NOT its downstream private callees. `go tool cover -func` reports each function separately; extract ONLY the target function's row.

**90.0% is NOT sufficient.** Coverage must strictly exceed 90%. If measured at exactly 90%, continue generating tests to push above the threshold. Do not stop at the boundary.

## Attribution Table Format (required at ALL coverage levels)

```
Attribution table for FunctionName (file.go:start-end):
  L<line#>     -> F<x>/L<x> -- <tier + test name that covers it>
  L<line#>     -> U<x> (<one-sentence reason>) -- excluded from denominator
```

Example:
```
Attribution table for TargetFunction (target.go:100-200):
  L101-103 -> F1/L1 -- state-check path, covered by TestTargetFunction_ValidState
  L108     -> F13/L5 -- privateMethod patched (ApplyPrivateMethod), TestTargetFunction_SuccessPath
  L150     -> U1 (mutually exclusive with L148 path) -- excluded from denominator
```

## coverage_report.txt Template

```
Function: FunctionName (<file_path>)
Before: 0.0%
After: YY.Y%
Lines total: N
Lines covered: M
Coverage percentage: (M/N)*100 = YY.Y% (verified)
Uncovered line numbers: line numbers or "All lines covered"
Unreachable lines (excluded from denominator): line numbers + reason, or "None"
Attribution table (Step 2.7 — required audit artifact):
  L<line#> -> F<x>/L<x> -- <tier + test name that covers it>
  L<line#> -> U<x> (<one-sentence reason>) -- excluded from denominator
```

## Unreachable Line Patterns

| ID | Pattern | Example |
|---|---|---|
| U1 | Mutually exclusive paths | `if x > 0 { return } ... if x <= 0 {` — second condition unreachable after first return |
| U2 | Post-nil-check recheck | `if err != nil { return } ... if err != nil {` — unreachable after early return |
| U3 | Constant-false condition | `if false {` or `if 1 == 0 {` |
| U4 | Defensive code after exhaustive switch | `default:` case in switch where all cases are handled |
| U5 | Unreachable after panic/fatal | Code after `t.Fatal()` or `log.Fatal()` |

When unreachable lines are identified, exclude them from the coverage denominator and document the reason in the attribution table.

## Unreachable Escalation Rule

Before classifying any line as unreachable (U1-U5), write a minimal probe test to verify the line cannot be reached. If the probe shows the line IS reachable, write a proper test case instead.

This applies especially to:
- **String-prefix fallback branches** in error-handling functions — these exist for backward compatibility with non-typed errors and are NOT unreachable by default. Test with plain `errors.New()` values, not typed error constructors.
- **Conditional callback blocks** inside error-handling paths — these are easy to miss but contribute to coverage gaps.

## Coverage Gap Attribution (Step 2.7)

When coverage ≤90% on target function body:

1. Generate line-level coverage, list UNCOVERED line numbers in target body.
2. Filter to target body only (ignore downstream private methods).
3. Per-line attribution using F1-F13 matrix (see `references/mock-tier-guide.md`).
4. Apply fixes in cost order: F8 (missing test) + L1/L2/L3 first. Only if still ≤90%, escalate L4 for F4, L5 for F5/F7.
5. Do not classify a coverable branch as unreachable if gomonkey injection could cover it — escalate to L5 first.
6. Re-measure after each batch. Repeat until >90% or all lines covered/attributed-unreachable.

**Attribution→action mapping**:
- **F8** (Missing test case) → write test with CURRENT tier, no tier change
- **F1** (State/config dependency) → L1: pre-construct state / set config field
- **F2** (Error-return branch) → L2: interface stub returns error
- **F3** (Function-field dispatch) → L3: inject `c.field = mockFn`
- **F4** (Routing predicate in target body) → L4: fake server raw protocol frame
- **F5/F7** (Patch-capability gap) → L5: gomonkey.ApplyMethod
- **F9** (Unreachable) → exclude from denominator
