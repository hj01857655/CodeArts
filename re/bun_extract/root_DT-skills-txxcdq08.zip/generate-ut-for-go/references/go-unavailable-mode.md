# Go-Unavailable Mode Workflow

## Trigger Conditions

Go-unavailable mode activates when:
- `go version` command fails (exit code non-zero)
- `go version` command times out (>30s)
- `go version` shows "downloading goX.Y.Z" without completion

**CRITICAL**: Do NOT attempt go.mod edits, GOTOOLCHAIN changes, GOPROXY modifications, or multiple retry attempts. Immediately accept Go unavailable and proceed with estimation workflow.

## Go Availability Decision Gate

```
Run `go version` with 30s timeout:
  IF exit code 0:
    → Go available → MUST attempt test execution
    → IF tests fail: fix compilation errors, NOT use estimated coverage
    → Use ACTUAL coverage measurement from go tool cover
  ELSE IF exit code non-zero OR timeout:
    → Go unavailable → Use ESTIMATED coverage workflow (this document)
```

**Common mistake**: Misinterpreting "tests failed" as "Go unavailable".
- `go version` exit 0 + tests fail → Go available → fix errors → actual coverage
- `go version` exit non-zero → Go unavailable → estimated coverage

## Step 1: Immediate Skeleton Write

After confirming Go unavailable, immediately Write test file skeleton. If no test file on disk after Step 1, Write skeleton NOW.

## Step 2: Systematic Test Generation

Follow Step 2 from SKILL.md. Key differences when Go unavailable:
- Tests cannot be executed, so focus on correct mock patterns and observable verification
- Cannot validate coverage via `go test -coverprofile` — use manual estimation

## Step 3: Coverage Estimation

1. **Count executable lines**: Read target function source, exclude comments/blank lines/type declarations, include if/else branches, for loops, function calls, assignments, returns.
2. **Map each line to test**: Create table: Line number → Test name → Coverage status. Verify each claimed covered line has observable test evidence.
3. **Calculate coverage percentage**: `percentage = (covered_lines / total_executable_lines) * 100`
4. **Write coverage_report.txt** with MANDATORY disclaimer `(estimated - Go toolchain unavailable)`.

**Tier escalation in estimation mode**: Enumerate ALL branches → apply F1-F13 matrix statically to each branch. Write tests for ALL enumerated branches first, escalate tier only for F4/F5/F7 inherent gaps.

## gomonkey-Unavailable Sub-Mode (Go Available + gomonkey Cannot Be Used)

### Trigger Conditions

- go.mod lacks gomonkey AND `go get` fails
- gomonkey fails to compile on current platform
- gomonkey patches cause persistent race conditions

### Fallback Strategies (in priority order)

1. **L4 — Fake Protocol Server** (PREFERRED for network clients): Launch local TCP server with `net.Listen("tcp", "127.0.0.1:0")` + protocol handler. Cross-platform, goroutine-safe, observable.
2. **L3 — Struct field injection via export_test.go**: Inject mock implementations via struct field assignment.
3. **L1 — Pre-constructed state**: Directly construct correct internal state rather than patching the state loader.
4. **Lightweight fake implementation**: Create minimal fake struct with nil embedded fields.
5. **Test boundary narrowing**: Call target function but truncate unstable goroutine paths at patch boundary.

### Coverage Measurement

Since Go IS available, use real coverage measurement — do NOT fall back to estimation. Write coverage_report.txt with `(verified)` label, NO estimated disclaimer.

### Critical Distinction

| Aspect | Go Unavailable | gomonkey Unavailable (Go available) |
|--------|---------------|-------------------------------------|
| `go version` | fails/times out | exits 0 |
| `go test` | cannot run | CAN run |
| Coverage | ESTIMATED | ACTUAL (`go test -coverprofile`) |
| Disclaimer | `(estimated - Go toolchain unavailable)` | NONE — use `(verified)` |
