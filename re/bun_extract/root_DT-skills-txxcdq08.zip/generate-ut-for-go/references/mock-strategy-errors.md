# Common Mock Strategy Errors

| Symptom | Root cause | Fix |
|---------|-----------|-----|
| `panic: reflect: Call of zero Value` | gomonkey patch target is nil (wrong `reflect.TypeOf` receiver) | Use `reflect.TypeOf(&Struct{})` not `reflect.TypeOf(Struct{})` |
| `panic: reflect.Set: value of type X not assignable to type Y` | Mock function return type doesn't match original | Check original method signature: return exact types |
| Mock callCount always 0 | Patch applied on wrong type (derived vs embedded) or method name typo | Verify method defined on target type: grep `func (c *TargetType) MethodName` |
| 0% coverage despite tests passing | Mock intercepts wrong call path | Trace actual call path in target body; patch the method the target ACTUALLY calls |
| `cannot use type as type` compile error | Interface mock missing required method | Add ALL interface methods to fake struct; add `var _ Interface = &fakeStruct{}` |
| Tests pass but flaky/race detector fails | gomonkey patch + goroutine race window | Apply goroutine-internal patches BEFORE goroutine-launching patches; use `t.Cleanup` LIFO order; use `atomic.Int32` for shared state |
| `gomonkey.ApplyMethod` silently doesn't patch | Method is inlined by compiler | Add `-gcflags=all=-l` to all `go test` commands |
| Coverage stuck at 60-70% on network function | Error-routing branches dead (gomonkey stub error bypasses protocol parser) | Use L4 fake server returning raw protocol error frame |
| `nil pointer dereference` on target call | Struct not fully constructed (missing embedded/base fields) | Construct ALL embedded structs; verify field path by reading struct definition |
| Test compiles but target function not called | Helper function bypasses target (violates Public Entry Principle) | Remove helper; call target function directly |
| `retrieve method by name failed` panic | Using `ApplyMethod` on unexported method | Check if method name starts with lowercase → use `ApplyPrivateMethod` instead |
| Type assertion fails in test (`ok` is false) | Mock struct doesn't satisfy type assertion `obj.(*ConcreteType)` | Use `gomonkey.ApplyMethod` on ConcreteType directly instead of creating mock struct |
| `callCount == 0` in concurrent test | Channel not drained in mock; goroutines haven't completed | Add `for range results {}` in channel-consumer mock to drain before assertions |
| `unknown field 'X' in struct literal` | Incorrect struct field path due to embedding | Read struct definition first; use `Derived{Base: &Base{X: ...}}` not `Derived{X: ...}` |

## Error Recovery Patterns

### gomonkey Instability Fallback

When gomonkey patches cause persistent test failures (race conditions, flaky behavior):

1. **First attempt**: Fix the specific issue (add atomic/mutex, reorder patches, use `t.Cleanup`).
2. **Second attempt**: If still failing, try `gomonkey.ApplyPrivateMethod` instead of `ApplyMethod` (different patch mechanism).
3. **Fallback**: If gomonkey remains unstable, replace with lighter tier:
   - L3 struct field injection for function/interface fields
   - L1 pre-constructed state for pure-logic dependencies
   - L4 fake server for network-client functions

### Progressive Repair Strategy

When tests fail repeatedly:
1. **Round 1** (5 min max): Fix compile errors, verify mock injection, check call path.
2. **Round 2** (5 min max): Verify patch targets (correct type, correct method name, correct receiver).
3. **Round 3**: If still failing, apply gomonkey Instability Fallback above.

### assertNoError Helper Pattern

For satisfying err!=nil verification in success-path tests:

```go
func assertNoError(t *testing.T, err error, msg string) {
    t.Helper()
    if err != nil {
        t.Fatalf("%s: %v", msg, err)
    }
}
```

This is cleaner than adding redundant `strings.Contains` checks for success-path tests where no error is expected.
