# Concurrent Safety, Goroutine Lifecycle, and Concurrent Test Patterns

## Simplicity First

When both L1/L3 (hooks, field injection) and L5 (gomonkey) can achieve the same coverage, prefer the approach that requires **less test infrastructure**. `gomonkey.ApplyMethod` on the target's core method is simpler than hook-based initialization when the target already uses gomonkey for other methods (consistency). Lower tier number does NOT always mean simpler implementation.

For L1 targets with <5 branches, prefer simple single-waiter tests over multi-waiter concurrent tests. Complex concurrent test scaffolding should only be used when the target function itself has concurrent dispatch logic.

## Critical Rule: Thread-Safe Shared State in gomonkey Closures

When using gomonkey patches in tests for concurrent target functions, ALL mutable state in the patch callback MUST be protected by `sync.Mutex`, `sync/atomic`, or channel-based collection. Never append to a plain slice or increment a plain int from a gomonkey callback that may be called concurrently.

### Why

gomonkey patches replace methods globally. If the target function calls the patched method from multiple goroutines, the callback executes concurrently, causing DATA RACES detectable by `go test -race`.

### Wrong Pattern (DATA RACE)

```go
callCount := 0
gomonkey.ApplyPrivateMethod(target, "someMethod", func(_ *TargetType) error {
    callCount++  // DATA RACE: plain int incremented concurrently
    return nil
})
```

### Correct Pattern (atomic.Int32)

```go
var callCount atomic.Int32
gomonkey.ApplyPrivateMethod(target, "someMethod", func(_ *TargetType) error {
    callCount.Add(1)  // Thread-safe
    return nil
})
// Assert:
if got := callCount.Load(); got != expected {
    t.Errorf("callCount = %d, want %d", got, expected)
}
```

### Correct Pattern (sync.Mutex for slice collection)

```go
var mu sync.Mutex
var captured []string
gomonkey.ApplyPrivateMethod(target, "someMethod", func(_ *TargetType) error {
    mu.Lock()
    captured = append(captured, "item")
    mu.Unlock()
    return nil
})
```

## Concurrent Test Trigger Conditions

Generate `TestFunction_ConcurrentCalls` ONLY when the target function body:
- Directly uses `sync.Mutex` or `sync.RWMutex`
- Modifies shared state (maps, slices with append)
- Iterates with `range` over shared collections

Calling methods on objects that could theoretically be shared does NOT qualify. When in doubt, skip the concurrent test.

## -Race Detection Gate

After all tests pass without `-race`, run:

```
go test -gcflags=all=-l -race -run TestFuncName -count=1
```

ALL tests must pass with `-race`. If any race is detected:
1. Identify the race source (shared variable in gomonkey closure, or shared test state).
2. Convert plain variables to `atomic.Int32` or protect with `sync.Mutex`.
3. Re-run `-race` to confirm fix.

## Channel-Draining Pattern

When mocking functions that consume from channels produced by goroutines in the target, drain the channel before returning to prevent goroutine leaks and assertion races:

```go
// In mock implementation for a channel consumer:
func(c *TargetType, ctx context.Context, request RequestType, results <-chan ResultType, ...) error {
    for range results {}  // Drain channel — ensures all producer goroutines complete
    return nil
}
```

Without draining, goroutines from the target may still be running when assertions execute, causing:
- `callCount == 0` failures (goroutine hasn't reached the patched method yet)
- Cross-test interference (goroutines from previous tests still active)
- DATA RACE reports from `-race` detector

## Goroutine Lifecycle Priority

When target function launches goroutines:
1. **Priority 1**: `sync.WaitGroup` — inject WaitGroup, wait for goroutine completion
2. **Priority 2**: `context.WithCancel` — cancel context to signal goroutine exit
3. **Priority 3**: `runtime.Gosched() + time.Sleep(100ms)` — ONLY for uncontrollable private-method goroutines where WaitGroup cannot be injected

### WaitGroup Pattern for Concurrent Tests

```go
func TestFunction_ConcurrentCalls(t *testing.T) {
    var wg sync.WaitGroup
    var callCount atomic.Int32

    patches := gomonkey.ApplyPrivateMethod(
        reflect.TypeOf(&TargetType{}), "someMethod",
        func(_ *TargetType) error {
            callCount.Add(1)
            wg.Done()
            return nil
        },
    )
    defer patches.Reset()

    wg.Add(3)
    for i := 0; i < 3; i++ {
        go func() {
            target.SomePublicMethod(ctx)
        }()
    }
    wg.Wait()

    if got := callCount.Load(); got != 3 {
        t.Errorf("callCount = %d, want 3", got)
    }
}
```

### Context Cancellation for Goroutine Cleanup

```go
ctx, cancel := context.WithCancel(context.Background())
defer cancel()

result := target.LongRunningOp(ctx)

cancel()
time.Sleep(50 * time.Millisecond)
```

## Concurrent Test Scaffolding for State-Transition Functions

For functions that manage state transitions (e.g., `TransitionTo`, `TryAcquire`) with CAS loops and goroutine coordination:

### Pattern 1: Sequential CAS Testing

Test each state transition path individually — do NOT launch concurrent goroutines unless the target function explicitly uses mutex/shared-state:

```go
func TestTransition_FastPath(t *testing.T) {
    sf := NewTarget()
    sf.state = targetState  // Pre-set state
    err := sf.Transition(ctx, fromState, targetState)
}
```

### Pattern 2: CAS Failure + Retry

```go
func TestTransition_CASRetry(t *testing.T) {
    sf := NewTarget()
    sf.state.Store(otherState)
    go func() {
        time.Sleep(10 * time.Millisecond)
        sf.state.Store(fromState)
    }()
    err := sf.Transition(ctx, fromState, targetState)
}
```

## Common Concurrent Safety Mistakes

| Mistake | Fix |
|---------|-----|
| Plain `int callCount` in concurrent gomonkey closure | Use `atomic.Int32` |
| Plain `[]string` append in concurrent gomonkey closure | Use `sync.Mutex` around append |
| Concurrent test for mutex-free function | Skip concurrent test unless target directly uses mutex |
| Not running `-race` gate | Add as Step 3 gate |
| `time.Sleep` for goroutine sync | Use `sync.WaitGroup` with `defer wg.Done()` |
| Undrained channel in mock | Add `for range ch {}` before returning |
| `patches.Reset()` before goroutines complete | Defer `patches.Reset()` or use `t.Cleanup`; drain channels first |
| Missing `wg.Done()` in goroutine | Always pair `wg.Add(1)` with `defer wg.Done()` |
| Over-engineering concurrent test scaffolding for simple L1 targets | Prefer simple single-waiter tests; use complex scaffolding only for targets with concurrent dispatch |
