---
name: improve-java-ut-coverage
description: Improve Java unit test coverage, including exception and catch block coverage detection, generating incremental test cases and complete code. Triggers when the user provides a test file and the method under test signature, requesting coverage improvement or exception coverage analysis.
allowed-tools: Read, Glob, Grep, CoverageAnalysis
language: java
---

# Improve Java UT Coverage

After the user provides the test file and the method under test signature, first create a task plan for coverage improvement, then execute the following steps in order.

## Execution Steps

### Step 1: Coverage Data Acquisition

1. Use the `Read` tool, passing the test file path, to read the test file code
2. Use the `CoverageAnalysis` tool, passing the test file path and the method under test signature, to get the returned coverage data

### Step 2: Insufficient Coverage Root Cause Analysis

Based on the test file code and coverage data details obtained in Step 1, analyze each uncovered statement as follows:

1. **Statement Classification**

Classify uncovered statements into one of the following types:
- **NULL_CHECK**: Null value check branch
- **EXCEPTION_HANDLING**: Exception throwing or catching path
- **BOUNDARY_CONDITION**: Boundary condition judgment
- **SWITCH_CASE**: Specific case branch of switch statement
- **LOOP_CONDITION**: Loop boundary condition (not entering loop / early exit)
- **BUSINESS_LOGIC**: Business logic branch
- **ERROR_HANDLING**: Error handling path
- **DEFAULT_BRANCH**: else/default branch
- **CATCH_BLOCK**: catch block processing logic (logging, exception conversion, fallback return, resource cleanup, etc.)

2. **Exception Coverage Detection**

For uncovered statements classified as `CATCH_BLOCK` or `EXCEPTION_HANDLING`, read `references/exception-coverage.md` for the complete specification and perform the following checks:

- **catch Block Identification and Coverage Assessment**

| Check Dimension | Description |
|-----------------|-------------|
| Method-level try-catch | Check whether the exception type caught by catch and its processing logic are covered by tests |
| Loop-level try-catch | Check whether exception capture paths during loop iterations are covered |
| Nested try-catch | Check whether both inner and outer exception handling are covered |
| Lambda expression try-catch | Check whether exception capture in functional interfaces is covered |

- **catch Block Processing Logic Coverage Check**

For each catch block, verify whether the following logic is covered by tests:

| Logic Type | Coverage Key Points |
|------------|---------------------|
| Logging | Verify that logs are recorded |
| Exception conversion | Verify the new exception type and message |
| Fallback logic | Verify that the return value meets expectations |
| Resource cleanup | Verify that resources are properly released |
| State rollback | Verify that state is correctly rolled back |
| Counter/metrics | Verify that metrics are correctly updated |
| Retry logic | Verify that retry count meets expectations |

- **Exception Coverage Quality Assessment**

| Dimension | Assessment Criteria | Priority |
|------------|---------------------|----------|
| Trigger validity | Whether the catch block is actually triggered via construction/mock | P0 |
| Logic coverage completeness | Whether every line of code in the catch block is executed | P0 |
| Assertion sufficiency | Whether the processing result of the catch block is verified | P1 |
| Side effect verification | Whether side effects during exception occurrence are verified | P2 |

- **Exception Coverage Checklist (Mandatory Self-Check)**

After completing exception coverage detection, the following items must be confirmed:

- [ ] Each catch block in the method under test has a corresponding test case that triggers it
- [ ] The processing logic in catch blocks (logging, exception conversion, fallback) is verified as executed
- [ ] Exception trigger conditions are implemented via construction or mock
- [ ] Test cases correctly assert the processing results of catch blocks
- [ ] All branch paths within catch blocks of the method under test are covered

3. **Uncovered Reason Analysis**

Based on the statement classification and exception coverage detection results, analyze the specific reason why each statement is not covered:
- What input conditions are missing in existing test cases?
- What preconditions are needed to trigger that path?
- Do specific dependency behaviors need to be Mocked?
- Is there a problem with insufficient test data preparation?

### Step 3: Coverage Improvement Suggestions

Based on the insufficient coverage root cause analysis and exception coverage detection results in Step 2, provide precise guidance for generating incremental test cases for each uncovered statement:

1. **Trigger Condition Derivation**

Clearly specify the conditions that need to be satisfied to trigger the execution of that statement:
- Specific values or ranges of input parameters
- Values or exceptions that dependency objects need to return
- Preconditions for system state

2. **Test Scenario Suggestions**

Design specific test scenarios for each uncovered statement:
- Scenario name (concise description of test purpose)
- Test input data
- Mock configuration (if needed)
- Expected results or exceptions

3. **Dependency Analysis**

Identify what may be needed to test that statement:
- External dependencies that need to be Mocked
- Test data that needs to be prepared
- Possible test order dependencies

4. **Test Strategies for Common Uncovered Scenarios**

| Uncovered Type | Typical Scenario | Recommended Test Strategy |
|-----------|---------|-------------|
| **Null check branch** | `if (obj == null)` | Pass null parameter, verify exception or default behavior |
| **Exception throwing statement** | `throw new XxxException()` | Construct conditions that trigger the exception, use `assertThrows` to verify exception type and message |
| **Exception catch block** | `catch (IOException e)` | Mock dependency to throw exception, verify exception handling logic |
| **catch block logging** | `log.error("failed", e)` | Mock to trigger exception, verify that log is recorded |
| **catch block exception conversion** | `throw new BizException("msg", e)` | Construct source exception, verify converted exception type and message |
| **catch block fallback** | `return defaultValue` | Construct exception scenario, verify return of default value |
| **catch block resource cleanup** | `closeResource()` | Construct exception scenario, verify resource is properly released |
| **Switch uncovered case** | `case ADMIN:` | Create independent test methods for each enum value, use `@ParameterizedTest` |
| **Loop not entered** | `for (Item item : list)` | Pass empty collection `Collections.emptyList()`, verify empty collection handling logic |
| **Loop early exit** | `if (condition) break;` | Construct data satisfying break condition, verify early exit behavior |
| **Condition false branch** | `if (flag) {...} else {...}` | Set flag to false, verify else branch behavior |
| **Short-circuit evaluation uncovered** | `if (a && b)` | Test separately: (1) a is false (2) a is true but b is false (3) both a and b are true |
| **Boundary value uncovered** | `if (age >= 18)` | Test boundary values: 17 (just not satisfied), 18 (just satisfied), 19 (safe value) |
| **Optional empty path** | `optional.orElse(default)` | Pass `Optional.empty()` to verify default value return |
| **Ternary operator** | `flag ? a : b` | Test both cases where flag is true and false |
| **finally block** | `finally { cleanup(); }` | Verify that finally is executed in both normal and exception cases |
| **Nested condition inner layer** | `if (a) { if (b) {...} }` | Construct scenario where a is true but b is false |
| **Empty collection return** | `if (list.isEmpty()) return;` | Pass empty collection to verify early return |
| **Lambda exception path** | `list.stream().map(...)` | Mock throwing exception in stream operation |

5. **Exception Coverage Test Templates**

For uncovered catch blocks identified in Step 2.2, use the following templates to generate test cases. For complete templates, refer to `references/exception-coverage.md`:

- **Basic catch block coverage**: Mock dependency to throw exception -> verify exception conversion in catch
- **Fallback logic coverage**: Mock to throw exception -> verify return of default value
- **Logging verification**: Mock to trigger exception -> verify logging
- **Resource cleanup verification**: Mock to trigger exception -> verify resource closure
- **Exception chain verification**: Verify that the cause chain is fully preserved
- **Multiple catch block coverage**: Mock different exception types separately, verify each catch branch

## Final Output

Please output analysis conclusions and coverage improvement suggestions for each uncovered statement.

Each uncovered statement's analysis conclusion and coverage improvement suggestion needs to include the following elements:
1. Basic information about the uncovered statement
2. Root cause analysis
   - Why it is not covered
   - Trigger conditions
   - Mock dependency requirements <if any>
3. Specific test scenario implementation suggestions
   - Test method naming suggestions (following the current test file style, e.g., given-when-then)
   - Input parameters
   - Mock configuration <if any>
   - Expected results
   - Complete test code example
4. Implementation difficulty (EASY/MEDIUM/HARD)
5. Priority (HIGH/MEDIUM/LOW), based on business risk and test value

**For uncovered exception/catch block statements**, the following additional elements are required:
6. catch block type (logging/exception conversion/fallback/resource cleanup/state rollback/counter metrics/retry logic)
7. Exception trigger method (Mock dependency throwing exception/constructing illegal data/constructing adverse environment)
8. Corresponding exception coverage test template reference
