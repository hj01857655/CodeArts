## Check Item: Exception Coverage Detection (check-exception-coverage)

### Core Objective

From a Java testing expert perspective, evaluate the extent to which test cases cover **catch blocks** in the code under test.

**Key distinction from traditional exception testing**:
- Traditional: Verify whether exceptions **thrown** by the method under test are covered by tests
- This item: Verify whether exception paths **caught** internally by the method under test are covered by tests

> Objective: Ensure that the processing logic in catch blocks (logging, fallback logic, exception conversion, etc.) is executed, improving the overall coverage of the method under test.

---

### Check Content

#### 1. catch Block Identification

| Location | Description | Check Key Points |
|----------|-------------|-------------------|
| Method-level try-catch | try-catch blocks within a method | Check the exception type caught by catch and its processing logic |
| Loop-level try-catch | Exception handling within loops | Check exceptions that may be thrown during loop iterations |
| Nested try-catch | Multi-layer exception capture | Check both inner and outer exception handling |
| Lambda expression try-catch | Exception handling in functional interfaces | Check exception capture within lambda |

#### 2. catch Block Processing Logic Identification

catch blocks may contain the following logic, which needs to be ensured as covered:

| Logic Type | Example | Coverage Key Points |
|------------|---------|---------------------|
| Logging | `log.error("failed", e)` | Verify that logs are recorded |
| Exception conversion | `throw new BusinessException("msg", e)` | Verify the new exception type and message |
| Fallback logic | `return defaultValue` | Verify that the return value meets expectations |
| Resource cleanup | `closeResource()` | Verify that resources are properly released |
| State rollback | `transaction.rollback()` | Verify that state is correctly rolled back |
| Counter/metrics | `errorCounter.increment()` | Verify that metrics are correctly updated |
| Retry logic | `retryCount++` | Verify that retry count meets expectations |

#### 3. Exception Trigger Condition Analysis

| Exception Source | Trigger Method | Example Scenario |
|------------------|----------------|------------------|
| Dependency service call | Mock to return exception | `when(service.call()).thenThrow(new IOException())` |
| External resource access | Construct adverse environment | File not found, network unreachable |
| Data validation failure | Construct illegal data | Parameter is null, exceeds threshold |
| Concurrency conflict | Multi-threaded competition | Simulate concurrent scenario |
| Timeout scenario | Set short timeout | Dependency service response timeout |

---

### Check Criteria

#### 1. catch Block Coverage Assessment Matrix

| catch Block Type | Must Cover | Check Key Points |
|------------------|-----------|-----------------|
| catch (Exception e) | YES | Cover all exception paths |
| catch (IOException e) | YES | Cover IO exception paths |
| catch (RuntimeException e) | YES | Cover runtime exception paths |
| catch (SpecificException e) | YES | Cover specific business exceptions |

#### 2. Exception Coverage Quality Assessment

| Dimension | Assessment Criteria | Priority |
|------------|---------------------|----------|
| Trigger validity | Whether the catch block is actually triggered via construction/mock | P0 |
| Logic coverage completeness | Whether every line of code in the catch block is executed | P0 |
| Assertion sufficiency | Whether the processing result of the catch block is verified | P1 |
| Side effect verification | Whether side effects during exception occurrence are verified | P2 |

#### 3. Common Missed Scenarios

| Scenario | Miss Risk | Recommendation |
|----------|-----------|----------------|
| Third-party call exception | catch block logs but not verified | Mock third-party to throw exception, verify logging |
| Exception conversion not covered | throw new exception in catch not tested | Construct test case that triggers the source exception |
| Fallback not executed | return default value in catch not tested | Construct exception scenario, verify return value |
| Resource leak | Resources not properly closed in catch | Construct exception scenario, verify resource closure |

---

### Pass Criteria

- [ ] Each catch block in the method under test has a corresponding test case that triggers it
- [ ] The processing logic in catch blocks (e.g., logging, exception conversion, fallback) is verified as executed
- [ ] Exception trigger conditions are implemented via construction or mock
- [ ] Test cases correctly assert the processing results of catch blocks
- [ ] All branch paths within catch blocks of the method under test are covered

---

### Failure Handling

**catch block not covered**
```
WARNING: testMethodName - method contains catch(IOException e) but no test case triggers it
Suggestion: Add a test case that mocks the dependency service to throw IOException, verifying catch block logic
```

**catch block logic not verified**
```
WARNING: testMethodName - catch block has logging but not verified
Suggestion: Add logging verification, or use ArgumentCaptor to capture log content
```

**Exception trigger conditions insufficient**
```
WARNING: testMethodName - catch block has exception conversion logic but test does not cover it
Suggestion: Construct the original exception via mock, verify the converted exception type and message
```

**Fallback logic not covered**
```
WARNING: testMethodName - catch block has fallback returning default value but test does not cover it
Suggestion: Construct an exception-triggering scenario, verify that the return value is the default value
```

---

### Reference Templates

#### 1. Basic catch Block Coverage Template

```java
/**
 * Case Description: Verify that the method correctly enters the catch block and executes processing logic when the dependency service throws an exception
 * Trigger Condition: External service call throws IOException
 * Coverage Target: Logging and exception conversion logic in the catch block
 *
 * Given: Prepare test data
 *  1. Mock external service to throw IOException
 * When: Execute action
 *  Execute: service.process()
 * Then: Result verification
 *  1. Assert that business exception is thrown (converted by catch block)
 *  2. Verify that log is recorded (optional)
 *  3. Verify that exception chain is correct
 */
@Test
@Description("DTAgent_v1.0")
public void testProcessShouldCatchIOExceptionAndThrowBusinessException() {
    // Given
    when(externalService.call()).thenThrow(new IOException("Connection refused"));

    // When & Then
    BusinessException exception = assertThrows(
        BusinessException.class,
        () -> service.process()
    );

    // Verify exception conversion
    assertEquals("Processing failed", exception.getMessage());
    assertTrue(exception.getCause() instanceof IOException);
}
```

#### 2. Fallback Logic Coverage Template

```java
/**
 * Case Description: Verify that the method returns fallback default value when an exception occurs
 * Trigger Condition: Database query throws SQLException
 * Coverage Target: Fallback logic in the catch block
 *
 * Given: Prepare test data
 *  1. Mock database to throw SQLException
 * When: Execute action
 *  Execute: service.getData()
 * Then: Result verification
 *  1. Assert that empty list is returned (fallback value)
 *  2. Verify that no exception is thrown
 */
@Test
@Description("DTAgent_v1.0")
public void testGetDataShouldReturnEmptyListWhenDatabaseError() {
    // Given
    when(repository.query()).thenThrow(new SQLException("DB unavailable"));

    // When
    List<Data> result = service.getData();

    // Then
    assertNotNull(result);
    assertTrue(result.isEmpty());
}
```

#### 3. Logging Verification Template

```java
/**
 * Case Description: Verify that the method correctly logs when an exception occurs
 * Trigger Condition: File read failure
 * Coverage Target: Logging logic in the catch block
 */
@Test
@Description("DTAgent_v1.0")
public void testReadFileShouldLogErrorWhenFileNotFound() {
    // Given
    when(fileReader.read(anyString())).thenThrow(new FileNotFoundException("file not found"));

    // When
    service.readFile("test.txt");

    // Then - Verify logging
    verify(logger).error(eq("Failed to read file"), any(FileNotFoundException.class));
}
```

#### 4. Resource Cleanup Verification Template

```java
/**
 * Case Description: Verify that the method correctly releases resources when an exception occurs
 * Trigger Condition: Exception thrown during processing
 * Coverage Target: Resource cleanup logic in the catch block
 */
@Test
@Description("DTAgent_v1.0")
public void testProcessShouldCloseConnectionOnError() {
    // Given
    when(processor.process(any())).thenThrow(new RuntimeException("Processing failed"));

    // When
    assertThrows(RuntimeException.class, () -> service.process(item));

    // Then - Verify resource closure
    verify(connection).close();
}
```

#### 5. Exception Chain Verification Template

```java
/**
 * Case Description: Verify that the method correctly preserves the exception chain
 * Trigger Condition: Underlying service throws exception
 * Coverage Target: Exception wrapping logic in the catch block
 */
@Test
@Description("DTAgent_v1.0")
public void testServiceShouldPreserveExceptionChain() {
    // Given
    IOException originalException = new IOException("Network error");
    when(httpClient.request()).thenThrow(originalException);

    // When & Then
    ServiceException exception = assertThrows(
        ServiceException.class,
        () -> service.request()
    );

    // Verify exception chain
    assertEquals("Service unavailable", exception.getMessage());
    assertSame(originalException, exception.getCause());
}
```

#### 6. Multiple catch Block Coverage Template

```java
/**
 * Case Description: Verify that the method handles different exception types
 * Coverage Target: Branch logic of multiple catch blocks
 */
@Test
@Description("DTAgent_v1.0")
public void testProcessShouldHandleIOExceptionAndRuntimeException() {
    // Scenario 1: IOException handling
    when(processor.process()).thenThrow(new IOException("IO Error"));
    assertThrows(BusinessException.class, () -> service.process());
    verify(handler).handleIOException(any());

    // Scenario 2: RuntimeException handling
    reset(processor);
    when(processor.process()).thenThrow(new RuntimeException("Runtime error"));
    assertThrows(BusinessException.class, () -> service.process());
    verify(handler).handleRuntimeException(any());
}
```

---

### Practical Example

#### Case: Payment Service Exception Handling Coverage

```java
// Code under test
public class PaymentService {
    private PaymentGateway gateway;
    private Logger logger;
    private MetricsCollector metrics;

    public PaymentResult pay(Order order) {
        try {
            GatewayResponse response = gateway.process(order);
            return PaymentResult.success(response.getTransactionId());
        } catch (GatewayTimeoutException e) {
            logger.error("Payment gateway timeout", e);
            metrics.increment("payment.timeout");
            return PaymentResult.retry();
        } catch (GatewayDeclinedException e) {
            logger.warn("Payment declined: {}", e.getMessage());
            metrics.increment("payment.declined");
            return PaymentResult.declined(e.getReason());
        } catch (Exception e) {
            logger.error("Payment unknown exception", e);
            metrics.increment("payment.error");
            return PaymentResult.failed(e.getMessage());
        }
    }
}
```

**catch blocks that need to be covered:**

| catch Block | Test Scenario | Verification Points |
|-------------|---------------|---------------------|
| GatewayTimeoutException | Mock gateway timeout | Return retry, verify timeout counter |
| GatewayDeclinedException | Mock gateway decline | Return declined, verify decline reason |
| Exception (fallback) | Mock unknown exception | Return failed, verify error message |

**Corresponding test cases:**

```java
@Test
public void testPayShouldReturnRetryWhenGatewayTimeout() {
    // Given
    when(gateway.process(any())).thenThrow(new GatewayTimeoutException("Timeout"));

    // When
    PaymentResult result = paymentService.pay(order);

    // Then
    assertEquals(PaymentStatus.RETRY, result.getStatus());
    verify(metrics).increment("payment.timeout");
}

@Test
public void testPayShouldReturnDeclinedWhenGatewayDeclined() {
    // Given
    when(gateway.process(any())).thenThrow(
        new GatewayDeclinedException("Insufficient funds")
    );

    // When
    PaymentResult result = paymentService.pay(order);

    // Then
    assertEquals(PaymentStatus.DECLINED, result.getStatus());
    assertEquals("Insufficient funds", result.getReason());
    verify(metrics).increment("payment.declined");
}

@Test
public void testPayShouldReturnFailedWhenUnknownError() {
    // Given
    when(gateway.process(any())).thenThrow(new RuntimeException("Unknown"));

    // When
    PaymentResult result = paymentService.pay(order);

    // Then
    assertEquals(PaymentStatus.FAILED, result.getStatus());
    verify(metrics).increment("payment.error");
}
```
