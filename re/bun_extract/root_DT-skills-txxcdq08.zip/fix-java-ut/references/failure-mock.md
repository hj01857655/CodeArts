# Mock Configuration and Parameter Mismatch Error Repair Strategy

## Four-Step Repair Process
### Step 1: Analyze Error Stack
- Locate the specific line number and class where `NPE` occurs
- Determine which object is null
- Trace the source of that object (parameter passed in, Mock return, new object creation, etc.)

### Step 2: Check Mock Configuration
- Find the relevant Mock configuration in the test
- Verify whether `when()` conditions match the test calls
- Check whether `thenReturn()` returns null or invalid values

### Step 3: Analyze the Logic of the Method Under Test
- See how the method under test handles input parameters
- Check whether there are null checks or default value handling
- Understand the expected input of the business logic

### Step 4: Select Repair Strategy
Based on the analysis results, select:
- Modify test input parameters (most commonly used)
- Adjust Mock configuration (add missing Mock or modify return values)
- Refactor test design (if the existing design is unreasonable)

## Common Mock Configuration Issues and Repair Strategies
### Case A: Parameter Value Mismatch
Symptom: The parameters passed in the test do not match the Mock configuration
Solutions:
1. Adjust test parameters to match Mock configuration
2. Use `any()` and other matchers instead of specific values
3. Add additional `when()` configurations to cover more parameters

### Case B: Mock Returns null Causing NPE
Symptom: Mock returns `null`, and the code under test has no `null` check
Solutions:
1. Modify Mock to return a valid object, ensuring Mock returns non-`null` values
2. If the test purpose is to verify `null` handling, modify the assertions

### Case C: Mock Missing in Chained Calls
Symptom: A Mock object's method returns another object, but the returned object's methods are not Mocked
Solutions:
1. Fully Mock the chain: Mock each level of chained calls
2. Use `Mockito.RETURNS_DEEP_STUBS`
3. Redesign the test to avoid complex chained calls

## Parameter Matching Tips
Exact matching is suitable for simple tests, e.g.: `when(service.method(5)).thenReturn(result);`
Flexible matching is suitable when parameters are not important, e.g.:

```java
when(service.method(anyInt())).thenReturn(result);
when(service.method(eq(5))).thenReturn(result); // specific value
when(service.method(any())).thenReturn(result); // any parameter
```

## Post-Repair Checks
- Ensure syntax is correct
- Mock verification: Use `verify()` to confirm that methods are called correctly
- Ensure the test still validates the intended business scenario
- Avoid over-repairing; only modify necessary parameters and keep the test concise

## Tool Usage Recommendations
- Reduce unnecessary exploration:
1. Prioritize analyzing Mock configurations in existing test code
2. Directly view the class and method pointed to by the error stack
3. Avoid over-exploring unrelated project structures

## Example Repair Patterns
Scenario: Pagination parameters null causing NPE

Original test:
```java
@Test
public void test_withNullParams() {
    // Pass null parameters
    controller.method(id, null, null);
}
```

Repair Strategy 1: Pass business default values
```java
@Test
public void test_withDefaultParams() {
    // Pass reasonable default values
    controller.method(id, 0, 10);
}
```

Repair Strategy 2: Adjust Mock to handle null
```java
// Handle null parameters in Mock
when(service.find(any(), any(), any())).thenReturn(page);
// or
when(service.find(null, null, null)).thenReturn(emptyPage);
```
