# Identify Error Type

Please match rules based on keywords in the error log (Case Insensitive) in **top-to-bottom** order. Once a match is successful, immediately stop matching and return the corresponding strategy file.

## Priority 0: Compilation Exception
If the code cannot run, compilation issues must be resolved first.
- **Trigger Keywords**: `must be caught or declared to be thrown`, `unhandled exception`
- **Target File**: `.codemate/skills/fix-java-ut/references/exception-compilation.md`

## Priority 1: Reflection-Related Errors
- **Trigger Keywords**: `Reflection`, `setAccessible`, `NoSuchField`, `IllegalAccess`, `could not find field`
- **Other Characteristics**:
  - When encountering runtime errors caused by field name mismatch in reflection API calls
  - Involving calls to `setField()` or `getField()` in ReflectionTestUtils
  - Involving calls to `Field.set()` or `getDeclaredField()` in Java reflection API
  - Errors occur in test code, not in the code under test
- **Target File**: `.codemate/skills/fix-java-ut/references/failure-reflect.md`

## Priority 2: Runtime Exception
- **Trigger Keywords**: `throw`, `threw`, `thrown`, `unexpected exception`
- **Other Characteristics**:
  - Encountering runtime exception test errors
  - Assertion failures during test execution, expected exception not thrown or wrong type of exception thrown
  - Involving the use of `@Test(expected=...)` or `assertThrows()`)
- **Target File**: `.codemate/skills/fix-java-ut/references/exception-runtime.md`

## Priority 3: Mock Framework Errors
- **Trigger Keywords**: `Mockito`, `Mock`, `Spy`, `ArgumentMatchers`, `UnfinishedStubbing`
- **Other Characteristics**:
  - When encountering runtime errors caused by Mock configuration or test input parameter mismatch with the method under test logic
  - Error stack shows `NullPointerException` in the Mock object call chain
  - Involving calls to `when().thenReturn()` or `when().thenThrow()`
  - Error when the method under test calls a dependent Mock service
- **Target File**: `.codemate/skills/fix-java-ut/references/failure-mock.md`
