# Runtime Exception Error Repair Strategy

## Two-Step Repair Process
### Step 1: Check if the code under test has exception handling mechanisms:
- try-catch blocks
- @ExceptionHandler annotation (Spring)
- Global exception handlers

### Step 2: Adjust test logic based on the actual behavior of the code under test
#### Case A: The code under test handles the exception, then the test code should verify the response after handling
Example:
```java
@Test
public void testCreate_whenException() {
    when(service.process()).thenThrow(new RuntimeException());
    Response result = controller.create();
    assertEquals("Processing failed", result.getMessage());
    assertEquals(500, result.getCode());
}
```

#### Case B: The code under test does not handle the exception, then the test code should verify that the exception is correctly thrown
JUnit 4 example:
```java
@Test(expected = RuntimeException.class)
public void testCreate_whenException() {
    when(service.process()).thenThrow(new RuntimeException());
    controller.create();
}
```

JUnit 5 example:
```java
@Test
public void testCreate_whenException() {
    when(service.process()).thenThrow(new RuntimeException());
    RuntimeException exception = assertThrows(RuntimeException.class, () -> controller.create());
    assertEquals("Expected error message", exception.getMessage());
}
```

## Tool Usage Recommendations
- Prioritize using error information to directly obtain the exception type and method location
