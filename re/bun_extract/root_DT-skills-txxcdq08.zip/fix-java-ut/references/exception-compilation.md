# Checked Exception Compilation Error Repair Strategy

## Two-Step Repair Process
### Step 1: Locate the Problem Method
1. Find the method call that throws a checked exception
2. View the method declaration (throws clause)
3. Determine the exception type

### Step 2: Select Repair Strategy Based on Test Intent
#### Option A: Catch and Handle the Exception
```java
@Test
public void testMethod() {
    try {
        methodThatThrowsException();
        // Verify normal logic
    } catch (Exception e) {
        fail("Should not throw exception: " + e.getMessage());
    }
}
```

#### Option B: Declare Exception in Test Method
```java
@Test
public void testMethod() throws Exception {
    methodThatThrowsException();
    // Verify normal logic
}
```

#### Option C: Use JUnit Exception Testing
```java
// JUnit 4
@Test(expected = IOException.class)
public void testMethod() throws Exception {
    methodThatThrowsException();
}
// JUnit 5
@Test
public void testMethod() {
    assertThrows(IOException.class, () -> {
    methodThatThrowsException();
    });
}
```

Example:

The `String content = FileUtils.readFile("test.txt");` in the test method has a compilation error. If testing the normal scenario, select Option A/B; if testing the file-not-found exception, select Option C.

## Tool Usage Recommendations
- Prioritize using compilation error information to directly obtain the exception type and method location, avoiding direct tool invocation
