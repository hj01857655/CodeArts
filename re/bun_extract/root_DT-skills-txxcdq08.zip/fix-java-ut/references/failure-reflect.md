# Type 2: Reflection API Field Name Mismatch Error

## Three-Step Repair Process
### Step 1: Locate the Problem
1. Find the specific reflection API call location from the error stack
2. Extract the field name specified in the test code and determine the target object type
### Step 2: Get the Correct Field Definition
1. Use the context_retrieve tool to get the target class definition
2. View the actual field list in the class
3. Check whether the specified field exists in the target class, paying attention to case and spelling
### Step 3: Execute Repair
1. Change the field name in the test code to the correct field name
2. Ensure the field name matches exactly (including case)
3. Update related comments if necessary

## Common Reflection API Issues and Solutions
### Case A: Field Name Spelling Error
Symptom: The field name specified in the test does not match the field name in the target class
Solution: Replace with the correct field name, paying attention to spelling and case

### Case B: Field Does Not Exist
Symptom: The field specified in the test does not exist at all in the target class
Solution:
1. Find an alternative field: Analyze the target class's fields and find a field with similar functionality
2. Understand the test intent: Based on the test context, determine which field should be used
3. Consider field mapping: For example, if the test expects to set "product name" but the class has a "name" field, use "name"

Example:
```java
ReflectionTestUtils.setField(product, "description", "test"); // Error: EsProduct class has no "description" field
ReflectionTestUtils.setField(product, "subTitle", "test"); // Repair: Find the closest field, such as "subTitle"
```
### Case C: Inheritance Chain Field Access
Solution: If you need to access a parent class field, confirm whether the field is in the parent class. If not, check the inheritance chain and use the correct field name

## Tool Usage Recommendations
For reflection issue tool selection:
1. Avoid over-exploration; extract the class name directly from error information, reduce guessing, and get the entire class definition at once rather than querying fields individually
2. If there are multiple field issues in the same test, fix them all at once to reduce rounds

## Post-Repair Checks
1. Ensure syntax is correct
2. After repair, reflection calls should no longer throw field-not-found exceptions
3. Ensure the new field's type is compatible with the set value
4. If the field is private, ensure that reflection access is part of the test strategy
