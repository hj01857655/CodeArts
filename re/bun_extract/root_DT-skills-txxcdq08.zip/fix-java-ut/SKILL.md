---
name: fix-java-ut
description: This skill provides a structured and expert-driven approach to validating and repairing the correctness of generated unit tests. It ensures both compilation and runtime correctness by leveraging specialized validation tools and expert repair strategies for common and complex test failures. Compared to ad-hoc debugging, this skill offers more efficient and reliable resolution paths. It is particularly suited for validating the correctness of newly generated unit tests and is strongly recommended before proceeding to further coverage or quality optimization.
allowed-tools: Read, Write, Edit, Glob, Grep, GetErrorMessage,Bash
language: java
---


After the user provides the test file and the method under test, first create a task plan for coverage improvement, then execute the following steps in order.

## Execution Steps

### Step 1: Get Current Error Information

1. **Goal**
   Get the error information of the current test file.

2. **Action**
   Must use the `getErrorMessage` tool, passing the absolute path of the test file, to get the test file error information, including compilation errors or execution errors.

3. **Output**
   The result returned by the `getErrorMessage` tool.

4. **Next Step**
   Based on the result of the `getErrorMessage` tool, determine whether repair is needed. If no errors exist, end the process. If errors need to be fixed, proceed to Step 2.


### Step 2: Context Information Collection

1. **Goal**
   Based on the output of Step 1, deeply analyze the root cause of the error, identify additional context that needs to be collected, and provide guidance for generating the repaired code.

2. **Principle**
   All context information collection should focus on the file containing the method under test and the definition of the method under test:
   Explore the project through the following steps to supplement the corresponding context information:
- Step 1: If you find that multiple context information entries are all located in the same method file, prioritize using the Read tool to retrieve that file. This is a way to read multiple context information entries at once.
   For individual context queries, follow these steps:
- Step 2: If Step 1 cannot obtain the identifier definition you need, first use the Grep tool to find where an identifier or code snippet appears, then use Read to get the definition of that code snippet or identifier.
- Step 3: For parameters/variables/fields that are difficult to construct or have no setter methods provided, consider using Mock/reflection capabilities to construct and set them when supported.
---
After context information collection is complete, proceed to Step 3


### Step 3: Generate Repaired Test Code

1. **Output Requirement** (mandatory)
   Must output the repaired test file through the Edit tool


### Step 4: Verify Repair Result

1. **Goal**
   After the test file is repaired, must use the `getErrorMessage` tool again to verify the repair result. If no errors exist, end the process. If errors still need to be fixed, return to Step 2.
