---
name: experience-refine
description: >-
   Evaluates, updates, de-duplicates, merges, archives, and rewrites existing
   engineering experiences in `experiences/`. Use when the experience library
   needs lifecycle management, systematic evaluation, conflict resolution,
   quality improvement, or partial consolidation after growth or retrieval
   misses.
---

# Experience Refinement

This skill systematically refines the **existing experience library**: it evaluates validity, applicability scope, active utility, and timeliness, then updates, merges, denoises, resolves conflicts, and archives experience documents.

## Responsibility Boundaries

This skill does:

1. Systematically evaluate existing experiences.
2. Distinguish document quality, active utility, and lifecycle actions.
3. Update, merge, denoise, resolve conflicts, and archive experience documents.

This skill does not:

1. Collect session traces.
2. Create new experiences from new session traces.
3. Retrieve experiences.
4. Update retrieval-hit or usage-consumption data.
5. Maintain index files.

## Progressive Loading

By default, read only this file. Read supporting files only when the corresponding step requires them:

1. When entering lifecycle action selection, read `references/lifecycle-policy.md`.
2. When performing systematic evaluation, read `references/systematic-evaluation-rubric.md`.
3. When content is overly project-specific and needs generalized rewriting, read `references/generalization-guidelines.md`.
4. When rewriting, merging, or creating a normalized experience document, read `templates/experience-template.md`.
5. After `category` is determined, read only one corresponding supplemental template:
   - `coding-pattern` -> `templates/coding-pattern.md`
   - `testing` -> `templates/testing.md`
   - `architecture` -> `templates/architecture.md`
   - `build-env` -> `templates/build-env.md`
   - `debugging` -> `templates/debugging.md`
   - `workflow` -> `templates/workflow.md`
   - `agent-ops` -> `templates/agent-ops.md`

Do not load any other files unless the current step explicitly requires them.

## Input Assumptions

The caller usually provides:

1. `project_root`
2. `experiences_dir`
3. `gate`

`gate` explains why this refinement run was triggered, for example:

1. The system is in an idle state during a reflection window.
2. Recently added experience documents have not been batch-organized.
3. Recent retrievals missed multiple times.
4. Recent retrievals produced multiple low-quality retrieval hits.
5. One category of experiences has grown rapidly in a short period.
6. Experiences need review because they may be outdated, have scope conflicts, or require active-utility reassessment.

## Hard Constraints

1. **Operate only on the experience library**: all changes must occur only under `experiences/`.
2. **Prioritize the gate-related subset**: do not indiscriminately rewrite the entire library.
3. **Preserve historical experiences**: do not perform unrecoverable deletion by default. Prefer archiving old documents by moving them to the same category directory under `experiences/.archived/`; if `experiences/.archived/` does not exist, create it first.
4. **Prefer reusing existing files**: update the original file when possible instead of creating a replacement.

## Refinement Workflow

### Step 0: Select Processing Scope

Prefer narrowing this run by `gate`. Common selections include:

1. Experiences recently added or updated.
2. A group of experiences related to recent missed retrieval query keywords.
3. Experiences marked as low-quality retrieval hits.
4. A group of experiences under the same `category` that grew rapidly in a short period.
5. A group of experiences whose retrieval-hit records show high duplication or mutual conflict.

Only inspect by category in batches when `gate` cannot point to a concrete subset. Even then, control the scope and avoid large-scale rewrites of the entire library.

### Step 1: Completeness Check

First check whether the target experiences satisfy the minimum structural requirements.

The frontmatter must be parseable and contain at least the following fields:

1. `id`
2. `title`
3. `category`
4. `nature`
5. `created_at`
6. `updated_at`
7. `tags`
8. `keywords`
9. `problem_patterns`
10. `source_sessions`
11. `project`
12. `severity`
13. `quality_score`
14. `hit_count`
15. `last_hit_at`
16. `low_quality_hit_count`
17. `tier`
18. `related_experiences`

If frontmatter parsing fails, skip the file and record it under `skipped`.

### Step 2: Systematic Evaluation

Read `references/systematic-evaluation-rubric.md` and complete the evaluation according to its rules.

The evaluation result must include at least:

1. `quality_score`: document quality score, written back to frontmatter.
2. `utility_score`: active utility score, used for lifecycle decisions in this run. If the document already supports this field, write it back to frontmatter.
3. `tier`: derived from `utility_score` and maintained accordingly.
4. Main reasons for score deductions: used for subsequent update, downgrade, merge, or archive decisions.

This step produces evaluation conclusions only. Do not restate scoring details here; use `references/systematic-evaluation-rubric.md` as the source of truth.

### Step 3: Similarity and Conflict Judgment

Compare experiences within the same subset group by group, focusing on:

1. Whether the problem scenarios are of the same type.
2. Whether `problem_patterns` overlap.
3. Whether `keywords` overlap heavily.
4. Whether the approaches or conclusions are essentially the same.
5. Whether the only difference is the project, or the methodology is genuinely different.

Use the following weighted judgment when helpful:

1. Problem scenario similarity: 0.30
2. `problem_patterns` overlap: 0.25
3. `keywords` overlap: 0.20
4. Solution similarity: 0.15
5. Same `category`: 0.10

Decision thresholds:

1. `>= 0.75`: highly redundant or duplicative; prefer merging.
2. `0.45 - 0.74`: partially overlapping; keep separate files but add boundaries or cross-references.
3. `< 0.45`: independent experiences; keep separate.

If two experiences have conflicting conclusions, first determine:

1. Whether their applicability boundaries differ.
2. Whether their technical versions, platforms, or prerequisites differ.
3. Whether one experience is already outdated.

Do not make a crude either-or choice. Prefer rewriting the conflict as a boundary distinction.

### Step 4: Action Selection

After reading `references/lifecycle-policy.md`, combine similarity, conflict judgment, `quality_score`, and `utility_score` to choose exactly one action for each experience:

1. **Keep**: valid, has clear applicability boundaries, has high active utility, and remains independent from other experiences.
2. **Update**: the topic is still valuable, but evidence, boundaries, steps, keywords, timeliness, or summary need completion.
3. **Downgrade**: the document is acceptable, but its scope is narrow, active utility is low, or timeliness is insufficient; lower `tier` or mark it for cautious use.
4. **Merge**: two or more files are essentially the same problem pattern, method pattern, or evidence chain.
5. **Archive**: still has historical value, but is invalid, outdated, superseded, or unsuitable for active retrieval hits.
6. **Create a normalized primary file**: use only when all existing files are too fragmented and none can naturally serve as the primary file.

### Step 5: Update and Generalized Rewriting

For experiences that require updates, prefer these rewrites:

1. Rewrite the title as a problem pattern, method pattern, or decision rule.
2. Generalize project-specific details and keep them only as evidence or examples.
3. Convert conclusions into actionable steps.
4. Add "Faster Next Time" shortcuts, checks, and warning signals.
5. Complete `tags`, `keywords`, and `problem_patterns`.
6. Complete applicability boundaries, technical versions, verification evidence, and counterexamples.
7. Refresh `quality_score`, and maintain `tier` according to `utility_score`.

When an experience is clearly project-specific, read `references/generalization-guidelines.md` before rewriting it.

`updated_at` must be refreshed (local time). Keep `created_at` and `id` unchanged.

### Step 6: Merge Specification

When merging is required:

1. Choose the file with higher `utility_score`, clearer structure, and more general applicability as the primary file.
2. Merge unique evidence, applicability boundaries, counterexamples, and better steps from the other files into the primary file.
3. Union and de-duplicate `tags`, `keywords`, `problem_patterns`, and `source_sessions` in the merged file.
4. Refresh the primary file's `updated_at` to the current refinement date (local time), then recalculate `quality_score` and update `tier`.
5. Move merged files by default to the same category directory under `experiences/.archived/` (create the corresponding subdirectory first if it does not exist), and add an archive note at the beginning of the body indicating the primary file they were merged into.
6. Preserve primary-secondary relationships in `related_experiences` so the linkage is not lost.

If a new normalized primary file must be created:

1. Read `templates/experience-template.md` first.
2. After `category` is determined, read the corresponding supplemental template.
3. Move all original files by default to the same category directory under `experiences/.archived/` (create the corresponding subdirectory first if it does not exist), and point their `related_experiences` to the new experience file.
4. The new file must follow the unified document structure and frontmatter constraints, and preserve links to the source experience files in `related_experiences`.

### Step 7: Archive Specification

Archiving applies when:

1. The experience is outdated, invalid, or its technical prerequisites no longer hold.
2. It has been superseded by a higher-value, more general, or newer experience.
3. The topic still has historical value but is unsuitable for default retrieval hits.
4. `utility_score` is very low and further optimization is not worthwhile in the near term.

Default archiving method:

1. Move the original file to the same category directory under `experiences/.archived/` (create the corresponding subdirectory first if it does not exist).
2. Point `related_experiences` in frontmatter to the replacement experience file, if any.
3. Update `updated_at` (local time).
4. Add a short note at the beginning of the body explaining the archive reason, such as invalidity, obsolescence, supersession, overly narrow scope, or insufficient active utility.

Do not hard-delete unless an external process explicitly requires it.

## Default Output

At the end of execution, return only a compact summary:

```markdown
task: refine
updated: <n>
merged: <n>
denoised: <n>
conflicts_resolved: <n>
archived: <n>
files:
  - experiences/<path>.md
skipped:
  - experiences/<path>.md: <reason>
notes: <one-sentence summary of this refinement focus>
```

If there are no actual content changes, explicitly return `updated: 0`, `merged: 0`, `denoised: 0`, `conflicts_resolved: 0`, `archived: 0`.
