# Lifecycle Management Policy

The goal is to reduce duplication, improve retrieval hit rate, preserve high-value experiences, and let the experience library evolve dynamically with validity, applicability scope, utility, and timeliness.

## Review Triggers

Review should happen when any of the following occurs:

1. The number of experiences increases significantly, or a `category` grows rapidly in a short period.
2. Multiple retrievals hit duplicate, low-value, or low-quality experiences.
3. `low_quality_hit_count` increases, indicating that experiences did not solve the problem after being hit.
4. An experience has not been hit for a long time, has not been updated for a long time, or depends on a technical version that has changed.
5. The user asks to organize, clean up, archive, or consistently improve general applicability.
6. A new experience conflicts with an old experience in conclusion, boundary, or technical prerequisite.

## Review Order

1. First perform a structural completeness check.
2. Then evaluate validity, applicability scope, utility, and timeliness.
3. Then check duplication and conflicts.
4. Finally decide whether to keep, update, downgrade, merge, archive, or create a normalized primary file.

## Conflict Check

Before writing, check `experiences/index.md` and files related to the candidate topic, focusing on:

1. Whether titles express the same problem pattern.
2. Whether `keywords` overlap heavily.
3. Whether `problem_patterns` are identical or highly similar.
4. Whether the solution methods are essentially the same.
5. Whether the difference is only project, version, or boundary, or the methodology is genuinely different.

If two experiences conflict, do not delete either one hastily. First determine:

1. Whether their applicability boundaries differ.
2. Whether their technical versions, platforms, toolchains, or prerequisites differ.
3. Whether one experience has been proven invalid by later evidence.
4. Whether they can be merged into a decision rule: "use X under prerequisite A, and use Y under prerequisite B".

## Scores and Tiers

`quality_score` evaluates document quality only: expression, structure, evidence, boundaries, retrievability, and signal-to-noise ratio.

`utility_score` evaluates active utility:

`utility_score = validity(25) + applicability scope(25) + utility gain(30) + timeliness(20)`

Maintain `tier` according to `utility_score`:

1. `S`: 85-100, core active experience.
2. `A`: 70-84, high-value active experience.
3. `B`: 50-69, stable experience that can participate in default retrieval.
4. `C`: 30-49, pending optimization or narrow-boundary experience; hit with caution.
5. `D`: 0-29, archive candidate.

Do not derive `tier` directly from `quality_score`. A well-written but outdated experience should be downgraded; a poorly written but valuable experience should be updated first.

## Action Selection

### Keep

Applies when:

1. Validity is clear and the conclusion remains reliable.
2. Applicability scope is clear and can serve at least similar scenarios.
3. Utility gain is clear and can reduce time, risk, or repeated trial and error.
4. Timeliness has no obvious risk.
5. It is not duplicate or conflicting with existing experiences.

Handling requirements:

1. Maintain `quality_score`.
2. Maintain `tier` according to `utility_score`.
3. Add only a small number of keywords, boundaries, or related experiences when necessary.

### Update

Applies when:

1. The topic is still valuable but evidence is insufficient.
2. The conclusion is valid, but steps, boundaries, failure branches, or verification methods are incomplete.
3. The same experience has been reused across projects and should be expressed more generally.
4. Hits are frequent but low-quality hits are also increasing, so false hits need to be reduced.
5. The technical prerequisites still broadly hold but need version, platform, or timeliness notes.

Handling requirements:

1. Add verification evidence, applicability boundaries, counterexamples, and prerequisite signals.
2. Move project-specific content into "Evidence or Examples".
3. Refresh `quality_score`, and maintain `tier` according to reevaluation.

### Downgrade

Applies when:

1. Document quality is acceptable, but applicability scope is very narrow.
2. The experience may still be useful, but timeliness is insufficient or lacks recent verification.
3. Utility gain is limited and it should not be a high-priority hit.
4. The experience has boundary conflicts but has not been confirmed invalid.

Handling requirements:

1. Lower `tier` to `B`, `C`, or `D`.
2. Add a cautious-use boundary note in the body.
3. If later review still cannot prove its value, archive it.

### Merge

Applies when:

1. Two experiences are the same pattern from different projects.
2. One experience focuses on the "problem symptom" and another on the "solution method"; together they are more complete.
3. A new experience is only stronger evidence, a more complete version, or recent verification of an old experience.
4. Multiple experiences have different titles, but their `problem_patterns` and approaches are essentially the same.

Merge principles:

1. Keep the file with higher `utility_score`, clearer structure, and broader applicability as the primary file.
2. Move project-specific content into the "Evidence or Examples" section.
3. Reorganize the primary file's `tags`, `keywords`, `problem_patterns`, `source_sessions`, and `related_experiences` after merging.
4. Recalculate the primary file's `quality_score`, and maintain `tier` according to `utility_score`.
5. By default, move merged files to the same category directory under `experiences/.archived/`, and ensure the index and `related_experiences` have been synchronized.

### Archive

Applies when:

1. The content still has historical value but is no longer suitable as a current default experience.
2. The experience has been confirmed invalid, outdated, or superseded by a higher-quality experience.
3. The technical version has changed, and the old experience is useful only as background or migration reference.
4. `utility_score` is very low and further optimization is not worthwhile in the near term.
5. The experience is highly project-specific, cannot be transferred reliably, and has no benefit as an active experience.

Handling requirements:

1. Do not hard-delete.
2. The archive note must state the reason: invalid, outdated, superseded, overly narrow in scope, or insufficient in utility.
3. If a replacement experience exists, point to it in `related_experiences`.

### Create a Normalized Primary File

Applies when:

1. Multiple fragmented files collectively point to one high-value pattern.
2. No existing file is suitable as the primary file.
3. Merging can form a more general, reliable, and executable experience.

Handling requirements:

1. The new primary file must satisfy the unified template and frontmatter constraints.
2. Archive the original fragmented experiences by default, and point them to the new primary file.
3. Write the new primary file's `quality_score` and `tier` according to reevaluation.

### Remove from the Active Library

Applies when:

1. The content is purely duplicate and completely covered by another experience.
2. The content is clearly misleading, and removing it does not affect the source linkage.
3. The file has no substantive content, only a log-like record, and no preservation value.

Handle removal the same way as archiving. Do not hard-delete.
