# Systematic Experience Evaluation Rubric

This rubric applies to the refinement, review, and lifecycle decisions of existing engineering experiences.

## Score Responsibilities

1. `quality_score`: evaluates whether the experience document itself is clear, executable, and retrievable.
2. `utility_score`: evaluates whether the experience is still worth participating in active default retrieval and recommendation.
3. `tier`: maintained according to `utility_score`; it is not directly determined by `quality_score`.

## `quality_score` Document Quality Score

Total score: 100, scored across six dimensions:

| Dimension | Max | Evaluation Question |
|------|:---:|----------|
| Reusable expression | 20 | Is it abstracted into a problem pattern, method pattern, or decision rule instead of a project log? |
| Executability | 20 | Does it provide directly followable steps, checklists, failure branches, or verification methods? |
| Evidence sufficiency | 15 | Does it explain scenario, signals, root cause, verification, turning points, or counterexamples? |
| Boundary clarity | 15 | Does it state applicable scenarios, non-applicable scenarios, versions, or prerequisite constraints? |
| Retrievability | 15 | Do the title, keywords, problem patterns, and category support future hits? |
| Signal-to-noise ratio | 15 | Is it concise enough to keep irrelevant background from burying the main conclusion? |

Score interpretation:

1. `85-100`: high document quality; candidate for a core experience or rule.
2. `70-84`: acceptable document; minor strengthening is enough for stable retention.
3. `50-69`: the topic may be valuable but needs rewriting, boundary completion, or evidence completion.
4. `30-49`: poor writing; invest in repair only when the topic is important.
5. `<30`: not recommended to remain in the active experience library in its current form.

## Systematic Evaluation Dimensions

In addition to `quality_score`, the review must evaluate the following four dimensions for lifecycle actions and `utility_score`.

### Experience Validity

Determine whether the experience is still correct, reliable, and adoptable:

1. It has clear successful verification, passing tests, user confirmation, or reproducible evidence.
2. Its key conclusion has not been overturned by later experiences, low-quality hits, or technical changes.
3. No missing prerequisites, failure scenarios, or counterexamples are severe enough to affect adoption.

Suggested scoring:

1. `25`: evidence is clear and the conclusion remains reliable.
2. `15`: the general direction is credible, but recent verification or boundary evidence is missing.
3. `5`: there is conflict, misleading content, or obvious obsolescence risk.
4. `0`: confirmed invalid or likely to mislead subsequent tasks.

### Applicability Scope

Determine how much scope the experience covers and whether it should be downgraded to a narrow-boundary experience:

1. Whether it applies only to a single project, single version, or one-off directory structure.
2. Whether it can transfer to similar projects, similar technology stacks, or general engineering scenarios.
3. Whether applicable and non-applicable boundaries are clearly marked.

Suggested scoring:

1. `25`: reusable across projects or general scenarios, with clear boundaries.
2. `15`: reusable within similar technology stacks, but boundaries need strengthening.
3. `5`: highly project-specific and suitable only as scenario-specific reference.
4. `0`: scope cannot be judged, or the conclusion is strongly bound to the scenario.

### Utility Gain

Determine whether the experience brings perceptible efficiency, quality, or risk reduction:

1. It can reduce the cost of diagnosing problems, implementing, verifying, rolling back, or communicating.
2. It can avoid high-risk mistakes, hidden defects, misjudged paths, or repeated trial and error.
3. It can form a checklist, decision rule, warning signal, or stable operation path.

Suggested scoring:

1. `30`: significantly reduces time or risk and is a high-value experience.
2. `20`: has clear benefit and improves efficiency for common tasks.
3. `10`: limited benefit, but usable as auxiliary reference.
4. `0`: benefit is unclear and close to an ordinary record or common sense.

### Timeliness

Determine whether the experience needs review, downgrade, or archive:

1. Whether `updated_at` has not been updated for a long time.
2. Whether `last_hit_at` has long been empty or is far in the past.
3. Whether the framework, API, platform, or tool version the experience depends on has changed.
4. Whether a newer and better experience has superseded the old approach.

Suggested scoring:

1. `20`: recently verified or hit, and technical prerequisites still hold.
2. `12`: no obvious obsolescence, but recent evidence is missing.
3. `5`: may be outdated and needs review or version boundary completion.
4. `0`: outdated or superseded by a new experience.

## `utility_score` Calculation

`utility_score = validity(25) + applicability scope(25) + utility gain(30) + timeliness(20)`

`utility_score` does not replace `quality_score`:

1. High `quality_score` but low `utility_score`: the document is well written, but may be outdated, narrow in scope, or low in benefit; downgrade or archive it.
2. Low `quality_score` but high `utility_score`: the topic is very valuable; prioritize rewriting, evidence completion, and boundary completion.
3. Both are high: keep as a core active experience.
4. Both are low: archive candidate.

## `tier` Mapping

1. `S`: `85-100`, core active experience.
2. `A`: `70-84`, high-value active experience.
3. `B`: `50-69`, stable experience that can participate in default retrieval.
4. `C`: `30-49`, pending optimization or narrow-boundary experience; hit with caution.
5. `D`: `0-29`, archive candidate.

## Correction Strategies

### Low Validity

1. Add verification evidence, failure counterexamples, or version prerequisites.
2. When conflicts come from different prerequisites or contexts, rewrite the conclusions as applicability boundary differences.
3. If confirmed invalid, archive it and mark the replacement experience.

### Low Applicability Scope

1. Remove project-name-dominated titles.
2. Extract the problem pattern, method pattern, or decision criterion.
3. Move project details into "Evidence or Examples".
4. Explicitly write "applies only to" and "does not apply to".

### Low Utility Gain

1. Add checks and warning signals that improve efficiency in subsequent tasks.
2. Rewrite ordinary process records into actions that save time or reduce risk.
3. If benefit remains unclear, downgrade or archive.

### Low Timeliness

1. Add technical version, tool version, and platform prerequisites.
2. Re-verify with recent evidence.
3. If superseded by a better experience, archive it and point to the replacement.
