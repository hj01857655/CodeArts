---
name: experience-collect
description: >-
  Extracts high-value engineering experiences from session trace records and
  writes new experience documents. Use when a `session_trace_path` is provided,
  when session trace records need to be turned into reusable engineering
  experience documents, or when only new experience files should be created
  without modifying existing experiences.
---

# Experience Collection

This skill is responsible only for: **extracting high-value engineering experiences from the provided session trace record and writing new experience documents**.

> If no session trace file is specified, use the current session history as the source.

## Responsibility Boundaries

This skill does:

1. Decide whether the provided trace is worth turning into reusable experience.
2. Extract zero to N high-value experiences from the trace.
3. Write the experiences into `experiences/`.
4. If `experiences/` does not exist, create `experiences/` and its subdirectories first, then continue with the remaining steps.

This skill does not:

1. Collect session trace records.
2. Retrieve experiences.
3. Update hit counts or usage metrics.
4. Merge, update, or archive existing experiences.
5. Maintain index files.
6. Rebuild the entire experience repository at scale.

## Progressive Loading

By default, read only this file. Read supporting files only when the corresponding step requires them:

1. When deciding whether to collect experiences, read `references/collection-triggers-low-threshold.md`.
2. When a candidate experience is overly project-specific and needs generalized rewriting, read `references/generalization-guidelines.md`.
3. When starting to write an experience document, read `templates/experience-template.md`.
4. After `category` is determined, read only one corresponding supplemental template:
   - `coding-pattern` -> `templates/coding-pattern.md`
   - `testing` -> `templates/testing.md`
   - `architecture` -> `templates/architecture.md`
   - `build-env` -> `templates/build-env.md`
   - `debugging` -> `templates/debugging.md`
   - `workflow` -> `templates/workflow.md`
   - `agent-ops` -> `templates/agent-ops.md`

Do not load any other files unless the current step explicitly requires them.

## Input Assumptions

The caller usually provides:

1. `project_root`
2. `experiences_dir`
3. `session_id`
4. `session_trace_path`
5. `limits.max_new`

Key principles:

1. **Work only from the provided trace**: do not fetch additional conversations, shell history, or extra context on your own.
2. **Keep collection decisions stable**: do not lower or raise the collection threshold because the input source changes.
3. **Only add, never modify existing experience documents**: creating new experiences is allowed; rewriting existing experience bodies is not.
4. **Prefer omission over noise**: a single run may produce `0` experiences.

## Collection Workflow

### Step 0: Outcome Threshold Check

First determine whether the task meets the minimum success criteria. Enter trigger evaluation only if all of the following are true:

1. The core objective of the task has been achieved.
2. There is verifiable evidence for the result, such as passing tests, a successful build, correct output, user confirmation, or closure of the key issue.

Skip collection immediately if any of the following is true:

1. The task was canceled, abandoned, or left unfinished.
2. The issue remains unresolved.
3. The result failed required verification.
4. The result was explicitly rejected or still requires substantial rework.
5. The trace shows many repeated attempts without forming an effective closure.

### Step 1: Trigger Evaluation

Read `references/collection-triggers-low-threshold.md` and decide whether to enter experience extraction and document writing.

Rules:

1. If any strong trigger is matched, proceed with experience extraction and document writing.
2. If two or more weak triggers are matched, proceed with experience extraction and document writing.
3. If no trigger is matched, end this collection run without creating any files.

### Step 2: Extract Experience Material

Extract only the parts of `session_trace_path` that are directly relevant to experience extraction:

1. Task objective, constraints, and completion criteria.
2. Key attempted approaches, turning points, and reasons for abandoning paths.
3. Key commands, error messages, and verification evidence.
4. Why external materials were consulted, which conclusions were adopted, and which were rejected.
5. The method that actually worked, its decision basis, and its applicability boundaries.

Do not mechanically copy large trace segments. The goal is to reconstruct why the method worked.

### Step 3: Form Candidate Experiences

Split the trace into zero to N candidate experiences. Each candidate must answer:

1. In what scenario will this be encountered again?
2. What is the key problem, essential constraint, or decision criterion?
3. What action, checklist, or warning signal can be reused next time?

If the same trace contains two or more types of experience, such as a debugging method and a workflow improvement, split them into separate experiences by type.

### Step 4: Value Filtering and Generalization

Keep a candidate experience only if all of the following are true:

1. It has clear reuse value.
2. It can help future work locate, decide, implement, or verify faster.
3. It contains non-obvious information rather than merely recording what was done.
4. It can be abstracted into a project-independent method, pattern, checklist, or decision rule.

Filter out by default:

1. One-off operation records.
2. Common-sense conclusions.
3. Implementation logs tightly coupled to the current project directory, naming, or scripts.
4. Hollow summaries that describe only results without the reasoning behind them.

When an experience is clearly project-specific, read `references/generalization-guidelines.md` before rewriting it.

### Step 5: Quality Assessment

Read `references/quality-rubric.md` and score each candidate experience across six dimensions, for a total score of 100:

1. Reusable expression
2. Executability
3. Evidence sufficiency
4. Boundary clarity
5. Retrievability
6. Signal-to-noise ratio

This step only assigns `quality_score`. Do not calculate `utility_score`, perform lifecycle downgrades, or make archival decisions during experience collection.

Initialize the `tier` of a new experience from `quality_score`:

1. `S`: `85-100`
2. `A`: `70-84`
3. `B`: `50-69`
4. `C`: `30-49`
5. `D`: `0-29`

This `tier` is only the initial level at creation time; later experience refinement may recompute or maintain `tier` based on `utility_score`.

### Step 6: Write Experience Documents

Before writing a document, read `templates/experience-template.md`. After `category` is determined, read one corresponding supplemental template.

The document path is fixed as:

`experiences/<category>/YYYY-MM-DD-<slug>.md`

Where:

1. `<category>` must be one of: `coding-pattern`, `testing`, `architecture`, `build-env`, `debugging`, `workflow`, `agent-ops`
2. `<slug>` uses lowercase English words and hyphens
3. The date in the file name is fixed to the first creation date and must not change later

The document frontmatter must contain at least the following fields:

1. `id`
2. `title`
3. `category`
4. `nature`
5. `created_at`
6. `updated_at`
7. `tags`
8. `keywords`
9. `problem_patterns`
10. `source_sessions`
11. `project`
12. `severity`
13. `quality_score`
14. `hit_count`
15. `last_hit_at`
16. `low_quality_hit_count`
17. `tier`
18. `related_experiences`

## Scale and Boundaries

1. Do not create more than `limits.max_new` new experiences in a single run; the default maximum is `5`.
2. If the trace contains many candidate experiences, keep only the highest-value few.
3. If a file name conflicts with an existing file, choose a new name; never overwrite existing files.
4. This skill may finish with `0` new experiences.

## Default Output

At the end of execution, return only a compact summary:

```markdown
task: collect
added: <n>
files:
  - experiences/<category>/<file>.md
notes: <one-sentence explanation of whether collection happened and why>
```

If no files were added, explicitly write `added: 0`.
