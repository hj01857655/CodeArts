# Development Workflow Supplemental Template

Applies to `workflow` experiences. Covers experiences produced at the development workflow level, including task decomposition, batch operation strategy, turning documentation into code, experience management processes, and collaboration patterns.

## Writing Focus

1. State which signal triggered this workflow experience instead of vaguely saying "after the task ended".
2. Reconstruct from a real event sequence, not a hypothetical case.
3. When possible, provide ROI judgment, such as time saved, rework reduced, or missed checks avoided.
4. Also write the anti-pattern, explaining when this approach should not be used.

## Recommended Additions

Beyond the base template, prioritize strengthening:

1. `Scenario`: the context and scale of the workflow, such as individual/team or small task/large batch.
2. `Key Signals`: the pain point or bottleneck that triggered workflow optimization.
3. `Approach`: recommended workflow steps, checkpoints, cadence control, and batching strategy.
4. `Faster Next Time`: how to reduce summarizing too early, summarizing too late, or repeated work.

## Keyword Priorities

1. Workflow stage names: requirements analysis, design, implementation, verification, release
2. Batch operation strategies: batching, parallelism, validation points, rollback
3. Knowledge management concepts: deduplication, update-first, lifecycle, archiving, migration

## Common Anti-Patterns

1. Writing workflow experience as abstract principles without executable steps.
2. Writing only "when it should be done" without "when it should not be done".
3. Failing to return to the actual task history, causing distorted conclusions.
4. Mixing technical implementation details into workflow experience.
