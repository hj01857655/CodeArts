# Experience Template

## File Naming Convention

Experience file names must start with the creation date, using this format:

```text
YYYY-MM-DD-<short-slug>.md
```

Examples:

1. `2026-03-17-cross-platform-encoding-strategy.md`
2. `2026-03-15-mock-static-method-pattern.md`
3. `2026-02-28-gradle-dependency-conflict-resolution.md`

Rules:

1. The date is the first creation date of the experience; later updates must not change the date in the file name.
2. `slug` uses lowercase English words and hyphens.
3. Store the file under the corresponding `experiences/<category>/` directory.

## Experience Frontmatter

All active experience documents must start with the following frontmatter. Key fields must not be omitted or renamed:

```yaml
---
id: YYYY-MM-DD-<short-slug>
title: Experience title
category: coding-pattern | testing | architecture | build-env | debugging | workflow | agent-ops
nature: pitfall | technique | decision | methodology
created_at: YYYY-MM-DDTHH:mm:ss
updated_at: YYYY-MM-DDTHH:mm:ss
tags: [3-5 tags]
keywords: [5-10 keywords]
problem_patterns: [1-3 patterns]
source_sessions: [session-trace-path-or-unknown]
project: project-name-or-unknown
severity: high | medium | low
quality_score: 0
hit_count: 0
last_hit_at: null
low_quality_hit_count: 0
tier: S | A | B | C | D
related_experiences: []
---
```

Field constraints:

1. `title`: Prefer abstraction to the level of a pattern, method, or decision rule; do not let project names dominate.
2. `category`: Must be selected from the seven fixed enum values.
3. `nature`: Describes the nature of the experience and is orthogonal to `category`.
4. `tags` / `keywords` / `problem_patterns`: Used for indexing and retrieval; they must be filled in.
5. `created_at`: First creation timestamp (local time).
6. `updated_at`: Most recent rewrite or correction timestamp (local time).

## Experience Body

```markdown
# Title

## Scenario
[Describe the task background and trigger conditions]

## Key Signals
[Describe the earliest visible errors, symptoms, and reasoning basis]

## Essence
[Describe the root cause, key constraint, or method that truly worked]

## Approach
1. [Executable step]
2. [Executable step]

## Faster Next Time
- [Reusable shortcut, checklist, or warning signal]

## Applicability Boundaries
- [Scenarios where this applies]
- [Scenarios where this does not apply]

## Evidence or Examples
- [Preserve project-specific facts, commands, error messages, and project-local examples]
```

## Writing Requirements

1. Prefer a title that names a pattern or method rather than a project name.
2. Put project-specific information in `Evidence or Examples`; do not put it in the main conclusion.
3. `Approach` must be executable and avoid vague statements.
4. `Faster Next Time` must answer how to reduce trial and error and how to detect the issue earlier.
5. If the experience is clearly project-specific, consult `../references/generalization-guidelines.md` before writing the document.

## Supplemental Templates on Demand

After completing the base template, read only one supplemental template when `category` is clear:

1. `coding-pattern` -> `coding-pattern.md`
2. `testing` -> `testing.md`
3. `architecture` -> `architecture.md`
4. `build-env` -> `build-env.md`
5. `debugging` -> `debugging.md`
6. `workflow` -> `workflow.md`
7. `agent-ops` -> `agent-ops.md`

These supplemental templates only strengthen category-specific focus areas; they do not replace this base template.
