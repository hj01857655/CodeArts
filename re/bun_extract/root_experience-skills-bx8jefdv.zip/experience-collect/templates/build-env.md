# Build and Environment Supplemental Template

Applies to `build-env` experiences. Covers experiences produced at the build and environment level, including build tools, CI/CD, dependency management, platform differences, environment configuration, and shell differences.

## Writing Focus

1. Provide complete commands, configuration snippets, or operation sequences that can be reused directly.
2. Clarify platform differences (Windows/Linux/macOS), shell differences (PowerShell/Bash/Cmd), and version differences.
3. If the primary solution may fail, add alternatives or fallback paths.
4. Prefer extracting a general troubleshooting sequence instead of recording only that one command succeeded.

## Recommended Additions

Beyond the base template, prioritize strengthening:

1. `Key Signals`: failed commands, error excerpts, version information, or environment variables.
2. `Approach`: full commands, key parameters, configuration file locations, or environment variable settings.
3. `Faster Next Time`: which diagnostic command to run first, which configuration to inspect first, and how to quickly confirm environment state.
4. `Applicability Boundaries`: which OS, shell, and tool versions the experience applies to.

## Keyword Priorities

1. Build tool name and version: Maven, Gradle, npm, pip, cargo, and similar tools
2. Key commands, parameters, and configuration file names
3. Platform and shell names, environment variable names
4. CI/CD platforms: GitHub Actions, Jenkins, GitLab CI, and similar platforms

## Common Anti-Patterns

1. Writing only half of a command, forcing future reuse to guess parameters.
2. Ignoring platform differences, making the experience valid only in the original environment.
3. Recording only the final command without the diagnostic sequence or troubleshooting entry point.
4. Mixing coding-level API issues into environment issues.
