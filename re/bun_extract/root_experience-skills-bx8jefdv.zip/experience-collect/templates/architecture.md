# Architecture Design Supplemental Template

Applies to `architecture` experiences. Covers experiences produced at the architecture design level, including solution selection, technical trade-offs, design pattern selection, module decomposition, and system evolution.

## Writing Focus

1. Describe at least two alternatives instead of recording only the final choice.
2. Clarify key trade-offs, such as performance, complexity, consistency, evolvability, and cost.
3. Preserve quantitative data when available; when no data exists, explain the judgment basis.
4. State which condition changes should trigger reevaluation.

## Recommended Additions

Beyond the base template, prioritize strengthening:

1. `Scenario`: why this is a decision requiring trade-off rather than a default choice.
2. `Essence`: the core tension behind the decision.
3. `Approach`: the final selection, adoption approach, and reasons rejected alternatives were abandoned.
4. `Applicability Boundaries`: thresholds or conditions that should trigger reevaluation.

## Keyword Priorities

1. Architecture pattern names, design strategy names, design pattern names
2. Key middleware, components, and protocols
3. Performance or capacity metrics, such as QPS, latency, throughput, and cost
4. Quality attributes: maintainability, testability, scalability, observability

## Common Anti-Patterns

1. Recording implementation details as architecture decisions; coding-level techniques should be classified as `coding-pattern`.
2. Writing only "what was chosen" without explaining "why other options were not chosen".
3. Omitting boundary conditions entirely, causing the experience to become misleading.
4. Mixing testing-level design decisions into system architecture; decisions purely at the testing level should be classified as `testing`.
