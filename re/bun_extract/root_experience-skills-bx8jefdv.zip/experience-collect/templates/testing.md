# Test Engineering Supplemental Template

Applies to `testing` experiences. Covers experiences produced during testing activities, including test strategy design, test framework usage, mocking patterns, coverage strategy, test isolation, and test generation.

## Writing Focus

1. State the test objective clearly, including what behavior is verified and which boundaries are covered; do not describe only test actions.
2. Explain key constraints or version differences in the test framework or tool.
3. If a mock, stub, or spy is involved, explain lifecycle management and isolation strategy.
4. For batch testing scenarios, extract common strategies instead of listing items one by one.

## Recommended Additions

Beyond the base template, prioritize strengthening:

1. `Key Signals`: assertion messages from failed tests, symptoms of insufficient isolation, or framework errors.
2. `Essence`: why this test strategy works, or why the original strategy failed.
3. `Approach`: test design matrix, mock lifecycle pattern, or verification checklist.
4. `Faster Next Time`: test templates, reusable fixtures/helpers, or automated validation points.

## Keyword Priorities

1. Test framework name and version: JUnit5, Mockito, pytest, Jest, and similar tools
2. Testing techniques: MockedStatic, ArgumentCaptor, parameterized tests, Fixture
3. Testing strategies: boundary testing, equivalence classes, state-machine testing, concurrency testing, isolation strategy

## Common Anti-Patterns

1. Writing only "the tests passed" without the decision basis of the test design.
2. Mixing test strategy with coding techniques; coding techniques should be split into `coding-pattern`.
3. Classifying test framework environment configuration issues as testing experience; they should be classified as `build-env`.
