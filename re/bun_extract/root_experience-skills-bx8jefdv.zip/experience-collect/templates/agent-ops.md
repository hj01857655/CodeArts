# Agent Operations Supplemental Template

Applies to `agent-ops` experiences. Covers experiences produced at the AI Agent operations level in an IDE, including operation strategy, permission management, context management, skill coordination, and environment adaptation.

## Writing Focus

1. Explain the specific limitation or adaptation requirement the Agent encountered, such as permissions, paths, shell, or encoding.
2. Provide command sequences or judgment logic that the Agent can execute directly, not only abstract strategy.
3. Clarify behavioral differences across runtime environments, such as main Agent, Subagent, and read-only mode.
4. Mark whether the experience targets a specific Agent platform, such as Cursor, or a general Agent pattern.

## Recommended Additions

Beyond the base template, prioritize strengthening:

1. `Key Signals`: Agent execution errors, permission denials, or symptoms of lost context.
2. `Essence`: key differences between the Agent runtime environment and the human-driven working environment.
3. `Approach`: environment-probing command sequences, fallback strategies, or context retention methods.
4. `Applicability Boundaries`: which Agent platforms, operating systems, and IDE versions the experience applies to.

## Keyword Priorities

1. Agent platform names: CodeAgent, OpenCode, Cursor, and similar Agent platforms
2. Runtime environment: shell type, permission model, file system
3. Operation modes: main Agent, Subagent, read-only, background
4. Adaptation techniques: path probing, encoding handling, timeout control, context pruning

## Common Anti-Patterns

1. Classifying general build or environment issues as Agent adaptation; they should be classified as `build-env`.
2. Writing only "the Agent should be careful" without concrete judgment logic and execution steps.
3. Ignoring differences between Agent runtime modes, such as main, subagent, and read-only.
