# Coding Pattern Supplemental Template

Applies to `coding-pattern` experiences. Covers experiences produced during code implementation, including language features, API usage, type systems, counterintuitive behavior, and coding techniques.

## Writing Focus

1. Explain the language mechanism or API contract involved in the pattern or pitfall; do not describe only surface symptoms.
2. When possible, present the difference with a minimal "incorrect usage vs correct usage" comparison.
3. Mark whether the behavior is guaranteed by the language specification or is an implementation detail that may change in the future.
4. Add how to detect it earlier during compilation, static analysis, or code review.

## Recommended Additions

Beyond the base template, prioritize strengthening:

1. `Key Signals`: compilation errors, runtime exceptions, counterintuitive return values, or silent failure symptoms.
2. `Essence`: language specification clauses, type-system rules, or API contract details.
3. `Approach`: minimal code examples for correct usage.
4. `Faster Next Time`: static analysis rules, IDE checks, or code review checkpoints.

## Keyword Priorities

1. Language name, version number, API name, method signature
2. Exception name, error code, compilation-error keywords
3. Root-cause mechanisms: type erasure, autoboxing, overload resolution, implicit conversion, lifecycle, ownership

## Common Anti-Patterns

1. Writing only "be careful with this API" without stating which specific behavior is counterintuitive.
2. Omitting minimal reproduction code, making it impossible for readers to judge whether the experience applies to their scenario.
3. Mixing coding-level issues with build or environment issues.
