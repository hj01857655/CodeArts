# Debugging and Diagnosis Supplemental Template

Applies to `debugging` experiences. Focuses on non-trivial fault localization methodology, root-cause analysis strategy, and reusable troubleshooting paths rather than simple records of "what was fixed".

## Writing Focus

1. Keep only the effective path from symptom to root cause; do not record every trial-and-error step.
2. Clarify the earliest trustworthy signal and which clues once misled the judgment.
3. Emphasize cross-layer localization: where the symptom appeared versus where the root cause actually was.
4. State how the fix was verified, avoiding fixes that only address surface symptoms.
5. Extract transferable troubleshooting strategies, such as what to check first and what to check next, rather than only recording one debugging process.

## Recommended Additions

Beyond the base template, prioritize strengthening:

1. `Key Signals`: first exception, logs, erroneous behavior, reproduction conditions, or misleading clues.
2. `Essence`: the root-cause chain as a complete causal chain, not only the final conclusion.
3. `Approach`: troubleshooting decision tree or priority sequence, including what to rule out first and what to locate next.
4. `Faster Next Time`: check order for locating the issue earlier, shortest troubleshooting path, or diagnostic command sequence.

## Keyword Priorities

1. Exception names, error codes, log keywords
2. Problematic APIs, methods, and configuration items
3. Root-cause mechanisms: state contamination, type ambiguity, lazy loading, race conditions, cache invalidation, resource leaks

## Common Anti-Patterns

1. Writing only "where it was fixed" without "why it happened", which lacks methodological value.
2. Recording many ineffective attempts and burying the truly critical path.
3. Omitting verification methods, making the experience hard to reuse.
4. Classifying known language/API pitfalls as debugging experience; known pitfalls should be classified as `coding-pattern`.
