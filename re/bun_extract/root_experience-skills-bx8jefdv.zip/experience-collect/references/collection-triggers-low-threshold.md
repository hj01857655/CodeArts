# Experience Collection Trigger Checklist

The goal of this file is to preserve more reviewable material first: if reusable signals exist, collect them first, then control noise during quality assessment. A collected item does not need to be complete, mature, or strongly generalizable every time.

## Prerequisite: Minimum Reviewable Closure Threshold

The following triggers take effect once the task has reached a minimum reviewable closure. This is not the same as complete delivery; it only requires an effective conclusion that can be reviewed and learned from.

**Minimum reviewable closure threshold**:

1. The task has a clear intermediate result, such as issue localization, solution validation, a runnable prototype, confirmation of a failure reason, or user confirmation that the direction is feasible.
2. At least one type of evidence supports the conclusion, such as command output, error messages, test results, compilation results, log excerpts, code diffs, user feedback, or an explainable reasoning chain.

**Cases that may still enter trigger evaluation**:

1. The final feature has not been fully released, but the key path, root cause, or effective approach has been confirmed.
2. Tests or builds have not all passed, but the failure reason is clear and the experience does not depend on complete delivery.
3. The solution was adjusted later, but the reason for adjustment itself has reuse value.
4. Only one subtask was completed, but that subtask produced transferable decision criteria, check steps, or a debugging path.

**Cases that should skip collection immediately**:

1. The task was canceled or abandoned midway, and no reusable judgment was formed.
2. There are only guesses, without evidence, trace records, or an explainable basis.
3. The key process was not actually executed and was only assumed to have succeeded.
4. The result was rejected by the user, and no reusable failure reason or correction conclusion was left.
5. The Agent entered a loop or exhausted resources without producing effective debugging signals.

## Strong Triggers

If any item is satisfied, collection should happen by default:

1. Non-one-shot success: the task went through multiple attempts, direction changes, rollbacks, or remedies, and formed a more efficient or reliable path.
2. Explicit failure lesson: although the task was not fully successful, a path was confirmed infeasible, an assumption was proven wrong, or a prerequisite was found missing.
3. Difficult issue fix or localization: the key cause of a bug, environment issue, configuration issue, dependency issue, or platform behavior was identified.
4. Knowledge discovery: a new usage, limitation, or counterintuitive behavior of a library, framework, tool, command, or platform was discovered.
5. Skill optimization: while executing a skill, the original skill description was found inaccurate, incomplete, based on an unsuitable threshold, or inconsistent with the real trace.
6. Key decision: a reusable trade-off was made among multiple feasible options, or the trade-off criteria were clarified.
7. Batch task: common problems, strategies, checklists, or reusable templates emerged across similar operations.
8. Complex coordination: the problem crossed boundaries between multiple modules, tools, environments, roles, or problem contexts.
9. Efficiency discovery: a method was found that significantly reduces repeated work, shortens localization time, or lowers error probability.

## Weak Triggers

Any single item suggests collection; two or more items should trigger collection by default:

1. External materials, history, existing experiences, or project documentation were consulted before judgment could be completed.
2. An unfamiliar API, CLI, platform capability, configuration item, or workflow was used for the first time or re-understood.
3. Earlier warning indicators were extracted from failure signals.
4. A faster, more stable, or easier-to-verify execution path was found.
5. This conclusion can help future work avoid rework, misjudgment, repeated search, or ineffective attempts.
6. The user corrected, supplemented, or confirmed a judgment that is valuable for later work.
7. The task exposed improvement points in skills, rules, templates, indexes, or process documents.
8. The task produced directly reusable commands, checklists, judgment sequences, or prompt fragments.
9. Although small, the content fills a missing detail in a high-frequency scenario.

## Natural Timing

In addition to after task completion, collection may happen at these points:

1. After an error fix: the root cause has just been confirmed, and details are most complete.
2. After a milestone: one subtask has just closed.
3. After a pattern forms: similar problems or similar solutions have appeared repeatedly.
4. Before context switching: the current project, module, or problem domain is about to be left.
5. At a skill revision point: a skill instruction has just been found to need correction.
6. At a validation-stage review point: a threshold, workflow, or template has been found to affect validation progress.

## Cases Not to Collect

Skip by default if any of the following applies:

1. Purely one-off trivial operations with no transferable judgment.
2. Common-sense conclusions with no new reasoning basis, evidence, or execution detail.
3. Records that only say "what was done" without explaining "why this was done" or "how to be faster next time".
4. Tool-output noise without executable conclusions.
5. Content that only expresses emotion, preference, or process logs and cannot be converted into checks, rules, or methods.

## Minimum Actions After Triggering

Once collection is chosen, complete at least these actions:

1. Obtain the conversation content and relevant tool outputs from the session trace.
2. Answer "what is the key point" and "how can this be faster next time".
3. If the experience is still immature, explicitly state applicability boundaries, evidence strength, and points needing validation in the body.
