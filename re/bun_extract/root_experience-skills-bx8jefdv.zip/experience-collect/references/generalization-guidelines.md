# Experience Generalization Rewriting Guidelines

Some experiences in the current repository are already too tightly coupled to specific projects. When writing new experiences, prefer generalized expression.

## Rewriting Goal

Rewrite "a one-time success case inside a project" into "a reusable method, pattern, checklist, or decision criterion for the future".

## Four-Step Rewriting Method

### 1. Identify Non-Transferable Content

Prioritize marking the following project-specific information:

1. Repository names, business names, and module names
2. Temporary directory structures from a specific task
3. One-off script paths
4. Temporary workarounds or ad hoc fixes used only in the current task
5. Terms that are valid only within this project's naming system

### 2. Extract the Stable Core

Rewrite the content into one of the following:

1. Problem pattern: what this class of problem essentially is.
2. Method pattern: what to do first and next when this class of problem appears.
3. Decision rule: when to choose A and not B.
4. Warning signal: which phenomena should immediately raise concern.
5. Checklist: what to check before starting, before submitting, or before regression.

### 3. Preserve Evidence Without Letting It Dominate the Title

Recommended structure:

1. Write the title as an abstract pattern.
2. Put generalized conclusions in the first half of the body.
3. Use `Evidence or Examples` in the second half to carry project facts.

## Rewriting Examples

### From Project Record to General Experience

1. Bad: `FooService tests failed in project abc because of cache ordering`
2. Good: `Static caches break test isolation and should be explicitly reset before test cases`

1. Bad: `Fixed script path errors under PowerShell in a repository`
2. Good: `Windows shell path separators and escaping differences can cause scripts to be misparsed`

## Self-Check Questions

After writing, ask yourself at least:

1. Does this experience still hold after the project name is removed?
2. Can someone from another project directly reuse the method?
3. Is this experience describing a fact, or transferring a method?
4. If only three sentences could be kept, which three are most worth keeping?
