# Experience Collection Trigger Checklist

Collect only when the experience has reuse value. Evaluate triggers first, then enter the formal collection workflow.

## Prerequisite: Outcome Threshold

The following triggers take effect only after the task has met the minimum success criteria. Tasks that do not meet the outcome threshold must not enter trigger evaluation.

**Outcome threshold**:

1. The core objective of the task has been achieved, such as feature completion, bug fix, or issue resolution.
2. There is verifiable success evidence, such as passing tests, a successful build, or correct output.

**Cases that should skip collection immediately**:

1. The task was canceled or abandoned midway.
2. The issue remains unresolved and debugging is still ongoing.
3. The code failed compilation or tests.
4. The key process was not actually executed and was only assumed to have succeeded.
5. The result was rejected by the user or requires substantial rework.
6. The Agent entered a loop or exhausted resources without achieving the goal.

## Strong Triggers

If any item is satisfied, collection should happen by default:

1. Non-one-shot success: the task went through multiple attempts, direction changes, rollbacks, or remedies, and was eventually completed successfully.
2. Difficult issue fix: a long-standing, hard-to-locate, hidden-root-cause, or high-impact issue was resolved.
3. Knowledge discovery: a new usage or counterintuitive behavior of a library, framework, tool, command, or platform was discovered.
4. Skill optimization: while executing a skill, the original skill description was found inaccurate, incomplete, or inconsistent with the real trace.
5. Key decision: a reusable trade-off was made among multiple feasible options.
6. Batch task: common problems, shared strategies, or reusable checklists emerged across similar operations.
7. Complex coordination: the problem crossed boundaries between multiple modules, tools, environments, or roles.

## Weak Triggers

Collection is recommended when multiple items are satisfied:

1. External materials were consulted before the task could be completed.
2. An unfamiliar API, CLI, or platform capability was used for the first time.
3. Earlier warning indicators were extracted from failure signals.
4. An execution path with substantially higher efficiency was found.
5. This conclusion can help future work avoid obvious rework.

## Natural Timing

In addition to after task completion, collection may happen at these points:

1. After an error fix: the root cause has just been confirmed, and details are most complete.
2. After a milestone: one subtask has just closed.
3. After a pattern forms: similar problems or similar solutions have appeared repeatedly.
4. Before context switching: the current project, module, or problem domain is about to be left.
5. At a skill revision point: a skill instruction has just been found to need correction.

## Cases Not to Collect

Skip by default if any of the following applies:

1. One-off trivial operations with no reuse value.
2. Common-sense conclusions with no new reasoning basis.
3. Records that only say "what was done" without explaining "why this was done".
4. Content that strongly depends on the current project directory, naming, scripts, or temporary environment and is nearly impossible to transfer.
5. Tool-output noise without executable conclusions.

## Minimum Actions After Triggering

Once collection is chosen, complete at least these actions:

1. Obtain the conversation content and relevant tool outputs from the session trace.
2. Answer "what is the key point" and "how can this be faster next time".
3. Decide whether to add a new experience, update an existing one, or merge into an existing experience.
