# Experience Quality Assessment Rubric

This rubric applies to scoring `quality_score` when adding experiences from session traces and mapping that score to the initial `tier`. It evaluates only whether the experience document itself is clear, executable, and retrievable; it does not handle lifecycle judgments such as `utility_score`, downgrading, or archiving.

## Six-Dimension Scoring

The total score is 100. `quality_score` should be assigned according to the table below:

| Dimension | Max | Assessment Question |
|-----------|:---:|---------------------|
| Reusable expression | 20 | Is it abstracted into a problem pattern, method pattern, or decision rule rather than a project log? |
| Executability | 20 | Does it provide directly executable steps, checklists, failure branches, or verification methods? |
| Evidence sufficiency | 15 | Does it explain the scenario, signals, root cause, verification, turning points, or counterexamples? |
| Boundary clarity | 15 | Does it state applicable scenarios, non-applicable scenarios, versions, or prerequisite constraints? |
| Retrievability | 15 | Do the title, keywords, problem patterns, and category help future retrieval? |
| Signal-to-noise ratio | 15 | Is it concise enough to avoid burying the main conclusion in irrelevant background? |

## Score Interpretation

1. `85-100`: High document quality; can be considered a core experience or rule candidate.
2. `70-84`: Qualified document; stable enough to retain with minor strengthening.
3. `50-69`: The topic may be valuable, but the document needs rewriting, clearer boundaries, or stronger evidence.
4. `30-49`: Low writing quality; invest in repair only if the topic is important.
5. `<30`: Not recommended to retain in the currently active experience repository in its current form.

## `tier` Mapping

When a new experience is written, initialize `tier` from `quality_score`:

1. `S`: `85-100`
2. `A`: `70-84`
3. `B`: `50-69`
4. `C`: `30-49`
5. `D`: `0-29`

This mapping is used only for the initial tier of a new experience; later systematic refinement still maintains `tier` based on `utility_score`.

## Low-Score Correction Strategies

### Low Reusable Expression

1. Remove titles dominated by project names.
2. Extract the problem pattern, method pattern, or decision criterion.
3. Move project details to `Evidence or Examples`.

### Low Executability

1. Rewrite conclusions as steps.
2. Add checks for `Faster Next Time` ("how can this be faster next time").
3. Add prerequisite signals, failure branches, and verification methods.

### Low Evidence Sufficiency

1. Add scenario, signals, root cause, turning points, and verification results.
2. Mark which information comes from the current trace and which is inferred.
3. Add counterexamples or failed paths when necessary.

### Low Boundary Clarity

1. Clearly state applicable and non-applicable scenarios.
2. Add version, platform, toolchain, or prerequisite constraints.
3. Rewrite one-off project conditions as assessable applicability boundaries.

### Low Retrievability

1. Rewrite the title so it reflects the essence of the problem.
2. Complete `keywords`.
3. Complete `problem_patterns`.

### Low Signal-to-Noise Ratio

1. Remove irrelevant background.
2. Merge repeated statements.
3. Keep only evidence that supports the conclusion.

## Writing Decision Recommendations

1. High score: add directly to the active experience repository.
2. Medium score: revise first, then add to the experience repository.
3. Low score but good topic: rewrite first, then decide whether to retain.
4. Low score and no reuse value: do not turn it into an experience, or leave it for later cleanup during refinement.
